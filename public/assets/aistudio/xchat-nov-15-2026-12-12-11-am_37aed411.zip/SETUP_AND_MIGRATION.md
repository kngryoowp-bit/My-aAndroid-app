# XChat Version 2.0 — Panduan Setup, Arsitektur & Migrasi

Dokumen ini menjelaskan arsitektur XChat V2.0, alur migrasi database Room non-destruktif (`v7 -> v8`), aturan keamanan Firebase Firestore, konfigurasi WebRTC & izin Android, serta perintah pengujian terverifikasi.

---

## 1. Ringkasan Arsitektur XChat V2.0

- **UI & Tema**: Jetpack Compose Material 3 dengan **Obsidian Cinematic Glassmorphism** (`#07080B`, `#13161D`, `#C4C9D4`, `#F5F7FA`) dan latar belakang **Animated Moving Marble** gratis untuk seluruh pengguna, dilengkapi *Mode Performa Rendah*.
- **Lokalisasi**: Default **Bahasa Indonesia (`id`)**, mendukung `en`, `ms`, dan `ja` melalui `AppLocalization`.
- **Database Lokal**: Room Database v8 (`AppDatabase`) dengan 33 entitas dan `MIGRATION_7_8` (tanpa `.fallbackToDestructiveMigration()`).
- **Cloud Realtime**: Firebase Authentication + Cloud Firestore (`FirestoreCloudRepository`) untuk sinkronisasi profil, server, kategori kanal, pesan, DM, game multiplayer, panggilan WebRTC, pembatasan akses, laporan, dan role admin RBAC.
- **Audio & Video Real-time**:
  - **WebRTC (`WebRtcCallManager`)**: Panggilan 1:1 DM (Suara/Video) dan Server Voice Room dengan `JavaAudioDeviceModule` (AEC/NS/AGC), STUN/TURN ICE server, signaling SDP/ICE via Firestore, serta *Voice Diagnostics* (uji loopback mikrofon & speaker).
  - **Media3 ExoPlayer (`XChatAudioService`)**: Pemutar musik persisten (mini player + layar penuh) dengan manajemen playlist, kontrol privasi *Sedang Mendengarkan*, serta 9 efek suara UI (`SoundEffectsEngine`).

---

## 2. Migrasi Database Room (`7 -> 8`)

`AppDatabase` naik dari `version = 7` ke `version = 8` melalui `AppDatabase.MIGRATION_7_8`:

- **Data Pengguna Lama Aman**: Seluruh baris pada `users`, `servers`, `channels`, `messages`, `direct_messages`, `server_members`, `server_roles`, dan tabel v7 lainnya dipertahankan utuh menggunakan `ALTER TABLE ... ADD COLUMN` dengan nilai default aman.
- **Kolom & Tabel Baru V2.0**:
  - Kolom V2 pada `users`: `level`, `xp`, `followersCount`, `followingCount`, `unlockedBadgesProgressJson`, `customWallpaperUri`, `wallpaperMode` (default `MARBLE`), `wallpaperGradientCsv`, `wallpaperBlur`, `wallpaperOpacity`, `wallpaperBrightness`, `wallpaperTintHex`, `lowPerfMode`, `soundEnabled`, `soundVolume`, `mutedSoundCategoriesCsv`, `notifPrefsJson`, `listening*`, `isLocked`, `lock*`, `adminRole`, `accentColorHex`.
  - Kolom V2 pada `servers`, `channels`, `messages`, dan `direct_messages`: `isVanished`, `categoryId`, `attachmentDurationMs`, `forwardedFrom*`, `location*`, `stickerId`, `gameInviteMatchId`, `mentionTargetsCsv`, `replyTo*`, `isEdited`, `isDeleted`, `reactions`.
  - Tabel baru: `channel_categories`, `user_follows`, `user_game_apps`, `sticker_packs`, `stickers`, `gif_favorites`, `playlists`, `audio_tracks`, `game_matches`, `game_ratings`, `tournaments`, `redeem_codes`, `user_restrictions`, `reports`, `call_sessions`.

---

## 3. Firebase Firestore & Security Rules

Aturan keamanan pada `firestore.rules` menerapkan prinsip *default-deny* (`allow read, write: if false;` di root):

- **RBAC Admin (`admins/{uid}`)**: Akses panel admin/moderator/owner dikontrol dokumen `admins/{uid}` dengan peran `SUPPORT`, `MODERATOR`, `ADMIN`, `SUPER_ADMIN`, atau `OWNER`. Pengguna biasa tidak dapat menaikkan hak akses sendiri.
- **Kunci Akses XChat (`restrictions/{id}`)**: Hanya pembatasan in-app XChat (tidak pernah mengunci OS Android). Pengguna yang dibatasi dapat membaca statusnya dan mengajukan banding (`appealStatus = 'PENDING'`), serta pembatasan berakhir otomatis saat `expiresAt` terlewati.
- **Batas Video <= 7 Detik**: `isValidVideoDuration` menolak pesan kanal maupun DM dengan `attachmentDurationMs > 7000`.
- **Isolasi DM & Panggilan**: Hanya `participants` yang dapat membaca atau memperbarui dokumen `direct_messages`, `friendships`, `calls`, dan `game_matches`.

### Menjalankan Pengujian Rules Secara Lokal

```bash
firebase emulators:exec --project demo-no-project --only auth,firestore "node --test firestore.test.js"
```

---

## 4. Konfigurasi Secret & Produksi

- Jangan pernah menyimpan kunci API rahasia langsung di kode sumber atau `local.properties`.
- Gunakan **Secrets panel di AI Studio** (terhubung lewat Secrets Gradle Plugin & `.env.example`) untuk menambahkan kunci produksi jika diperlukan (misalnya `GEMINI_API_KEY` atau kredensial TURN server privat / Tenor produksi).
- Untuk produksi skala besar, ganti kredensial TURN relay publik di `WebRtcCallManager.iceServers()` dengan server TURN khusus Anda melalui variabel konfigurasi aman.

---

## 5. Izin Android (`AndroidManifest.xml`)

- `INTERNET`, `ACCESS_NETWORK_STATE`, `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PLAYBACK` (pemutar musik latar)
- `RECORD_AUDIO`, `MODIFY_AUDIO_SETTINGS` (panggilan suara WebRTC & uji loopback mikrofon)
- `CAMERA` (panggilan video WebRTC & pratinjau kamera)
- `ACCESS_FINE_LOCATION`, `ACCESS_COARSE_LOCATION` (hanya diminta saat pengguna memilih *Bagikan Lokasi*)
- `POST_NOTIFICATIONS` (notifikasi pesan & panggilan masuk)

---

## 6. Pengujian Unit & Build APK

Jalankan seluruh tes unit JVM & Robolectric (termasuk tes aturan 4 mini-game, validasi durasi video 7 detik, dan tes migrasi non-destruktif Room `7 -> 8`):

```bash
firebase emulators:exec --project demo-no-project --only auth,firestore "gradle :app:testDebugUnitTest"
```

Build APK Debug:

```bash
gradle assembleDebug
```

Output APK terletak di: `app/build/outputs/apk/debug/app-debug.apk`.
