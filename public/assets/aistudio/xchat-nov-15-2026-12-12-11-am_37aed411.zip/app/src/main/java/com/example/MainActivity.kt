package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.credentials.CredentialManager
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainTab
import com.example.ui.XChatViewModel
import com.example.ui.screens.*
import com.example.ui.theme.AppLocalization
import com.example.ui.theme.LocalStrings
import com.example.ui.theme.MyApplicationTheme
import com.example.utils.GoogleSignInHelper
import com.example.utils.IpDetectionResult
import com.example.utils.IpLanguageDetector
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val auth = remember { Firebase.auth }
      var firebaseUser by remember { mutableStateOf<FirebaseUser?>(auth.currentUser) }
      val credentialManager = remember { CredentialManager.create(this@MainActivity) }
      val scope = rememberCoroutineScope()

      var ipInfo by remember { mutableStateOf<IpDetectionResult?>(null) }
      var unauthManualLang by remember { mutableStateOf<String?>(null) }
      var unauthScreen by remember { mutableStateOf("landing") } // "landing", "login", "register"
      var pendingUsername by remember { mutableStateOf<String?>(null) }
      var pendingDisplayName by remember { mutableStateOf<String?>(null) }

      DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
          firebaseUser = firebaseAuth.currentUser
        }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
      }

      LaunchedEffect(Unit) {
        ipInfo = IpLanguageDetector.detectIpAndLanguage()
      }

      LaunchedEffect(Unit) {
        GoogleSignInHelper.attemptAutoSignIn(
          context = this@MainActivity,
          credentialManager = credentialManager,
          onAuthSuccess = {
            firebaseUser = auth.currentUser
          },
          onUnauthenticated = { },
          scope = scope
        )
      }

      val activeUser = firebaseUser
      if (activeUser == null) {
        val activeLang = when {
          unauthManualLang == "AUTO" -> ipInfo?.recommendedLang ?: "en"
          unauthManualLang != null -> unauthManualLang!!
          else -> "en"
        }
        val strings = AppLocalization.forCode(activeLang)

        CompositionLocalProvider(LocalStrings provides strings) {
          MyApplicationTheme(
            themeId = "obsidian_marble",
            customGradientCsv = null,
            customAccentHex = null,
            fontKey = "SERIF"
          ) {
            BackHandler(enabled = unauthScreen != "landing") {
              unauthScreen = "landing"
            }
            androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize()) {
              com.example.ui.components.XChatCinematicBackground(
                wallpaperMode = "MARBLE",
                lowPerfMode = false
              )
              Surface(
                modifier = Modifier.fillMaxSize(),
                color = androidx.compose.ui.graphics.Color.Transparent
              ) {
              when (unauthScreen) {
                "login" -> LoginScreen(
                  onBack = { unauthScreen = "landing" },
                  onNavigateToRegister = { unauthScreen = "register" },
                  onGoogleSignInSuccess = {
                    firebaseUser = auth.currentUser
                  }
                )
                "register" -> RegisterScreen(
                  onBack = { unauthScreen = "landing" },
                  onNavigateToLogin = { unauthScreen = "login" },
                  onBeforeGoogleSignUp = { prefUser, prefDisp ->
                    pendingUsername = prefUser.takeIf { it.isNotBlank() }
                    pendingDisplayName = prefDisp.takeIf { it.isNotBlank() }
                  },
                  onGoogleSignUpSuccess = { prefUser, prefDisp ->
                    pendingUsername = prefUser.takeIf { it.isNotBlank() }
                    pendingDisplayName = prefDisp.takeIf { it.isNotBlank() }
                    firebaseUser = auth.currentUser
                  }
                )
                else -> LandingScreen(
                  activeLang = activeLang,
                  ipInfo = ipInfo,
                  onSelectLanguage = { code -> unauthManualLang = code },
                  onNavigateToLogin = { unauthScreen = "login" },
                  onNavigateToRegister = { unauthScreen = "register" },
                  onGoogleSignInSuccess = {
                    firebaseUser = auth.currentUser
                  }
                )
              }
            }
            }
          }
        }
      } else {
        key(activeUser.uid) {
          val authenticatedViewModel: XChatViewModel = viewModel(key = activeUser.uid)

          LaunchedEffect(activeUser.uid) {
            authenticatedViewModel.bindAuthenticatedUser(
              preferredUsername = pendingUsername,
              preferredDisplayName = pendingDisplayName,
              detectedIp = ipInfo
            )
            pendingUsername = null
            pendingDisplayName = null
            val navType = intent?.getStringExtra(com.example.utils.XChatNotificationHelper.EXTRA_NAV_TYPE)
            val navTarget = intent?.getStringExtra(com.example.utils.XChatNotificationHelper.EXTRA_NAV_TARGET_ID)
            authenticatedViewModel.handleNotificationLaunchIntent(navType, navTarget)
          }

          val currentUser by authenticatedViewModel.currentUser.collectAsState()
          val activeLang by authenticatedViewModel.activeLanguageCode.collectAsState()
          val activeTab by authenticatedViewModel.activeTab.collectAsState()
          val voiceState by authenticatedViewModel.voiceState.collectAsState()

          val strings = AppLocalization.forCode(activeLang)

          CompositionLocalProvider(LocalStrings provides strings) {
            MyApplicationTheme(
              themeId = currentUser?.appThemeId ?: "obsidian_marble",
              customGradientCsv = currentUser?.appThemeGradientCsv,
              customAccentHex = currentUser?.accentColorHex,
              fontKey = currentUser?.appFontKey ?: "SERIF"
            ) {
              BackHandler(enabled = true) {
                when {
                  voiceState.isInVoice -> authenticatedViewModel.leaveVoice()
                  activeTab != MainTab.HOME -> authenticatedViewModel.setActiveTab(MainTab.HOME)
                  else -> finish()
                }
              }

              Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
              ) {
                MainScreen(
                  viewModel = authenticatedViewModel,
                  onGoogleSignOut = {
                    pendingUsername = null
                    pendingDisplayName = null
                    authenticatedViewModel.logout()
                    GoogleSignInHelper.signOut(credentialManager, scope) {
                      unauthScreen = "landing"
                    }
                  }
                )
              }
            }
          }
        }
      }
    }
  }
}
