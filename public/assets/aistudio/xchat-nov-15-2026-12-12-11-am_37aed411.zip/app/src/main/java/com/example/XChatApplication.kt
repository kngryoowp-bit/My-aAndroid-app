package com.example

import android.app.Application
import android.os.Build
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.example.utils.CloudMediaHelper
import com.example.utils.XChatNotificationHelper
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class XChatApplication : Application(), ImageLoaderFactory {
  override fun onCreate() {
    super.onCreate()
    CloudMediaHelper.init(this)
    XChatNotificationHelper.ensureChannels(this)
    com.example.utils.SoundEffectsEngine.init(this)
  }

  override fun newImageLoader(): ImageLoader {
    val coilHttpClient = OkHttpClient.Builder()
      .followRedirects(true)
      .followSslRedirects(true)
      .connectTimeout(25, TimeUnit.SECONDS)
      .readTimeout(60, TimeUnit.SECONDS)
      .addInterceptor { chain ->
        val req = chain.request().newBuilder()
          .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) XChat/2.0")
          .build()
        chain.proceed(req)
      }
      .build()

    return ImageLoader.Builder(this)
      .okHttpClient(coilHttpClient)
      .allowHardware(false)
      .components {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
          add(ImageDecoderDecoder.Factory())
        } else {
          add(GifDecoder.Factory())
        }
      }
      .memoryCache {
        MemoryCache.Builder(this)
          .maxSizePercent(0.25)
          .build()
      }
      .diskCache {
        DiskCache.Builder()
          .directory(cacheDir.resolve("image_cache"))
          .maxSizeBytes(128L * 1024L * 1024L)
          .build()
      }
      .respectCacheHeaders(false)
      .crossfade(false)
      .build()
  }
}
