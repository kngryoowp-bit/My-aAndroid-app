package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
  entities = [
    UserEntity::class,
    ServerEntity::class,
    ChannelCategoryEntity::class,
    ServerMemberEntity::class,
    ServerRoleEntity::class,
    ChannelEntity::class,
    MessageEntity::class,
    ForumPostEntity::class,
    ForumReplyEntity::class,
    DirectMessageEntity::class,
    FriendEntity::class,
    UserFollowEntity::class,
    UserGameAppEntity::class,
    StickerPackEntity::class,
    StickerEntity::class,
    GifFavoriteEntity::class,
    PlaylistEntity::class,
    AudioTrackEntity::class,
    GameMatchEntity::class,
    GameRatingEntity::class,
    TournamentEntity::class,
    RedeemCodeEntity::class,
    UserRestrictionEntity::class,
    ReportEntity::class,
    CallSessionEntity::class,
    NotificationEntity::class,
    MarketplaceItemEntity::class,
    UserInventoryEntity::class,
    QuestEntity::class,
    PaymentRequestEntity::class,
    AuditLogEntity::class,
    ProfileVisitorEntity::class,
    SavedProfileThemeEntity::class
  ],
  version = 9,
  exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
  abstract fun userDao(): UserDao
  abstract fun serverDao(): ServerDao
  abstract fun channelCategoryDao(): ChannelCategoryDao
  abstract fun serverMemberDao(): ServerMemberDao
  abstract fun serverRoleDao(): ServerRoleDao
  abstract fun channelDao(): ChannelDao
  abstract fun messageDao(): MessageDao
  abstract fun forumPostDao(): ForumPostDao
  abstract fun forumReplyDao(): ForumReplyDao
  abstract fun directMessageDao(): DirectMessageDao
  abstract fun friendDao(): FriendDao
  abstract fun userFollowDao(): UserFollowDao
  abstract fun userGameAppDao(): UserGameAppDao
  abstract fun stickerDao(): StickerDao
  abstract fun gifFavoriteDao(): GifFavoriteDao
  abstract fun playlistDao(): PlaylistDao
  abstract fun gameDao(): GameDao
  abstract fun adminModerationDao(): AdminModerationDao
  abstract fun callSessionDao(): CallSessionDao
  abstract fun notificationDao(): NotificationDao
  abstract fun marketplaceDao(): MarketplaceDao
  abstract fun questDao(): QuestDao
  abstract fun paymentRequestDao(): PaymentRequestDao
  abstract fun auditLogDao(): AuditLogDao
  abstract fun profileVisitorDao(): ProfileVisitorDao
  abstract fun savedProfileThemeDao(): SavedProfileThemeDao

  companion object {
    @Volatile
    private var INSTANCE: AppDatabase? = null

    val MIGRATION_3_4 = object : Migration(3, 4) {
      override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE messages ADD COLUMN senderFrameId TEXT")
        db.execSQL("ALTER TABLE messages ADD COLUMN senderBadges TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE messages ADD COLUMN attachmentName TEXT")
        db.execSQL("ALTER TABLE messages ADD COLUMN attachmentMimeType TEXT")
        db.execSQL("ALTER TABLE messages ADD COLUMN attachmentSizeBytes INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE direct_messages ADD COLUMN attachmentName TEXT")
        db.execSQL("ALTER TABLE direct_messages ADD COLUMN attachmentMimeType TEXT")
        db.execSQL("ALTER TABLE direct_messages ADD COLUMN attachmentSizeBytes INTEGER NOT NULL DEFAULT 0")
      }
    }

    val MIGRATION_4_5 = object : Migration(4, 5) {
      override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE users ADD COLUMN boostBalance INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE users ADD COLUMN displayNameEffect TEXT NOT NULL DEFAULT 'GRADIENT'")
        db.execSQL("ALTER TABLE servers ADD COLUMN boostCount INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE server_members ADD COLUMN roleColor INTEGER NOT NULL DEFAULT 4287929252")
        db.execSQL("ALTER TABLE messages ADD COLUMN senderDisplayEffect TEXT NOT NULL DEFAULT 'GRADIENT'")
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `server_roles` (
            `id` TEXT NOT NULL,
            `serverId` TEXT NOT NULL,
            `name` TEXT NOT NULL,
            `colorHex` INTEGER NOT NULL DEFAULT 4287323126,
            `permissionsCsv` TEXT NOT NULL DEFAULT 'SEND_MESSAGES',
            `position` INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(`id`)
          )
          """.trimIndent()
        )
      }
    }

    val MIGRATION_5_6 = object : Migration(5, 6) {
      override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE users ADD COLUMN presenceStatus TEXT NOT NULL DEFAULT 'ONLINE'")
        db.execSQL("ALTER TABLE users ADD COLUMN statusTag TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE users ADD COLUMN lastSeenAt INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE users ADD COLUMN typingChannelId TEXT")
        db.execSQL("ALTER TABLE users ADD COLUMN typingUpdatedAt INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE servers ADD COLUMN serverTagIcon TEXT NOT NULL DEFAULT 'shield'")
        db.execSQL("ALTER TABLE server_members ADD COLUMN roleIconUri TEXT")
        db.execSQL("ALTER TABLE server_members ADD COLUMN roleChromaColorsCsv TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE server_roles ADD COLUMN iconUri TEXT")
        db.execSQL("ALTER TABLE server_roles ADD COLUMN chromaKeyColorsCsv TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE messages ADD COLUMN senderServerTag TEXT")
        db.execSQL("ALTER TABLE messages ADD COLUMN senderServerTagIcon TEXT")
        db.execSQL("ALTER TABLE messages ADD COLUMN senderRoleIconUri TEXT")
        db.execSQL("ALTER TABLE messages ADD COLUMN senderRoleChromaCsv TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE messages ADD COLUMN senderRoleColor INTEGER NOT NULL DEFAULT 4287929252")
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `forum_posts` (
            `id` TEXT NOT NULL,
            `channelId` TEXT NOT NULL,
            `authorId` TEXT NOT NULL,
            `authorName` TEXT NOT NULL,
            `authorAvatarUri` TEXT,
            `title` TEXT NOT NULL,
            `content` TEXT NOT NULL DEFAULT '',
            `imageUri` TEXT,
            `tagLabel` TEXT NOT NULL DEFAULT 'Meta',
            `tagEmoji` TEXT NOT NULL DEFAULT '❗',
            `isPinned` INTEGER NOT NULL DEFAULT 0,
            `replyCount` INTEGER NOT NULL DEFAULT 0,
            `reactionCount` INTEGER NOT NULL DEFAULT 0,
            `reactionEmoji` TEXT NOT NULL DEFAULT '🔥',
            `createdAt` INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(`id`)
          )
          """.trimIndent()
        )
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `forum_replies` (
            `id` TEXT NOT NULL,
            `postId` TEXT NOT NULL,
            `channelId` TEXT NOT NULL,
            `authorId` TEXT NOT NULL,
            `authorName` TEXT NOT NULL,
            `authorAvatarUri` TEXT,
            `content` TEXT NOT NULL,
            `createdAt` INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(`id`)
          )
          """.trimIndent()
        )
      }
    }

    val MIGRATION_6_7 = object : Migration(6, 7) {
      override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE users ADD COLUMN connectionsJson TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE users ADD COLUMN activeAppName TEXT")
        db.execSQL("ALTER TABLE users ADD COLUMN activeAppPackage TEXT")
        db.execSQL("ALTER TABLE users ADD COLUMN activeAppStartedAt INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE messages ADD COLUMN readByCsv TEXT NOT NULL DEFAULT ''")
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `saved_profile_themes` (
            `id` TEXT NOT NULL,
            `userId` TEXT NOT NULL,
            `name` TEXT NOT NULL,
            `displayNameFont` TEXT NOT NULL DEFAULT 'SERIF',
            `displayNameColorsCsv` TEXT NOT NULL DEFAULT '0xFFF2F3F5,0xFFC084FC',
            `displayNameEffect` TEXT NOT NULL DEFAULT 'GRADIENT',
            `profileBgColorsCsv` TEXT NOT NULL DEFAULT '0xFF2B2D31,0xFF3B2E5A,0xFF1E1F22',
            `profileColor` INTEGER NOT NULL DEFAULT 4287323126,
            `equippedEffect` TEXT,
            `chatBubbleBgCsv` TEXT NOT NULL DEFAULT '0xFF7C3AED,0xFF9333EA',
            `chatBubbleImageUri` TEXT,
            `appThemeId` TEXT NOT NULL DEFAULT 'discord_purple',
            `appThemeGradientCsv` TEXT NOT NULL DEFAULT '',
            `appFontKey` TEXT NOT NULL DEFAULT 'SERIF',
            `isEquipped` INTEGER NOT NULL DEFAULT 0,
            `createdAt` INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(`id`)
          )
          """.trimIndent()
        )
      }
    }

    val MIGRATION_7_8 = object : Migration(7, 8) {
      override fun migrate(db: SupportSQLiteDatabase) {
        // Users V2.0 additions
        db.execSQL("ALTER TABLE users ADD COLUMN level INTEGER NOT NULL DEFAULT 1")
        db.execSQL("ALTER TABLE users ADD COLUMN xp INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE users ADD COLUMN followersCount INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE users ADD COLUMN followingCount INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE users ADD COLUMN unlockedBadgesProgressJson TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE users ADD COLUMN customWallpaperUri TEXT")
        db.execSQL("ALTER TABLE users ADD COLUMN wallpaperMode TEXT NOT NULL DEFAULT 'MARBLE'")
        db.execSQL("ALTER TABLE users ADD COLUMN wallpaperGradientCsv TEXT NOT NULL DEFAULT '0xFF07080B,0xFF111318,0xFF1E222A'")
        db.execSQL("ALTER TABLE users ADD COLUMN wallpaperBlur REAL NOT NULL DEFAULT 0.0")
        db.execSQL("ALTER TABLE users ADD COLUMN wallpaperOpacity REAL NOT NULL DEFAULT 0.85")
        db.execSQL("ALTER TABLE users ADD COLUMN wallpaperBrightness REAL NOT NULL DEFAULT 0.9")
        db.execSQL("ALTER TABLE users ADD COLUMN wallpaperTintHex INTEGER NOT NULL DEFAULT 4278650891")
        db.execSQL("ALTER TABLE users ADD COLUMN lowPerfMode INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE users ADD COLUMN soundEnabled INTEGER NOT NULL DEFAULT 1")
        db.execSQL("ALTER TABLE users ADD COLUMN soundVolume REAL NOT NULL DEFAULT 0.75")
        db.execSQL("ALTER TABLE users ADD COLUMN mutedSoundCategoriesCsv TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE users ADD COLUMN notifPrefsJson TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE users ADD COLUMN listeningTitle TEXT")
        db.execSQL("ALTER TABLE users ADD COLUMN listeningArtist TEXT")
        db.execSQL("ALTER TABLE users ADD COLUMN listeningCoverUri TEXT")
        db.execSQL("ALTER TABLE users ADD COLUMN listeningSourceUrl TEXT")
        db.execSQL("ALTER TABLE users ADD COLUMN listeningDurationMs INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE users ADD COLUMN listeningPositionMs INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE users ADD COLUMN listeningIsPlaying INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE users ADD COLUMN listeningPrivacy TEXT NOT NULL DEFAULT 'PUBLIC'")
        db.execSQL("ALTER TABLE users ADD COLUMN isLocked INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE users ADD COLUMN lockReason TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE users ADD COLUMN lockMessage TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE users ADD COLUMN lockStartedAt INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE users ADD COLUMN lockExpiresAt INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE users ADD COLUMN adminRole TEXT NOT NULL DEFAULT 'NONE'")
        db.execSQL("ALTER TABLE users ADD COLUMN accentColorHex INTEGER NOT NULL DEFAULT 4291086804")

        // Servers & Channels V2.0 additions
        db.execSQL("ALTER TABLE servers ADD COLUMN isVanished INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE channels ADD COLUMN categoryId TEXT NOT NULL DEFAULT ''")

        // Messages V2.0 additions
        db.execSQL("ALTER TABLE messages ADD COLUMN attachmentDurationMs INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE messages ADD COLUMN forwardedFromId TEXT")
        db.execSQL("ALTER TABLE messages ADD COLUMN forwardedFromName TEXT")
        db.execSQL("ALTER TABLE messages ADD COLUMN locationLat REAL")
        db.execSQL("ALTER TABLE messages ADD COLUMN locationLng REAL")
        db.execSQL("ALTER TABLE messages ADD COLUMN locationLabel TEXT")
        db.execSQL("ALTER TABLE messages ADD COLUMN locationLiveUntil INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE messages ADD COLUMN stickerId TEXT")
        db.execSQL("ALTER TABLE messages ADD COLUMN gameInviteMatchId TEXT")
        db.execSQL("ALTER TABLE messages ADD COLUMN mentionTargetsCsv TEXT NOT NULL DEFAULT ''")

        // Direct Messages V2.0 additions
        db.execSQL("ALTER TABLE direct_messages ADD COLUMN attachmentDurationMs INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE direct_messages ADD COLUMN replyToMessageId TEXT")
        db.execSQL("ALTER TABLE direct_messages ADD COLUMN replyToSnippet TEXT")
        db.execSQL("ALTER TABLE direct_messages ADD COLUMN isEdited INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE direct_messages ADD COLUMN isDeleted INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE direct_messages ADD COLUMN reactions TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE direct_messages ADD COLUMN forwardedFromId TEXT")
        db.execSQL("ALTER TABLE direct_messages ADD COLUMN forwardedFromName TEXT")
        db.execSQL("ALTER TABLE direct_messages ADD COLUMN locationLat REAL")
        db.execSQL("ALTER TABLE direct_messages ADD COLUMN locationLng REAL")
        db.execSQL("ALTER TABLE direct_messages ADD COLUMN locationLabel TEXT")
        db.execSQL("ALTER TABLE direct_messages ADD COLUMN locationLiveUntil INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE direct_messages ADD COLUMN stickerId TEXT")
        db.execSQL("ALTER TABLE direct_messages ADD COLUMN gameInviteMatchId TEXT")

        // New V2.0 Tables
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `channel_categories` (
            `id` TEXT NOT NULL,
            `serverId` TEXT NOT NULL,
            `name` TEXT NOT NULL,
            `orderIndex` INTEGER NOT NULL DEFAULT 0,
            `isCollapsed` INTEGER NOT NULL DEFAULT 0,
            `createdAt` INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(`id`)
          )
          """.trimIndent()
        )
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `user_follows` (
            `id` TEXT NOT NULL,
            `followerId` TEXT NOT NULL,
            `targetUserId` TEXT NOT NULL,
            `createdAt` INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(`id`)
          )
          """.trimIndent()
        )
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `user_game_apps` (
            `id` TEXT NOT NULL,
            `userId` TEXT NOT NULL,
            `name` TEXT NOT NULL,
            `iconKey` TEXT NOT NULL DEFAULT 'gamepad',
            `iconUri` TEXT,
            `description` TEXT NOT NULL DEFAULT '',
            `activityStatus` TEXT NOT NULL DEFAULT '',
            `appLink` TEXT NOT NULL DEFAULT '',
            `category` TEXT NOT NULL DEFAULT 'Game',
            `orderIndex` INTEGER NOT NULL DEFAULT 0,
            `createdAt` INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(`id`)
          )
          """.trimIndent()
        )
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `sticker_packs` (
            `id` TEXT NOT NULL,
            `creatorId` TEXT NOT NULL,
            `creatorName` TEXT NOT NULL,
            `name` TEXT NOT NULL,
            `description` TEXT NOT NULL DEFAULT '',
            `coverUri` TEXT,
            `isShared` INTEGER NOT NULL DEFAULT 1,
            `createdAt` INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(`id`)
          )
          """.trimIndent()
        )
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `stickers` (
            `id` TEXT NOT NULL,
            `packId` TEXT NOT NULL,
            `creatorId` TEXT NOT NULL,
            `name` TEXT NOT NULL,
            `imageUri` TEXT NOT NULL,
            `overlayText` TEXT NOT NULL DEFAULT '',
            `textColorHex` INTEGER NOT NULL DEFAULT 4294967295,
            `outlineColorHex` INTEGER NOT NULL DEFAULT 4278190080,
            `hasGlow` INTEGER NOT NULL DEFAULT 0,
            `hasShadow` INTEGER NOT NULL DEFAULT 1,
            `isFavorite` INTEGER NOT NULL DEFAULT 0,
            `createdAt` INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(`id`)
          )
          """.trimIndent()
        )
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `gif_favorites` (
            `id` TEXT NOT NULL,
            `userId` TEXT NOT NULL,
            `gifUrl` TEXT NOT NULL,
            `previewUrl` TEXT NOT NULL,
            `title` TEXT NOT NULL DEFAULT '',
            `category` TEXT NOT NULL DEFAULT 'Trending',
            `isRecent` INTEGER NOT NULL DEFAULT 0,
            `isFavorite` INTEGER NOT NULL DEFAULT 0,
            `updatedAt` INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(`id`)
          )
          """.trimIndent()
        )
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `playlists` (
            `id` TEXT NOT NULL,
            `userId` TEXT NOT NULL,
            `name` TEXT NOT NULL,
            `coverUri` TEXT,
            `createdAt` INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(`id`)
          )
          """.trimIndent()
        )
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `audio_tracks` (
            `id` TEXT NOT NULL,
            `playlistId` TEXT NOT NULL,
            `userId` TEXT NOT NULL,
            `title` TEXT NOT NULL,
            `artist` TEXT NOT NULL,
            `coverUri` TEXT,
            `sourceUri` TEXT NOT NULL,
            `sourceType` TEXT NOT NULL DEFAULT 'LOCAL',
            `durationMs` INTEGER NOT NULL DEFAULT 0,
            `orderIndex` INTEGER NOT NULL DEFAULT 0,
            `createdAt` INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(`id`)
          )
          """.trimIndent()
        )
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `game_matches` (
            `id` TEXT NOT NULL,
            `gameType` TEXT NOT NULL,
            `mode` TEXT NOT NULL DEFAULT 'CLASSIC',
            `tournamentId` TEXT,
            `channelOrConvId` TEXT NOT NULL,
            `challengerId` TEXT NOT NULL,
            `challengerName` TEXT NOT NULL,
            `opponentId` TEXT NOT NULL,
            `opponentName` TEXT NOT NULL,
            `status` TEXT NOT NULL DEFAULT 'INVITED',
            `turnUserId` TEXT NOT NULL,
            `boardStateJson` TEXT NOT NULL,
            `movesJson` TEXT NOT NULL DEFAULT '[]',
            `winnerId` TEXT,
            `whiteTimeMs` INTEGER NOT NULL DEFAULT 300000,
            `blackTimeMs` INTEGER NOT NULL DEFAULT 300000,
            `lastMoveAt` INTEGER NOT NULL DEFAULT 0,
            `drawOfferedBy` TEXT,
            `createdAt` INTEGER NOT NULL DEFAULT 0,
            `updatedAt` INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(`id`)
          )
          """.trimIndent()
        )
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `game_ratings` (
            `id` TEXT NOT NULL,
            `userId` TEXT NOT NULL,
            `username` TEXT NOT NULL,
            `displayName` TEXT NOT NULL,
            `gameType` TEXT NOT NULL,
            `elo` INTEGER NOT NULL DEFAULT 1000,
            `wins` INTEGER NOT NULL DEFAULT 0,
            `losses` INTEGER NOT NULL DEFAULT 0,
            `draws` INTEGER NOT NULL DEFAULT 0,
            `updatedAt` INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(`id`)
          )
          """.trimIndent()
        )
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `tournaments` (
            `id` TEXT NOT NULL,
            `name` TEXT NOT NULL,
            `gameType` TEXT NOT NULL,
            `creatorId` TEXT NOT NULL,
            `status` TEXT NOT NULL DEFAULT 'OPEN',
            `participantsCsv` TEXT NOT NULL DEFAULT '',
            `bracketJson` TEXT NOT NULL DEFAULT '[]',
            `winnerId` TEXT,
            `createdAt` INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(`id`)
          )
          """.trimIndent()
        )
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `redeem_codes` (
            `id` TEXT NOT NULL,
            `code` TEXT NOT NULL,
            `rewardXit` INTEGER NOT NULL DEFAULT 200,
            `rewardBoosts` INTEGER NOT NULL DEFAULT 0,
            `rewardBadgeId` TEXT,
            `maxUses` INTEGER NOT NULL DEFAULT 100,
            `usedCount` INTEGER NOT NULL DEFAULT 0,
            `usedByCsv` TEXT NOT NULL DEFAULT '',
            `expiresAt` INTEGER NOT NULL DEFAULT 0,
            `isActive` INTEGER NOT NULL DEFAULT 1,
            `createdAt` INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(`id`)
          )
          """.trimIndent()
        )
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `user_restrictions` (
            `id` TEXT NOT NULL,
            `userId` TEXT NOT NULL,
            `username` TEXT NOT NULL,
            `adminId` TEXT NOT NULL,
            `adminRole` TEXT NOT NULL DEFAULT 'ADMIN',
            `reason` TEXT NOT NULL,
            `customMessage` TEXT NOT NULL,
            `startedAt` INTEGER NOT NULL DEFAULT 0,
            `expiresAt` INTEGER NOT NULL DEFAULT 0,
            `isActive` INTEGER NOT NULL DEFAULT 1,
            `appealStatus` TEXT NOT NULL DEFAULT 'NONE',
            `appealMessage` TEXT NOT NULL DEFAULT '',
            `updatedAt` INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(`id`)
          )
          """.trimIndent()
        )
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `reports` (
            `id` TEXT NOT NULL,
            `reporterId` TEXT NOT NULL,
            `reporterName` TEXT NOT NULL,
            `targetUserId` TEXT,
            `targetServerId` TEXT,
            `targetMessageId` TEXT,
            `reason` TEXT NOT NULL,
            `details` TEXT NOT NULL DEFAULT '',
            `status` TEXT NOT NULL DEFAULT 'OPEN',
            `handledBy` TEXT,
            `resolutionNote` TEXT NOT NULL DEFAULT '',
            `createdAt` INTEGER NOT NULL DEFAULT 0,
            `updatedAt` INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(`id`)
          )
          """.trimIndent()
        )
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `call_sessions` (
            `id` TEXT NOT NULL,
            `callType` TEXT NOT NULL DEFAULT 'DM_VOICE',
            `callerId` TEXT NOT NULL,
            `callerName` TEXT NOT NULL,
            `callerAvatarUri` TEXT,
            `calleeId` TEXT NOT NULL,
            `calleeName` TEXT NOT NULL,
            `channelId` TEXT,
            `serverId` TEXT,
            `status` TEXT NOT NULL DEFAULT 'RINGING',
            `offerSdp` TEXT,
            `answerSdp` TEXT,
            `qualityLabel` TEXT NOT NULL DEFAULT 'HD',
            `startedAt` INTEGER NOT NULL DEFAULT 0,
            `endedAt` INTEGER NOT NULL DEFAULT 0,
            `updatedAt` INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(`id`)
          )
          """.trimIndent()
        )
      }
    }

    val MIGRATION_8_9 = object : Migration(8, 9) {
      override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE users ADD COLUMN invisibleServerIdsCsv TEXT NOT NULL DEFAULT ''")
      }
    }

    fun getDatabase(context: Context): AppDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          AppDatabase::class.java,
          "xchat_database"
        )
          .addMigrations(MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9)
          .addCallback(DatabaseCallback())
          .build()
        INSTANCE = instance
        instance
      }
    }
  }

  private class DatabaseCallback : RoomDatabase.Callback() {
    override fun onCreate(db: SupportSQLiteDatabase) {
      super.onCreate(db)
      INSTANCE?.let { database ->
        CoroutineScope(Dispatchers.IO).launch {
          populateInitialData(database)
        }
      }
    }
  }
}

suspend fun populateInitialData(db: AppDatabase) {
  val now = System.currentTimeMillis()

  val owner = UserEntity(
    id = "usr_ridho",
    username = "ridho",
    displayName = "ridho",
    email = "kngryoowp@gmail.com",
    passwordHash = "",
    bio = "Owner & Master Architect XChat V2.0.",
    pronouns = "He/Him",
    profileColor = 0xFFC4C9D4L,
    subscriptionTier = "ASTRAL",
    xitBalance = 999999999L,
    isOwner = true,
    adminRole = "OWNER",
    isBanned = false,
    level = 50,
    xp = 24500L,
    equippedBadges = "owner,astral,developer,programmer,early_supporter,server_booster,xit_claimer,xchat_pioneer,hall_of_fame",
    equippedFrame = "frame_royal_gold",
    equippedNameplate = "np_hologram",
    equippedEffect = "eff_sparkles",
    displayNameFont = "SERIF",
    displayNameColorsCsv = "0xFFFFFFFF,0xFFC4C9D4,0xFF6E7685",
    profileBgColorsCsv = "0xFF07080B,0xFF111318,0xFF1A1D24",
    chatBubbleBgCsv = "0xFF1C2029,0xFF2B303D",
    appThemeId = "obsidian_marble",
    languageCode = "en",
    boostBalance = 999999,
    displayNameEffect = "SHIMMER",
    createdAt = now
  )

  val alex = UserEntity(
    id = "usr_alex",
    username = "alex",
    displayName = "Alex Rivera",
    email = "alex@example.com",
    passwordHash = "",
    bio = "Software Engineer & Competitive Chess Player.",
    pronouns = "He/Him",
    profileColor = 0xFF94A3B8L,
    subscriptionTier = "ASTRIX",
    xitBalance = 1500L,
    level = 14,
    xp = 3800L,
    equippedBadges = "programmer,developer,astrix,early_supporter,chess_master",
    equippedFrame = "frame_neon_iris",
    displayNameFont = "MONO",
    displayNameColorsCsv = "0xFFE2E8F0,0xFF94A3B8",
    profileBgColorsCsv = "0xFF07080B,0xFF111318,0xFF1F242D",
    appThemeId = "obsidian_marble",
    languageCode = "en",
    createdAt = now - 100000
  )

  val sarah = UserEntity(
    id = "usr_sarah",
    username = "sarah",
    displayName = "Sarah Chen",
    email = "sarah@example.com",
    passwordHash = "",
    bio = "Community Manager & Visual Designer.",
    pronouns = "She/Her",
    profileColor = 0xFFE2E8F0L,
    subscriptionTier = "ASTRAL",
    xitBalance = 3200L,
    level = 22,
    xp = 8200L,
    equippedBadges = "community_contributor,server_booster,astral,sticker_artist",
    equippedFrame = "frame_diamond_crest",
    displayNameFont = "SERIF",
    displayNameColorsCsv = "0xFFFFFFFF,0xFFC4C9D4,0xFF94A3B8",
    profileBgColorsCsv = "0xFF0A0B0F,0xFF161922,0xFF1F242D",
    appThemeId = "obsidian_marble",
    languageCode = "en",
    createdAt = now - 200000
  )

  db.userDao().insertUser(owner)
  db.userDao().insertUser(alex)
  db.userDao().insertUser(sarah)

  val server1 = ServerEntity(
    id = "srv_official",
    name = "XChat Official Lounge",
    description = "Main global XChat community. Discuss ideas, share creations, join tournaments, and chat in real time.",
    inviteCode = "XCHAT-MAIN",
    ownerId = "usr_ridho",
    boostLevel = 3,
    boostCount = 15,
    category = "Official Community",
    serverType = "Official Community",
    serverTag = "#Official",
    serverGenre = "Social & General",
    createdAt = now
  )
  val server2 = ServerEntity(
    id = "srv_dev",
    name = "Developer HQ",
    description = "Gathering place for software engineers, system architects, and UI/UX designers.",
    inviteCode = "DEV-HQ88",
    ownerId = "usr_ridho",
    boostLevel = 2,
    boostCount = 7,
    category = "Tech & Coding",
    serverType = "Education & Tech",
    serverTag = "#Coding",
    serverGenre = "Technology",
    createdAt = now - 50000
  )
  val server3 = ServerEntity(
    id = "srv_gaming",
    name = "Arena & Esports Hub",
    description = "Play together, join Chess, Reversi, Connect Four tournaments, & competitive matches.",
    inviteCode = "MC-ARENA",
    ownerId = "usr_sarah",
    boostLevel = 2,
    boostCount = 7,
    category = "Gaming",
    serverType = "Gaming Hub",
    serverTag = "#Gaming",
    serverGenre = "Esports & Strategy",
    supportedGame = "minecraft,chess",
    createdAt = now - 80000
  )
  val server4 = ServerEntity(
    id = "srv_val",
    name = "Valorant & MLBB Squad",
    description = "Find ranked parties, discuss team strategies, and compete in weekly cups.",
    inviteCode = "SQUAD-GG",
    ownerId = "usr_alex",
    boostLevel = 1,
    boostCount = 2,
    category = "Gaming",
    serverType = "Esports Clan",
    serverTag = "#Competitive",
    serverGenre = "FPS / MOBA",
    supportedGame = "valorant,mlbb",
    createdAt = now - 90000
  )

  db.serverDao().insertServer(server1)
  db.serverDao().insertServer(server2)
  db.serverDao().insertServer(server3)
  db.serverDao().insertServer(server4)

  // Categories
  db.channelCategoryDao().insertCategories(
    listOf(
      ChannelCategoryEntity("cat_s1_general", "srv_official", "GENERAL", 0, false, now),
      ChannelCategoryEntity("cat_s1_community", "srv_official", "COMMUNITY", 1, false, now),
      ChannelCategoryEntity("cat_s1_gaming", "srv_official", "GAMING", 2, false, now),
      ChannelCategoryEntity("cat_s2_general", "srv_dev", "GENERAL", 0, false, now),
      ChannelCategoryEntity("cat_s2_community", "srv_dev", "COMMUNITY", 1, false, now),
      ChannelCategoryEntity("cat_s3_gaming", "srv_gaming", "GAMING", 0, false, now),
      ChannelCategoryEntity("cat_s4_gaming", "srv_val", "GAMING", 0, false, now)
    )
  )

  db.serverMemberDao().insertMemberships(
    listOf(
      ServerMemberEntity("srv_official_usr_ridho", "srv_official", "usr_ridho", role = "Owner", roleColor = 0xFFEAB308),
      ServerMemberEntity("srv_dev_usr_ridho", "srv_dev", "usr_ridho", role = "Owner", roleColor = 0xFFEAB308),
      ServerMemberEntity("srv_official_usr_alex", "srv_official", "usr_alex", role = "Member", roleColor = 0xFF949BA4),
      ServerMemberEntity("srv_val_usr_alex", "srv_val", "usr_alex", role = "Owner", roleColor = 0xFFEAB308),
      ServerMemberEntity("srv_official_usr_sarah", "srv_official", "usr_sarah", role = "Admin", roleColor = 0xFFC4C9D4),
      ServerMemberEntity("srv_gaming_usr_sarah", "srv_gaming", "usr_sarah", role = "Owner", roleColor = 0xFFEAB308)
    )
  )

  db.serverRoleDao().insertRoles(
    listOf(
      ServerRoleEntity("role_s1_owner", "srv_official", "Owner", 0xFFEAB308, permissionsCsv = "MANAGE_SERVER,MANAGE_CHANNELS,MANAGE_ROLES,MENTION_EVERYONE,SEND_MESSAGES", position = 100),
      ServerRoleEntity("role_s1_mod", "srv_official", "Moderator", 0xFFC4C9D4, permissionsCsv = "MANAGE_MESSAGES,PIN_MESSAGES,MENTION_EVERYONE,SEND_MESSAGES", position = 50),
      ServerRoleEntity("role_s1_member", "srv_official", "Member", 0xFF94A3B8, permissionsCsv = "SEND_MESSAGES", position = 10),
      ServerRoleEntity("role_s2_owner", "srv_dev", "Owner", 0xFFEAB308, permissionsCsv = "MANAGE_SERVER,MANAGE_CHANNELS,MANAGE_ROLES,MENTION_EVERYONE,SEND_MESSAGES", position = 100),
      ServerRoleEntity("role_s3_owner", "srv_gaming", "Owner", 0xFFEAB308, permissionsCsv = "MANAGE_SERVER,MANAGE_CHANNELS,MANAGE_ROLES,MENTION_EVERYONE,SEND_MESSAGES", position = 100),
      ServerRoleEntity("role_s4_owner", "srv_val", "Owner", 0xFFEAB308, permissionsCsv = "MANAGE_SERVER,MANAGE_CHANNELS,MANAGE_ROLES,MENTION_EVERYONE,SEND_MESSAGES", position = 100)
    )
  )

  db.channelDao().insertChannels(
    listOf(
      ChannelEntity("ch_s1_gen", "srv_official", "general", "Everyday chill chat for all community members", "text", false, 0, "cat_s1_general"),
      ChannelEntity("ch_s1_intro", "srv_official", "introductions", "Introduce yourself to the XChat community", "text", false, 1, "cat_s1_general"),
      ChannelEntity("ch_s1_ann", "srv_official", "announcements", "Important XChat platform announcements and updates", "announcements", false, 2, "cat_s1_general"),
      ChannelEntity("ch_s1_rules", "srv_official", "rules", "Community guidelines and rules on XChat", "rules", false, 3, "cat_s1_general"),
      ChannelEntity("ch_s1_forums", "srv_official", "forums", "Long-form discussions and community topics", "forums", false, 4, "cat_s1_community"),
      ChannelEntity("ch_s1_media", "srv_official", "media", "Share photos, 7s videos, GIFs, and custom stickers", "media", false, 5, "cat_s1_community"),
      ChannelEntity("ch_s1_showcase", "srv_official", "showcase", "Showcase your profile, marble themes, and creative work", "text", false, 6, "cat_s1_community"),
      ChannelEntity("ch_s1_games", "srv_official", "games", "Challenge friends in Tic Tac Toe, Chess, Connect Four & Reversi", "text", false, 7, "cat_s1_gaming"),
      ChannelEntity("ch_s1_tourn", "srv_official", "tournaments", "Official XChat tournament brackets and match schedules", "text", false, 8, "cat_s1_gaming"),
      ChannelEntity("ch_s1_voice", "srv_official", "Voice Lounge Obsidian", "HD WebRTC voice room with audio diagnostics", "voice", false, 9, "cat_s1_gaming"),

      ChannelEntity("ch_s2_gen", "srv_dev", "dev-discussion", "Kotlin, Jetpack Compose, WebRTC, and architecture chat", "text", false, 0, "cat_s2_general"),
      ChannelEntity("ch_s2_showcase", "srv_dev", "project-showcase", "Show off your projects and portfolios", "forums", false, 1, "cat_s2_community"),
      ChannelEntity("ch_s2_voice", "srv_dev", "Voice Dev Room", "Live technical discussions over WebRTC voice", "voice", false, 2, "cat_s2_community"),

      ChannelEntity("ch_s3_gen", "srv_gaming", "arena-chat", "Tournament coordination & group matches", "text", false, 0, "cat_s3_gaming"),
      ChannelEntity("ch_s3_voice", "srv_gaming", "Squad Voice #1", "Live strategy comms room", "voice", false, 1, "cat_s3_gaming"),

      ChannelEntity("ch_s4_gen", "srv_val", "looking-for-party", "Find ranked teammates for Valorant & MLBB", "text", false, 0, "cat_s4_gaming"),
      ChannelEntity("ch_s4_voice", "srv_val", "Comms Room #1", "Live team voice communication", "voice", false, 1, "cat_s4_gaming")
    )
  )

  db.messageDao().insertMessage(
    MessageEntity(
      id = "msg_ann_1",
      channelId = "ch_s1_ann",
      senderId = "usr_ridho",
      senderName = "ridho",
      senderFrameId = "frame_royal_gold",
      senderTier = "ASTRAL",
      senderBadges = "owner,astral,developer",
      senderDisplayFont = "SERIF",
      senderDisplayColorsCsv = "0xFFFFFFFF,0xFFC4C9D4,0xFF6E7685",
      senderDisplayEffect = "SHIMMER",
      content = "Welcome to XChat V2.0! Featuring the free Animated Moving Marble (Obsidian Glass) theme, two-way WebRTC voice & video calls, 4 multiplayer mini games, Music Player, and Sticker Studio. Type #forums to jump to discussions!",
      isPinned = true,
      reactions = "like:5,star:4,rocket:6",
      timestamp = now - 3600000
    )
  )

  db.messageDao().insertMessage(
    MessageEntity(
      id = "msg_gen_1",
      channelId = "ch_s1_gen",
      senderId = "usr_ridho",
      senderName = "ridho",
      senderFrameId = "frame_royal_gold",
      senderTier = "ASTRAL",
      senderBadges = "owner,astral,developer",
      senderDisplayFont = "SERIF",
      senderDisplayColorsCsv = "0xFFFFFFFF,0xFFC4C9D4,0xFF6E7685",
      senderDisplayEffect = "SHIMMER",
      content = "Hey everyone! Jump to #forums for threads or challenge someone to a Chess match in #games!",
      reactions = "like:4,fire:2",
      timestamp = now - 1800000
    )
  )

  db.forumPostDao().insertPosts(
    listOf(
      ForumPostEntity("fp_1", "ch_s1_forums", "usr_ridho", "ridho", null, "Feature requests & discussions!", "Share your ideas, bug reports, or new tournament requests in this thread!", null, "Meta", "❗", true, 45, 28, "🔥", now - 432000000L),
      ForumPostEntity("fp_2", "ch_s1_forums", "usr_sarah", "Sarah Chen", null, "XChat Marble Glass Showcase", "Share your best Moving Marble theme + custom wallpaper setups here!", null, "Showcase", "✨", false, 19, 36, "🖤", now - 300000L),
      ForumPostEntity("fp_3", "ch_s1_forums", "usr_alex", "Alex Rivera", null, "Chess Grandmaster Strategy Thread", "Discuss Sicilian Defense, Queen's Gambit openings, and upcoming XChat Chess tournaments.", null, "Games", "♟️", false, 64, 22, "⚡", now - 840000L)
    )
  )

  // Populated Quests (8 quests covering all major features)
  db.questDao().insertQuests(
    listOf(
      QuestEntity("q_1", "Send 20 Messages in Servers / DM", "DAILY", "Chat actively in server channels or direct messages.", 150L, 20, 0, false),
      QuestEntity("q_2", "Add 3 New Friends", "SOCIAL", "Grow your friend network on XChat.", 250L, 3, 0, false),
      QuestEntity("q_3", "Play 2 Mini Games", "GAMING", "Play Tic Tac Toe, Chess, Connect Four, or Reversi.", 200L, 2, 0, false),
      QuestEntity("q_4", "Join a New Server", "COMMUNITY", "Browse Explore and join a community server.", 150L, 1, 0, false),
      QuestEntity("q_5", "Complete a Chess Match", "GAMING", "Finish 1 multiplayer Chess game from start to finish.", 350L, 1, 0, false),
      QuestEntity("q_6", "Use Voice Chat / Call", "VOICE", "Join a Voice Room or place a voice call.", 180L, 1, 0, false),
      QuestEntity("q_7", "Create 1 Custom Sticker", "CREATIVE", "Use Sticker Studio to craft a custom sticker.", 200L, 1, 0, false),
      QuestEntity("q_8", "Create a Music Playlist", "MUSIC", "Add a track to a playlist in the Music Player.", 120L, 1, 0, false)
    )
  )

  // Rich XIT Exchange Marketplace Items
  db.marketplaceDao().insertItems(
    listOf(
      // Frames (Animated, Gradient, Glow, Premium, Seasonal)
      MarketplaceItemEntity("frame_obsidian_halo", "Obsidian Glass Halo", "FRAME", 180L, "Reflective monochrome glass frame with sleek silver trim.", 0xFFC4C9D4, "sparkle", false),
      MarketplaceItemEntity("frame_royal_gold", "Royal Gold Frame", "FRAME", 300L, "Regal golden frame with ornate engraved accents.", 0xFFEAB308, "crown", false),
      MarketplaceItemEntity("frame_neon_iris", "Animated Neon Pulse", "FRAME", 280L, "Pulsing cyan neon border with kinetic light ring.", 0xFF38BDF8, "sparkle", false),
      MarketplaceItemEntity("frame_diamond_crest", "Diamond Crest (Astral)", "FRAME", 500L, "Prestigious animated diamond crest with crystal prism shine.", 0xFFE2E8F0, "diamond", true),
      MarketplaceItemEntity("frame_winter_frost", "Seasonal Frost Aura", "FRAME", 350L, "Seasonal frost halo accented with silver ice crystals.", 0xFFBAE6FD, "snow", false),
      // 10 Display Name Text Effects
      MarketplaceItemEntity("txt_gradient", "Text Effect: Gradient", "TEXT_EFFECT", 80L, "Multi-color smooth gradient for your Display Name.", 0xFFC4C9D4, "text", false),
      MarketplaceItemEntity("txt_glow", "Text Effect: Soft Glow", "TEXT_EFFECT", 120L, "Soft luminescent aura framing your display name.", 0xFFF8FAFC, "text", false),
      MarketplaceItemEntity("txt_neon", "Text Effect: Neon Edge", "TEXT_EFFECT", 150L, "Crisp high-contrast neon outline effect.", 0xFF38BDF8, "text", false),
      MarketplaceItemEntity("txt_shimmer", "Text Effect: Silver Shimmer", "TEXT_EFFECT", 180L, "Sweeping light shimmer across your name characters.", 0xFFE2E8F0, "text", false),
      MarketplaceItemEntity("txt_rainbow", "Text Effect: Prismatic Rainbow", "TEXT_EFFECT", 220L, "Fluid moving prism spectrum effect.", 0xFFF472B6, "text", false),
      MarketplaceItemEntity("txt_floating", "Text Effect: Floating", "TEXT_EFFECT", 160L, "Gentle vertical levitation animation.", 0xFFA7F3D0, "text", false),
      MarketplaceItemEntity("txt_wave", "Text Effect: Wave", "TEXT_EFFECT", 190L, "Rhythmic per-character wave motion.", 0xFF93C5FD, "text", false),
      MarketplaceItemEntity("txt_pulse", "Text Effect: Pulse", "TEXT_EFFECT", 140L, "Modern rhythmic scale & opacity pulse.", 0xFFFDE68A, "text", false),
      MarketplaceItemEntity("txt_typing", "Text Effect: Typing", "TEXT_EFFECT", 200L, "Character-by-character typewriter animation.", 0xFFC4C9D4, "text", false),
      MarketplaceItemEntity("txt_reverse_typing", "Text Effect: Reverse Typing Loop", "TEXT_EFFECT", 240L, "Type and erase loop animation.", 0xFFE2E8F0, "text", false),
      // Badge Effects, Name Colors, Chat Effects, Background Themes, Sticker Packs, Nameplates
      MarketplaceItemEntity("np_hologram", "Hologram Nameplate", "NAMEPLATE", 200L, "Futuristic glassmorphic nameplate.", 0xFFC4C9D4, "badge", false),
      MarketplaceItemEntity("eff_sparkles", "Profile Sparkles Decoration", "DECORATION", 250L, "Lightweight sparkle particles across your profile.", 0xFFF8FAFC, "sparkle", false),
      MarketplaceItemEntity("badge_eff_prism", "Badge Effect: Prism Halo", "BADGE_EFFECT", 300L, "Refractive halo highlight for your badge row.", 0xFF94A3B8, "shield", false),
      MarketplaceItemEntity("chat_eff_glass", "Chat Bubble: Frosted Obsidian", "CHAT_EFFECT", 160L, "Reflective frosted obsidian chat bubble glass.", 0xFF334155, "palette", false),
      MarketplaceItemEntity("bg_marble_gold", "Background: Noir Gold Marble", "BACKGROUND_THEME", 280L, "Obsidian black marble veined with brushed gold.", 0xFFEAB308, "palette", false),
      MarketplaceItemEntity("pack_xchat_noir", "Sticker Pack: XChat Noir", "STICKER_PACK", 150L, "Expressive Obsidian-styled sticker bundle.", 0xFFC4C9D4, "sticker", false)
    )
  )

  // Redeem Codes
  db.adminModerationDao().insertRedeemCodes(
    listOf(
      RedeemCodeEntity("rc_1", "XCHAT2026", 500L, 1, "xchat_pioneer", 1000, 0, "", 0L, true, now),
      RedeemCodeEntity("rc_2", "MARBLEVIP", 300L, 0, "early_bird", 500, 0, "", 0L, true, now),
      RedeemCodeEntity("rc_3", "CHESSPRO", 250L, 0, "game_explorer", 500, 0, "", 0L, true, now)
    )
  )

  // Seed initial demo tournament & friend data
  db.gameDao().upsertTournament(
    TournamentEntity(
      id = "trn_chess_open",
      name = "XChat Obsidian Chess Open",
      gameType = "CHESS",
      creatorId = "usr_ridho",
      status = "OPEN",
      participantsCsv = "usr_ridho,usr_alex",
      bracketJson = "[{\"round\":1,\"p1\":\"ridho\",\"p2\":\"alex\",\"winner\":\"\"}]",
      createdAt = now
    )
  )

  db.friendDao().insertFriend(FriendEntity("usr_ridho_usr_alex", "usr_ridho", "usr_alex", "alex", "Alex Rivera", null, "ACCEPTED", true, "Online - Ready for Chess"))
  db.friendDao().insertFriend(FriendEntity("usr_ridho_usr_sarah", "usr_ridho", "usr_sarah", "sarah", "Sarah Chen", null, "ACCEPTED", true, "Online - Designing Marble Themes"))

  val convId = "dm_usr_ridho_usr_alex"
  db.directMessageDao().insertDM(DirectMessageEntity("dm_1", convId, "usr_alex", "Alex Rivera", "usr_ridho", "Hey ridho! The Moving Marble Obsidian V2.0 theme looks super clean!", timestamp = now - 600000, isRead = true))
  db.directMessageDao().insertDM(DirectMessageEntity("dm_2", convId, "usr_ridho", "ridho", "usr_alex", "Thanks Alex! Let's test WebRTC calls and play a Chess match soon.", timestamp = now - 300000, isRead = true))

  db.notificationDao().insertNotification(NotificationEntity("notif_1", "usr_ridho", "Welcome to XChat V2.0", "Cinematic Glassmorphism & Moving Marble design is active. All your data is safely migrated.", "ANNOUNCEMENT", false, now))
  db.auditLogDao().insertLog(AuditLogEntity("log_1", "system", "SYSTEM_INIT", "XChat V2.0 initialized cleanly.", now))
}
