package com.example.data.local

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
  @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
  suspend fun getUserById(userId: String): UserEntity?

  @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
  fun getUserByIdFlow(userId: String): Flow<UserEntity?>

  @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
  suspend fun getUserByUsername(username: String): UserEntity?

  @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
  suspend fun getUserByEmail(email: String): UserEntity?

  @Query("SELECT * FROM users ORDER BY createdAt DESC")
  fun getAllUsersFlow(): Flow<List<UserEntity>>

  @Query("SELECT * FROM users ORDER BY createdAt DESC")
  suspend fun getAllUsers(): List<UserEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertUser(user: UserEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertUsers(users: List<UserEntity>)

  @Update
  suspend fun updateUser(user: UserEntity)

  @Query("UPDATE users SET isBanned = :isBanned WHERE id = :userId")
  suspend fun setBanStatus(userId: String, isBanned: Boolean)

  @Query("UPDATE users SET subscriptionTier = :tier WHERE id = :userId")
  suspend fun updateSubscriptionTier(userId: String, tier: String)

  @Query("UPDATE users SET xitBalance = :balance WHERE id = :userId")
  suspend fun updateXitBalance(userId: String, balance: Long)

  @Query("UPDATE users SET equippedBadges = :badgesCsv WHERE id = :userId")
  suspend fun updateEquippedBadges(userId: String, badgesCsv: String)

  @Query("UPDATE users SET equippedBadges = :badgesCsv, unlockedBadgesProgressJson = :progressJson WHERE id = :userId")
  suspend fun updateEquippedBadgesAndProgress(userId: String, badgesCsv: String, progressJson: String)

  @Query("UPDATE users SET invisibleServerIdsCsv = :csv WHERE id = :userId")
  suspend fun updateInvisibleServers(userId: String, csv: String)

  @Query("DELETE FROM users WHERE id = :userId")
  suspend fun deleteUserById(userId: String)

  @Query("UPDATE users SET boostBalance = :boostBalance WHERE id = :userId")
  suspend fun updateBoostBalance(userId: String, boostBalance: Int)

  @Query("UPDATE users SET presenceStatus = :presenceStatus, statusTag = :statusTag, lastSeenAt = :lastSeenAt WHERE id = :userId")
  suspend fun updatePresence(userId: String, presenceStatus: String, statusTag: String, lastSeenAt: Long)

  @Query("UPDATE users SET typingChannelId = :typingChannelId, typingUpdatedAt = :typingUpdatedAt WHERE id = :userId")
  suspend fun updateTyping(userId: String, typingChannelId: String?, typingUpdatedAt: Long)

  @Query("UPDATE users SET activeAppName = :appName, activeAppPackage = :appPkg, activeAppStartedAt = :startedAt WHERE id = :userId")
  suspend fun updateActiveApp(userId: String, appName: String?, appPkg: String?, startedAt: Long)
}

@Dao
interface ServerDao {
  @Query("SELECT * FROM servers ORDER BY createdAt ASC")
  fun getAllServersFlow(): Flow<List<ServerEntity>>

  @Query("SELECT * FROM servers WHERE id = :serverId LIMIT 1")
  suspend fun getServerById(serverId: String): ServerEntity?

  @Query("SELECT * FROM servers WHERE inviteCode = :code LIMIT 1")
  suspend fun getServerByInviteCode(code: String): ServerEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertServer(server: ServerEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertServers(servers: List<ServerEntity>)

  @Update
  suspend fun updateServer(server: ServerEntity)

  @Delete
  suspend fun deleteServer(server: ServerEntity)
}

@Dao
interface ChannelCategoryDao {
  @Query("SELECT * FROM channel_categories WHERE serverId = :serverId ORDER BY orderIndex ASC, createdAt ASC")
  fun getCategoriesForServer(serverId: String): Flow<List<ChannelCategoryEntity>>

  @Query("SELECT * FROM channel_categories WHERE id = :categoryId LIMIT 1")
  suspend fun getCategoryById(categoryId: String): ChannelCategoryEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCategory(category: ChannelCategoryEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCategories(categories: List<ChannelCategoryEntity>)

  @Update
  suspend fun updateCategory(category: ChannelCategoryEntity)

  @Delete
  suspend fun deleteCategory(category: ChannelCategoryEntity)
}

@Dao
interface ServerMemberDao {
  @Query("SELECT serverId FROM server_members WHERE userId = :userId")
  fun getJoinedServerIdsFlow(userId: String): Flow<List<String>>

  @Query("SELECT * FROM server_members WHERE serverId = :serverId ORDER BY joinedAt ASC")
  fun getMembersForServerFlow(serverId: String): Flow<List<ServerMemberEntity>>

  @Query("SELECT * FROM server_members WHERE serverId = :serverId AND userId = :userId LIMIT 1")
  suspend fun getMembership(serverId: String, userId: String): ServerMemberEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMembership(member: ServerMemberEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMemberships(members: List<ServerMemberEntity>)

  @Query("UPDATE server_members SET role = :role, roleColor = :roleColor, roleIconUri = :roleIconUri, roleChromaColorsCsv = :roleChromaColorsCsv WHERE serverId = :serverId AND userId = :userId")
  suspend fun updateMemberRole(serverId: String, userId: String, role: String, roleColor: Long, roleIconUri: String?, roleChromaColorsCsv: String)
}

@Dao
interface ServerRoleDao {
  @Query("SELECT * FROM server_roles WHERE serverId = :serverId ORDER BY position DESC, name ASC")
  fun getRolesForServerFlow(serverId: String): Flow<List<ServerRoleEntity>>

  @Query("SELECT * FROM server_roles WHERE serverId = :serverId")
  suspend fun getRolesForServerOnce(serverId: String): List<ServerRoleEntity>

  @Query("SELECT * FROM server_roles WHERE id = :roleId LIMIT 1")
  suspend fun getRoleById(roleId: String): ServerRoleEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertRole(role: ServerRoleEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertRoles(roles: List<ServerRoleEntity>)

  @Update
  suspend fun updateRole(role: ServerRoleEntity)

  @Delete
  suspend fun deleteRole(role: ServerRoleEntity)
}

@Dao
interface ChannelDao {
  @Query("SELECT * FROM channels WHERE serverId = :serverId ORDER BY orderIndex ASC")
  fun getChannelsForServer(serverId: String): Flow<List<ChannelEntity>>

  @Query("SELECT * FROM channels ORDER BY orderIndex ASC")
  fun getAllChannels(): Flow<List<ChannelEntity>>

  @Query("SELECT * FROM channels WHERE id = :channelId LIMIT 1")
  suspend fun getChannelById(channelId: String): ChannelEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertChannel(channel: ChannelEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertChannels(channels: List<ChannelEntity>)

  @Update
  suspend fun updateChannel(channel: ChannelEntity)

  @Delete
  suspend fun deleteChannel(channel: ChannelEntity)
}

@Dao
interface MessageDao {
  @Query("SELECT * FROM messages WHERE channelId = :channelId ORDER BY timestamp ASC")
  fun getMessagesForChannel(channelId: String): Flow<List<MessageEntity>>

  @Query("SELECT * FROM messages WHERE channelId = :channelId ORDER BY timestamp DESC LIMIT :limit")
  fun getMessagesForChannelPaged(channelId: String, limit: Int): Flow<List<MessageEntity>>

  @Query("SELECT * FROM messages WHERE channelId = :channelId AND isPinned = 1 ORDER BY timestamp DESC")
  fun getPinnedMessages(channelId: String): Flow<List<MessageEntity>>

  @Query("SELECT * FROM messages WHERE channelId = :channelId AND content LIKE '%' || :query || '%' ORDER BY timestamp DESC")
  suspend fun searchMessages(channelId: String, query: String): List<MessageEntity>

  @Query("SELECT * FROM messages WHERE content LIKE '%' || :query || '%' ORDER BY timestamp DESC LIMIT 50")
  suspend fun searchAllMessages(query: String): List<MessageEntity>

  @Query("SELECT * FROM messages WHERE id = :messageId LIMIT 1")
  suspend fun getMessageById(messageId: String): MessageEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMessage(message: MessageEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertMessages(messages: List<MessageEntity>)

  @Update
  suspend fun updateMessage(message: MessageEntity)

  @Delete
  suspend fun deleteMessage(message: MessageEntity)
}

@Dao
interface ForumPostDao {
  @Query("SELECT * FROM forum_posts WHERE channelId = :channelId ORDER BY isPinned DESC, createdAt DESC")
  fun getPostsForChannel(channelId: String): Flow<List<ForumPostEntity>>

  @Query("SELECT * FROM forum_posts WHERE id = :postId LIMIT 1")
  suspend fun getPostById(postId: String): ForumPostEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPost(post: ForumPostEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPosts(posts: List<ForumPostEntity>)

  @Update
  suspend fun updatePost(post: ForumPostEntity)

  @Delete
  suspend fun deletePost(post: ForumPostEntity)
}

@Dao
interface ForumReplyDao {
  @Query("SELECT * FROM forum_replies WHERE postId = :postId ORDER BY createdAt ASC")
  fun getRepliesForPost(postId: String): Flow<List<ForumReplyEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertReply(reply: ForumReplyEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertReplies(replies: List<ForumReplyEntity>)
}

@Dao
interface DirectMessageDao {
  @Query("SELECT * FROM direct_messages WHERE conversationId = :convId AND isDeleted = 0 ORDER BY timestamp ASC")
  fun getDMsForConversation(convId: String): Flow<List<DirectMessageEntity>>

  @Query("SELECT * FROM direct_messages WHERE id = :id LIMIT 1")
  suspend fun getDMById(id: String): DirectMessageEntity?

  @Query("SELECT * FROM direct_messages WHERE isDeleted = 0 AND content LIKE '%' || :query || '%' ORDER BY timestamp DESC LIMIT 50")
  suspend fun searchAllDMs(query: String): List<DirectMessageEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertDM(dm: DirectMessageEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertDMs(dms: List<DirectMessageEntity>)

  @Update
  suspend fun updateDM(dm: DirectMessageEntity)

  @Query("UPDATE direct_messages SET isRead = 1 WHERE conversationId = :convId AND receiverId = :currentUserId AND isRead = 0")
  suspend fun markConversationRead(convId: String, currentUserId: String)

  @Query("SELECT * FROM direct_messages WHERE conversationId = :convId AND receiverId = :currentUserId AND isRead = 0")
  suspend fun getUnreadDMsInConversation(convId: String, currentUserId: String): List<DirectMessageEntity>
}

@Dao
interface FriendDao {
  @Query("SELECT * FROM friends WHERE userId = :userId ORDER BY updatedAt DESC")
  fun getFriendsForUser(userId: String): Flow<List<FriendEntity>>

  @Query("SELECT * FROM friends WHERE userId = :userId AND friendId = :friendId LIMIT 1")
  suspend fun getFriendship(userId: String, friendId: String): FriendEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertFriend(friend: FriendEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertFriends(friends: List<FriendEntity>)

  @Update
  suspend fun updateFriend(friend: FriendEntity)

  @Delete
  suspend fun deleteFriend(friend: FriendEntity)
}

@Dao
interface UserFollowDao {
  @Query("SELECT * FROM user_follows WHERE followerId = :userId")
  fun getFollowingFlow(userId: String): Flow<List<UserFollowEntity>>

  @Query("SELECT * FROM user_follows WHERE targetUserId = :userId")
  fun getFollowersFlow(userId: String): Flow<List<UserFollowEntity>>

  @Query("SELECT * FROM user_follows WHERE followerId = :followerId AND targetUserId = :targetId LIMIT 1")
  suspend fun getFollowRecord(followerId: String, targetId: String): UserFollowEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertFollow(follow: UserFollowEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertFollows(follows: List<UserFollowEntity>)

  @Delete
  suspend fun deleteFollow(follow: UserFollowEntity)
}

@Dao
interface UserGameAppDao {
  @Query("SELECT * FROM user_game_apps WHERE userId = :userId ORDER BY orderIndex ASC, createdAt ASC")
  fun getGamesAppsForUser(userId: String): Flow<List<UserGameAppEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertGameApp(item: UserGameAppEntity)

  @Update
  suspend fun updateGameApp(item: UserGameAppEntity)

  @Delete
  suspend fun deleteGameApp(item: UserGameAppEntity)
}

@Dao
interface StickerDao {
  @Query("SELECT * FROM sticker_packs ORDER BY createdAt DESC")
  fun getAllStickerPacks(): Flow<List<StickerPackEntity>>

  @Query("SELECT * FROM stickers ORDER BY isFavorite DESC, createdAt DESC")
  fun getAllStickers(): Flow<List<StickerEntity>>

  @Query("SELECT * FROM stickers WHERE packId = :packId ORDER BY createdAt DESC")
  fun getStickersInPack(packId: String): Flow<List<StickerEntity>>

  @Query("SELECT * FROM stickers WHERE id = :stickerId LIMIT 1")
  suspend fun getStickerById(stickerId: String): StickerEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPack(pack: StickerPackEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSticker(sticker: StickerEntity)

  @Update
  suspend fun updateSticker(sticker: StickerEntity)

  @Delete
  suspend fun deleteSticker(sticker: StickerEntity)
}

@Dao
interface GifFavoriteDao {
  @Query("SELECT * FROM gif_favorites WHERE userId = :userId ORDER BY isFavorite DESC, updatedAt DESC")
  fun getGifsForUser(userId: String): Flow<List<GifFavoriteEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertGif(gif: GifFavoriteEntity)

  @Delete
  suspend fun deleteGif(gif: GifFavoriteEntity)
}

@Dao
interface PlaylistDao {
  @Query("SELECT * FROM playlists WHERE userId = :userId ORDER BY createdAt DESC")
  fun getPlaylistsForUser(userId: String): Flow<List<PlaylistEntity>>

  @Query("SELECT * FROM audio_tracks WHERE playlistId = :playlistId ORDER BY orderIndex ASC, createdAt ASC")
  fun getTracksForPlaylist(playlistId: String): Flow<List<AudioTrackEntity>>

  @Query("SELECT * FROM audio_tracks WHERE userId = :userId ORDER BY orderIndex ASC, createdAt DESC")
  fun getAllTracksForUser(userId: String): Flow<List<AudioTrackEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPlaylist(playlist: PlaylistEntity)

  @Update
  suspend fun updatePlaylist(playlist: PlaylistEntity)

  @Delete
  suspend fun deletePlaylist(playlist: PlaylistEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTrack(track: AudioTrackEntity)

  @Update
  suspend fun updateTrack(track: AudioTrackEntity)

  @Delete
  suspend fun deleteTrack(track: AudioTrackEntity)
}

@Dao
interface GameDao {
  @Query("SELECT * FROM game_matches ORDER BY updatedAt DESC")
  fun getAllMatches(): Flow<List<GameMatchEntity>>

  @Query("SELECT * FROM game_matches WHERE id = :matchId LIMIT 1")
  suspend fun getMatchById(matchId: String): GameMatchEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertMatch(match: GameMatchEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertMatches(matches: List<GameMatchEntity>)

  @Query("SELECT * FROM game_ratings WHERE gameType = :gameType ORDER BY elo DESC")
  fun getRatingsByGame(gameType: String): Flow<List<GameRatingEntity>>

  @Query("SELECT * FROM game_ratings ORDER BY elo DESC")
  fun getAllRatings(): Flow<List<GameRatingEntity>>

  @Query("SELECT * FROM game_ratings WHERE userId = :userId AND gameType = :gameType LIMIT 1")
  suspend fun getRating(userId: String, gameType: String): GameRatingEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertRating(rating: GameRatingEntity)

  @Query("SELECT * FROM tournaments ORDER BY createdAt DESC")
  fun getAllTournaments(): Flow<List<TournamentEntity>>

  @Query("SELECT * FROM tournaments WHERE id = :id LIMIT 1")
  suspend fun getTournamentById(id: String): TournamentEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertTournament(tournament: TournamentEntity)
}

@Dao
interface AdminModerationDao {
  @Query("SELECT * FROM redeem_codes ORDER BY createdAt DESC")
  fun getAllRedeemCodes(): Flow<List<RedeemCodeEntity>>

  @Query("SELECT * FROM redeem_codes WHERE code = :code LIMIT 1")
  suspend fun getRedeemCodeByCode(code: String): RedeemCodeEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertRedeemCode(code: RedeemCodeEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertRedeemCodes(codes: List<RedeemCodeEntity>)

  @Query("SELECT * FROM user_restrictions ORDER BY updatedAt DESC")
  fun getAllRestrictions(): Flow<List<UserRestrictionEntity>>

  @Query("SELECT * FROM user_restrictions WHERE userId = :userId AND isActive = 1 ORDER BY startedAt DESC LIMIT 1")
  fun getActiveRestrictionForUserFlow(userId: String): Flow<UserRestrictionEntity?>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertRestriction(restriction: UserRestrictionEntity)

  @Query("SELECT * FROM reports ORDER BY updatedAt DESC")
  fun getAllReports(): Flow<List<ReportEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertReport(report: ReportEntity)
}

@Dao
interface CallSessionDao {
  @Query("SELECT * FROM call_sessions ORDER BY updatedAt DESC LIMIT 20")
  fun getRecentCalls(): Flow<List<CallSessionEntity>>

  @Query("SELECT * FROM call_sessions WHERE id = :callId LIMIT 1")
  suspend fun getCallById(callId: String): CallSessionEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertCall(call: CallSessionEntity)
}

@Dao
interface NotificationDao {
  @Query("SELECT * FROM notifications WHERE userId = :userId ORDER BY timestamp DESC")
  fun getNotifications(userId: String): Flow<List<NotificationEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertNotification(notif: NotificationEntity)

  @Query("UPDATE notifications SET isRead = 1 WHERE userId = :userId")
  suspend fun markAllAsRead(userId: String)
}

@Dao
interface MarketplaceDao {
  @Query("SELECT * FROM marketplace_items")
  fun getAllItems(): Flow<List<MarketplaceItemEntity>>

  @Query("SELECT * FROM user_inventory WHERE userId = :userId")
  fun getUserInventory(userId: String): Flow<List<UserInventoryEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertItem(item: MarketplaceItemEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertItems(items: List<MarketplaceItemEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertInventory(inventory: UserInventoryEntity)

  @Query("UPDATE user_inventory SET isEquipped = :isEquipped WHERE userId = :userId AND itemId = :itemId")
  suspend fun setEquipped(userId: String, itemId: String, isEquipped: Boolean)
}

@Dao
interface QuestDao {
  @Query("SELECT * FROM quests")
  fun getAllQuests(): Flow<List<QuestEntity>>

  @Query("SELECT * FROM quests WHERE id = :questId LIMIT 1")
  suspend fun getQuestById(questId: String): QuestEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertQuests(quests: List<QuestEntity>)

  @Update
  suspend fun updateQuest(quest: QuestEntity)
}

@Dao
interface PaymentRequestDao {
  @Query("SELECT * FROM payment_requests ORDER BY createdAt DESC")
  fun getAllPaymentRequests(): Flow<List<PaymentRequestEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPaymentRequest(request: PaymentRequestEntity)

  @Query("UPDATE payment_requests SET status = :status WHERE id = :id")
  suspend fun updateStatus(id: String, status: String)
}

@Dao
interface AuditLogDao {
  @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 200")
  fun getAuditLogs(): Flow<List<AuditLogEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertLog(log: AuditLogEntity)
}

@Dao
interface ProfileVisitorDao {
  @Query("SELECT * FROM profile_visitors WHERE profileUserId = :userId ORDER BY visitedAt DESC LIMIT 20")
  fun getVisitors(userId: String): Flow<List<ProfileVisitorEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertVisitor(visitor: ProfileVisitorEntity)
}

@Dao
interface SavedProfileThemeDao {
  @Query("SELECT * FROM saved_profile_themes WHERE userId = :userId ORDER BY isEquipped DESC, createdAt DESC")
  fun getThemesForUser(userId: String): Flow<List<SavedProfileThemeEntity>>

  @Query("SELECT * FROM saved_profile_themes WHERE id = :themeId LIMIT 1")
  suspend fun getThemeById(themeId: String): SavedProfileThemeEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTheme(theme: SavedProfileThemeEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertThemes(themes: List<SavedProfileThemeEntity>)

  @Query("UPDATE saved_profile_themes SET isEquipped = 0 WHERE userId = :userId")
  suspend fun unequipAllForUser(userId: String)

  @Query("UPDATE saved_profile_themes SET isEquipped = :equipped WHERE id = :themeId")
  suspend fun setThemeEquipped(themeId: String, equipped: Boolean)

  @Delete
  suspend fun deleteTheme(theme: SavedProfileThemeEntity)
}
