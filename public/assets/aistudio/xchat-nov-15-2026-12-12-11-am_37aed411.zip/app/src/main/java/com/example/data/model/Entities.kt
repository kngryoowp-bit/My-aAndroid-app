package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
  @PrimaryKey val id: String,
  val username: String,
  val displayName: String,
  val email: String,
  val passwordHash: String,
  val bio: String = "Hello world! I'm a new member on XChat.",
  val pronouns: String = "He/Him",
  val avatarUri: String? = null,
  val bannerUri: String? = null,
  val profileColor: Long = 0xFFC4C9D4L,
  val subscriptionTier: String = "FREE", // "FREE", "ASTRIX", "ASTRAL"
  val xitBalance: Long = 250L,
  val isOwner: Boolean = false,
  val isBanned: Boolean = false,
  val equippedBadges: String = "early_supporter",
  val equippedFrame: String? = null,
  val equippedNameplate: String? = null,
  val equippedEffect: String? = null,
  val messageBubbleStyle: String = "comfortable",
  val allowProfileVisitors: Boolean = true,
  val displayNameFont: String = "SERIF",
  val displayNameColorsCsv: String = "0xFFF5F7FA,0xFFC4C9D4",
  val profileBgColorsCsv: String = "0xFF07080B,0xFF111318,0xFF1A1D24",
  val chatBubbleBgCsv: String = "0xFF1C2029,0xFF2B303D",
  val chatBubbleImageUri: String? = null,
  val appThemeId: String = "obsidian_marble",
  val appThemeGradientCsv: String = "",
  val appFontKey: String = "SERIF",
  val languageCode: String = "en",
  val boostBalance: Int = 0,
  val displayNameEffect: String = "GRADIENT",
  val presenceStatus: String = "ONLINE", // "ONLINE", "IDLE", "DND", "OFFLINE"
  val statusTag: String = "",
  val lastSeenAt: Long = System.currentTimeMillis(),
  val typingChannelId: String? = null,
  val typingUpdatedAt: Long = 0L,
  val connectionsJson: String = "",
  val activeAppName: String? = null,
  val activeAppPackage: String? = null,
  val activeAppStartedAt: Long = 0L,
  // XChat V2.0 fields
  val level: Int = 1,
  val xp: Long = 0L,
  val followersCount: Int = 0,
  val followingCount: Int = 0,
  val unlockedBadgesProgressJson: String = "",
  val customWallpaperUri: String? = null,
  val wallpaperMode: String = "MARBLE", // "MARBLE", "IMAGE", "GIF", "VIDEO", "GRADIENT"
  val wallpaperGradientCsv: String = "0xFF07080B,0xFF111318,0xFF1E222A",
  val wallpaperBlur: Float = 0f,
  val wallpaperOpacity: Float = 0.85f,
  val wallpaperBrightness: Float = 0.9f,
  val wallpaperTintHex: Long = 0xFF07080BL,
  val lowPerfMode: Boolean = false,
  val soundEnabled: Boolean = true,
  val soundVolume: Float = 0.75f,
  val mutedSoundCategoriesCsv: String = "",
  val notifPrefsJson: String = "",
  val listeningTitle: String? = null,
  val listeningArtist: String? = null,
  val listeningCoverUri: String? = null,
  val listeningSourceUrl: String? = null,
  val listeningDurationMs: Long = 0L,
  val listeningPositionMs: Long = 0L,
  val listeningIsPlaying: Boolean = false,
  val listeningPrivacy: String = "PUBLIC", // "PUBLIC", "FRIENDS", "PRIVATE"
  val isLocked: Boolean = false,
  val lockReason: String = "",
  val lockMessage: String = "",
  val lockStartedAt: Long = 0L,
  val lockExpiresAt: Long = 0L,
  val adminRole: String = "NONE", // "NONE", "SUPPORT", "MODERATOR", "ADMIN", "SUPER_ADMIN", "OWNER"
  val accentColorHex: Long = 0xFFC4C9D4L,
  val invisibleServerIdsCsv: String = "",
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "servers")
data class ServerEntity(
  @PrimaryKey val id: String,
  val name: String,
  val description: String,
  val iconUri: String? = null,
  val bannerUri: String? = null,
  val inviteCode: String,
  val ownerId: String,
  val boostLevel: Int = 1,
  val boostCount: Int = 0,
  val category: String = "Komunitas",
  val serverType: String = "Komunitas",
  val serverTag: String = "#Santai",
  val serverTagIcon: String = "shield",
  val serverGenre: String = "Umum",
  val supportedGame: String? = null,
  val isVanished: Boolean = false,
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "channel_categories")
data class ChannelCategoryEntity(
  @PrimaryKey val id: String,
  val serverId: String,
  val name: String,
  val orderIndex: Int = 0,
  val isCollapsed: Boolean = false,
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "server_members")
data class ServerMemberEntity(
  @PrimaryKey val id: String,
  val serverId: String,
  val userId: String,
  val nickname: String? = null,
  val role: String = "Member",
  val roleColor: Long = 0xFF949BA4,
  val roleIconUri: String? = null,
  val roleChromaColorsCsv: String = "",
  val joinedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "server_roles")
data class ServerRoleEntity(
  @PrimaryKey val id: String,
  val serverId: String,
  val name: String,
  val colorHex: Long = 0xFFC4C9D4L,
  val iconUri: String? = null,
  val chromaKeyColorsCsv: String = "",
  val permissionsCsv: String = "SEND_MESSAGES",
  val position: Int = 0
)

@Entity(tableName = "channels")
data class ChannelEntity(
  @PrimaryKey val id: String,
  val serverId: String,
  val name: String,
  val description: String,
  val type: String = "text", // "text", "voice", "announcements", "rules", "forums", "media"
  val isPrivate: Boolean = false,
  val orderIndex: Int = 0,
  val categoryId: String = ""
)

@Entity(tableName = "messages")
data class MessageEntity(
  @PrimaryKey val id: String,
  val channelId: String,
  val senderId: String,
  val senderName: String,
  val senderAvatarUri: String? = null,
  val senderFrameId: String? = null,
  val senderTier: String = "FREE",
  val senderBadges: String = "",
  val senderDisplayFont: String = "SERIF",
  val senderDisplayColorsCsv: String = "",
  val senderDisplayEffect: String = "GRADIENT",
  val senderServerTag: String? = null,
  val senderServerTagIcon: String? = null,
  val senderRoleIconUri: String? = null,
  val senderRoleChromaCsv: String = "",
  val senderRoleColor: Long = 0xFF949BA4,
  val content: String,
  val attachmentUri: String? = null,
  val attachmentName: String? = null,
  val attachmentMimeType: String? = null,
  val attachmentSizeBytes: Long = 0L,
  val attachmentDurationMs: Long = 0L,
  val replyToMessageId: String? = null,
  val replyToSnippet: String? = null,
  val isPinned: Boolean = false,
  val isEdited: Boolean = false,
  val reactions: String = "",
  val readByCsv: String = "",
  val forwardedFromId: String? = null,
  val forwardedFromName: String? = null,
  val locationLat: Double? = null,
  val locationLng: Double? = null,
  val locationLabel: String? = null,
  val locationLiveUntil: Long = 0L,
  val stickerId: String? = null,
  val gameInviteMatchId: String? = null,
  val mentionTargetsCsv: String = "",
  val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "forum_posts")
data class ForumPostEntity(
  @PrimaryKey val id: String,
  val channelId: String,
  val authorId: String,
  val authorName: String,
  val authorAvatarUri: String? = null,
  val title: String,
  val content: String = "",
  val imageUri: String? = null,
  val tagLabel: String = "Meta",
  val tagEmoji: String = "❗",
  val isPinned: Boolean = false,
  val replyCount: Int = 0,
  val reactionCount: Int = 0,
  val reactionEmoji: String = "🔥",
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "forum_replies")
data class ForumReplyEntity(
  @PrimaryKey val id: String,
  val postId: String,
  val channelId: String,
  val authorId: String,
  val authorName: String,
  val authorAvatarUri: String? = null,
  val content: String,
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "direct_messages")
data class DirectMessageEntity(
  @PrimaryKey val id: String,
  val conversationId: String,
  val senderId: String,
  val senderName: String,
  val receiverId: String,
  val content: String,
  val attachmentUri: String? = null,
  val attachmentName: String? = null,
  val attachmentMimeType: String? = null,
  val attachmentSizeBytes: Long = 0L,
  val attachmentDurationMs: Long = 0L,
  val replyToMessageId: String? = null,
  val replyToSnippet: String? = null,
  val isEdited: Boolean = false,
  val isDeleted: Boolean = false,
  val reactions: String = "",
  val forwardedFromId: String? = null,
  val forwardedFromName: String? = null,
  val locationLat: Double? = null,
  val locationLng: Double? = null,
  val locationLabel: String? = null,
  val locationLiveUntil: Long = 0L,
  val stickerId: String? = null,
  val gameInviteMatchId: String? = null,
  val timestamp: Long = System.currentTimeMillis(),
  val isRead: Boolean = false
)

@Entity(tableName = "friends")
data class FriendEntity(
  @PrimaryKey val id: String,
  val userId: String,
  val friendId: String,
  val friendUsername: String,
  val friendDisplayName: String,
  val friendAvatarUri: String? = null,
  val status: String = "ACCEPTED",
  val isOnline: Boolean = true,
  val statusText: String = "Online",
  val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_follows")
data class UserFollowEntity(
  @PrimaryKey val id: String,
  val followerId: String,
  val targetUserId: String,
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_game_apps")
data class UserGameAppEntity(
  @PrimaryKey val id: String,
  val userId: String,
  val name: String,
  val iconKey: String = "gamepad",
  val iconUri: String? = null,
  val description: String = "",
  val activityStatus: String = "",
  val appLink: String = "",
  val category: String = "Game",
  val orderIndex: Int = 0,
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sticker_packs")
data class StickerPackEntity(
  @PrimaryKey val id: String,
  val creatorId: String,
  val creatorName: String,
  val name: String,
  val description: String = "",
  val coverUri: String? = null,
  val isShared: Boolean = true,
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "stickers")
data class StickerEntity(
  @PrimaryKey val id: String,
  val packId: String,
  val creatorId: String,
  val name: String,
  val imageUri: String,
  val overlayText: String = "",
  val textColorHex: Long = 0xFFFFFFFFL,
  val outlineColorHex: Long = 0xFF000000L,
  val hasGlow: Boolean = false,
  val hasShadow: Boolean = true,
  val isFavorite: Boolean = false,
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "gif_favorites")
data class GifFavoriteEntity(
  @PrimaryKey val id: String,
  val userId: String,
  val gifUrl: String,
  val previewUrl: String,
  val title: String = "",
  val category: String = "Trending",
  val isRecent: Boolean = false,
  val isFavorite: Boolean = false,
  val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
  @PrimaryKey val id: String,
  val userId: String,
  val name: String,
  val coverUri: String? = null,
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "audio_tracks")
data class AudioTrackEntity(
  @PrimaryKey val id: String,
  val playlistId: String,
  val userId: String,
  val title: String,
  val artist: String,
  val coverUri: String? = null,
  val sourceUri: String,
  val sourceType: String = "LOCAL", // "LOCAL", "URL", "SPOTIFY", "YOUTUBE"
  val durationMs: Long = 0L,
  val orderIndex: Int = 0,
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "game_matches")
data class GameMatchEntity(
  @PrimaryKey val id: String,
  val gameType: String, // "TIC_TAC_TOE", "CHESS", "CONNECT_FOUR", "REVERSI"
  val mode: String = "CLASSIC", // "CLASSIC", "RANKED", "TOURNAMENT"
  val tournamentId: String? = null,
  val channelOrConvId: String,
  val challengerId: String,
  val challengerName: String,
  val opponentId: String,
  val opponentName: String,
  val status: String = "INVITED", // "INVITED", "ACTIVE", "FINISHED", "DECLINED"
  val turnUserId: String,
  val boardStateJson: String,
  val movesJson: String = "[]",
  val winnerId: String? = null,
  val whiteTimeMs: Long = 300_000L,
  val blackTimeMs: Long = 300_000L,
  val lastMoveAt: Long = System.currentTimeMillis(),
  val drawOfferedBy: String? = null,
  val createdAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "game_ratings")
data class GameRatingEntity(
  @PrimaryKey val id: String,
  val userId: String,
  val username: String,
  val displayName: String,
  val gameType: String,
  val elo: Int = 1000,
  val wins: Int = 0,
  val losses: Int = 0,
  val draws: Int = 0,
  val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "tournaments")
data class TournamentEntity(
  @PrimaryKey val id: String,
  val name: String,
  val gameType: String,
  val creatorId: String,
  val status: String = "OPEN", // "OPEN", "IN_PROGRESS", "COMPLETED"
  val participantsCsv: String = "",
  val bracketJson: String = "[]",
  val winnerId: String? = null,
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "redeem_codes")
data class RedeemCodeEntity(
  @PrimaryKey val id: String,
  val code: String,
  val rewardXit: Long = 200L,
  val rewardBoosts: Int = 0,
  val rewardBadgeId: String? = null,
  val maxUses: Int = 100,
  val usedCount: Int = 0,
  val usedByCsv: String = "",
  val expiresAt: Long = 0L,
  val isActive: Boolean = true,
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_restrictions")
data class UserRestrictionEntity(
  @PrimaryKey val id: String,
  val userId: String,
  val username: String,
  val adminId: String,
  val adminRole: String = "ADMIN",
  val reason: String,
  val customMessage: String,
  val startedAt: Long = System.currentTimeMillis(),
  val expiresAt: Long = 0L,
  val isActive: Boolean = true,
  val appealStatus: String = "NONE", // "NONE", "PENDING", "APPROVED", "REJECTED"
  val appealMessage: String = "",
  val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "reports")
data class ReportEntity(
  @PrimaryKey val id: String,
  val reporterId: String,
  val reporterName: String,
  val targetUserId: String? = null,
  val targetServerId: String? = null,
  val targetMessageId: String? = null,
  val reason: String,
  val details: String = "",
  val status: String = "OPEN", // "OPEN", "INVESTIGATING", "RESOLVED", "DISMISSED"
  val handledBy: String? = null,
  val resolutionNote: String = "",
  val createdAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "call_sessions")
data class CallSessionEntity(
  @PrimaryKey val id: String,
  val callType: String = "DM_VOICE", // "DM_VOICE", "DM_VIDEO", "SERVER_VOICE"
  val callerId: String,
  val callerName: String,
  val callerAvatarUri: String? = null,
  val calleeId: String,
  val calleeName: String,
  val channelId: String? = null,
  val serverId: String? = null,
  val status: String = "RINGING", // "RINGING", "ACTIVE", "ENDED", "DECLINED", "RECONNECTING"
  val offerSdp: String? = null,
  val answerSdp: String? = null,
  val qualityLabel: String = "HD",
  val startedAt: Long = System.currentTimeMillis(),
  val endedAt: Long = 0L,
  val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notifications")
data class NotificationEntity(
  @PrimaryKey val id: String,
  val userId: String,
  val title: String,
  val message: String,
  val type: String = "MENTION",
  val isRead: Boolean = false,
  val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "marketplace_items")
data class MarketplaceItemEntity(
  @PrimaryKey val id: String,
  val name: String,
  val category: String,
  val priceXit: Long,
  val description: String,
  val previewColor: Long = 0xFFC4C9D4L,
  val iconType: String = "palette",
  val isAstralOnly: Boolean = false
)

@Entity(tableName = "user_inventory")
data class UserInventoryEntity(
  @PrimaryKey val id: String,
  val userId: String,
  val itemId: String,
  val isEquipped: Boolean = false,
  val acquiredAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "quests")
data class QuestEntity(
  @PrimaryKey val id: String,
  val title: String,
  val category: String = "DAILY",
  val description: String,
  val rewardXit: Long = 50L,
  val targetCount: Int = 1,
  val currentCount: Int = 0,
  val isClaimed: Boolean = false
)

@Entity(tableName = "payment_requests")
data class PaymentRequestEntity(
  @PrimaryKey val id: String,
  val userId: String,
  val username: String,
  val targetTier: String,
  val senderName: String,
  val senderAccount: String,
  val destinationNumber: String = "088212365499",
  val slipUri: String? = null,
  val status: String = "PENDING",
  val amountIdr: String = "Rp 35.000",
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
  @PrimaryKey val id: String,
  val actorUsername: String,
  val action: String,
  val details: String,
  val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "profile_visitors")
data class ProfileVisitorEntity(
  @PrimaryKey val id: String,
  val profileUserId: String,
  val visitorUserId: String,
  val visitorUsername: String,
  val visitorAvatarUri: String? = null,
  val visitedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "saved_profile_themes")
data class SavedProfileThemeEntity(
  @PrimaryKey val id: String,
  val userId: String,
  val name: String,
  val displayNameFont: String = "SERIF",
  val displayNameColorsCsv: String = "0xFFF5F7FA,0xFFC4C9D4",
  val displayNameEffect: String = "GRADIENT",
  val profileBgColorsCsv: String = "0xFF07080B,0xFF111318,0xFF1A1D24",
  val profileColor: Long = 0xFFC4C9D4L,
  val equippedEffect: String? = null,
  val chatBubbleBgCsv: String = "0xFF1C2029,0xFF2B303D",
  val chatBubbleImageUri: String? = null,
  val appThemeId: String = "obsidian_marble",
  val appThemeGradientCsv: String = "",
  val appFontKey: String = "SERIF",
  val isEquipped: Boolean = false,
  val createdAt: Long = System.currentTimeMillis()
)

data class VoiceParticipantModel(
  val userId: String = "",
  val channelId: String = "",
  val serverId: String = "",
  val displayName: String = "",
  val avatarUri: String? = null,
  val isMuted: Boolean = false,
  val isDeafened: Boolean = false,
  val isCameraOn: Boolean = false,
  val isScreenSharing: Boolean = false,
  val isSpeaking: Boolean = false,
  val audioQuality: String = "HD",
  val updatedAt: Long = System.currentTimeMillis()
)
