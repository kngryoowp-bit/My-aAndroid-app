package com.example.data.remote

import android.content.Context
import com.example.R
import com.example.data.model.*
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.security.MessageDigest

class FirestoreCloudRepository(
  private val db: FirebaseFirestore,
  private val auth: FirebaseAuth = Firebase.auth
) {
  constructor(context: Context) : this(
    FirebaseFirestore.getInstance(
      context.applicationContext.getString(R.string.firestore_database_id)
    ),
    Firebase.auth
  )

  private fun requireUserId(): String {
    return auth.currentUser?.uid
      ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
  }

  fun currentUidOrNull(): String? = auth.currentUser?.uid

  private inline fun <T> safeSnapshotFlow(
    path: String,
    operationType: OperationType,
    crossinline flowProvider: () -> Flow<T>
  ): Flow<T> = flow {
    val uid = requireUserId()
    emitAll(
      flowProvider().catch { error ->
        val firestoreError = generateSequence(error) { it.cause }
          .filterIsInstance<com.google.firebase.firestore.FirebaseFirestoreException>()
          .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exToLog = firestoreError ?: (error as? Exception)
        if (exToLog != null && auth.currentUser?.uid == uid) {
          handleFirestoreError(exToLog, operationType, path)
        }
        throw error
      }
    )
  }

  // --- ADMIN VERIFICATION & RBAC ---

  suspend fun registerAdminRecord(keyInput: String? = null) {
    val uid = requireUserId()
    val docRef = db.collection("admins").document(uid)
    val keyHash = if (!keyInput.isNullOrBlank()) {
      MessageDigest.getInstance("SHA-256")
        .digest(keyInput.trim().toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
    } else {
      "ce0f6602acd6389de048bd0d20e65b74c08f669af0a1b1112c8a88534829944a"
    }
    val payload = mapOf(
      "uid" to uid,
      "keyHash" to keyHash,
      "role" to "OWNER",
      "updatedAt" to FieldValue.serverTimestamp()
    )
    try {
      docRef.set(payload).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
    }
  }

  suspend fun checkVerifiedAdminRole(): String {
    val uid = auth.currentUser?.uid ?: return "NONE"
    return try {
      val snap = db.collection("admins").document(uid).get().await()
      if (!snap.exists()) "NONE" else (snap.getString("role") ?: "OWNER")
    } catch (_: Exception) {
      "NONE"
    }
  }

  suspend fun assignAdminRoleRecord(targetUid: String, role: String) {
    requireUserId()
    val docRef = db.collection("admins").document(targetUid)
    try {
      if (role == "NONE") {
        docRef.delete().await()
      } else {
        docRef.set(
          mapOf(
            "uid" to targetUid,
            "role" to role,
            "updatedAt" to FieldValue.serverTimestamp()
          ),
          SetOptions.merge()
        ).await()
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
    }
  }

  // --- USER PROFILE & PRIVATE SETTINGS ---

  suspend fun ensureUserProfile(
    firebaseUser: FirebaseUser,
    preferredUsername: String? = null,
    preferredDisplayName: String? = null
  ): UserEntity {
    val uid = firebaseUser.uid
    val userRef = db.collection("users").document(uid)
    val snap = try {
      userRef.get().await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.GET, userRef.path)
      throw e
    }

    val isRidhoOwner = firebaseUser.email.equals("kngryoowp@gmail.com", ignoreCase = true)
    if (isRidhoOwner) {
      runCatching { registerAdminRecord() }
    }

    val cleanPrefUser = preferredUsername?.trim()?.lowercase()?.replace(Regex("[^a-z0-9_]"), "_")
      ?.takeIf { it.length >= 2 }?.take(32)
    val cleanPrefDisp = preferredDisplayName?.trim()?.takeIf { it.isNotBlank() }?.take(60)

    if (snap.exists()) {
      val existing = snap.toUserEntity()
      val needsPrefUpdate = (cleanPrefUser != null && cleanPrefUser != existing.username) ||
        (cleanPrefDisp != null && cleanPrefDisp != existing.displayName)
      val needsOwnerPatch = isRidhoOwner && (!existing.isOwner || existing.subscriptionTier != "ASTRAL" || existing.adminRole != "OWNER")
      if (needsOwnerPatch || needsPrefUpdate) {
        val patched = existing.copy(
          username = cleanPrefUser ?: existing.username,
          displayName = cleanPrefDisp ?: existing.displayName,
          isOwner = if (isRidhoOwner) true else existing.isOwner,
          adminRole = if (isRidhoOwner) "OWNER" else existing.adminRole,
          subscriptionTier = if (isRidhoOwner) "ASTRAL" else existing.subscriptionTier,
          boostBalance = if (isRidhoOwner) 999999 else existing.boostBalance,
          xitBalance = if (isRidhoOwner) 999999999L else existing.xitBalance
        )
        upsertPublicProfile(patched, isCreate = false)
        return patched.copy(email = firebaseUser.email ?: "")
      }
      return existing.copy(email = firebaseUser.email ?: "")
    }

    val emailPrefix = firebaseUser.email?.substringBefore("@")
      ?.lowercase()?.replace(Regex("[^a-z0-9_]"), "_")
      ?.take(20)
      ?: "user"
    val cleanUsername = (preferredUsername?.trim()?.lowercase()?.replace(Regex("[^a-z0-9_]"), "_"))
      ?.takeIf { it.length >= 2 }
      ?: if (isRidhoOwner) "ridho" else "${emailPrefix}_${uid.take(4).lowercase()}"
    val cleanDisplay = preferredDisplayName?.trim()?.takeIf { it.isNotBlank() }
      ?: firebaseUser.displayName?.takeIf { it.isNotBlank() }
      ?: cleanUsername

    val created = UserEntity(
      id = uid,
      username = cleanUsername.take(32),
      displayName = cleanDisplay.take(60),
      email = firebaseUser.email ?: "",
      passwordHash = "",
      bio = if (isRidhoOwner) "Owner & Master Architect XChat." else "Hello world! I'm a new member on XChat.",
      pronouns = "He/Him",
      avatarUri = firebaseUser.photoUrl?.toString(),
      bannerUri = null,
      profileColor = 0xFFC4C9D4L,
      accentColorHex = 0xFFC4C9D4L,
      appThemeId = "obsidian_marble",
      wallpaperMode = "MARBLE",
      languageCode = "en",
      subscriptionTier = if (isRidhoOwner) "ASTRAL" else "FREE",
      xitBalance = if (isRidhoOwner) 999999999L else 300L,
      boostBalance = if (isRidhoOwner) 999999 else 0,
      isOwner = isRidhoOwner,
      adminRole = if (isRidhoOwner) "OWNER" else "NONE",
      isBanned = false,
      equippedBadges = if (isRidhoOwner) "owner,astral,developer,programmer,early_supporter,server_booster,xit_claimer" else "early_supporter",
      equippedFrame = if (isRidhoOwner) "frame_royal_gold" else null,
      equippedNameplate = if (isRidhoOwner) "np_hologram" else null,
      equippedEffect = if (isRidhoOwner) "eff_sparkles" else null,
      presenceStatus = "ONLINE",
      statusTag = "",
      lastSeenAt = System.currentTimeMillis(),
      createdAt = System.currentTimeMillis()
    )

    upsertPublicProfile(created, isCreate = true)
    upsertPrivateInfo(
      userId = uid,
      email = firebaseUser.email,
      languageCode = "en",
      allowProfileVisitors = true
    )
    return created
  }

  suspend fun createOrUpdateOwnProfile(
    username: String,
    displayName: String,
    bio: String = "Hello world! I'm a member of XChat.",
    subscriptionTier: String = "FREE",
    presenceStatus: String = "ONLINE",
    statusTag: String = ""
  ): Result<UserEntity> {
    val uid = requireUserId()
    val userRef = db.collection("users").document(uid)
    val snap = try {
      userRef.get().await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.GET, userRef.path)
      return Result.failure(e)
    }

    val entity = UserEntity(
      id = uid,
      username = username.trim().take(32),
      displayName = displayName.trim().take(60),
      email = auth.currentUser?.email ?: "",
      passwordHash = "",
      bio = bio,
      subscriptionTier = subscriptionTier,
      presenceStatus = presenceStatus,
      statusTag = statusTag,
      lastSeenAt = System.currentTimeMillis()
    )
    return try {
      upsertPublicProfile(entity, isCreate = !snap.exists())
      upsertPrivateInfo(uid, auth.currentUser?.email, "en", true)
      Result.success(entity)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun upsertPublicProfile(user: UserEntity, isCreate: Boolean? = null) {
    val uid = requireUserId()
    val docRef = db.collection("users").document(user.id)
    val shouldCreate = isCreate ?: !(try { docRef.get().await().exists() } catch (_: Exception) { true })

    val safeTier = when (user.subscriptionTier.uppercase()) {
      "ASTRAL", "VIP" -> "ASTRAL"
      "ASTRIX", "PREM" -> "ASTRIX"
      else -> "FREE"
    }
    val safePresence = when (user.presenceStatus.uppercase()) {
      "IDLE", "DND", "OFFLINE" -> user.presenceStatus.uppercase()
      else -> "ONLINE"
    }
    val safeListeningPrivacy = when (user.listeningPrivacy.uppercase()) {
      "FRIENDS", "PRIVATE" -> user.listeningPrivacy.uppercase()
      else -> "PUBLIC"
    }

    val map = mutableMapOf<String, Any?>(
      "username" to user.username.ifBlank { "user_${user.id.take(4)}" }.take(32),
      "displayName" to user.displayName.ifBlank { user.username }.take(60),
      "bio" to user.bio.take(500),
      "pronouns" to user.pronouns.take(40),
      "avatarUri" to user.avatarUri,
      "bannerUri" to user.bannerUri,
      "profileColor" to user.profileColor,
      "accentColorHex" to user.accentColorHex,
      "subscriptionTier" to safeTier,
      "xitBalance" to user.xitBalance,
      "boostBalance" to user.boostBalance.toLong(),
      "level" to user.level.toLong(),
      "xp" to user.xp,
      "followingCount" to user.followingCount.toLong(),
      "isOwner" to user.isOwner,
      "equippedBadges" to user.equippedBadges.take(1200),
      "unlockedBadgesProgressJson" to user.unlockedBadgesProgressJson.take(8000),
      "invisibleServerIdsCsv" to user.invisibleServerIdsCsv.take(2000),
      "equippedFrame" to user.equippedFrame,
      "equippedNameplate" to user.equippedNameplate,
      "equippedEffect" to user.equippedEffect,
      "displayNameFont" to user.displayNameFont,
      "displayNameColorsCsv" to user.displayNameColorsCsv,
      "displayNameEffect" to user.displayNameEffect,
      "profileBgColorsCsv" to user.profileBgColorsCsv,
      "chatBubbleBgCsv" to user.chatBubbleBgCsv,
      "chatBubbleImageUri" to user.chatBubbleImageUri,
      "appThemeId" to user.appThemeId.take(60),
      "appThemeGradientCsv" to user.appThemeGradientCsv.take(200),
      "appFontKey" to user.appFontKey.take(30),
      "wallpaperMode" to user.wallpaperMode.take(30),
      "customWallpaperUri" to user.customWallpaperUri,
      "presenceStatus" to safePresence,
      "statusTag" to user.statusTag.take(100),
      "lastSeenAt" to user.lastSeenAt,
      "typingChannelId" to user.typingChannelId,
      "typingUpdatedAt" to user.typingUpdatedAt,
      "connectionsJson" to user.connectionsJson.take(4000),
      "activeAppName" to user.activeAppName?.take(100),
      "activeAppPackage" to user.activeAppPackage?.take(160),
      "activeAppStartedAt" to user.activeAppStartedAt,
      "listeningTitle" to user.listeningTitle?.take(160),
      "listeningArtist" to user.listeningArtist?.take(160),
      "listeningCoverUri" to user.listeningCoverUri,
      "listeningSourceUrl" to user.listeningSourceUrl?.take(500),
      "listeningIsPlaying" to user.listeningIsPlaying,
      "listeningPrivacy" to safeListeningPrivacy,
      "updatedAt" to FieldValue.serverTimestamp()
    )

    try {
      if (shouldCreate) {
        map["ownerUid"] = uid
        map["isBanned"] = user.isBanned
        map["isLocked"] = user.isLocked
        map["adminRole"] = user.adminRole
        map["followersCount"] = user.followersCount.toLong()
        map["isPublicProfile"] = true
        map["createdAt"] = FieldValue.serverTimestamp()
        docRef.set(map.filterValues { it != null }).await()
      } else {
        docRef.set(map, SetOptions.merge()).await()
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, if (shouldCreate) OperationType.CREATE else OperationType.UPDATE, docRef.path)
      throw e
    }
  }

  suspend fun adminUpdateUserFields(
    targetUserId: String,
    subscriptionTier: String? = null,
    xitBalance: Long? = null,
    boostBalance: Int? = null,
    level: Int? = null,
    xp: Long? = null,
    isBanned: Boolean? = null,
    isLocked: Boolean? = null,
    adminRole: String? = null,
    equippedBadges: String? = null,
    unlockedBadgesProgressJson: String? = null,
    invisibleServerIdsCsv: String? = null
  ) {
    requireUserId()
    val docRef = db.collection("users").document(targetUserId)
    val updates = mutableMapOf<String, Any>("updatedAt" to FieldValue.serverTimestamp())
    subscriptionTier?.let { updates["subscriptionTier"] = it }
    xitBalance?.let { updates["xitBalance"] = it }
    boostBalance?.let { updates["boostBalance"] = it.toLong() }
    level?.let { updates["level"] = it.toLong() }
    xp?.let { updates["xp"] = it }
    isBanned?.let { updates["isBanned"] = it }
    isLocked?.let { updates["isLocked"] = it }
    adminRole?.let { updates["adminRole"] = it }
    equippedBadges?.let { updates["equippedBadges"] = it.take(1200) }
    unlockedBadgesProgressJson?.let { updates["unlockedBadgesProgressJson"] = it.take(8000) }
    invisibleServerIdsCsv?.let { updates["invisibleServerIdsCsv"] = it.take(2000) }
    try {
      docRef.update(updates).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
    }
  }

  suspend fun deleteUserRemote(targetUserId: String) {
    requireUserId()
    val docRef = db.collection("users").document(targetUserId)
    try {
      docRef.delete().await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, docRef.path)
    }
  }

  suspend fun updateFollowersCountRemote(targetUserId: String, delta: Long) {
    requireUserId()
    val docRef = db.collection("users").document(targetUserId)
    try {
      docRef.update(
        mapOf(
          "followersCount" to FieldValue.increment(delta),
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
    } catch (_: Exception) {
    }
  }

  suspend fun updatePresenceAndTyping(
    presenceStatus: String? = null,
    statusTag: String? = null,
    typingChannelId: String? = null,
    updateTyping: Boolean = false
  ) {
    val uid = auth.currentUser?.uid ?: return
    val docRef = db.collection("users").document(uid)
    val updates = mutableMapOf<String, Any?>(
      "lastSeenAt" to System.currentTimeMillis(),
      "updatedAt" to FieldValue.serverTimestamp()
    )
    if (presenceStatus != null) updates["presenceStatus"] = presenceStatus
    if (statusTag != null) updates["statusTag"] = statusTag.take(100)
    if (updateTyping) {
      updates["typingChannelId"] = typingChannelId
      updates["typingUpdatedAt"] = System.currentTimeMillis()
    }
    try {
      docRef.update(updates).await()
    } catch (e: CancellationException) {
      throw e
    } catch (_: Exception) {
    }
  }

  suspend fun updateActiveAppFields(appName: String?, appPkg: String?, startedAt: Long) {
    val uid = auth.currentUser?.uid ?: return
    val docRef = db.collection("users").document(uid)
    val updates = mapOf<String, Any?>(
      "activeAppName" to appName?.take(100),
      "activeAppPackage" to appPkg?.take(160),
      "activeAppStartedAt" to startedAt,
      "lastSeenAt" to System.currentTimeMillis(),
      "updatedAt" to FieldValue.serverTimestamp()
    )
    try {
      docRef.update(updates).await()
    } catch (_: Exception) {
    }
  }

  suspend fun updateListeningStatusRemote(
    title: String?,
    artist: String?,
    coverUri: String?,
    sourceUrl: String?,
    isPlaying: Boolean,
    privacy: String
  ) {
    val uid = auth.currentUser?.uid ?: return
    val docRef = db.collection("users").document(uid)
    val updates = mapOf<String, Any?>(
      "listeningTitle" to title?.take(160),
      "listeningArtist" to artist?.take(160),
      "listeningCoverUri" to coverUri,
      "listeningSourceUrl" to sourceUrl?.take(500),
      "listeningIsPlaying" to isPlaying,
      "listeningPrivacy" to privacy,
      "updatedAt" to FieldValue.serverTimestamp()
    )
    try {
      docRef.update(updates).await()
    } catch (_: Exception) {
    }
  }

  suspend fun upsertSavedTheme(theme: SavedProfileThemeEntity) {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid).collection("saved_themes").document(theme.id)
    val payload = mutableMapOf<String, Any?>(
      "userId" to uid,
      "name" to theme.name.take(40),
      "displayNameFont" to theme.displayNameFont,
      "displayNameColorsCsv" to theme.displayNameColorsCsv,
      "displayNameEffect" to theme.displayNameEffect,
      "profileBgColorsCsv" to theme.profileBgColorsCsv,
      "profileColor" to theme.profileColor,
      "equippedEffect" to theme.equippedEffect,
      "chatBubbleBgCsv" to theme.chatBubbleBgCsv,
      "chatBubbleImageUri" to theme.chatBubbleImageUri,
      "appThemeId" to theme.appThemeId,
      "appThemeGradientCsv" to theme.appThemeGradientCsv,
      "appFontKey" to theme.appFontKey,
      "isEquipped" to theme.isEquipped,
      "createdAtMs" to theme.createdAt
    ).filterValues { it != null }
    try {
      docRef.set(payload).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
    }
  }

  suspend fun deleteSavedTheme(themeId: String) {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid).collection("saved_themes").document(themeId)
    try {
      docRef.delete().await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, docRef.path)
    }
  }

  fun observeSavedThemes(userId: String): Flow<List<SavedProfileThemeEntity>> =
    safeSnapshotFlow("users/$userId/saved_themes", OperationType.LIST) {
      db.collection("users").document(userId).collection("saved_themes")
        .snapshots()
        .map { snap -> snap.documents.mapNotNull { it.toSavedProfileThemeSafe() } }
    }

  suspend fun upsertPrivateInfo(
    userId: String,
    email: String?,
    languageCode: String,
    allowProfileVisitors: Boolean,
    soundEnabled: Boolean = true,
    soundVolume: Float = 0.75f,
    lowPerfMode: Boolean = false,
    notifPrefsJson: String = ""
  ) {
    requireUserId()
    val docRef = db.collection("users").document(userId).collection("private").document("info")
    val payload = mutableMapOf<String, Any>(
      "userId" to userId,
      "languageCode" to languageCode.take(12),
      "allowProfileVisitors" to allowProfileVisitors,
      "soundEnabled" to soundEnabled,
      "soundVolume" to soundVolume.toDouble(),
      "lowPerfMode" to lowPerfMode,
      "notifPrefsJson" to notifPrefsJson.take(2000),
      "updatedAt" to FieldValue.serverTimestamp()
    )
    if (!email.isNullOrBlank()) {
      payload["email"] = email.take(160)
    }
    try {
      docRef.set(payload).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
      throw e
    }
  }

  suspend fun readPrivateInfo(userId: String): Result<Map<String, Any?>?> {
    requireUserId()
    val docRef = db.collection("users").document(userId).collection("private").document("info")
    return try {
      val snap = docRef.get().await()
      Result.success(snap.data)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.GET, docRef.path)
      Result.failure(e)
    }
  }

  fun observePublicUsers(): Flow<List<UserEntity>> =
    safeSnapshotFlow("users", OperationType.LIST) {
      db.collection("users")
        .whereEqualTo("isPublicProfile", true)
        .snapshots()
        .map { snap -> snap.documents.mapNotNull { it.toUserEntitySafe() } }
    }

  suspend fun findUserByUsernameOnce(username: String): UserEntity? {
    requireUserId()
    val clean = username.trim().removePrefix("@").lowercase()
    return try {
      val snap = db.collection("users")
        .whereEqualTo("isPublicProfile", true)
        .whereEqualTo("username", clean)
        .limit(1)
        .get()
        .await()
      snap.documents.firstOrNull()?.toUserEntitySafe()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.LIST, "users")
      null
    }
  }

  // --- FOLLOWS & GAMES/APPS & NOTIFICATIONS ---

  suspend fun upsertFollowRemote(follow: UserFollowEntity) {
    requireUserId()
    val docRef = db.collection("follows").document(follow.id)
    val payload = mapOf(
      "followerId" to follow.followerId,
      "targetUserId" to follow.targetUserId,
      "createdAt" to FieldValue.serverTimestamp()
    )
    try {
      docRef.set(payload).await()
    } catch (_: Exception) {
    }
  }

  suspend fun deleteFollowRemote(followId: String) {
    requireUserId()
    try {
      db.collection("follows").document(followId).delete().await()
    } catch (_: Exception) {
    }
  }

  fun observeMyFollows(userId: String): Flow<List<UserFollowEntity>> =
    safeSnapshotFlow("follows", OperationType.LIST) {
      db.collection("follows")
        .whereEqualTo("followerId", userId)
        .snapshots()
        .map { snap -> snap.documents.mapNotNull { it.toUserFollowSafe() } }
    }

  fun observeMyFollowers(userId: String): Flow<List<UserFollowEntity>> =
    safeSnapshotFlow("follows", OperationType.LIST) {
      db.collection("follows")
        .whereEqualTo("targetUserId", userId)
        .snapshots()
        .map { snap -> snap.documents.mapNotNull { it.toUserFollowSafe() } }
    }

  suspend fun upsertUserGameApp(item: UserGameAppEntity) {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid).collection("games_apps").document(item.id)
    val payload = mapOf(
      "userId" to uid,
      "name" to item.name.take(80),
      "iconKey" to item.iconKey,
      "iconUri" to item.iconUri,
      "description" to item.description.take(300),
      "activityStatus" to item.activityStatus.take(100),
      "appLink" to item.appLink.take(300),
      "category" to item.category.take(40),
      "orderIndex" to item.orderIndex.toLong(),
      "createdAtMs" to item.createdAt
    ).filterValues { it != null }
    try {
      docRef.set(payload).await()
    } catch (_: Exception) {
    }
  }

  suspend fun deleteUserGameApp(appId: String) {
    val uid = requireUserId()
    try {
      db.collection("users").document(uid).collection("games_apps").document(appId).delete().await()
    } catch (_: Exception) {
    }
  }

  suspend fun fetchUserGamesAppsOnce(userId: String): List<UserGameAppEntity> {
    return try {
      db.collection("users").document(userId).collection("games_apps")
        .get().await().documents.mapNotNull { it.toUserGameAppSafe() }
    } catch (_: Exception) {
      emptyList()
    }
  }

  suspend fun sendRemoteNotification(targetUserId: String, title: String, message: String, type: String) {
    requireUserId()
    val notifId = "ntf_${System.currentTimeMillis()}_${(100..999).random()}"
    val docRef = db.collection("users").document(targetUserId).collection("notifications").document(notifId)
    val payload = mapOf(
      "userId" to targetUserId,
      "title" to title.take(140),
      "message" to message.take(600),
      "type" to type,
      "isRead" to false,
      "timestampMs" to System.currentTimeMillis()
    )
    try {
      docRef.set(payload).await()
    } catch (_: Exception) {
    }
  }

  fun observeUserNotifications(userId: String): Flow<List<NotificationEntity>> =
    safeSnapshotFlow("users/$userId/notifications", OperationType.LIST) {
      db.collection("users").document(userId).collection("notifications")
        .orderBy("timestampMs", Query.Direction.DESCENDING)
        .limit(60)
        .snapshots()
        .map { snap -> snap.documents.mapNotNull { it.toNotificationSafe() } }
    }

  suspend fun markNotificationReadRemote(userId: String, notifId: String) {
    try {
      db.collection("users").document(userId).collection("notifications").document(notifId)
        .update("isRead", true).await()
    } catch (_: Exception) {
    }
  }

  // --- SERVERS, CATEGORIES, CHANNELS, ROLES, MEMBERS ---

  suspend fun upsertServer(server: ServerEntity, isCreate: Boolean? = null) {
    val uid = requireUserId()
    val docRef = db.collection("servers").document(server.id)
    val shouldCreate = isCreate ?: !(try { docRef.get().await().exists() } catch (_: Exception) { true })

    val payload = mutableMapOf<String, Any?>(
      "name" to server.name.take(80),
      "description" to server.description.take(500),
      "iconUri" to server.iconUri,
      "bannerUri" to server.bannerUri,
      "inviteCode" to server.inviteCode.take(32),
      "boostLevel" to server.boostLevel.toLong(),
      "boostCount" to server.boostCount.toLong(),
      "serverType" to server.serverType.take(40),
      "serverTag" to server.serverTag.take(24),
      "serverTagIcon" to server.serverTagIcon,
      "serverGenre" to server.serverGenre.take(60),
      "supportedGame" to server.supportedGame?.take(400),
      "isVanished" to server.isVanished,
      "updatedAt" to FieldValue.serverTimestamp()
    )
    try {
      if (shouldCreate) {
        payload["ownerId"] = uid
        payload["isPublic"] = true
        payload["createdAt"] = FieldValue.serverTimestamp()
        docRef.set(payload.filterValues { it != null }).await()
      } else {
        docRef.set(payload, SetOptions.merge()).await()
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, if (shouldCreate) OperationType.CREATE else OperationType.UPDATE, docRef.path)
      throw e
    }
  }

  suspend fun updateServerBoostOnly(serverId: String, boostLevel: Int, boostCount: Int) {
    requireUserId()
    val docRef = db.collection("servers").document(serverId)
    try {
      docRef.update(
        mapOf(
          "boostLevel" to boostLevel.toLong(),
          "boostCount" to boostCount.toLong(),
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
    }
  }

  fun observePublicServers(): Flow<List<ServerEntity>> =
    safeSnapshotFlow("servers", OperationType.LIST) {
      db.collection("servers")
        .whereEqualTo("isPublic", true)
        .snapshots()
        .map { snap -> snap.documents.mapNotNull { it.toServerEntitySafe() } }
    }

  suspend fun upsertCategory(category: ChannelCategoryEntity) {
    requireUserId()
    val docRef = db.collection("servers").document(category.serverId).collection("categories").document(category.id)
    val payload = mapOf(
      "serverId" to category.serverId,
      "name" to category.name.take(60),
      "orderIndex" to category.orderIndex.toLong(),
      "isCollapsed" to category.isCollapsed
    )
    try {
      docRef.set(payload, SetOptions.merge()).await()
    } catch (_: Exception) {
    }
  }

  suspend fun deleteCategory(serverId: String, categoryId: String) {
    requireUserId()
    try {
      db.collection("servers").document(serverId).collection("categories").document(categoryId).delete().await()
    } catch (_: Exception) {
    }
  }

  fun observeServerCategories(serverId: String): Flow<List<ChannelCategoryEntity>> =
    safeSnapshotFlow("servers/$serverId/categories", OperationType.LIST) {
      db.collection("servers").document(serverId).collection("categories")
        .whereEqualTo("serverId", serverId)
        .snapshots()
        .map { snap -> snap.documents.mapNotNull { it.toCategoryEntitySafe() } }
    }

  suspend fun upsertChannel(channel: ChannelEntity, isUpdate: Boolean = false) {
    val uid = requireUserId()
    val docRef = db.collection("servers").document(channel.serverId).collection("channels").document(channel.id)
    try {
      if (isUpdate) {
        docRef.update(
          mapOf(
            "name" to channel.name.take(60),
            "description" to channel.description.take(300),
            "type" to channel.type,
            "categoryId" to channel.categoryId,
            "orderIndex" to channel.orderIndex.toLong()
          )
        ).await()
      } else {
        val payload = mapOf(
          "serverId" to channel.serverId,
          "name" to channel.name.take(60),
          "description" to channel.description.take(300),
          "type" to channel.type,
          "categoryId" to channel.categoryId,
          "orderIndex" to channel.orderIndex.toLong(),
          "createdBy" to uid,
          "createdAt" to FieldValue.serverTimestamp()
        )
        docRef.set(payload).await()
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, if (isUpdate) OperationType.UPDATE else OperationType.CREATE, docRef.path)
    }
  }

  fun observeServerChannels(serverId: String): Flow<List<ChannelEntity>> =
    safeSnapshotFlow("servers/$serverId/channels", OperationType.LIST) {
      db.collection("servers").document(serverId).collection("channels")
        .whereEqualTo("serverId", serverId)
        .snapshots()
        .map { snap -> snap.documents.mapNotNull { it.toChannelEntitySafe() } }
    }

  suspend fun upsertRole(role: ServerRoleEntity) {
    requireUserId()
    val docRef = db.collection("servers").document(role.serverId).collection("roles").document(role.id)
    val payload = mutableMapOf<String, Any?>(
      "serverId" to role.serverId,
      "name" to role.name.take(50),
      "colorHex" to role.colorHex,
      "iconUri" to role.iconUri,
      "chromaKeyColorsCsv" to role.chromaKeyColorsCsv.take(200),
      "permissionsCsv" to role.permissionsCsv.take(300),
      "position" to role.position.toLong(),
      "updatedAt" to FieldValue.serverTimestamp()
    )
    try {
      docRef.set(payload, SetOptions.merge()).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
    }
  }

  suspend fun deleteRole(serverId: String, roleId: String) {
    requireUserId()
    val docRef = db.collection("servers").document(serverId).collection("roles").document(roleId)
    try {
      docRef.delete().await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, docRef.path)
    }
  }

  fun observeServerRoles(serverId: String): Flow<List<ServerRoleEntity>> =
    safeSnapshotFlow("servers/$serverId/roles", OperationType.LIST) {
      db.collection("servers").document(serverId).collection("roles")
        .whereEqualTo("serverId", serverId)
        .snapshots()
        .map { snap -> snap.documents.mapNotNull { it.toServerRoleEntitySafe() } }
    }

  suspend fun upsertMember(member: ServerMemberEntity) {
    requireUserId()
    val docRef = db.collection("servers").document(member.serverId).collection("members").document(member.id)
    val exists = try { docRef.get().await().exists() } catch (_: Exception) { false }
    try {
      if (!exists) {
        val payload = mapOf(
          "serverId" to member.serverId,
          "userId" to member.userId,
          "role" to member.role.take(50),
          "roleColor" to member.roleColor,
          "roleIconUri" to member.roleIconUri,
          "roleChromaColorsCsv" to member.roleChromaColorsCsv.take(200),
          "joinedAt" to FieldValue.serverTimestamp()
        ).filterValues { it != null }
        docRef.set(payload).await()
      } else {
        docRef.update(
          mapOf(
            "role" to member.role.take(50),
            "roleColor" to member.roleColor,
            "roleIconUri" to member.roleIconUri,
            "roleChromaColorsCsv" to member.roleChromaColorsCsv.take(200)
          )
        ).await()
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
    }
  }

  suspend fun deleteMember(serverId: String, memberId: String) {
    requireUserId()
    try {
      db.collection("servers").document(serverId).collection("members").document(memberId).delete().await()
    } catch (_: Exception) {
    }
  }

  fun observeServerMembers(serverId: String): Flow<List<ServerMemberEntity>> =
    safeSnapshotFlow("servers/$serverId/members", OperationType.LIST) {
      db.collection("servers").document(serverId).collection("members")
        .whereEqualTo("serverId", serverId)
        .snapshots()
        .map { snap -> snap.documents.mapNotNull { it.toServerMemberEntitySafe() } }
    }

  // --- CHANNEL MESSAGES ---

  suspend fun sendChannelMessage(message: MessageEntity) {
    val uid = requireUserId()
    val docRef = db.collection("channels").document(message.channelId).collection("messages").document(message.id)
    val safeDuration = message.attachmentDurationMs.coerceIn(0L, 7000L)
    val payload = mutableMapOf<String, Any?>(
      "channelId" to message.channelId,
      "senderId" to uid,
      "senderName" to message.senderName.take(60),
      "senderAvatarUri" to message.senderAvatarUri,
      "senderFrameId" to message.senderFrameId,
      "senderTier" to message.senderTier,
      "senderBadges" to message.senderBadges.take(1200),
      "senderDisplayFont" to message.senderDisplayFont,
      "senderDisplayColorsCsv" to message.senderDisplayColorsCsv,
      "senderDisplayEffect" to message.senderDisplayEffect,
      "senderServerTag" to message.senderServerTag,
      "senderServerTagIcon" to message.senderServerTagIcon,
      "senderRoleIconUri" to message.senderRoleIconUri,
      "senderRoleChromaCsv" to message.senderRoleChromaCsv,
      "senderRoleColor" to message.senderRoleColor,
      "content" to message.content.take(4000),
      "attachmentUri" to message.attachmentUri,
      "attachmentName" to message.attachmentName?.take(200),
      "attachmentMimeType" to message.attachmentMimeType?.take(120),
      "attachmentSizeBytes" to message.attachmentSizeBytes,
      "attachmentDurationMs" to safeDuration,
      "replyToMessageId" to message.replyToMessageId,
      "replyToSnippet" to message.replyToSnippet?.take(200),
      "isPinned" to message.isPinned,
      "isEdited" to message.isEdited,
      "reactions" to message.reactions.take(500),
      "readByCsv" to message.readByCsv.take(2000),
      "forwardedFromId" to message.forwardedFromId,
      "forwardedFromName" to message.forwardedFromName?.take(60),
      "locationLat" to message.locationLat,
      "locationLng" to message.locationLng,
      "locationLabel" to message.locationLabel?.take(200),
      "locationLiveUntil" to message.locationLiveUntil,
      "stickerId" to message.stickerId,
      "gameInviteMatchId" to message.gameInviteMatchId,
      "mentionTargetsCsv" to message.mentionTargetsCsv.take(500),
      "timestampMs" to message.timestamp,
      "createdAt" to FieldValue.serverTimestamp(),
      "updatedAt" to FieldValue.serverTimestamp()
    ).filterValues { it != null }
    try {
      docRef.set(payload).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
    }
  }

  suspend fun updateChannelMessageContent(channelId: String, messageId: String, newContent: String) {
    requireUserId()
    val docRef = db.collection("channels").document(channelId).collection("messages").document(messageId)
    try {
      docRef.update(
        mapOf(
          "content" to newContent.take(4000),
          "isEdited" to true,
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
    }
  }

  suspend fun updateChannelMessageReactionsOrPin(
    channelId: String,
    messageId: String,
    reactions: String? = null,
    isPinned: Boolean? = null
  ) {
    requireUserId()
    val docRef = db.collection("channels").document(channelId).collection("messages").document(messageId)
    val updates = mutableMapOf<String, Any>("updatedAt" to FieldValue.serverTimestamp())
    if (reactions != null) updates["reactions"] = reactions.take(500)
    if (isPinned != null) updates["isPinned"] = isPinned
    try {
      docRef.update(updates).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
    }
  }

  suspend fun deleteChannelMessage(channelId: String, messageId: String) {
    requireUserId()
    val docRef = db.collection("channels").document(channelId).collection("messages").document(messageId)
    try {
      docRef.delete().await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, docRef.path)
    }
  }

  suspend fun markChannelMessageReadBy(channelId: String, messageId: String, readByCsv: String) {
    requireUserId()
    val docRef = db.collection("channels").document(channelId).collection("messages").document(messageId)
    try {
      docRef.update(
        mapOf(
          "readByCsv" to readByCsv.take(2000),
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
    } catch (_: Exception) {
    }
  }

  suspend fun upsertVoiceParticipant(participant: VoiceParticipantModel) {
    val uid = requireUserId()
    val docRef = db.collection("servers").document(participant.serverId)
      .collection("channels").document(participant.channelId)
      .collection("voice_participants").document(uid)
    val payload = mutableMapOf<String, Any?>(
      "userId" to uid,
      "channelId" to participant.channelId,
      "serverId" to participant.serverId,
      "displayName" to participant.displayName.take(60),
      "avatarUri" to participant.avatarUri,
      "isMuted" to participant.isMuted,
      "isDeafened" to participant.isDeafened,
      "isCameraOn" to participant.isCameraOn,
      "isScreenSharing" to participant.isScreenSharing,
      "isSpeaking" to participant.isSpeaking,
      "audioQuality" to participant.audioQuality,
      "updatedAtMs" to System.currentTimeMillis()
    ).filterValues { it != null }
    try {
      docRef.set(payload).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
    }
  }

  suspend fun removeVoiceParticipant(serverId: String, channelId: String) {
    val uid = auth.currentUser?.uid ?: return
    val docRef = db.collection("servers").document(serverId)
      .collection("channels").document(channelId)
      .collection("voice_participants").document(uid)
    try {
      docRef.delete().await()
    } catch (_: Exception) {
    }
  }

  fun observeVoiceParticipants(serverId: String, channelId: String): Flow<List<VoiceParticipantModel>> =
    safeSnapshotFlow("servers/$serverId/channels/$channelId/voice_participants", OperationType.LIST) {
      db.collection("servers").document(serverId)
        .collection("channels").document(channelId)
        .collection("voice_participants")
        .snapshots()
        .map { snap -> snap.documents.mapNotNull { it.toVoiceParticipantSafe() } }
    }

  fun observeChannelMessages(channelId: String): Flow<List<MessageEntity>> =
    safeSnapshotFlow("channels/$channelId/messages", OperationType.LIST) {
      db.collection("channels").document(channelId).collection("messages")
        .whereEqualTo("channelId", channelId)
        .snapshots()
        .map { snap -> snap.documents.mapNotNull { it.toMessageEntitySafe() } }
    }

  // --- FORUM POSTS & REPLIES ---

  suspend fun createForumPost(post: ForumPostEntity) {
    val uid = requireUserId()
    val docRef = db.collection("channels").document(post.channelId).collection("forum_posts").document(post.id)
    val payload = mapOf(
      "channelId" to post.channelId,
      "authorId" to uid,
      "authorName" to post.authorName.take(60),
      "authorAvatarUri" to post.authorAvatarUri,
      "title" to post.title.take(160),
      "content" to post.content.take(4000),
      "imageUri" to post.imageUri,
      "tagLabel" to post.tagLabel.take(30),
      "tagEmoji" to post.tagEmoji.take(16),
      "isPinned" to post.isPinned,
      "replyCount" to post.replyCount.toLong(),
      "reactionCount" to post.reactionCount.toLong(),
      "reactionEmoji" to post.reactionEmoji,
      "createdAtMs" to post.createdAt,
      "createdAt" to FieldValue.serverTimestamp(),
      "updatedAt" to FieldValue.serverTimestamp()
    ).filterValues { it != null }
    try {
      docRef.set(payload).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
    }
  }

  suspend fun updateForumPostCounters(channelId: String, postId: String, replyCount: Int, reactionCount: Int) {
    requireUserId()
    val docRef = db.collection("channels").document(channelId).collection("forum_posts").document(postId)
    try {
      docRef.update(
        mapOf(
          "replyCount" to replyCount.toLong(),
          "reactionCount" to reactionCount.toLong(),
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
    } catch (_: Exception) {
    }
  }

  fun observeForumPosts(channelId: String): Flow<List<ForumPostEntity>> =
    safeSnapshotFlow("channels/$channelId/forum_posts", OperationType.LIST) {
      db.collection("channels").document(channelId).collection("forum_posts")
        .whereEqualTo("channelId", channelId)
        .snapshots()
        .map { snap -> snap.documents.mapNotNull { it.toForumPostEntitySafe() } }
    }

  suspend fun insertForumReply(reply: ForumReplyEntity) {
    val uid = requireUserId()
    val docRef = db.collection("channels").document(reply.channelId)
      .collection("forum_posts").document(reply.postId)
      .collection("replies").document(reply.id)
    val payload = mapOf(
      "postId" to reply.postId,
      "channelId" to reply.channelId,
      "authorId" to uid,
      "authorName" to reply.authorName.take(60),
      "authorAvatarUri" to reply.authorAvatarUri,
      "content" to reply.content.take(2000),
      "createdAtMs" to reply.createdAt,
      "createdAt" to FieldValue.serverTimestamp()
    ).filterValues { it != null }
    try {
      docRef.set(payload).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
    }
  }

  fun observeForumReplies(channelId: String, postId: String): Flow<List<ForumReplyEntity>> =
    safeSnapshotFlow("channels/$channelId/forum_posts/$postId/replies", OperationType.LIST) {
      db.collection("channels").document(channelId)
        .collection("forum_posts").document(postId)
        .collection("replies")
        .whereEqualTo("postId", postId)
        .snapshots()
        .map { snap -> snap.documents.mapNotNull { it.toForumReplyEntitySafe() } }
    }

  // --- DIRECT MESSAGES & FRIENDSHIPS ---

  suspend fun sendDirectMessage(dm: DirectMessageEntity): Result<Unit> {
    val uid = requireUserId()
    val docRef = db.collection("direct_messages").document(dm.id)
    val participants = listOf(uid, dm.receiverId).sorted()
    val safeDuration = dm.attachmentDurationMs.coerceIn(0L, 7000L)
    val payload = mapOf(
      "conversationId" to dm.conversationId,
      "participants" to participants,
      "senderId" to uid,
      "senderName" to dm.senderName.take(60),
      "receiverId" to dm.receiverId,
      "content" to dm.content.take(4000),
      "attachmentUri" to dm.attachmentUri,
      "attachmentName" to dm.attachmentName?.take(200),
      "attachmentMimeType" to dm.attachmentMimeType?.take(120),
      "attachmentSizeBytes" to dm.attachmentSizeBytes,
      "attachmentDurationMs" to safeDuration,
      "replyToMessageId" to dm.replyToMessageId,
      "replyToSnippet" to dm.replyToSnippet?.take(200),
      "isEdited" to dm.isEdited,
      "isDeleted" to dm.isDeleted,
      "reactions" to dm.reactions.take(500),
      "forwardedFromId" to dm.forwardedFromId,
      "forwardedFromName" to dm.forwardedFromName?.take(60),
      "locationLat" to dm.locationLat,
      "locationLng" to dm.locationLng,
      "locationLabel" to dm.locationLabel?.take(200),
      "locationLiveUntil" to dm.locationLiveUntil,
      "stickerId" to dm.stickerId,
      "gameInviteMatchId" to dm.gameInviteMatchId,
      "timestampMs" to dm.timestamp,
      "isRead" to dm.isRead,
      "createdAt" to FieldValue.serverTimestamp(),
      "updatedAt" to FieldValue.serverTimestamp()
    ).filterValues { it != null }
    return try {
      docRef.set(payload).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun updateDirectMessageContent(dmId: String, newContent: String) {
    requireUserId()
    try {
      db.collection("direct_messages").document(dmId).update(
        mapOf("content" to newContent.take(4000), "isEdited" to true, "updatedAt" to FieldValue.serverTimestamp())
      ).await()
    } catch (_: Exception) {
    }
  }

  suspend fun softDeleteDirectMessage(dmId: String) {
    requireUserId()
    try {
      db.collection("direct_messages").document(dmId).update(
        mapOf("isDeleted" to true, "content" to "[Message deleted]", "updatedAt" to FieldValue.serverTimestamp())
      ).await()
    } catch (_: Exception) {
    }
  }

  suspend fun updateDirectMessageReactions(dmId: String, reactions: String) {
    requireUserId()
    try {
      db.collection("direct_messages").document(dmId).update(
        mapOf("reactions" to reactions.take(500), "updatedAt" to FieldValue.serverTimestamp())
      ).await()
    } catch (_: Exception) {
    }
  }

  suspend fun markDirectMessageRead(dmId: String) {
    requireUserId()
    val docRef = db.collection("direct_messages").document(dmId)
    try {
      docRef.update(
        mapOf(
          "isRead" to true,
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
    } catch (_: Exception) {
    }
  }

  suspend fun readDirectMessage(dmId: String): Result<DirectMessageEntity?> {
    requireUserId()
    val docRef = db.collection("direct_messages").document(dmId)
    return try {
      val snap = docRef.get().await()
      Result.success(if (snap.exists()) snap.toDirectMessageEntitySafe() else null)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.GET, docRef.path)
      Result.failure(e)
    }
  }

  fun observeDirectMessagesForUser(): Flow<List<DirectMessageEntity>> = flow {
    val uid = requireUserId()
    emitAll(
      safeSnapshotFlow("direct_messages", OperationType.LIST) {
        db.collection("direct_messages")
          .whereArrayContains("participants", uid)
          .snapshots()
          .map { snap -> snap.documents.mapNotNull { it.toDirectMessageEntitySafe() } }
      }
    )
  }

  suspend fun upsertFriendship(friend: FriendEntity) {
    val uid = requireUserId()
    val docRef = db.collection("friendships").document(friend.id)
    val participants = listOf(uid, friend.friendId).sorted()
    val payload = mapOf(
      "participants" to participants,
      "userId" to friend.userId,
      "friendId" to friend.friendId,
      "friendUsername" to friend.friendUsername.take(40),
      "friendDisplayName" to friend.friendDisplayName.take(60),
      "friendAvatarUri" to friend.friendAvatarUri,
      "status" to friend.status,
      "isOnline" to friend.isOnline,
      "statusText" to friend.statusText.take(100),
      "createdAt" to FieldValue.serverTimestamp(),
      "updatedAt" to FieldValue.serverTimestamp()
    ).filterValues { it != null }
    try {
      docRef.set(payload).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
    }
  }

  fun observeFriendshipsForUser(): Flow<List<FriendEntity>> = flow {
    val uid = requireUserId()
    emitAll(
      safeSnapshotFlow("friendships", OperationType.LIST) {
        db.collection("friendships")
          .whereArrayContains("participants", uid)
          .snapshots()
          .map { snap -> snap.documents.mapNotNull { it.toFriendEntitySafe(uid) } }
      }
    )
  }

  // --- STICKERS, MINI GAMES, RATINGS, TOURNAMENTS ---

  suspend fun upsertStickerPack(pack: StickerPackEntity) {
    val uid = requireUserId()
    val payload = mapOf(
      "creatorId" to uid,
      "creatorName" to pack.creatorName.take(60),
      "name" to pack.name.take(60),
      "description" to pack.description.take(300),
      "coverUri" to pack.coverUri,
      "isShared" to pack.isShared,
      "createdAtMs" to pack.createdAt
    ).filterValues { it != null }
    try {
      db.collection("sticker_packs").document(pack.id).set(payload, SetOptions.merge()).await()
    } catch (_: Exception) {
    }
  }

  suspend fun upsertSticker(sticker: StickerEntity, isShared: Boolean = true) {
    val uid = requireUserId()
    val payload = mapOf(
      "packId" to sticker.packId,
      "creatorId" to uid,
      "name" to sticker.name.take(60),
      "imageUri" to sticker.imageUri,
      "overlayText" to sticker.overlayText.take(60),
      "textColorHex" to sticker.textColorHex,
      "outlineColorHex" to sticker.outlineColorHex,
      "hasGlow" to sticker.hasGlow,
      "hasShadow" to sticker.hasShadow,
      "isShared" to isShared,
      "createdAtMs" to sticker.createdAt
    )
    try {
      db.collection("stickers").document(sticker.id).set(payload, SetOptions.merge()).await()
    } catch (_: Exception) {
    }
  }

  fun observeSharedStickerPacks(): Flow<List<StickerPackEntity>> =
    safeSnapshotFlow("sticker_packs", OperationType.LIST) {
      db.collection("sticker_packs")
        .whereEqualTo("isShared", true)
        .snapshots()
        .map { snap -> snap.documents.mapNotNull { it.toStickerPackSafe() } }
    }

  fun observeSharedStickers(): Flow<List<StickerEntity>> =
    safeSnapshotFlow("stickers", OperationType.LIST) {
      db.collection("stickers")
        .whereEqualTo("isShared", true)
        .snapshots()
        .map { snap -> snap.documents.mapNotNull { it.toStickerSafe() } }
    }

  suspend fun createOrUpdateGameMatch(match: GameMatchEntity, isCreate: Boolean) {
    requireUserId()
    val docRef = db.collection("game_matches").document(match.id)
    val participants = listOf(match.challengerId, match.opponentId)
    try {
      if (isCreate) {
        val payload = mapOf(
          "participants" to participants,
          "gameType" to match.gameType,
          "mode" to match.mode,
          "tournamentId" to match.tournamentId,
          "channelOrConvId" to match.channelOrConvId,
          "challengerId" to match.challengerId,
          "challengerName" to match.challengerName.take(60),
          "opponentId" to match.opponentId,
          "opponentName" to match.opponentName.take(60),
          "status" to match.status,
          "turnUserId" to match.turnUserId,
          "boardStateJson" to match.boardStateJson,
          "movesJson" to match.movesJson,
          "winnerId" to match.winnerId,
          "whiteTimeMs" to match.whiteTimeMs,
          "blackTimeMs" to match.blackTimeMs,
          "lastMoveAt" to match.lastMoveAt,
          "drawOfferedBy" to match.drawOfferedBy,
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp()
        ).filterValues { it != null }
        docRef.set(payload).await()
      } else {
        docRef.update(
          mapOf(
            "status" to match.status,
            "turnUserId" to match.turnUserId,
            "boardStateJson" to match.boardStateJson,
            "movesJson" to match.movesJson,
            "winnerId" to match.winnerId,
            "whiteTimeMs" to match.whiteTimeMs,
            "blackTimeMs" to match.blackTimeMs,
            "lastMoveAt" to match.lastMoveAt,
            "drawOfferedBy" to match.drawOfferedBy,
            "updatedAt" to FieldValue.serverTimestamp()
          )
        ).await()
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, if (isCreate) OperationType.CREATE else OperationType.UPDATE, docRef.path)
    }
  }

  fun observeGameMatchesForUser(userId: String): Flow<List<GameMatchEntity>> =
    safeSnapshotFlow("game_matches", OperationType.LIST) {
      db.collection("game_matches")
        .whereArrayContains("participants", userId)
        .snapshots()
        .map { snap -> snap.documents.mapNotNull { it.toGameMatchSafe() } }
    }

  suspend fun upsertGameRating(rating: GameRatingEntity) {
    requireUserId()
    val payload = mapOf(
      "userId" to rating.userId,
      "username" to rating.username.take(40),
      "displayName" to rating.displayName.take(60),
      "gameType" to rating.gameType,
      "elo" to rating.elo.toLong(),
      "wins" to rating.wins.toLong(),
      "losses" to rating.losses.toLong(),
      "draws" to rating.draws.toLong(),
      "isPublic" to true,
      "updatedAtMs" to rating.updatedAt
    )
    try {
      db.collection("game_ratings").document(rating.id).set(payload, SetOptions.merge()).await()
    } catch (_: Exception) {
    }
  }

  fun observePublicGameRatings(): Flow<List<GameRatingEntity>> =
    safeSnapshotFlow("game_ratings", OperationType.LIST) {
      db.collection("game_ratings")
        .whereEqualTo("isPublic", true)
        .snapshots()
        .map { snap -> snap.documents.mapNotNull { it.toGameRatingSafe() } }
    }

  suspend fun upsertTournament(t: TournamentEntity) {
    requireUserId()
    val payload = mapOf(
      "name" to t.name.take(80),
      "gameType" to t.gameType,
      "creatorId" to t.creatorId,
      "status" to t.status,
      "participantsCsv" to t.participantsCsv,
      "bracketJson" to t.bracketJson,
      "winnerId" to t.winnerId,
      "isPublic" to true,
      "updatedAt" to FieldValue.serverTimestamp()
    ).filterValues { it != null }
    try {
      db.collection("tournaments").document(t.id).set(payload, SetOptions.merge()).await()
    } catch (_: Exception) {
    }
  }

  fun observeTournaments(): Flow<List<TournamentEntity>> =
    safeSnapshotFlow("tournaments", OperationType.LIST) {
      db.collection("tournaments")
        .whereEqualTo("isPublic", true)
        .snapshots()
        .map { snap -> snap.documents.mapNotNull { it.toTournamentSafe() } }
    }

  // --- REDEEM CODES, RESTRICTIONS (LOCK SCREEN), REPORTS, AUDIT LOGS ---

  suspend fun upsertRedeemCode(code: RedeemCodeEntity) {
    requireUserId()
    val payload = mapOf(
      "code" to code.code.uppercase(),
      "rewardXit" to code.rewardXit,
      "rewardBoosts" to code.rewardBoosts.toLong(),
      "rewardBadgeId" to code.rewardBadgeId,
      "maxUses" to code.maxUses.toLong(),
      "usedCount" to code.usedCount.toLong(),
      "usedByCsv" to code.usedByCsv,
      "expiresAt" to code.expiresAt,
      "isActive" to code.isActive,
      "updatedAt" to FieldValue.serverTimestamp()
    ).filterValues { it != null }
    try {
      db.collection("redeem_codes").document(code.id).set(payload, SetOptions.merge()).await()
    } catch (_: Exception) {
    }
  }

  suspend fun fetchActiveRedeemCodes(): List<RedeemCodeEntity> {
    return try {
      db.collection("redeem_codes")
        .whereEqualTo("isActive", true)
        .get().await().documents.mapNotNull { it.toRedeemCodeSafe() }
    } catch (_: Exception) {
      emptyList()
    }
  }

  suspend fun upsertRestrictionRemote(r: UserRestrictionEntity) {
    requireUserId()
    val payload = mapOf(
      "userId" to r.userId,
      "username" to r.username.take(60),
      "adminId" to r.adminId,
      "adminRole" to r.adminRole,
      "reason" to r.reason.take(300),
      "customMessage" to r.customMessage.take(1000),
      "startedAt" to r.startedAt,
      "expiresAt" to r.expiresAt,
      "isActive" to r.isActive,
      "appealStatus" to r.appealStatus,
      "appealMessage" to r.appealMessage.take(1000),
      "updatedAt" to FieldValue.serverTimestamp()
    )
    try {
      db.collection("restrictions").document(r.id).set(payload, SetOptions.merge()).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "restrictions/${r.id}")
    }
  }

  suspend fun submitRestrictionAppealRemote(restrictionId: String, appealMessage: String) {
    requireUserId()
    try {
      db.collection("restrictions").document(restrictionId).update(
        mapOf(
          "appealStatus" to "PENDING",
          "appealMessage" to appealMessage.take(1000),
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
    } catch (_: Exception) {
    }
  }

  suspend fun clearExpiredRestrictionRemote(restrictionId: String) {
    requireUserId()
    try {
      db.collection("restrictions").document(restrictionId).update(
        mapOf(
          "isActive" to false,
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
    } catch (_: Exception) {
    }
  }

  fun observeRestrictionsForUser(userId: String): Flow<List<UserRestrictionEntity>> =
    safeSnapshotFlow("restrictions", OperationType.LIST) {
      db.collection("restrictions")
        .whereEqualTo("userId", userId)
        .snapshots()
        .map { snap -> snap.documents.mapNotNull { it.toRestrictionSafe() } }
    }

  suspend fun createOrUpdateReportRemote(report: ReportEntity, isCreate: Boolean) {
    requireUserId()
    val payload = mutableMapOf<String, Any?>(
      "reporterId" to report.reporterId,
      "reporterName" to report.reporterName.take(60),
      "targetUserId" to report.targetUserId,
      "targetServerId" to report.targetServerId,
      "targetMessageId" to report.targetMessageId,
      "reason" to report.reason.take(300),
      "details" to report.details.take(1000),
      "status" to report.status,
      "handledBy" to report.handledBy,
      "resolutionNote" to report.resolutionNote.take(500),
      "updatedAtMs" to report.updatedAt
    ).filterValues { it != null }
    try {
      val ref = db.collection("reports").document(report.id)
      if (isCreate) ref.set(payload).await() else ref.set(payload, SetOptions.merge()).await()
    } catch (_: Exception) {
    }
  }

  suspend fun writeAdminLogRemote(logId: String, action: String, details: String) {
    val uid = auth.currentUser?.uid ?: return
    val payload = mapOf(
      "actorId" to uid,
      "action" to action.take(80),
      "details" to details.take(600),
      "createdAt" to FieldValue.serverTimestamp()
    )
    try {
      db.collection("admin_logs").document(logId).set(payload).await()
    } catch (_: Exception) {
    }
  }

  // --- SAFE SNAPSHOT MAPPERS ---

  private fun DocumentSnapshot.toUserEntitySafe(): UserEntity? = try {
    if (!exists()) null else toUserEntity()
  } catch (_: Exception) {
    null
  }

  private fun DocumentSnapshot.toUserEntity(): UserEntity {
    val uid = id
    return UserEntity(
      id = uid,
      username = getString("username") ?: "user_${uid.take(4)}",
      displayName = getString("displayName") ?: getString("username") ?: "User",
      email = "",
      passwordHash = "",
      bio = getString("bio") ?: "",
      pronouns = getString("pronouns") ?: "He/Him",
      avatarUri = getString("avatarUri"),
      bannerUri = getString("bannerUri"),
      profileColor = getLong("profileColor") ?: 0xFFC4C9D4L,
      accentColorHex = getLong("accentColorHex") ?: 0xFFC4C9D4L,
      subscriptionTier = getString("subscriptionTier") ?: "FREE",
      xitBalance = getLong("xitBalance") ?: 250L,
      boostBalance = (getLong("boostBalance") ?: 0L).toInt(),
      level = (getLong("level") ?: 1L).toInt(),
      xp = getLong("xp") ?: 0L,
      followersCount = (getLong("followersCount") ?: 0L).toInt(),
      followingCount = (getLong("followingCount") ?: 0L).toInt(),
      isOwner = getBoolean("isOwner") ?: false,
      isBanned = getBoolean("isBanned") ?: false,
      isLocked = getBoolean("isLocked") ?: false,
      adminRole = getString("adminRole") ?: "NONE",
      equippedBadges = getString("equippedBadges") ?: "",
      unlockedBadgesProgressJson = getString("unlockedBadgesProgressJson") ?: "",
      invisibleServerIdsCsv = getString("invisibleServerIdsCsv") ?: "",
      equippedFrame = getString("equippedFrame"),
      equippedNameplate = getString("equippedNameplate"),
      equippedEffect = getString("equippedEffect"),
      displayNameFont = getString("displayNameFont") ?: "SERIF",
      displayNameColorsCsv = getString("displayNameColorsCsv") ?: "0xFFF5F7FA,0xFFC4C9D4",
      displayNameEffect = getString("displayNameEffect") ?: "GRADIENT",
      profileBgColorsCsv = getString("profileBgColorsCsv") ?: "0xFF07080B,0xFF111318,0xFF1A1D24",
      chatBubbleBgCsv = getString("chatBubbleBgCsv") ?: "0xFF1C2029,0xFF2B303D",
      chatBubbleImageUri = getString("chatBubbleImageUri"),
      appThemeId = getString("appThemeId") ?: "obsidian_marble",
      appThemeGradientCsv = getString("appThemeGradientCsv") ?: "",
      appFontKey = getString("appFontKey") ?: "SERIF",
      wallpaperMode = getString("wallpaperMode") ?: "MARBLE",
      customWallpaperUri = getString("customWallpaperUri"),
      presenceStatus = getString("presenceStatus") ?: "ONLINE",
      statusTag = getString("statusTag") ?: "",
      lastSeenAt = getLong("lastSeenAt") ?: System.currentTimeMillis(),
      typingChannelId = getString("typingChannelId"),
      typingUpdatedAt = getLong("typingUpdatedAt") ?: 0L,
      connectionsJson = getString("connectionsJson") ?: "",
      activeAppName = getString("activeAppName"),
      activeAppPackage = getString("activeAppPackage"),
      activeAppStartedAt = getLong("activeAppStartedAt") ?: 0L,
      listeningTitle = getString("listeningTitle"),
      listeningArtist = getString("listeningArtist"),
      listeningCoverUri = getString("listeningCoverUri"),
      listeningSourceUrl = getString("listeningSourceUrl"),
      listeningIsPlaying = getBoolean("listeningIsPlaying") ?: false,
      listeningPrivacy = getString("listeningPrivacy") ?: "PUBLIC",
      createdAt = getTimestamp("createdAt")?.toDate()?.time ?: System.currentTimeMillis()
    )
  }

  private fun DocumentSnapshot.toServerEntitySafe(): ServerEntity? {
    return try {
      val name = getString("name") ?: return null
      ServerEntity(
        id = id,
        name = name,
        description = getString("description") ?: "",
        iconUri = getString("iconUri"),
        bannerUri = getString("bannerUri"),
        inviteCode = getString("inviteCode") ?: "XCHAT",
        ownerId = getString("ownerId") ?: "",
        boostLevel = (getLong("boostLevel") ?: 0L).toInt(),
        boostCount = (getLong("boostCount") ?: 0L).toInt(),
        category = getString("serverGenre") ?: "Komunitas",
        serverType = getString("serverType") ?: "Komunitas",
        serverTag = getString("serverTag") ?: "#Santai",
        serverTagIcon = getString("serverTagIcon") ?: "shield",
        serverGenre = getString("serverGenre") ?: "Umum",
        supportedGame = getString("supportedGame"),
        isVanished = getBoolean("isVanished") ?: false,
        createdAt = getTimestamp("createdAt")?.toDate()?.time ?: System.currentTimeMillis()
      )
    } catch (_: Exception) {
      null
    }
  }

  private fun DocumentSnapshot.toCategoryEntitySafe(): ChannelCategoryEntity? {
    return try {
      ChannelCategoryEntity(
        id = id,
        serverId = getString("serverId") ?: return null,
        name = getString("name") ?: return null,
        orderIndex = (getLong("orderIndex") ?: 0L).toInt(),
        isCollapsed = getBoolean("isCollapsed") ?: false
      )
    } catch (_: Exception) {
      null
    }
  }

  private fun DocumentSnapshot.toChannelEntitySafe(): ChannelEntity? {
    return try {
      ChannelEntity(
        id = id,
        serverId = getString("serverId") ?: return null,
        name = getString("name") ?: return null,
        description = getString("description") ?: "",
        type = getString("type") ?: "text",
        isPrivate = false,
        orderIndex = (getLong("orderIndex") ?: 0L).toInt(),
        categoryId = getString("categoryId") ?: ""
      )
    } catch (_: Exception) {
      null
    }
  }

  private fun DocumentSnapshot.toServerRoleEntitySafe(): ServerRoleEntity? {
    return try {
      ServerRoleEntity(
        id = id,
        serverId = getString("serverId") ?: return null,
        name = getString("name") ?: return null,
        colorHex = getLong("colorHex") ?: 0xFFC4C9D4L,
        iconUri = getString("iconUri"),
        chromaKeyColorsCsv = getString("chromaKeyColorsCsv") ?: "",
        permissionsCsv = getString("permissionsCsv") ?: "SEND_MESSAGES",
        position = (getLong("position") ?: 0L).toInt()
      )
    } catch (_: Exception) {
      null
    }
  }

  private fun DocumentSnapshot.toServerMemberEntitySafe(): ServerMemberEntity? {
    return try {
      ServerMemberEntity(
        id = id,
        serverId = getString("serverId") ?: return null,
        userId = getString("userId") ?: return null,
        role = getString("role") ?: "Member",
        roleColor = getLong("roleColor") ?: 0xFF949BA4L,
        roleIconUri = getString("roleIconUri"),
        roleChromaColorsCsv = getString("roleChromaColorsCsv") ?: "",
        joinedAt = getTimestamp("joinedAt")?.toDate()?.time ?: System.currentTimeMillis()
      )
    } catch (_: Exception) {
      null
    }
  }

  private fun DocumentSnapshot.toMessageEntitySafe(): MessageEntity? {
    return try {
      MessageEntity(
        id = id,
        channelId = getString("channelId") ?: return null,
        senderId = getString("senderId") ?: return null,
        senderName = getString("senderName") ?: "User",
        senderAvatarUri = getString("senderAvatarUri"),
        senderFrameId = getString("senderFrameId"),
        senderTier = getString("senderTier") ?: "FREE",
        senderBadges = getString("senderBadges") ?: "",
        senderDisplayFont = getString("senderDisplayFont") ?: "SERIF",
        senderDisplayColorsCsv = getString("senderDisplayColorsCsv") ?: "",
        senderDisplayEffect = getString("senderDisplayEffect") ?: "GRADIENT",
        senderServerTag = getString("senderServerTag"),
        senderServerTagIcon = getString("senderServerTagIcon"),
        senderRoleIconUri = getString("senderRoleIconUri"),
        senderRoleChromaCsv = getString("senderRoleChromaCsv") ?: "",
        senderRoleColor = getLong("senderRoleColor") ?: 0xFF949BA4L,
        content = getString("content") ?: "",
        attachmentUri = getString("attachmentUri"),
        attachmentName = getString("attachmentName"),
        attachmentMimeType = getString("attachmentMimeType"),
        attachmentSizeBytes = getLong("attachmentSizeBytes") ?: 0L,
        attachmentDurationMs = getLong("attachmentDurationMs") ?: 0L,
        replyToMessageId = getString("replyToMessageId"),
        replyToSnippet = getString("replyToSnippet"),
        isPinned = getBoolean("isPinned") ?: false,
        isEdited = getBoolean("isEdited") ?: false,
        reactions = getString("reactions") ?: "",
        readByCsv = getString("readByCsv") ?: "",
        forwardedFromId = getString("forwardedFromId"),
        forwardedFromName = getString("forwardedFromName"),
        locationLat = getDouble("locationLat"),
        locationLng = getDouble("locationLng"),
        locationLabel = getString("locationLabel"),
        locationLiveUntil = getLong("locationLiveUntil") ?: 0L,
        stickerId = getString("stickerId"),
        gameInviteMatchId = getString("gameInviteMatchId"),
        mentionTargetsCsv = getString("mentionTargetsCsv") ?: "",
        timestamp = getLong("timestampMs") ?: getTimestamp("createdAt")?.toDate()?.time ?: System.currentTimeMillis()
      )
    } catch (_: Exception) {
      null
    }
  }

  private fun DocumentSnapshot.toForumPostEntitySafe(): ForumPostEntity? {
    return try {
      ForumPostEntity(
        id = id,
        channelId = getString("channelId") ?: return null,
        authorId = getString("authorId") ?: return null,
        authorName = getString("authorName") ?: "User",
        authorAvatarUri = getString("authorAvatarUri"),
        title = getString("title") ?: return null,
        content = getString("content") ?: "",
        imageUri = getString("imageUri"),
        tagLabel = getString("tagLabel") ?: "Meta",
        tagEmoji = getString("tagEmoji") ?: "❗",
        isPinned = getBoolean("isPinned") ?: false,
        replyCount = (getLong("replyCount") ?: 0L).toInt(),
        reactionCount = (getLong("reactionCount") ?: 0L).toInt(),
        reactionEmoji = getString("reactionEmoji") ?: "🔥",
        createdAt = getLong("createdAtMs") ?: getTimestamp("createdAt")?.toDate()?.time ?: System.currentTimeMillis()
      )
    } catch (_: Exception) {
      null
    }
  }

  private fun DocumentSnapshot.toForumReplyEntitySafe(): ForumReplyEntity? {
    return try {
      ForumReplyEntity(
        id = id,
        postId = getString("postId") ?: return null,
        channelId = getString("channelId") ?: return null,
        authorId = getString("authorId") ?: return null,
        authorName = getString("authorName") ?: "User",
        authorAvatarUri = getString("authorAvatarUri"),
        content = getString("content") ?: return null,
        createdAt = getLong("createdAtMs") ?: getTimestamp("createdAt")?.toDate()?.time ?: System.currentTimeMillis()
      )
    } catch (_: Exception) {
      null
    }
  }

  private fun DocumentSnapshot.toDirectMessageEntitySafe(): DirectMessageEntity? {
    return try {
      DirectMessageEntity(
        id = id,
        conversationId = getString("conversationId") ?: return null,
        senderId = getString("senderId") ?: return null,
        senderName = getString("senderName") ?: "User",
        receiverId = getString("receiverId") ?: return null,
        content = getString("content") ?: "",
        attachmentUri = getString("attachmentUri"),
        attachmentName = getString("attachmentName"),
        attachmentMimeType = getString("attachmentMimeType"),
        attachmentSizeBytes = getLong("attachmentSizeBytes") ?: 0L,
        attachmentDurationMs = getLong("attachmentDurationMs") ?: 0L,
        replyToMessageId = getString("replyToMessageId"),
        replyToSnippet = getString("replyToSnippet"),
        isEdited = getBoolean("isEdited") ?: false,
        isDeleted = getBoolean("isDeleted") ?: false,
        reactions = getString("reactions") ?: "",
        forwardedFromId = getString("forwardedFromId"),
        forwardedFromName = getString("forwardedFromName"),
        locationLat = getDouble("locationLat"),
        locationLng = getDouble("locationLng"),
        locationLabel = getString("locationLabel"),
        locationLiveUntil = getLong("locationLiveUntil") ?: 0L,
        stickerId = getString("stickerId"),
        gameInviteMatchId = getString("gameInviteMatchId"),
        timestamp = getLong("timestampMs") ?: getTimestamp("createdAt")?.toDate()?.time ?: System.currentTimeMillis(),
        isRead = getBoolean("isRead") ?: false
      )
    } catch (_: Exception) {
      null
    }
  }

  private fun DocumentSnapshot.toFriendEntitySafe(currentUid: String): FriendEntity? {
    return try {
      val uId = getString("userId") ?: return null
      val fId = getString("friendId") ?: return null
      val peerId = if (uId == currentUid) fId else uId
      FriendEntity(
        id = "${currentUid}_$peerId",
        userId = currentUid,
        friendId = peerId,
        friendUsername = getString("friendUsername") ?: "user",
        friendDisplayName = getString("friendDisplayName") ?: getString("friendUsername") ?: "User",
        friendAvatarUri = getString("friendAvatarUri"),
        status = getString("status") ?: "ACCEPTED",
        isOnline = getBoolean("isOnline") ?: true,
        statusText = getString("statusText") ?: "Online",
        updatedAt = getTimestamp("updatedAt")?.toDate()?.time ?: System.currentTimeMillis()
      )
    } catch (_: Exception) {
      null
    }
  }

  private fun DocumentSnapshot.toSavedProfileThemeSafe(): SavedProfileThemeEntity? {
    return try {
      SavedProfileThemeEntity(
        id = id,
        userId = getString("userId") ?: return null,
        name = getString("name") ?: return null,
        displayNameFont = getString("displayNameFont") ?: "SERIF",
        displayNameColorsCsv = getString("displayNameColorsCsv") ?: "0xFFF5F7FA,0xFFC4C9D4",
        displayNameEffect = getString("displayNameEffect") ?: "GRADIENT",
        profileBgColorsCsv = getString("profileBgColorsCsv") ?: "0xFF07080B,0xFF111318,0xFF1A1D24",
        profileColor = getLong("profileColor") ?: 0xFFC4C9D4L,
        equippedEffect = getString("equippedEffect"),
        chatBubbleBgCsv = getString("chatBubbleBgCsv") ?: "0xFF1C2029,0xFF2B303D",
        chatBubbleImageUri = getString("chatBubbleImageUri"),
        appThemeId = getString("appThemeId") ?: "obsidian_marble",
        appThemeGradientCsv = getString("appThemeGradientCsv") ?: "",
        appFontKey = getString("appFontKey") ?: "SERIF",
        isEquipped = getBoolean("isEquipped") ?: false,
        createdAt = getLong("createdAtMs") ?: System.currentTimeMillis()
      )
    } catch (_: Exception) {
      null
    }
  }

  private fun DocumentSnapshot.toVoiceParticipantSafe(): VoiceParticipantModel? {
    return try {
      VoiceParticipantModel(
        userId = getString("userId") ?: return null,
        channelId = getString("channelId") ?: return null,
        serverId = getString("serverId") ?: "",
        displayName = getString("displayName") ?: "User",
        avatarUri = getString("avatarUri"),
        isMuted = getBoolean("isMuted") ?: false,
        isDeafened = getBoolean("isDeafened") ?: false,
        isCameraOn = getBoolean("isCameraOn") ?: false,
        isScreenSharing = getBoolean("isScreenSharing") ?: false,
        isSpeaking = getBoolean("isSpeaking") ?: false,
        audioQuality = getString("audioQuality") ?: "HD",
        updatedAt = getLong("updatedAtMs") ?: System.currentTimeMillis()
      )
    } catch (_: Exception) {
      null
    }
  }

  private fun DocumentSnapshot.toUserFollowSafe(): UserFollowEntity? {
    return try {
      UserFollowEntity(
        id = id,
        followerId = getString("followerId") ?: return null,
        targetUserId = getString("targetUserId") ?: return null,
        createdAt = getTimestamp("createdAt")?.toDate()?.time ?: System.currentTimeMillis()
      )
    } catch (_: Exception) { null }
  }

  private fun DocumentSnapshot.toUserGameAppSafe(): UserGameAppEntity? {
    return try {
      UserGameAppEntity(
        id = id,
        userId = getString("userId") ?: return null,
        name = getString("name") ?: return null,
        iconKey = getString("iconKey") ?: "gamepad",
        iconUri = getString("iconUri"),
        description = getString("description") ?: "",
        activityStatus = getString("activityStatus") ?: "",
        appLink = getString("appLink") ?: "",
        category = getString("category") ?: "Game",
        orderIndex = (getLong("orderIndex") ?: 0L).toInt(),
        createdAt = getLong("createdAtMs") ?: System.currentTimeMillis()
      )
    } catch (_: Exception) { null }
  }

  private fun DocumentSnapshot.toNotificationSafe(): NotificationEntity? {
    return try {
      NotificationEntity(
        id = id,
        userId = getString("userId") ?: return null,
        title = getString("title") ?: return null,
        message = getString("message") ?: "",
        type = getString("type") ?: "MENTION",
        isRead = getBoolean("isRead") ?: false,
        timestamp = getLong("timestampMs") ?: System.currentTimeMillis()
      )
    } catch (_: Exception) { null }
  }

  private fun DocumentSnapshot.toStickerPackSafe(): StickerPackEntity? {
    return try {
      StickerPackEntity(
        id = id,
        creatorId = getString("creatorId") ?: return null,
        creatorName = getString("creatorName") ?: "User",
        name = getString("name") ?: return null,
        description = getString("description") ?: "",
        coverUri = getString("coverUri"),
        isShared = getBoolean("isShared") ?: true,
        createdAt = getLong("createdAtMs") ?: System.currentTimeMillis()
      )
    } catch (_: Exception) { null }
  }

  private fun DocumentSnapshot.toStickerSafe(): StickerEntity? {
    return try {
      StickerEntity(
        id = id,
        packId = getString("packId") ?: "pack_default",
        creatorId = getString("creatorId") ?: return null,
        name = getString("name") ?: return null,
        imageUri = getString("imageUri") ?: return null,
        overlayText = getString("overlayText") ?: "",
        textColorHex = getLong("textColorHex") ?: 0xFFFFFFFFL,
        outlineColorHex = getLong("outlineColorHex") ?: 0xFF000000L,
        hasGlow = getBoolean("hasGlow") ?: false,
        hasShadow = getBoolean("hasShadow") ?: true,
        createdAt = getLong("createdAtMs") ?: System.currentTimeMillis()
      )
    } catch (_: Exception) { null }
  }

  private fun DocumentSnapshot.toGameMatchSafe(): GameMatchEntity? {
    return try {
      GameMatchEntity(
        id = id,
        gameType = getString("gameType") ?: return null,
        mode = getString("mode") ?: "CLASSIC",
        tournamentId = getString("tournamentId"),
        channelOrConvId = getString("channelOrConvId") ?: "",
        challengerId = getString("challengerId") ?: return null,
        challengerName = getString("challengerName") ?: "Player 1",
        opponentId = getString("opponentId") ?: return null,
        opponentName = getString("opponentName") ?: "Player 2",
        status = getString("status") ?: "INVITED",
        turnUserId = getString("turnUserId") ?: return null,
        boardStateJson = getString("boardStateJson") ?: return null,
        movesJson = getString("movesJson") ?: "[]",
        winnerId = getString("winnerId"),
        whiteTimeMs = getLong("whiteTimeMs") ?: 300_000L,
        blackTimeMs = getLong("blackTimeMs") ?: 300_000L,
        lastMoveAt = getLong("lastMoveAt") ?: System.currentTimeMillis(),
        drawOfferedBy = getString("drawOfferedBy"),
        createdAt = getTimestamp("createdAt")?.toDate()?.time ?: System.currentTimeMillis(),
        updatedAt = getTimestamp("updatedAt")?.toDate()?.time ?: System.currentTimeMillis()
      )
    } catch (_: Exception) { null }
  }

  private fun DocumentSnapshot.toGameRatingSafe(): GameRatingEntity? {
    return try {
      GameRatingEntity(
        id = id,
        userId = getString("userId") ?: return null,
        username = getString("username") ?: "player",
        displayName = getString("displayName") ?: "Player",
        gameType = getString("gameType") ?: return null,
        elo = (getLong("elo") ?: 1000L).toInt(),
        wins = (getLong("wins") ?: 0L).toInt(),
        losses = (getLong("losses") ?: 0L).toInt(),
        draws = (getLong("draws") ?: 0L).toInt(),
        updatedAt = getLong("updatedAtMs") ?: System.currentTimeMillis()
      )
    } catch (_: Exception) { null }
  }

  private fun DocumentSnapshot.toTournamentSafe(): TournamentEntity? {
    return try {
      TournamentEntity(
        id = id,
        name = getString("name") ?: return null,
        gameType = getString("gameType") ?: "CHESS",
        creatorId = getString("creatorId") ?: return null,
        status = getString("status") ?: "OPEN",
        participantsCsv = getString("participantsCsv") ?: "",
        bracketJson = getString("bracketJson") ?: "[]",
        winnerId = getString("winnerId")
      )
    } catch (_: Exception) { null }
  }

  private fun DocumentSnapshot.toRedeemCodeSafe(): RedeemCodeEntity? {
    return try {
      RedeemCodeEntity(
        id = id,
        code = getString("code") ?: return null,
        rewardXit = getLong("rewardXit") ?: 200L,
        rewardBoosts = (getLong("rewardBoosts") ?: 0L).toInt(),
        rewardBadgeId = getString("rewardBadgeId"),
        maxUses = (getLong("maxUses") ?: 100L).toInt(),
        usedCount = (getLong("usedCount") ?: 0L).toInt(),
        usedByCsv = getString("usedByCsv") ?: "",
        expiresAt = getLong("expiresAt") ?: 0L,
        isActive = getBoolean("isActive") ?: true
      )
    } catch (_: Exception) { null }
  }

  private fun DocumentSnapshot.toRestrictionSafe(): UserRestrictionEntity? {
    return try {
      UserRestrictionEntity(
        id = id,
        userId = getString("userId") ?: return null,
        username = getString("username") ?: "",
        adminId = getString("adminId") ?: return null,
        adminRole = getString("adminRole") ?: "ADMIN",
        reason = getString("reason") ?: return null,
        customMessage = getString("customMessage") ?: return null,
        startedAt = getLong("startedAt") ?: System.currentTimeMillis(),
        expiresAt = getLong("expiresAt") ?: 0L,
        isActive = getBoolean("isActive") ?: true,
        appealStatus = getString("appealStatus") ?: "NONE",
        appealMessage = getString("appealMessage") ?: "",
        updatedAt = getTimestamp("updatedAt")?.toDate()?.time ?: System.currentTimeMillis()
      )
    } catch (_: Exception) { null }
  }
}
