package com.example.data.repository

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.model.*
import com.example.data.remote.FirestoreCloudRepository
import com.example.ui.components.BadgeCatalog
import com.example.utils.MiniGameEngines
import com.example.utils.SoundEffectsEngine
import com.example.utils.VideoTrimHelper
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.UUID

data class GlobalSearchResult(
  val users: List<UserEntity> = emptyList(),
  val servers: List<ServerEntity> = emptyList(),
  val channels: List<ChannelEntity> = emptyList(),
  val messages: List<MessageEntity> = emptyList(),
  val dms: List<DirectMessageEntity> = emptyList(),
  val stickers: List<StickerEntity> = emptyList(),
  val games: List<String> = emptyList()
)

class XChatRepository(context: Context) {
  private val appContext = context.applicationContext
  private val db = AppDatabase.getDatabase(appContext)
  val cloudRepo = FirestoreCloudRepository(appContext)

  private val userDao = db.userDao()
  private val serverDao = db.serverDao()
  private val channelCategoryDao = db.channelCategoryDao()
  private val serverMemberDao = db.serverMemberDao()
  private val serverRoleDao = db.serverRoleDao()
  private val channelDao = db.channelDao()
  private val messageDao = db.messageDao()
  private val forumPostDao = db.forumPostDao()
  private val forumReplyDao = db.forumReplyDao()
  private val directMessageDao = db.directMessageDao()
  private val friendDao = db.friendDao()
  private val userFollowDao = db.userFollowDao()
  private val userGameAppDao = db.userGameAppDao()
  private val stickerDao = db.stickerDao()
  private val gifFavoriteDao = db.gifFavoriteDao()
  private val playlistDao = db.playlistDao()
  private val gameDao = db.gameDao()
  private val adminModerationDao = db.adminModerationDao()
  private val callSessionDao = db.callSessionDao()
  private val notificationDao = db.notificationDao()
  private val marketplaceDao = db.marketplaceDao()
  private val questDao = db.questDao()
  private val paymentRequestDao = db.paymentRequestDao()
  private val auditLogDao = db.auditLogDao()
  private val profileVisitorDao = db.profileVisitorDao()
  private val savedProfileThemeDao = db.savedProfileThemeDao()

  private val sessionPrefs = appContext.getSharedPreferences("xchat_session_prefs", Context.MODE_PRIVATE)

  private val _currentUserId = MutableStateFlow(sessionPrefs.getString("session_user_id", null))
  val currentUserId = _currentUserId.asStateFlow()

  private val _mutedUserIds = MutableStateFlow<Set<String>>(emptySet())
  val mutedUserIds = _mutedUserIds.asStateFlow()

  private val _mutedServerIds = MutableStateFlow<Set<String>>(emptySet())
  val mutedServerIds = _mutedServerIds.asStateFlow()

  init {
    refreshMuteSets()
  }

  private fun refreshMuteSets() {
    val uid = _currentUserId.value
    if (uid == null) {
      _mutedUserIds.value = emptySet()
      _mutedServerIds.value = emptySet()
    } else {
      _mutedUserIds.value = sessionPrefs.getStringSet("muted_users_$uid", emptySet())?.toSet() ?: emptySet()
      _mutedServerIds.value = sessionPrefs.getStringSet("muted_servers_$uid", emptySet())?.toSet() ?: emptySet()
    }
  }

  fun setCurrentUserId(userId: String?) {
    _currentUserId.value = userId
    sessionPrefs.edit().apply {
      if (userId == null) remove("session_user_id") else putString("session_user_id", userId)
    }.apply()
    refreshMuteSets()
  }

  fun toggleMuteUser(targetUserId: String): Boolean {
    val uid = _currentUserId.value ?: return false
    val current = _mutedUserIds.value.toMutableSet()
    val nowMuted = if (current.contains(targetUserId)) {
      current.remove(targetUserId)
      false
    } else {
      current.add(targetUserId)
      true
    }
    _mutedUserIds.value = current
    sessionPrefs.edit().putStringSet("muted_users_$uid", current).apply()
    return nowMuted
  }

  fun toggleMuteServer(serverId: String): Boolean {
    val uid = _currentUserId.value ?: return false
    val current = _mutedServerIds.value.toMutableSet()
    val nowMuted = if (current.contains(serverId)) {
      current.remove(serverId)
      false
    } else {
      current.add(serverId)
      true
    }
    _mutedServerIds.value = current
    sessionPrefs.edit().putStringSet("muted_servers_$uid", current).apply()
    return nowMuted
  }

  fun hasAppLockPin(): Boolean {
    val uid = _currentUserId.value ?: return false
    return !sessionPrefs.getString("app_pin_hash_$uid", null).isNullOrBlank()
  }

  fun setAppLockPin(pin: String) {
    val uid = _currentUserId.value ?: return
    val hash = sha256Hex(pin)
    sessionPrefs.edit().putString("app_pin_hash_$uid", hash).apply()
  }

  fun verifyAppLockPin(pin: String): Boolean {
    val uid = _currentUserId.value ?: return false
    val saved = sessionPrefs.getString("app_pin_hash_$uid", null) ?: return true
    return saved == sha256Hex(pin)
  }

  fun clearAppLockPin() {
    val uid = _currentUserId.value ?: return
    sessionPrefs.edit().remove("app_pin_hash_$uid").apply()
  }

  private fun sha256Hex(input: String): String {
    return java.security.MessageDigest.getInstance("SHA-256")
      .digest(input.toByteArray(Charsets.UTF_8))
      .joinToString("") { "%02x".format(it) }
  }

  fun isOwnerKeyUnlocked(): Boolean {
    val uid = _currentUserId.value ?: return false
    return sessionPrefs.getBoolean("owner_unlocked_$uid", false)
  }

  fun saveOwnerKeyUnlocked(unlocked: Boolean) {
    val uid = _currentUserId.value ?: return
    sessionPrefs.edit().apply {
      if (unlocked) putBoolean("owner_unlocked_$uid", true) else remove("owner_unlocked_$uid")
    }.apply()
  }

  fun saveSelectedServerId(serverId: String) {
    val uid = _currentUserId.value ?: return
    sessionPrefs.edit().putString("selected_server_$uid", serverId).apply()
  }

  fun getSavedSelectedServerId(): String {
    val uid = _currentUserId.value ?: return "srv_official"
    return sessionPrefs.getString("selected_server_$uid", null) ?: "srv_official"
  }

  fun saveSelectedChannelId(channelId: String) {
    val uid = _currentUserId.value ?: return
    sessionPrefs.edit().putString("selected_channel_$uid", channelId).apply()
  }

  fun getSavedSelectedChannelId(): String {
    val uid = _currentUserId.value ?: return "ch_s1_gen"
    return sessionPrefs.getString("selected_channel_$uid", null) ?: "ch_s1_gen"
  }

  // --- AUTHENTICATED GOOGLE + FIRESTORE SYNC ---

  suspend fun syncAuthenticatedUser(
    preferredUsername: String?,
    preferredDisplayName: String?
  ): Result<UserEntity> = withContext(Dispatchers.IO) {
    val fbUser = Firebase.auth.currentUser
      ?: return@withContext Result.failure(Exception("Google sign-in required."))
    val existingLocal = userDao.getUserById(fbUser.uid)
    try {
      var user = cloudRepo.ensureUserProfile(
        firebaseUser = fbUser,
        preferredUsername = preferredUsername,
        preferredDisplayName = preferredDisplayName
      )
      val verifiedRole = runCatching { cloudRepo.checkVerifiedAdminRole() }.getOrDefault("NONE")
      val privateRes = runCatching { cloudRepo.readPrivateInfo(user.id).getOrNull() }.getOrNull()
      val savedLang = (privateRes?.get("languageCode") as? String)?.takeIf { it.isNotBlank() } ?: "en"
      val allowVisitors = privateRes?.get("allowProfileVisitors") as? Boolean
      val soundEn = privateRes?.get("soundEnabled") as? Boolean
      val soundVol = (privateRes?.get("soundVolume") as? Number)?.toFloat()
      val lowPerf = privateRes?.get("lowPerfMode") as? Boolean
      val notifPrefs = privateRes?.get("notifPrefsJson") as? String

      user = user.copy(
        email = user.email.ifBlank { fbUser.email ?: existingLocal?.email ?: "" },
        languageCode = savedLang,
        allowProfileVisitors = allowVisitors ?: user.allowProfileVisitors,
        soundEnabled = soundEn ?: existingLocal?.soundEnabled ?: user.soundEnabled,
        soundVolume = soundVol ?: existingLocal?.soundVolume ?: user.soundVolume,
        lowPerfMode = lowPerf ?: existingLocal?.lowPerfMode ?: user.lowPerfMode,
        notifPrefsJson = notifPrefs ?: existingLocal?.notifPrefsJson ?: user.notifPrefsJson,
        unlockedBadgesProgressJson = existingLocal?.unlockedBadgesProgressJson ?: user.unlockedBadgesProgressJson,
        wallpaperBlur = existingLocal?.wallpaperBlur ?: user.wallpaperBlur,
        wallpaperOpacity = existingLocal?.wallpaperOpacity ?: user.wallpaperOpacity,
        wallpaperBrightness = existingLocal?.wallpaperBrightness ?: user.wallpaperBrightness,
        wallpaperTintHex = existingLocal?.wallpaperTintHex ?: user.wallpaperTintHex,
        wallpaperGradientCsv = existingLocal?.wallpaperGradientCsv ?: user.wallpaperGradientCsv,
        adminRole = if (verifiedRole != "NONE") verifiedRole else user.adminRole
      )

      SoundEffectsEngine.updateSettings(user.soundEnabled, user.soundVolume, user.mutedSoundCategoriesCsv)

      if (user.isBanned) {
        return@withContext Result.failure(Exception("This account has been disabled by an administrator."))
      }
      userDao.insertUser(user)
      setCurrentUserId(user.id)

      val officialMember = ServerMemberEntity(
        id = "srv_official_${user.id}",
        serverId = "srv_official",
        userId = user.id,
        role = if (user.isOwner) "Owner" else "Member",
        roleColor = if (user.isOwner) 0xFFEAB308 else 0xFF949BA4
      )
      if (serverMemberDao.getMembership("srv_official", user.id) == null) {
        serverMemberDao.insertMembership(officialMember)
      }
      runCatching { cloudRepo.upsertMember(officialMember) }
      Result.success(user)
    } catch (e: Exception) {
      val firestoreEx = generateSequence<Throwable>(e) { it.cause }
        .filterIsInstance<com.google.firebase.firestore.FirebaseFirestoreException>()
        .firstOrNull()
      val isPermissionDenied = firestoreEx?.code ==
        com.google.firebase.firestore.FirebaseFirestoreException.Code.PERMISSION_DENIED
      if (!isPermissionDenied) {
        val emailPrefix = fbUser.email?.substringBefore("@")
          ?.lowercase()?.replace(Regex("[^a-z0-9_]"), "_")
          ?.take(20) ?: "user"
        val cleanPrefUser = preferredUsername?.trim()?.lowercase()?.replace(Regex("[^a-z0-9_]"), "_")
          ?.takeIf { it.length >= 2 }?.take(32)
        val cleanPrefDisp = preferredDisplayName?.trim()?.takeIf { it.isNotBlank() }?.take(60)
        val fallbackUser = existingLocal?.copy(
          email = existingLocal.email.ifBlank { fbUser.email ?: "" },
          username = cleanPrefUser ?: existingLocal.username,
          displayName = cleanPrefDisp ?: existingLocal.displayName
        ) ?: UserEntity(
          id = fbUser.uid,
          username = cleanPrefUser ?: "${emailPrefix}_${fbUser.uid.take(4).lowercase()}",
          displayName = cleanPrefDisp ?: fbUser.displayName?.takeIf { it.isNotBlank() } ?: emailPrefix,
          email = fbUser.email ?: "",
          passwordHash = "",
          bio = "Hello world! I'm a new member on XChat.",
          pronouns = "He/Him",
          avatarUri = fbUser.photoUrl?.toString(),
          languageCode = "en",
          subscriptionTier = "FREE",
          xitBalance = 300L,
          isOwner = false,
          adminRole = "NONE",
          presenceStatus = "ONLINE",
          lastSeenAt = System.currentTimeMillis()
        )
        if (!fallbackUser.isBanned) {
          userDao.insertUser(fallbackUser)
          setCurrentUserId(fallbackUser.id)
          return@withContext Result.success(fallbackUser)
        }
      }
      Result.failure(e)
    }
  }

  // Cloud snapshot -> Room cache upsert helpers
  suspend fun upsertCloudUsers(users: List<UserEntity>) = withContext(Dispatchers.IO) {
    if (users.isEmpty()) return@withContext
    val merged = users.map { remote ->
      val local = userDao.getUserById(remote.id)
      if (local != null) {
        remote.copy(
          email = remote.email.ifBlank { local.email },
          languageCode = if (remote.id == _currentUserId.value) local.languageCode else remote.languageCode,
          allowProfileVisitors = if (remote.id == _currentUserId.value) local.allowProfileVisitors else remote.allowProfileVisitors,
          unlockedBadgesProgressJson = local.unlockedBadgesProgressJson.ifBlank { remote.unlockedBadgesProgressJson },
          wallpaperBlur = local.wallpaperBlur,
          wallpaperOpacity = local.wallpaperOpacity,
          wallpaperBrightness = local.wallpaperBrightness,
          wallpaperTintHex = local.wallpaperTintHex,
          wallpaperGradientCsv = local.wallpaperGradientCsv,
          lowPerfMode = if (remote.id == _currentUserId.value) local.lowPerfMode else remote.lowPerfMode,
          soundEnabled = if (remote.id == _currentUserId.value) local.soundEnabled else remote.soundEnabled,
          soundVolume = if (remote.id == _currentUserId.value) local.soundVolume else remote.soundVolume,
          mutedSoundCategoriesCsv = if (remote.id == _currentUserId.value) local.mutedSoundCategoriesCsv else remote.mutedSoundCategoriesCsv,
          notifPrefsJson = if (remote.id == _currentUserId.value) local.notifPrefsJson else remote.notifPrefsJson
        )
      } else {
        remote
      }
    }
    userDao.upsertUsers(merged)
  }

  suspend fun upsertCloudServers(servers: List<ServerEntity>) = withContext(Dispatchers.IO) {
    if (servers.isNotEmpty()) serverDao.upsertServers(servers)
  }

  suspend fun upsertCloudCategories(cats: List<ChannelCategoryEntity>) = withContext(Dispatchers.IO) {
    if (cats.isNotEmpty()) channelCategoryDao.insertCategories(cats)
  }

  suspend fun upsertCloudChannels(channels: List<ChannelEntity>) = withContext(Dispatchers.IO) {
    if (channels.isNotEmpty()) channelDao.insertChannels(channels)
  }

  suspend fun upsertCloudRoles(roles: List<ServerRoleEntity>) = withContext(Dispatchers.IO) {
    if (roles.isNotEmpty()) serverRoleDao.insertRoles(roles)
  }

  suspend fun upsertCloudMembers(members: List<ServerMemberEntity>) = withContext(Dispatchers.IO) {
    if (members.isNotEmpty()) serverMemberDao.insertMemberships(members)
  }

  suspend fun upsertCloudMessages(messages: List<MessageEntity>) = withContext(Dispatchers.IO) {
    if (messages.isNotEmpty()) messageDao.upsertMessages(messages)
  }

  suspend fun upsertCloudForumPosts(posts: List<ForumPostEntity>) = withContext(Dispatchers.IO) {
    if (posts.isNotEmpty()) forumPostDao.insertPosts(posts)
  }

  suspend fun upsertCloudForumReplies(replies: List<ForumReplyEntity>) = withContext(Dispatchers.IO) {
    if (replies.isNotEmpty()) forumReplyDao.insertReplies(replies)
  }

  suspend fun upsertCloudDMs(dms: List<DirectMessageEntity>) = withContext(Dispatchers.IO) {
    if (dms.isNotEmpty()) directMessageDao.upsertDMs(dms)
  }

  suspend fun upsertCloudFriends(friends: List<FriendEntity>) = withContext(Dispatchers.IO) {
    if (friends.isNotEmpty()) friendDao.upsertFriends(friends)
  }

  suspend fun upsertCloudFollows(follows: List<UserFollowEntity>) = withContext(Dispatchers.IO) {
    if (follows.isNotEmpty()) userFollowDao.upsertFollows(follows)
  }

  suspend fun upsertCloudStickers(packs: List<StickerPackEntity>, stickers: List<StickerEntity>) = withContext(Dispatchers.IO) {
    packs.forEach { stickerDao.insertPack(it) }
    stickers.forEach { stickerDao.insertSticker(it) }
  }

  suspend fun upsertCloudMatches(matches: List<GameMatchEntity>) = withContext(Dispatchers.IO) {
    if (matches.isNotEmpty()) gameDao.upsertMatches(matches)
  }

  suspend fun upsertCloudRatings(ratings: List<GameRatingEntity>) = withContext(Dispatchers.IO) {
    ratings.forEach { gameDao.upsertRating(it) }
  }

  suspend fun upsertCloudTournaments(tournaments: List<TournamentEntity>) = withContext(Dispatchers.IO) {
    tournaments.forEach { gameDao.upsertTournament(it) }
  }

  suspend fun upsertCloudRestrictions(restrictions: List<UserRestrictionEntity>) = withContext(Dispatchers.IO) {
    restrictions.forEach { adminModerationDao.upsertRestriction(it) }
  }

  suspend fun upsertCloudNotifications(notifs: List<NotificationEntity>) = withContext(Dispatchers.IO) {
    notifs.forEach { notificationDao.insertNotification(it) }
  }

  fun getCurrentUserFlow(): Flow<UserEntity?> {
    return _currentUserId.flatMapLatest { id ->
      if (id == null) flowOf(null)
      else userDao.getUserByIdFlow(id)
    }
  }

  suspend fun getCurrentUser(): UserEntity? = withContext(Dispatchers.IO) {
    val id = _currentUserId.value ?: Firebase.auth.currentUser?.uid
    id?.let { userDao.getUserById(it) }
  }

  suspend fun getUserById(userId: String): UserEntity? = withContext(Dispatchers.IO) {
    userDao.getUserById(userId)
  }

  suspend fun awardXp(xpDelta: Long) = withContext(Dispatchers.IO) {
    val current = getCurrentUser() ?: return@withContext
    val nextXp = (current.xp + xpDelta).coerceAtLeast(0L)
    val nextLevel = ((nextXp / 250L).toInt() + 1).coerceAtLeast(1)
    if (nextXp != current.xp || nextLevel != current.level) {
      val updated = current.copy(xp = nextXp, level = nextLevel)
      userDao.updateUser(updated)
      if (nextLevel >= 5) recordBadgeProgress("loyal_member", nextLevel, setAbsolute = true)
      if (nextLevel >= 10) recordBadgeProgress("veteran", nextLevel, setAbsolute = true)
      runCatching { cloudRepo.upsertPublicProfile(updated, isCreate = false) }
    }
  }

  suspend fun recordBadgeProgress(badgeId: String, amount: Int = 1, setAbsolute: Boolean = false) = withContext(Dispatchers.IO) {
    val current = getCurrentUser() ?: return@withContext
    val def = BadgeCatalog.getBadge(badgeId) ?: return@withContext
    val map = BadgeCatalog.parseProgressMap(current.unlockedBadgesProgressJson).toMutableMap()
    val prev = map[badgeId] ?: 0
    val next = if (setAbsolute) maxOf(prev, amount) else (prev + amount)
    map[badgeId] = next

    val currentBadges = current.equippedBadges.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableSet()
    var unlockedNew = false
    if (next >= def.targetProgress && !currentBadges.contains(badgeId)) {
      currentBadges.add(badgeId)
      unlockedNew = true
    }

    // Check Hall of Fame milestone (15+ unlocked badges)
    if (currentBadges.size >= 15 && currentBadges.add("hall_of_fame")) {
      map["hall_of_fame"] = currentBadges.size
      unlockedNew = true
    }

    val updated = current.copy(
      unlockedBadgesProgressJson = BadgeCatalog.serializeProgressMap(map),
      equippedBadges = currentBadges.joinToString(",")
    )
    userDao.updateUser(updated)
    if (unlockedNew) {
      runCatching { cloudRepo.upsertPublicProfile(updated, isCreate = false) }
      pushLocalAndRemoteNotification(
        targetUserId = current.id,
        title = "Badge Baru Terbuka: ${def.name}",
        message = def.description,
        type = "REWARD"
      )
    }
  }

  suspend fun recordProfileVisit(profileUserId: String) = withContext(Dispatchers.IO) {
    val visitor = getCurrentUser() ?: return@withContext
    if (visitor.id == profileUserId) return@withContext
    val target = userDao.getUserById(profileUserId) ?: return@withContext
    if (!target.allowProfileVisitors) return@withContext
    profileVisitorDao.insertVisitor(
      ProfileVisitorEntity(
        id = "vis_${profileUserId}_${visitor.id}",
        profileUserId = profileUserId,
        visitorUserId = visitor.id,
        visitorUsername = visitor.username,
        visitorAvatarUri = visitor.avatarUri,
        visitedAt = System.currentTimeMillis()
      )
    )
  }

  suspend fun updateProfile(
    displayName: String,
    bio: String,
    pronouns: String,
    avatarUri: String?,
    bannerUri: String?,
    profileColor: Long,
    bubbleStyle: String,
    displayNameFont: String,
    displayNameColorsCsv: String,
    displayNameEffect: String,
    profileBgColorsCsv: String,
    equippedBadges: String? = null,
    presenceStatus: String? = null,
    statusTag: String? = null,
    equippedEffect: String? = null
  ) = withContext(Dispatchers.IO) {
    val current = getCurrentUser() ?: return@withContext
    val safeAvatar = avatarUri ?: current.avatarUri
    val safeBanner = bannerUri ?: current.bannerUri

    val updated = current.copy(
      displayName = displayName.ifBlank { current.displayName },
      bio = bio,
      pronouns = pronouns,
      avatarUri = safeAvatar,
      bannerUri = safeBanner,
      profileColor = profileColor,
      messageBubbleStyle = bubbleStyle,
      displayNameFont = displayNameFont,
      displayNameColorsCsv = displayNameColorsCsv,
      displayNameEffect = displayNameEffect,
      profileBgColorsCsv = profileBgColorsCsv,
      equippedBadges = equippedBadges ?: current.equippedBadges,
      presenceStatus = presenceStatus ?: current.presenceStatus,
      statusTag = statusTag ?: current.statusTag,
      equippedEffect = equippedEffect ?: current.equippedEffect,
      lastSeenAt = System.currentTimeMillis()
    )
    userDao.updateUser(updated)
    runCatching { cloudRepo.upsertPublicProfile(updated, isCreate = false) }
  }

  // --- FOLLOWS & GAMES/APPS ---

  fun getFollowingFlow(userId: String): Flow<List<UserFollowEntity>> = userFollowDao.getFollowingFlow(userId)
  fun getFollowersFlow(userId: String): Flow<List<UserFollowEntity>> = userFollowDao.getFollowersFlow(userId)

  suspend fun toggleFollowUser(targetUserId: String): Result<Boolean> = withContext(Dispatchers.IO) {
    val me = getCurrentUser() ?: return@withContext Result.failure(Exception("Harus login"))
    if (me.id == targetUserId) return@withContext Result.failure(Exception("Tidak dapat mengikuti diri sendiri."))
    val followId = "${me.id}_$targetUserId"
    val existing = userFollowDao.getFollowRecord(me.id, targetUserId)
    return@withContext if (existing != null) {
      userFollowDao.deleteFollow(existing)
      val nextMe = me.copy(followingCount = (me.followingCount - 1).coerceAtLeast(0))
      userDao.updateUser(nextMe)
      val target = userDao.getUserById(targetUserId)
      if (target != null) {
        userDao.updateUser(target.copy(followersCount = (target.followersCount - 1).coerceAtLeast(0)))
      }
      runCatching {
        cloudRepo.deleteFollowRemote(followId)
        cloudRepo.upsertPublicProfile(nextMe, isCreate = false)
        cloudRepo.updateFollowersCountRemote(targetUserId, -1L)
      }
      Result.success(false)
    } else {
      val follow = UserFollowEntity(id = followId, followerId = me.id, targetUserId = targetUserId)
      userFollowDao.insertFollow(follow)
      val nextMe = me.copy(followingCount = me.followingCount + 1)
      userDao.updateUser(nextMe)
      val target = userDao.getUserById(targetUserId)
      if (target != null) {
        val nextCount = target.followersCount + 1
        userDao.updateUser(target.copy(followersCount = nextCount))
      }
      runCatching {
        cloudRepo.upsertFollowRemote(follow)
        cloudRepo.upsertPublicProfile(nextMe, isCreate = false)
        cloudRepo.updateFollowersCountRemote(targetUserId, 1L)
        pushLocalAndRemoteNotification(
          targetUserId = targetUserId,
          title = "New Follower",
          message = "@${me.username} started following your profile.",
          type = "FOLLOW"
        )
      }
      Result.success(true)
    }
  }

  fun getUserGamesApps(userId: String): Flow<List<UserGameAppEntity>> = userGameAppDao.getGamesAppsForUser(userId)

  suspend fun saveUserGameApp(item: UserGameAppEntity) = withContext(Dispatchers.IO) {
    userGameAppDao.insertGameApp(item)
    recordBadgeProgress("gamer", 1)
    runCatching { cloudRepo.upsertUserGameApp(item) }
  }

  suspend fun deleteUserGameApp(item: UserGameAppEntity) = withContext(Dispatchers.IO) {
    userGameAppDao.deleteGameApp(item)
    runCatching { cloudRepo.deleteUserGameApp(item.id) }
  }

  suspend fun swapUserGameAppOrder(first: UserGameAppEntity, second: UserGameAppEntity) = withContext(Dispatchers.IO) {
    val u1 = first.copy(orderIndex = second.orderIndex)
    val u2 = second.copy(orderIndex = first.orderIndex)
    userGameAppDao.updateGameApp(u1)
    userGameAppDao.updateGameApp(u2)
    runCatching {
      cloudRepo.upsertUserGameApp(u1)
      cloudRepo.upsertUserGameApp(u2)
    }
  }

  // --- PRESENCE & CONNECTIONS ---

  suspend fun sendPresenceHeartbeat(status: String? = null, statusTag: String? = null) = withContext(Dispatchers.IO) {
    val current = getCurrentUser() ?: return@withContext
    val nextStatus = status ?: current.presenceStatus
    val nextTag = statusTag ?: current.statusTag
    val now = System.currentTimeMillis()
    userDao.updatePresence(current.id, nextStatus, nextTag, now)
    runCatching {
      cloudRepo.updatePresenceAndTyping(
        presenceStatus = nextStatus,
        statusTag = nextTag,
        updateTyping = false
      )
    }
  }

  suspend fun setTypingChannel(channelId: String?) = withContext(Dispatchers.IO) {
    val current = getCurrentUser() ?: return@withContext
    val now = System.currentTimeMillis()
    userDao.updateTyping(current.id, channelId, now)
    runCatching {
      cloudRepo.updatePresenceAndTyping(
        typingChannelId = channelId,
        updateTyping = true
      )
    }
  }

  suspend fun updateUserConnections(connectionsJson: String) = withContext(Dispatchers.IO) {
    val current = getCurrentUser() ?: return@withContext
    val updated = current.copy(connectionsJson = connectionsJson, lastSeenAt = System.currentTimeMillis())
    userDao.updateUser(updated)
    if (connectionsJson.contains("github", ignoreCase = true)) {
      recordBadgeProgress("programmer", 1, setAbsolute = true)
    }
    runCatching { cloudRepo.upsertPublicProfile(updated, isCreate = false) }
  }

  suspend fun updateActiveAppState(appName: String?, appPkg: String?, startedAt: Long) = withContext(Dispatchers.IO) {
    val current = getCurrentUser() ?: return@withContext
    if (current.activeAppName == appName && current.activeAppPackage == appPkg) return@withContext
    userDao.updateActiveApp(current.id, appName, appPkg, startedAt)
    runCatching { cloudRepo.updateActiveAppFields(appName, appPkg, startedAt) }
  }

  suspend fun updateListeningStatus(
    title: String?,
    artist: String?,
    coverUri: String?,
    sourceUrl: String?,
    isPlaying: Boolean,
    privacy: String? = null
  ) = withContext(Dispatchers.IO) {
    val current = getCurrentUser() ?: return@withContext
    val effectivePrivacy = privacy ?: current.listeningPrivacy
    val updated = current.copy(
      listeningTitle = title,
      listeningArtist = artist,
      listeningCoverUri = coverUri,
      listeningSourceUrl = sourceUrl,
      listeningIsPlaying = isPlaying,
      listeningPrivacy = effectivePrivacy
    )
    userDao.updateUser(updated)
    runCatching {
      cloudRepo.updateListeningStatusRemote(
        title = title,
        artist = artist,
        coverUri = coverUri,
        sourceUrl = sourceUrl,
        isPlaying = isPlaying,
        privacy = effectivePrivacy
      )
    }
  }

  // --- SAVED PROFILE THEMES, APPEARANCE, CUSTOM BACKGROUND & SETTINGS ---

  fun getSavedProfileThemes(userId: String): Flow<List<SavedProfileThemeEntity>> =
    savedProfileThemeDao.getThemesForUser(userId)

  suspend fun upsertCloudSavedThemes(themes: List<SavedProfileThemeEntity>) = withContext(Dispatchers.IO) {
    if (themes.isNotEmpty()) savedProfileThemeDao.upsertThemes(themes)
  }

  suspend fun saveCurrentProfileTheme(name: String): Result<SavedProfileThemeEntity> = withContext(Dispatchers.IO) {
    val current = getCurrentUser() ?: return@withContext Result.failure(Exception("Sign in required"))
    val cleanName = name.trim().take(40)
    if (cleanName.isBlank()) return@withContext Result.failure(Exception("Theme name cannot be empty."))
    savedProfileThemeDao.unequipAllForUser(current.id)
    val theme = SavedProfileThemeEntity(
      id = "thm_${UUID.randomUUID().toString().take(8)}",
      userId = current.id,
      name = cleanName,
      displayNameFont = current.displayNameFont,
      displayNameColorsCsv = current.displayNameColorsCsv,
      displayNameEffect = current.displayNameEffect,
      profileBgColorsCsv = current.profileBgColorsCsv,
      profileColor = current.profileColor,
      equippedEffect = current.equippedEffect,
      chatBubbleBgCsv = current.chatBubbleBgCsv,
      chatBubbleImageUri = current.chatBubbleImageUri,
      appThemeId = current.appThemeId,
      appThemeGradientCsv = current.appThemeGradientCsv,
      appFontKey = current.appFontKey,
      isEquipped = true,
      createdAt = System.currentTimeMillis()
    )
    savedProfileThemeDao.insertTheme(theme)
    recordBadgeProgress("trendsetter", 1)
    runCatching { cloudRepo.upsertSavedTheme(theme) }
    Result.success(theme)
  }

  suspend fun equipSavedProfileTheme(themeId: String): Result<Unit> = withContext(Dispatchers.IO) {
    val current = getCurrentUser() ?: return@withContext Result.failure(Exception("Sign in required"))
    val theme = savedProfileThemeDao.getThemeById(themeId)
      ?: return@withContext Result.failure(Exception("Theme not found."))
    savedProfileThemeDao.unequipAllForUser(current.id)
    val equippedTheme = theme.copy(isEquipped = true)
    savedProfileThemeDao.insertTheme(equippedTheme)
    val updatedUser = current.copy(
      displayNameFont = theme.displayNameFont,
      displayNameColorsCsv = theme.displayNameColorsCsv,
      displayNameEffect = theme.displayNameEffect,
      profileBgColorsCsv = theme.profileBgColorsCsv,
      profileColor = theme.profileColor,
      equippedEffect = theme.equippedEffect,
      chatBubbleBgCsv = theme.chatBubbleBgCsv,
      chatBubbleImageUri = theme.chatBubbleImageUri,
      appThemeId = theme.appThemeId,
      appThemeGradientCsv = theme.appThemeGradientCsv,
      appFontKey = theme.appFontKey
    )
    userDao.updateUser(updatedUser)
    runCatching {
      cloudRepo.upsertSavedTheme(equippedTheme)
      cloudRepo.upsertPublicProfile(updatedUser, isCreate = false)
    }
    Result.success(Unit)
  }

  suspend fun unequipSavedProfileTheme(): Result<Unit> = withContext(Dispatchers.IO) {
    val current = getCurrentUser() ?: return@withContext Result.failure(Exception("Harus login"))
    savedProfileThemeDao.unequipAllForUser(current.id)
    val updatedUser = current.copy(
      displayNameFont = "SERIF",
      displayNameColorsCsv = "0xFFF5F7FA,0xFFC4C9D4",
      displayNameEffect = "GRADIENT",
      profileBgColorsCsv = "0xFF07080B,0xFF111318,0xFF1A1D24",
      profileColor = 0xFFC4C9D4L,
      equippedEffect = null,
      chatBubbleBgCsv = "0xFF1C2029,0xFF2B303D",
      chatBubbleImageUri = null,
      appThemeId = "obsidian_marble",
      appThemeGradientCsv = "",
      appFontKey = "SERIF"
    )
    userDao.updateUser(updatedUser)
    runCatching { cloudRepo.upsertPublicProfile(updatedUser, isCreate = false) }
    Result.success(Unit)
  }

  suspend fun deleteSavedProfileTheme(theme: SavedProfileThemeEntity) = withContext(Dispatchers.IO) {
    savedProfileThemeDao.deleteTheme(theme)
    runCatching { cloudRepo.deleteSavedTheme(theme.id) }
  }

  suspend fun updateAppearanceAndLanguage(
    appThemeId: String? = null,
    appThemeGradientCsv: String? = null,
    appFontKey: String? = null,
    accentColorHex: Long? = null,
    chatBubbleBgCsv: String? = null,
    chatBubbleImageUri: String? = null,
    clearChatBubbleImage: Boolean = false,
    languageCode: String? = null
  ) = withContext(Dispatchers.IO) {
    val current = getCurrentUser() ?: return@withContext
    val safeBubbleImage = if (clearChatBubbleImage) null else (chatBubbleImageUri ?: current.chatBubbleImageUri)
    val updated = current.copy(
      appThemeId = appThemeId ?: current.appThemeId,
      appThemeGradientCsv = appThemeGradientCsv ?: current.appThemeGradientCsv,
      appFontKey = appFontKey ?: current.appFontKey,
      accentColorHex = accentColorHex ?: current.accentColorHex,
      chatBubbleBgCsv = chatBubbleBgCsv ?: current.chatBubbleBgCsv,
      chatBubbleImageUri = safeBubbleImage,
      languageCode = languageCode ?: current.languageCode
    )
    userDao.updateUser(updated)
    runCatching { cloudRepo.upsertPublicProfile(updated, isCreate = false) }
    runCatching {
      cloudRepo.upsertPrivateInfo(
        userId = updated.id,
        email = updated.email,
        languageCode = updated.languageCode,
        allowProfileVisitors = updated.allowProfileVisitors,
        soundEnabled = updated.soundEnabled,
        soundVolume = updated.soundVolume,
        lowPerfMode = updated.lowPerfMode,
        notifPrefsJson = updated.notifPrefsJson
      )
    }
  }

  suspend fun updateCustomWallpaper(
    mode: String,
    uri: String?,
    gradientCsv: String,
    blur: Float,
    opacity: Float,
    brightness: Float,
    tintHex: Long
  ) = withContext(Dispatchers.IO) {
    val current = getCurrentUser() ?: return@withContext
    val updated = current.copy(
      wallpaperMode = mode,
      customWallpaperUri = uri,
      wallpaperGradientCsv = gradientCsv,
      wallpaperBlur = blur,
      wallpaperOpacity = opacity,
      wallpaperBrightness = brightness,
      wallpaperTintHex = tintHex
    )
    userDao.updateUser(updated)
    runCatching { cloudRepo.upsertPublicProfile(updated, isCreate = false) }
  }

  suspend fun updateSoundAndPerfSettings(
    soundEnabled: Boolean? = null,
    soundVolume: Float? = null,
    mutedSoundCategoriesCsv: String? = null,
    lowPerfMode: Boolean? = null,
    notifPrefsJson: String? = null
  ) = withContext(Dispatchers.IO) {
    val current = getCurrentUser() ?: return@withContext
    val updated = current.copy(
      soundEnabled = soundEnabled ?: current.soundEnabled,
      soundVolume = soundVolume ?: current.soundVolume,
      mutedSoundCategoriesCsv = mutedSoundCategoriesCsv ?: current.mutedSoundCategoriesCsv,
      lowPerfMode = lowPerfMode ?: current.lowPerfMode,
      notifPrefsJson = notifPrefsJson ?: current.notifPrefsJson
    )
    SoundEffectsEngine.updateSettings(updated.soundEnabled, updated.soundVolume, updated.mutedSoundCategoriesCsv)
    userDao.updateUser(updated)
    runCatching {
      cloudRepo.upsertPrivateInfo(
        userId = updated.id,
        email = updated.email,
        languageCode = updated.languageCode,
        allowProfileVisitors = updated.allowProfileVisitors,
        soundEnabled = updated.soundEnabled,
        soundVolume = updated.soundVolume,
        lowPerfMode = updated.lowPerfMode,
        notifPrefsJson = updated.notifPrefsJson
      )
    }
  }

  fun getAllUsers(): Flow<List<UserEntity>> = userDao.getAllUsersFlow()

  // --- SERVERS, CATEGORIES, CHANNELS, ROLES ---

  fun getServers(): Flow<List<ServerEntity>> = serverDao.getAllServersFlow()
  fun getJoinedServerIds(userId: String): Flow<List<String>> = serverMemberDao.getJoinedServerIdsFlow(userId)
  fun getCategories(serverId: String): Flow<List<ChannelCategoryEntity>> = channelCategoryDao.getCategoriesForServer(serverId)
  fun getChannels(serverId: String): Flow<List<ChannelEntity>> = channelDao.getChannelsForServer(serverId)
  fun getServerRoles(serverId: String): Flow<List<ServerRoleEntity>> = serverRoleDao.getRolesForServerFlow(serverId)
  fun getServerMembers(serverId: String): Flow<List<ServerMemberEntity>> = serverMemberDao.getMembersForServerFlow(serverId)

  suspend fun createServer(
    name: String,
    description: String,
    serverType: String,
    serverTag: String,
    serverGenre: String,
    supportedGame: String?,
    customInviteCode: String?
  ): Result<ServerEntity> = withContext(Dispatchers.IO) {
    val owner = getCurrentUser() ?: return@withContext Result.failure(Exception("Sign in required"))
    val isAstral = owner.subscriptionTier.equals("ASTRAL", ignoreCase = true) || owner.isOwner

    val cleanCustomCode = customInviteCode?.trim()?.uppercase()?.replace(" ", "-")
    val finalCode = if (!cleanCustomCode.isNullOrBlank()) {
      if (!isAstral) {
        return@withContext Result.failure(Exception("Custom invite codes require Astral tier!"))
      }
      if (cleanCustomCode.length < 3) {
        return@withContext Result.failure(Exception("Custom invite code must be at least 3 characters."))
      }
      if (serverDao.getServerByInviteCode(cleanCustomCode) != null) {
        return@withContext Result.failure(Exception("Invite code '$cleanCustomCode' is already in use."))
      }
      cleanCustomCode
    } else {
      "XC-${UUID.randomUUID().toString().take(6).uppercase()}"
    }

    val serverId = "srv_${UUID.randomUUID().toString().take(8)}"
    val newServer = ServerEntity(
      id = serverId,
      name = name.trim(),
      description = description.trim().ifBlank { "Server $serverType ($serverGenre)" },
      inviteCode = finalCode,
      ownerId = owner.id,
      boostLevel = if (isAstral) 1 else 0,
      boostCount = if (isAstral) 2 else 0,
      category = serverGenre,
      serverType = serverType,
      serverTag = if (serverTag.startsWith("#")) serverTag else "#$serverTag",
      serverTagIcon = "shield",
      serverGenre = serverGenre,
      supportedGame = supportedGame?.takeIf { it.isNotBlank() }
    )
    val catGeneral = ChannelCategoryEntity("cat_${serverId}_gen", serverId, "GENERAL", 0)
    val catCommunity = ChannelCategoryEntity("cat_${serverId}_com", serverId, "COMMUNITY", 1)
    val catGaming = ChannelCategoryEntity("cat_${serverId}_gam", serverId, "GAMING", 2)
    val ownerMember = ServerMemberEntity("${serverId}_${owner.id}", serverId, owner.id, role = "Owner", roleColor = 0xFFEAB308)
    val defaultRoles = listOf(
      ServerRoleEntity("role_${serverId}_owner", serverId, "Owner", 0xFFEAB308, permissionsCsv = "MANAGE_SERVER,MANAGE_CHANNELS,MANAGE_ROLES,MENTION_EVERYONE,SEND_MESSAGES", position = 100),
      ServerRoleEntity("role_${serverId}_mod", serverId, "Moderator", 0xFFC4C9D4, permissionsCsv = "MANAGE_MESSAGES,PIN_MESSAGES,MENTION_EVERYONE,SEND_MESSAGES", position = 50),
      ServerRoleEntity("role_${serverId}_member", serverId, "Member", 0xFF94A3B8, permissionsCsv = "SEND_MESSAGES", position = 10)
    )
    val defaultChannels = listOf(
      ChannelEntity("ch_${serverId}_gen", serverId, "general", "Main text chat channel", "text", false, 0, catGeneral.id),
      ChannelEntity("ch_${serverId}_ann", serverId, "announcements", "Important server news", "announcements", false, 1, catGeneral.id),
      ChannelEntity("ch_${serverId}_rules", serverId, "rules", "Server member rules", "rules", false, 2, catGeneral.id),
      ChannelEntity("ch_${serverId}_forums", serverId, "forums", "Community topics & discussions", "forums", false, 3, catCommunity.id),
      ChannelEntity("ch_${serverId}_media", serverId, "media", "Photos, 7s videos, GIFs & stickers", "media", false, 4, catCommunity.id),
      ChannelEntity("ch_${serverId}_voice", serverId, "Voice Room", "Voice hangout channel", "voice", false, 5, catGaming.id)
    )

    serverDao.insertServer(newServer)
    channelCategoryDao.insertCategories(listOf(catGeneral, catCommunity, catGaming))
    serverMemberDao.insertMembership(ownerMember)
    serverRoleDao.insertRoles(defaultRoles)
    channelDao.insertChannels(defaultChannels)

    runCatching {
      cloudRepo.upsertServer(newServer, isCreate = true)
      listOf(catGeneral, catCommunity, catGaming).forEach { cloudRepo.upsertCategory(it) }
      cloudRepo.upsertMember(ownerMember)
      defaultRoles.forEach { cloudRepo.upsertRole(it) }
      defaultChannels.forEach { cloudRepo.upsertChannel(it) }
    }

    recordBadgeProgress("server_founder", 1)
    incrementQuestProgress("q_4", 1)
    logAudit("CREATE_SERVER", "Created server: ${newServer.name} (${newServer.serverType}) code $finalCode")
    Result.success(newServer)
  }

  suspend fun createCategory(serverId: String, name: String): Result<ChannelCategoryEntity> = withContext(Dispatchers.IO) {
    val clean = name.trim().uppercase()
    if (clean.isBlank()) return@withContext Result.failure(Exception("Category name is required."))
    val cat = ChannelCategoryEntity(
      id = "cat_${UUID.randomUUID().toString().take(8)}",
      serverId = serverId,
      name = clean,
      orderIndex = (System.currentTimeMillis() % 10000).toInt()
    )
    channelCategoryDao.insertCategory(cat)
    recordBadgeProgress("community_builder", 1)
    runCatching { cloudRepo.upsertCategory(cat) }
    Result.success(cat)
  }

  suspend fun updateCategory(category: ChannelCategoryEntity) = withContext(Dispatchers.IO) {
    channelCategoryDao.updateCategory(category)
    runCatching { cloudRepo.upsertCategory(category) }
  }

  suspend fun deleteCategory(category: ChannelCategoryEntity) = withContext(Dispatchers.IO) {
    channelCategoryDao.deleteCategory(category)
    runCatching { cloudRepo.deleteCategory(category.serverId, category.id) }
  }

  suspend fun createChannel(
    serverId: String,
    name: String,
    description: String,
    type: String,
    categoryId: String = ""
  ): Result<ChannelEntity> = withContext(Dispatchers.IO) {
    val cleanName = name.trim().lowercase().replace(" ", "-")
    if (cleanName.isBlank()) {
      return@withContext Result.failure(Exception("Channel name cannot be empty."))
    }
    val ch = ChannelEntity(
      id = "ch_${UUID.randomUUID().toString().take(8)}",
      serverId = serverId,
      name = if (type == "voice") name.trim() else cleanName,
      description = description.trim().ifBlank { "$type channel" },
      type = type,
      isPrivate = false,
      orderIndex = (System.currentTimeMillis() % 100000).toInt(),
      categoryId = categoryId
    )
    channelDao.insertChannel(ch)
    recordBadgeProgress("community_builder", 1)
    runCatching { cloudRepo.upsertChannel(ch) }
    logAudit("CREATE_CHANNEL", "Added channel '${ch.name}' ($type) to server $serverId")
    Result.success(ch)
  }

  suspend fun moveChannelToCategory(channel: ChannelEntity, newCategoryId: String) = withContext(Dispatchers.IO) {
    val updated = channel.copy(categoryId = newCategoryId)
    channelDao.updateChannel(updated)
    runCatching { cloudRepo.upsertChannel(updated, isUpdate = true) }
  }

  suspend fun toggleServerVanish(serverId: String, vanish: Boolean): Result<ServerEntity> = withContext(Dispatchers.IO) {
    val verifiedRole = cloudRepo.checkVerifiedAdminRole()
    if (verifiedRole == "NONE") {
      return@withContext Result.failure(Exception("Only verified admins can toggle Vanish Server."))
    }
    val srv = serverDao.getServerById(serverId) ?: return@withContext Result.failure(Exception("Server not found."))
    val updated = srv.copy(isVanished = vanish)
    serverDao.updateServer(updated)
    runCatching { cloudRepo.upsertServer(updated, isCreate = false) }
    logAudit("VANISH_SERVER", "Admin (${verifiedRole}) set Vanish Server '${srv.name}' -> $vanish")
    Result.success(updated)
  }

  suspend fun kickOrRemoveMember(serverId: String, userId: String) = withContext(Dispatchers.IO) {
    runCatching { cloudRepo.deleteMember(serverId, "${serverId}_$userId") }
    logAudit("KICK_MEMBER", "Member $userId removed from server $serverId")
  }

  suspend fun createOrUpdateServerRole(
    serverId: String,
    roleId: String? = null,
    name: String,
    colorHex: Long,
    iconUri: String? = null,
    chromaKeyColorsCsv: String = "",
    permissionsCsv: String
  ): Result<ServerRoleEntity> = withContext(Dispatchers.IO) {
    val cleanName = name.trim()
    if (cleanName.isBlank()) return@withContext Result.failure(Exception("Role name is required."))
    val user = getCurrentUser()
    val srv = serverDao.getServerById(serverId)
    val hasRoleIconBoost = (srv?.boostCount ?: 0) >= 5 || user?.isOwner == true
    val oldRole = roleId?.let { serverRoleDao.getRoleById(it) }
    val cleanIcon = iconUri?.takeIf { it.isNotBlank() }
    if (cleanIcon != null && cleanIcon != oldRole?.iconUri && !hasRoleIconBoost) {
      return@withContext Result.failure(Exception("Gallery role icons require at least 5 Server Boosts!"))
    }

    val existing = serverRoleDao.getRolesForServerOnce(serverId)
    val role = if (oldRole != null) {
      oldRole.copy(
        name = cleanName,
        colorHex = colorHex,
        iconUri = cleanIcon,
        chromaKeyColorsCsv = chromaKeyColorsCsv.trim(),
        permissionsCsv = permissionsCsv.ifBlank { "SEND_MESSAGES" }
      )
    } else {
      ServerRoleEntity(
        id = "role_${UUID.randomUUID().toString().take(8)}",
        serverId = serverId,
        name = cleanName,
        colorHex = colorHex,
        iconUri = cleanIcon,
        chromaKeyColorsCsv = chromaKeyColorsCsv.trim(),
        permissionsCsv = permissionsCsv.ifBlank { "SEND_MESSAGES" },
        position = (existing.maxOfOrNull { it.position } ?: 10) + 1
      )
    }
    serverRoleDao.insertRole(role)
    runCatching { cloudRepo.upsertRole(role) }

    val members = serverMemberDao.getMembersForServerFlow(serverId).firstOrNull().orEmpty()
    val matchName = oldRole?.name ?: role.name
    members.filter { it.role.equals(matchName, ignoreCase = true) || it.role.equals(role.name, ignoreCase = true) }
      .forEach { m ->
        serverMemberDao.updateMemberRole(
          serverId = serverId,
          userId = m.userId,
          role = role.name,
          roleColor = role.colorHex,
          roleIconUri = role.iconUri,
          roleChromaColorsCsv = role.chromaKeyColorsCsv
        )
        runCatching {
          cloudRepo.upsertMember(
            m.copy(
              role = role.name,
              roleColor = role.colorHex,
              roleIconUri = role.iconUri,
              roleChromaColorsCsv = role.chromaKeyColorsCsv
            )
          )
        }
      }

    logAudit(if (oldRole == null) "CREATE_ROLE" else "UPDATE_ROLE", "Role '${role.name}' saved on server $serverId")
    Result.success(role)
  }

  suspend fun createServerRole(
    serverId: String,
    name: String,
    colorHex: Long,
    permissionsCsv: String
  ): Result<ServerRoleEntity> = createOrUpdateServerRole(
    serverId = serverId,
    roleId = null,
    name = name,
    colorHex = colorHex,
    iconUri = null,
    chromaKeyColorsCsv = "",
    permissionsCsv = permissionsCsv
  )

  suspend fun deleteServerRole(role: ServerRoleEntity) = withContext(Dispatchers.IO) {
    serverRoleDao.deleteRole(role)
    runCatching { cloudRepo.deleteRole(role.serverId, role.id) }
    logAudit("DELETE_ROLE", "Role '${role.name}' deleted from server ${role.serverId}")
  }

  suspend fun assignRoleToUser(
    serverId: String,
    targetUserId: String,
    role: ServerRoleEntity
  ) = withContext(Dispatchers.IO) {
    val existing = serverMemberDao.getMembership(serverId, targetUserId)
    val member = if (existing == null) {
      ServerMemberEntity(
        id = "${serverId}_$targetUserId",
        serverId = serverId,
        userId = targetUserId,
        role = role.name,
        roleColor = role.colorHex,
        roleIconUri = role.iconUri,
        roleChromaColorsCsv = role.chromaKeyColorsCsv
      )
    } else {
      existing.copy(
        role = role.name,
        roleColor = role.colorHex,
        roleIconUri = role.iconUri,
        roleChromaColorsCsv = role.chromaKeyColorsCsv
      )
    }
    serverMemberDao.insertMembership(member)
    runCatching { cloudRepo.upsertMember(member) }
    logAudit("ASSIGN_ROLE", "Assigned role '${role.name}' to user $targetUserId on server $serverId")
  }

  suspend fun updateServerAppearance(
    serverId: String,
    name: String,
    description: String,
    iconUri: String?,
    bannerUri: String?,
    serverTag: String? = null,
    serverTagIcon: String? = null,
    supportedGame: String? = null
  ): Result<ServerEntity> = withContext(Dispatchers.IO) {
    val user = getCurrentUser() ?: return@withContext Result.failure(Exception("Sign in required"))
    val srv = serverDao.getServerById(serverId) ?: return@withContext Result.failure(Exception("Server not found"))
    val finalBanner = if (!bannerUri.isNullOrBlank() && bannerUri != srv.bannerUri && srv.boostLevel < 1 && !user.isOwner) {
      return@withContext Result.failure(Exception("Server banner unlocks at Boost Level 1 (2+ Boosts)!"))
    } else {
      bannerUri ?: srv.bannerUri
    }

    val cleanTag = serverTag?.trim()?.let {
      if (it.isBlank()) srv.serverTag else if (it.startsWith("#")) it else "#$it"
    } ?: srv.serverTag
    val cleanTagIcon = serverTagIcon?.trim()?.takeIf { it.isNotBlank() } ?: srv.serverTagIcon
    val tagChanged = cleanTag != srv.serverTag || cleanTagIcon != srv.serverTagIcon
    if (tagChanged && srv.boostCount < 3 && !user.isOwner) {
      return@withContext Result.failure(Exception("Custom server tag & icon require at least 3 Server Boosts!"))
    }

    val updated = srv.copy(
      name = name.trim().ifBlank { srv.name },
      description = description.trim().ifBlank { srv.description },
      iconUri = iconUri ?: srv.iconUri,
      bannerUri = finalBanner,
      serverTag = cleanTag,
      serverTagIcon = cleanTagIcon,
      supportedGame = supportedGame ?: srv.supportedGame
    )
    serverDao.updateServer(updated)
    runCatching { cloudRepo.upsertServer(updated, isCreate = false) }
    logAudit("UPDATE_SERVER", "Updated server '${updated.name}'")
    Result.success(updated)
  }

  suspend fun boostServer(serverId: String): Result<ServerEntity> = withContext(Dispatchers.IO) {
    val user = getCurrentUser() ?: return@withContext Result.failure(Exception("Sign in required"))
    val srv = serverDao.getServerById(serverId) ?: return@withContext Result.failure(Exception("Server not found"))
    if (!user.isOwner && user.boostBalance <= 0) {
      return@withContext Result.failure(Exception("No Server Boosts left! Get 7 Boosts in Marketplace."))
    }
    val newCount = srv.boostCount + 1
    val newLevel = when {
      newCount >= 14 -> 3
      newCount >= 7 -> 2
      newCount >= 2 -> 1
      else -> 0
    }
    val updatedSrv = srv.copy(boostCount = newCount, boostLevel = newLevel)
    serverDao.updateServer(updatedSrv)
    runCatching { cloudRepo.updateServerBoostOnly(serverId, newLevel, newCount) }

    var updatedUser = user
    if (!user.isOwner) {
      val nextBoostBal = (user.boostBalance - 1).coerceAtLeast(0)
      userDao.updateBoostBalance(user.id, nextBoostBal)
      updatedUser = updatedUser.copy(boostBalance = nextBoostBal)
    }
    recordBadgeProgress("server_booster", 1)
    runCatching { cloudRepo.upsertPublicProfile(updatedUser, isCreate = false) }
    logAudit("BOOST_SERVER", "@${user.username} boosted '${srv.name}' (Total: $newCount Boosts, Lvl $newLevel)")
    Result.success(updatedSrv)
  }

  suspend fun joinServerByInviteCode(code: String): Result<ServerEntity> = withContext(Dispatchers.IO) {
    val user = getCurrentUser() ?: return@withContext Result.failure(Exception("Sign in required"))
    val clean = code.trim().uppercase()
    val server = serverDao.getServerByInviteCode(clean)
      ?: return@withContext Result.failure(Exception("Invite code '$clean' not found."))
    val member = ServerMemberEntity("${server.id}_${user.id}", server.id, user.id, role = "Member", roleColor = 0xFF949BA4)
    serverMemberDao.insertMembership(member)
    runCatching { cloudRepo.upsertMember(member) }
    incrementQuestProgress("q_4", 1)
    recordBadgeProgress("explorer", 1)
    Result.success(server)
  }

  suspend fun ensureServerMembership(serverId: String) = withContext(Dispatchers.IO) {
    val user = getCurrentUser() ?: return@withContext
    if (serverMemberDao.getMembership(serverId, user.id) == null) {
      val member = ServerMemberEntity(
        id = "${serverId}_${user.id}",
        serverId = serverId,
        userId = user.id,
        role = if (user.isOwner) "Owner" else "Member",
        roleColor = if (user.isOwner) 0xFFEAB308 else 0xFF949BA4
      )
      serverMemberDao.insertMembership(member)
      runCatching { cloudRepo.upsertMember(member) }
    }
  }

  suspend fun deleteServer(server: ServerEntity) = withContext(Dispatchers.IO) {
    serverDao.deleteServer(server)
    logAudit("DELETE_SERVER", "Server dihapus: ${server.name}")
  }

  // --- MESSAGES (CHANNEL + MENTIONS + LOCATION + STICKER + 7S VIDEO + FORWARD + PAGINATION) ---

  fun getMessages(channelId: String): Flow<List<MessageEntity>> = messageDao.getMessagesForChannel(channelId)
  fun getPinnedMessages(channelId: String): Flow<List<MessageEntity>> = messageDao.getPinnedMessages(channelId)

  suspend fun sendMessage(
    channelId: String,
    content: String,
    attachmentUri: String? = null,
    attachmentName: String? = null,
    attachmentMimeType: String? = null,
    attachmentSizeBytes: Long = 0L,
    attachmentDurationMs: Long = 0L,
    replyToId: String? = null,
    replyToSnippet: String? = null,
    forwardedFromId: String? = null,
    forwardedFromName: String? = null,
    locationLat: Double? = null,
    locationLng: Double? = null,
    locationLabel: String? = null,
    locationLiveUntil: Long = 0L,
    stickerId: String? = null,
    gameInviteMatchId: String? = null
  ): Result<MessageEntity> = withContext(Dispatchers.IO) {
    val user = getCurrentUser() ?: return@withContext Result.failure(Exception("Harus login"))
    if (attachmentMimeType?.startsWith("video/") == true && attachmentDurationMs > VideoTrimHelper.MAX_VIDEO_DURATION_MS) {
      return@withContext Result.failure(Exception("Video melebihi batas maksimal 7 detik!"))
    }
    val channel = channelDao.getChannelById(channelId)
    val server = channel?.let { serverDao.getServerById(it.serverId) }
    val member = channel?.let { serverMemberDao.getMembership(it.serverId, user.id) }
    val matchingRole = if (channel != null && member != null) {
      serverRoleDao.getRolesForServerOnce(channel.serverId).firstOrNull {
        it.name.equals(member.role, ignoreCase = true)
      }
    } else null

    val rolePerms = matchingRole?.permissionsCsv ?: "SEND_MESSAGES"
    val canMentionEveryone = user.isOwner ||
      server?.ownerId == user.id ||
      rolePerms.contains("MANAGE_SERVER") ||
      rolePerms.contains("MENTION_EVERYONE")

    val mentionedTargets = mutableListOf<String>()
    val allUsers = userDao.getAllUsers()
    Regex("@([a-zA-Z0-9_]+)").findAll(content).forEach { m ->
      val handle = m.groupValues[1].lowercase()
      if (handle == "everyone") {
        if (canMentionEveryone) mentionedTargets.add("everyone")
      } else {
        allUsers.find { it.username.equals(handle, ignoreCase = true) }?.let { target ->
          mentionedTargets.add(target.id)
        }
      }
    }

    val msg = MessageEntity(
      id = "msg_${UUID.randomUUID().toString().take(10)}",
      channelId = channelId,
      senderId = user.id,
      senderName = user.displayName,
      senderAvatarUri = user.avatarUri,
      senderFrameId = user.equippedFrame,
      senderTier = user.subscriptionTier,
      senderBadges = user.equippedBadges,
      senderDisplayFont = user.displayNameFont,
      senderDisplayColorsCsv = user.displayNameColorsCsv,
      senderDisplayEffect = user.displayNameEffect,
      senderServerTag = server?.serverTag,
      senderServerTagIcon = server?.serverTagIcon,
      senderRoleIconUri = matchingRole?.iconUri ?: member?.roleIconUri,
      senderRoleChromaCsv = matchingRole?.chromaKeyColorsCsv ?: member?.roleChromaColorsCsv ?: "",
      senderRoleColor = matchingRole?.colorHex ?: member?.roleColor ?: 0xFF949BA4L,
      content = content,
      attachmentUri = attachmentUri,
      attachmentName = attachmentName,
      attachmentMimeType = attachmentMimeType,
      attachmentSizeBytes = attachmentSizeBytes,
      attachmentDurationMs = attachmentDurationMs.coerceIn(0L, VideoTrimHelper.MAX_VIDEO_DURATION_MS),
      replyToMessageId = replyToId,
      replyToSnippet = replyToSnippet,
      forwardedFromId = forwardedFromId,
      forwardedFromName = forwardedFromName,
      locationLat = locationLat,
      locationLng = locationLng,
      locationLabel = locationLabel,
      locationLiveUntil = locationLiveUntil,
      stickerId = stickerId,
      gameInviteMatchId = gameInviteMatchId,
      mentionTargetsCsv = mentionedTargets.distinct().joinToString(","),
      reactions = "",
      timestamp = System.currentTimeMillis()
    )
    messageDao.insertMessage(msg)
    runCatching { cloudRepo.sendChannelMessage(msg) }

    // Mention notifications respecting role permissions
    mentionedTargets.distinct().forEach { target ->
      if (target == "everyone" && channel != null && canMentionEveryone) {
        val members = serverMemberDao.getMembersForServerFlow(channel.serverId).firstOrNull().orEmpty()
        members.filter { it.userId != user.id }.take(25).forEach { m ->
          pushLocalAndRemoteNotification(
            targetUserId = m.userId,
            title = "@everyone in #${channel.name}",
            message = "${user.displayName}: ${content.take(120)}",
            type = "MENTION"
          )
        }
      } else if (target != user.id && target != "everyone") {
        pushLocalAndRemoteNotification(
          targetUserId = target,
          title = "Mention from ${user.displayName}",
          message = content.take(120),
          type = "MENTION"
        )
      }
    }

    incrementQuestProgress("q_1", 1)
    awardXp(15L)
    trackTimeAndMediaBadges(attachmentMimeType)
    Result.success(msg)
  }

  private suspend fun trackTimeAndMediaBadges(mimeType: String?) {
    val cal = Calendar.getInstance()
    val hour = cal.get(Calendar.HOUR_OF_DAY)
    if (hour in 5..8) recordBadgeProgress("early_bird", 1)
    if (hour in 0..4) recordBadgeProgress("night_owl", 1)
    recordBadgeProgress("conversation_master", 1)
    recordBadgeProgress("community_legend", 1)
    if (mimeType != null && (mimeType.startsWith("image/") || mimeType.startsWith("video/"))) {
      recordBadgeProgress("photographer", 1)
    }
    if (mimeType == "image/gif") {
      recordBadgeProgress("gif_collector", 1)
    }
  }

  suspend fun editMessage(messageId: String, newContent: String) = withContext(Dispatchers.IO) {
    val msg = messageDao.getMessageById(messageId) ?: return@withContext
    messageDao.updateMessage(msg.copy(content = newContent, isEdited = true))
    runCatching { cloudRepo.updateChannelMessageContent(msg.channelId, msg.id, newContent) }
  }

  suspend fun deleteMessage(messageId: String) = withContext(Dispatchers.IO) {
    val msg = messageDao.getMessageById(messageId) ?: return@withContext
    messageDao.deleteMessage(msg)
    runCatching { cloudRepo.deleteChannelMessage(msg.channelId, msg.id) }
  }

  suspend fun togglePinMessage(messageId: String) = withContext(Dispatchers.IO) {
    val msg = messageDao.getMessageById(messageId) ?: return@withContext
    val nextPinned = !msg.isPinned
    messageDao.updateMessage(msg.copy(isPinned = nextPinned))
    runCatching { cloudRepo.updateChannelMessageReactionsOrPin(msg.channelId, msg.id, isPinned = nextPinned) }
  }

  suspend fun addReaction(messageId: String, reactionType: String) = withContext(Dispatchers.IO) {
    val msg = messageDao.getMessageById(messageId) ?: return@withContext
    val map = mutableMapOf<String, Int>()
    if (msg.reactions.isNotBlank()) {
      msg.reactions.split(",").forEach {
        val parts = it.split(":")
        if (parts.size == 2) {
          map[parts[0]] = parts[1].toIntOrNull() ?: 1
        }
      }
    }
    map[reactionType] = (map[reactionType] ?: 0) + 1
    val newReactions = map.entries.joinToString(",") { "${it.key}:${it.value}" }
    messageDao.updateMessage(msg.copy(reactions = newReactions))
    runCatching { cloudRepo.updateChannelMessageReactionsOrPin(msg.channelId, msg.id, reactions = newReactions) }
    recordBadgeProgress("supporter", 1)
  }

  suspend fun markChannelMessagesAsRead(channelId: String, messages: List<MessageEntity>) = withContext(Dispatchers.IO) {
    val uid = _currentUserId.value ?: return@withContext
    val toMark = messages.takeLast(12).filter { msg ->
      msg.senderId != uid && !msg.readByCsv.split(",").contains(uid)
    }
    toMark.forEach { msg ->
      val readers = (msg.readByCsv.split(",").filter { it.isNotBlank() } + uid).distinct()
      val nextCsv = readers.joinToString(",")
      messageDao.updateMessage(msg.copy(readByCsv = nextCsv))
      runCatching { cloudRepo.markChannelMessageReadBy(channelId, msg.id, nextCsv) }
    }
  }

  suspend fun searchMessages(channelId: String, query: String): List<MessageEntity> = withContext(Dispatchers.IO) {
    messageDao.searchMessages(channelId, query)
  }

  suspend fun globalSearch(query: String): GlobalSearchResult = withContext(Dispatchers.IO) {
    val q = query.trim().lowercase()
    if (q.isBlank()) return@withContext GlobalSearchResult()
    val users = userDao.getAllUsers().filter {
      it.username.lowercase().contains(q) || it.displayName.lowercase().contains(q)
    }.take(12)
    val servers = serverDao.getAllServersFlow().firstOrNull().orEmpty().filter {
      it.name.lowercase().contains(q) || it.description.lowercase().contains(q) || it.serverTag.lowercase().contains(q)
    }.take(12)
    val channels = channelDao.getAllChannels().firstOrNull().orEmpty().filter {
      it.name.lowercase().contains(q) || it.description.lowercase().contains(q)
    }.take(15)
    val msgs = messageDao.searchAllMessages(query).take(20)
    val dms = directMessageDao.searchAllDMs(query).take(20)
    val stickers = stickerDao.getAllStickers().firstOrNull().orEmpty().filter {
      it.name.lowercase().contains(q) || it.overlayText.lowercase().contains(q)
    }.take(12)
    val games = listOf("Tic Tac Toe", "Chess / Catur", "Connect Four", "Reversi / Othello")
      .filter { it.lowercase().contains(q) }
    GlobalSearchResult(users, servers, channels, msgs, dms, stickers, games)
  }

  // --- FORUMS ---

  fun getForumPosts(channelId: String): Flow<List<ForumPostEntity>> = forumPostDao.getPostsForChannel(channelId)
  fun getForumReplies(postId: String): Flow<List<ForumReplyEntity>> = forumReplyDao.getRepliesForPost(postId)

  suspend fun createForumPost(
    channelId: String,
    title: String,
    content: String,
    imageUri: String?,
    tagLabel: String,
    tagEmoji: String,
    isPinned: Boolean = false
  ): Result<ForumPostEntity> = withContext(Dispatchers.IO) {
    val user = getCurrentUser() ?: return@withContext Result.failure(Exception("Sign in required"))
    val cleanTitle = title.trim()
    if (cleanTitle.isBlank()) return@withContext Result.failure(Exception("Thread title is required."))
    val post = ForumPostEntity(
      id = "fp_${UUID.randomUUID().toString().take(8)}",
      channelId = channelId,
      authorId = user.id,
      authorName = user.displayName,
      authorAvatarUri = user.avatarUri,
      title = cleanTitle,
      content = content.trim(),
      imageUri = imageUri,
      tagLabel = tagLabel.ifBlank { "Meta" },
      tagEmoji = tagEmoji.ifBlank { "❗" },
      isPinned = isPinned,
      replyCount = 0,
      reactionCount = 1,
      reactionEmoji = "🔥",
      createdAt = System.currentTimeMillis()
    )
    forumPostDao.insertPost(post)
    recordBadgeProgress("creator", 1)
    runCatching { cloudRepo.createForumPost(post) }
    Result.success(post)
  }

  suspend fun toggleForumPostReaction(post: ForumPostEntity) = withContext(Dispatchers.IO) {
    val updated = post.copy(reactionCount = post.reactionCount + 1)
    forumPostDao.updatePost(updated)
    runCatching { cloudRepo.updateForumPostCounters(post.channelId, post.id, updated.replyCount, updated.reactionCount) }
  }

  suspend fun addForumReply(channelId: String, postId: String, content: String): Result<ForumReplyEntity> = withContext(Dispatchers.IO) {
    val user = getCurrentUser() ?: return@withContext Result.failure(Exception("Sign in required"))
    val clean = content.trim()
    if (clean.isBlank()) return@withContext Result.failure(Exception("Reply cannot be empty."))
    val reply = ForumReplyEntity(
      id = "fr_${UUID.randomUUID().toString().take(8)}",
      postId = postId,
      channelId = channelId,
      authorId = user.id,
      authorName = user.displayName,
      authorAvatarUri = user.avatarUri,
      content = clean,
      createdAt = System.currentTimeMillis()
    )
    forumReplyDao.insertReply(reply)
    val post = forumPostDao.getPostById(postId)
    val nextReplies = (post?.replyCount ?: 0) + 1
    if (post != null) {
      forumPostDao.updatePost(post.copy(replyCount = nextReplies))
    }
    recordBadgeProgress("community_contributor", 1)
    runCatching {
      cloudRepo.insertForumReply(reply)
      cloudRepo.updateForumPostCounters(channelId, postId, nextReplies, post?.reactionCount ?: 0)
    }
    Result.success(reply)
  }

  // --- FRIENDS & DIRECT MESSAGES ---

  fun getFriends(userId: String): Flow<List<FriendEntity>> = friendDao.getFriendsForUser(userId)

  suspend fun addFriendByUsername(username: String): Result<Unit> = withContext(Dispatchers.IO) {
    val currentUser = getCurrentUser() ?: return@withContext Result.failure(Exception("Sign in required"))
    val clean = username.trim().removePrefix("@").lowercase()
    val targetUser = userDao.getUserByUsername(clean)
      ?: cloudRepo.findUserByUsernameOnce(clean)?.also { userDao.insertUser(it) }
      ?: return@withContext Result.failure(Exception("User @$clean not found."))
    if (targetUser.id == currentUser.id) {
      return@withContext Result.failure(Exception("You cannot add yourself as a friend."))
    }
    val friend = FriendEntity(
      id = "${currentUser.id}_${targetUser.id}",
      userId = currentUser.id,
      friendId = targetUser.id,
      friendUsername = targetUser.username,
      friendDisplayName = targetUser.displayName,
      friendAvatarUri = targetUser.avatarUri,
      status = "ACCEPTED",
      isOnline = true,
      statusText = targetUser.statusTag.ifBlank { "Online on XChat" }
    )
    friendDao.insertFriend(friend)
    runCatching { cloudRepo.upsertFriendship(friend) }
    incrementQuestProgress("q_2", 1)
    recordBadgeProgress("first_friend", 1)
    recordBadgeProgress("social_butterfly", 1)
    pushLocalAndRemoteNotification(
      targetUserId = targetUser.id,
      title = "Friend Request",
      message = "@${currentUser.username} added you as a friend!",
      type = "FRIEND_REQUEST"
    )
    Result.success(Unit)
  }

  suspend fun ensureFriendForDm(targetUserId: String) = withContext(Dispatchers.IO) {
    val currentUser = getCurrentUser() ?: return@withContext
    val targetUser = userDao.getUserById(targetUserId) ?: return@withContext
    if (targetUser.id == currentUser.id) return@withContext
    val friend = FriendEntity(
      id = "${currentUser.id}_${targetUser.id}",
      userId = currentUser.id,
      friendId = targetUser.id,
      friendUsername = targetUser.username,
      friendDisplayName = targetUser.displayName,
      friendAvatarUri = targetUser.avatarUri,
      status = "ACCEPTED",
      isOnline = true,
      statusText = targetUser.statusTag.ifBlank { "Online - Menggunakan XChat" }
    )
    friendDao.insertFriend(friend)
    runCatching { cloudRepo.upsertFriendship(friend) }
  }

  fun getDirectMessages(conversationId: String): Flow<List<DirectMessageEntity>> = directMessageDao.getDMsForConversation(conversationId)

  suspend fun sendDirectMessage(
    conversationId: String,
    receiverId: String,
    content: String,
    attachmentUri: String? = null,
    attachmentName: String? = null,
    attachmentMimeType: String? = null,
    attachmentSizeBytes: Long = 0L,
    attachmentDurationMs: Long = 0L,
    replyToId: String? = null,
    replyToSnippet: String? = null,
    forwardedFromId: String? = null,
    forwardedFromName: String? = null,
    locationLat: Double? = null,
    locationLng: Double? = null,
    locationLabel: String? = null,
    locationLiveUntil: Long = 0L,
    stickerId: String? = null,
    gameInviteMatchId: String? = null
  ): Result<DirectMessageEntity> = withContext(Dispatchers.IO) {
    val user = getCurrentUser() ?: return@withContext Result.failure(Exception("Harus login"))
    if (attachmentMimeType?.startsWith("video/") == true && attachmentDurationMs > VideoTrimHelper.MAX_VIDEO_DURATION_MS) {
      return@withContext Result.failure(Exception("Video melebihi batas maksimal 7 detik!"))
    }
    val dm = DirectMessageEntity(
      id = "dm_${UUID.randomUUID().toString().take(10)}",
      conversationId = conversationId,
      senderId = user.id,
      senderName = user.displayName,
      receiverId = receiverId,
      content = content,
      attachmentUri = attachmentUri,
      attachmentName = attachmentName,
      attachmentMimeType = attachmentMimeType,
      attachmentSizeBytes = attachmentSizeBytes,
      attachmentDurationMs = attachmentDurationMs.coerceIn(0L, VideoTrimHelper.MAX_VIDEO_DURATION_MS),
      replyToMessageId = replyToId,
      replyToSnippet = replyToSnippet,
      forwardedFromId = forwardedFromId,
      forwardedFromName = forwardedFromName,
      locationLat = locationLat,
      locationLng = locationLng,
      locationLabel = locationLabel,
      locationLiveUntil = locationLiveUntil,
      stickerId = stickerId,
      gameInviteMatchId = gameInviteMatchId,
      timestamp = System.currentTimeMillis()
    )
    directMessageDao.insertDM(dm)
    runCatching { cloudRepo.sendDirectMessage(dm) }
    incrementQuestProgress("q_1", 1)
    awardXp(15L)
    trackTimeAndMediaBadges(attachmentMimeType)
    Result.success(dm)
  }

  suspend fun editDirectMessage(dmId: String, newContent: String) = withContext(Dispatchers.IO) {
    val dm = directMessageDao.getDMById(dmId) ?: return@withContext
    directMessageDao.updateDM(dm.copy(content = newContent, isEdited = true))
    runCatching { cloudRepo.updateDirectMessageContent(dmId, newContent) }
  }

  suspend fun deleteDirectMessage(dmId: String) = withContext(Dispatchers.IO) {
    val dm = directMessageDao.getDMById(dmId) ?: return@withContext
    directMessageDao.updateDM(dm.copy(isDeleted = true, content = "[Pesan dihapus]"))
    runCatching { cloudRepo.softDeleteDirectMessage(dmId) }
  }

  suspend fun addDmReaction(dmId: String, emojiKey: String) = withContext(Dispatchers.IO) {
    val dm = directMessageDao.getDMById(dmId) ?: return@withContext
    val map = mutableMapOf<String, Int>()
    if (dm.reactions.isNotBlank()) {
      dm.reactions.split(",").forEach {
        val parts = it.split(":")
        if (parts.size == 2) map[parts[0]] = parts[1].toIntOrNull() ?: 1
      }
    }
    map[emojiKey] = (map[emojiKey] ?: 0) + 1
    val next = map.entries.joinToString(",") { "${it.key}:${it.value}" }
    directMessageDao.updateDM(dm.copy(reactions = next))
    runCatching { cloudRepo.updateDirectMessageReactions(dmId, next) }
  }

  suspend fun markConversationAsRead(conversationId: String) = withContext(Dispatchers.IO) {
    val uid = _currentUserId.value ?: return@withContext
    val unread = directMessageDao.getUnreadDMsInConversation(conversationId, uid)
    if (unread.isEmpty()) return@withContext
    directMessageDao.markConversationRead(conversationId, uid)
    unread.forEach { dm ->
      runCatching { cloudRepo.markDirectMessageRead(dm.id) }
    }
  }

  // --- VOICE PARTICIPANTS ---

  fun observeVoiceParticipants(serverId: String, channelId: String): Flow<List<VoiceParticipantModel>> =
    cloudRepo.observeVoiceParticipants(serverId, channelId)

  suspend fun joinOrUpdateVoiceParticipant(
    serverId: String,
    channelId: String,
    isMuted: Boolean,
    isDeafened: Boolean,
    isCameraOn: Boolean,
    isScreenSharing: Boolean,
    isSpeaking: Boolean,
    audioQuality: String = "HD"
  ) = withContext(Dispatchers.IO) {
    val user = getCurrentUser() ?: return@withContext
    val participant = VoiceParticipantModel(
      userId = user.id,
      channelId = channelId,
      serverId = serverId,
      displayName = user.displayName,
      avatarUri = user.avatarUri,
      isMuted = isMuted,
      isDeafened = isDeafened,
      isCameraOn = isCameraOn,
      isScreenSharing = isScreenSharing,
      isSpeaking = isSpeaking,
      audioQuality = audioQuality,
      updatedAt = System.currentTimeMillis()
    )
    runCatching { cloudRepo.upsertVoiceParticipant(participant) }
  }

  suspend fun leaveVoiceParticipant(serverId: String, channelId: String) = withContext(Dispatchers.IO) {
    runCatching { cloudRepo.removeVoiceParticipant(serverId, channelId) }
  }

  // --- STICKER STUDIO & GIF FAVORITES ---

  fun getStickerPacks(): Flow<List<StickerPackEntity>> = stickerDao.getAllStickerPacks()
  fun getAllStickers(): Flow<List<StickerEntity>> = stickerDao.getAllStickers()
  fun getGifFavorites(userId: String): Flow<List<GifFavoriteEntity>> = gifFavoriteDao.getGifsForUser(userId)

  suspend fun saveCustomSticker(
    name: String,
    packName: String,
    imageUri: String,
    overlayText: String,
    textColorHex: Long,
    outlineColorHex: Long,
    hasGlow: Boolean,
    hasShadow: Boolean,
    isShared: Boolean = true
  ): Result<StickerEntity> = withContext(Dispatchers.IO) {
    val user = getCurrentUser() ?: return@withContext Result.failure(Exception("Harus login"))
    val packId = "pack_${user.id}_${packName.lowercase().replace(Regex("[^a-z0-9]"), "_").take(20).ifBlank { "custom" }}"
    val pack = StickerPackEntity(
      id = packId,
      creatorId = user.id,
      creatorName = user.displayName,
      name = packName.ifBlank { "Koleksi ${user.displayName}" },
      coverUri = imageUri,
      isShared = isShared
    )
    val sticker = StickerEntity(
      id = "stk_${UUID.randomUUID().toString().take(8)}",
      packId = packId,
      creatorId = user.id,
      name = name.ifBlank { "Sticker Kustom" },
      imageUri = imageUri,
      overlayText = overlayText,
      textColorHex = textColorHex,
      outlineColorHex = outlineColorHex,
      hasGlow = hasGlow,
      hasShadow = hasShadow,
      isFavorite = true
    )
    stickerDao.insertPack(pack)
    stickerDao.insertSticker(sticker)
    incrementQuestProgress("q_7", 1)
    recordBadgeProgress("sticker_artist", 1)
    recordBadgeProgress("creator", 1)
    if (isShared) recordBadgeProgress("verified_creator", 1)
    runCatching {
      cloudRepo.upsertStickerPack(pack)
      cloudRepo.upsertSticker(sticker, isShared)
    }
    Result.success(sticker)
  }

  suspend fun toggleStickerFavorite(sticker: StickerEntity) = withContext(Dispatchers.IO) {
    stickerDao.updateSticker(sticker.copy(isFavorite = !sticker.isFavorite))
  }

  suspend fun deleteSticker(sticker: StickerEntity) = withContext(Dispatchers.IO) {
    stickerDao.deleteSticker(sticker)
  }

  suspend fun saveGifRecord(
    gifUrl: String,
    previewUrl: String,
    title: String,
    category: String,
    isFavorite: Boolean,
    isRecent: Boolean
  ) = withContext(Dispatchers.IO) {
    val uid = _currentUserId.value ?: return@withContext
    val id = "gif_${uid}_${gifUrl.hashCode()}"
    gifFavoriteDao.upsertGif(
      GifFavoriteEntity(
        id = id,
        userId = uid,
        gifUrl = gifUrl,
        previewUrl = previewUrl,
        title = title,
        category = category,
        isRecent = isRecent,
        isFavorite = isFavorite,
        updatedAt = System.currentTimeMillis()
      )
    )
    if (isFavorite) recordBadgeProgress("gif_collector", 1)
  }

  // --- MUSIC PLAYLISTS & TRACKS ---

  fun getPlaylistsForUser(userId: String): Flow<List<PlaylistEntity>> = playlistDao.getPlaylistsForUser(userId)
  fun getTracksForPlaylist(playlistId: String): Flow<List<AudioTrackEntity>> = playlistDao.getTracksForPlaylist(playlistId)
  fun getAllTracksForUser(userId: String): Flow<List<AudioTrackEntity>> = playlistDao.getAllTracksForUser(userId)

  suspend fun createPlaylist(name: String): Result<PlaylistEntity> = withContext(Dispatchers.IO) {
    val uid = _currentUserId.value ?: Firebase.auth.currentUser?.uid
      ?: return@withContext Result.failure(Exception("Sign in required"))
    val clean = name.trim()
    if (clean.isBlank()) return@withContext Result.failure(Exception("Playlist name cannot be empty."))
    val pl = PlaylistEntity("pl_${UUID.randomUUID().toString().take(8)}", uid, clean)
    playlistDao.insertPlaylist(pl)
    incrementQuestProgress("q_8", 1)
    recordBadgeProgress("music_lover", 1)
    Result.success(pl)
  }

  suspend fun renamePlaylist(playlist: PlaylistEntity, newName: String) = withContext(Dispatchers.IO) {
    if (newName.isNotBlank()) playlistDao.updatePlaylist(playlist.copy(name = newName.trim()))
  }

  suspend fun deletePlaylist(playlist: PlaylistEntity) = withContext(Dispatchers.IO) {
    playlistDao.deletePlaylist(playlist)
  }

  suspend fun resolveOrCreateDefaultPlaylistId(preferredId: String? = null): Result<String> = withContext(Dispatchers.IO) {
    val uid = _currentUserId.value ?: Firebase.auth.currentUser?.uid
      ?: return@withContext Result.failure(Exception("Sign in required"))
    val cleanId = preferredId?.trim().orEmpty()
    val userPlaylists = playlistDao.getPlaylistsForUser(uid).firstOrNull().orEmpty()
    if (cleanId.isNotBlank() && userPlaylists.any { it.id == cleanId }) {
      return@withContext Result.success(cleanId)
    }
    val existingFirst = userPlaylists.firstOrNull()
    if (existingFirst != null) {
      return@withContext Result.success(existingFirst.id)
    }
    val defaultPl = PlaylistEntity("pl_${UUID.randomUUID().toString().take(8)}", uid, "Favorites")
    playlistDao.insertPlaylist(defaultPl)
    incrementQuestProgress("q_8", 1)
    recordBadgeProgress("music_lover", 1)
    Result.success(defaultPl.id)
  }

  suspend fun addTrackToPlaylist(
    playlistId: String,
    title: String,
    artist: String,
    sourceUri: String,
    sourceType: String,
    coverUri: String? = null,
    durationMs: Long = 0L
  ): Result<AudioTrackEntity> = withContext(Dispatchers.IO) {
    val uid = _currentUserId.value ?: Firebase.auth.currentUser?.uid
      ?: return@withContext Result.failure(Exception("Sign in required"))
    val resolvedPlaylistId = resolveOrCreateDefaultPlaylistId(playlistId).getOrElse {
      return@withContext Result.failure(it)
    }
    val existing = playlistDao.getTracksForPlaylist(resolvedPlaylistId).firstOrNull().orEmpty()
    val track = AudioTrackEntity(
      id = "trk_${UUID.randomUUID().toString().take(8)}",
      playlistId = resolvedPlaylistId,
      userId = uid,
      title = title.ifBlank { "Audio Track" },
      artist = artist.ifBlank { "Local Artist" },
      coverUri = coverUri,
      sourceUri = sourceUri,
      sourceType = sourceType,
      durationMs = durationMs,
      orderIndex = (existing.maxOfOrNull { it.orderIndex } ?: -1) + 1
    )
    playlistDao.insertTrack(track)
    incrementQuestProgress("q_8", 1)
    recordBadgeProgress("music_lover", 1)
    Result.success(track)
  }

  suspend fun deleteTrack(track: AudioTrackEntity) = withContext(Dispatchers.IO) {
    playlistDao.deleteTrack(track)
  }

  suspend fun swapTrackOrder(first: AudioTrackEntity, second: AudioTrackEntity) = withContext(Dispatchers.IO) {
    playlistDao.updateTrack(first.copy(orderIndex = second.orderIndex))
    playlistDao.updateTrack(second.copy(orderIndex = first.orderIndex))
  }

  // --- MINI GAMES & TOURNAMENTS (4 REAL MULTIPLAYER GAMES + ELO) ---

  fun getAllMatches(): Flow<List<GameMatchEntity>> = gameDao.getAllMatches()
  fun getAllGameRatings(): Flow<List<GameRatingEntity>> = gameDao.getAllRatings()
  fun getAllTournaments(): Flow<List<TournamentEntity>> = gameDao.getAllTournaments()

  suspend fun createGameMatch(
    gameType: String,
    mode: String,
    opponentId: String,
    channelOrConvId: String,
    isDm: Boolean,
    tournamentId: String? = null
  ): Result<GameMatchEntity> = withContext(Dispatchers.IO) {
    val me = getCurrentUser() ?: return@withContext Result.failure(Exception("Sign in required"))
    val opp = userDao.getUserById(opponentId)
      ?: return@withContext Result.failure(Exception("Opponent not found."))
    val initialBoard = when (gameType) {
      "TIC_TAC_TOE" -> MiniGameEngines.TicTacToeState().toJson()
      "CONNECT_FOUR" -> MiniGameEngines.ConnectFourState().toJson()
      "REVERSI" -> MiniGameEngines.ReversiState().toJson()
      "CHESS" -> MiniGameEngines.ChessState().toJson()
      else -> return@withContext Result.failure(Exception("Unknown game type."))
    }
    val match = GameMatchEntity(
      id = "gm_${UUID.randomUUID().toString().take(8)}",
      gameType = gameType,
      mode = mode,
      tournamentId = tournamentId,
      channelOrConvId = channelOrConvId,
      challengerId = me.id,
      challengerName = me.displayName,
      opponentId = opp.id,
      opponentName = opp.displayName,
      status = "INVITED",
      turnUserId = me.id,
      boardStateJson = initialBoard
    )
    gameDao.upsertMatch(match)
    runCatching { cloudRepo.createOrUpdateGameMatch(match, isCreate = true) }

    val inviteText = "🎮 $gameType ($mode) Duel Invite vs ${opp.displayName}!"
    if (isDm) {
      sendDirectMessage(
        conversationId = channelOrConvId,
        receiverId = opp.id,
        content = inviteText,
        gameInviteMatchId = match.id
      )
    } else {
      sendMessage(
        channelId = channelOrConvId,
        content = inviteText,
        gameInviteMatchId = match.id
      )
    }
    pushLocalAndRemoteNotification(
      targetUserId = opp.id,
      title = "Mini Game Invite: $gameType",
      message = "${me.displayName} challenged you in $mode mode!",
      type = "GAME_INVITE"
    )
    Result.success(match)
  }

  suspend fun acceptGameMatch(matchId: String): Result<GameMatchEntity> = withContext(Dispatchers.IO) {
    val match = gameDao.getMatchById(matchId) ?: return@withContext Result.failure(Exception("Match not found."))
    if (match.status != "INVITED") return@withContext Result.failure(Exception("Invite already handled."))
    val updated = match.copy(status = "ACTIVE", lastMoveAt = System.currentTimeMillis(), updatedAt = System.currentTimeMillis())
    gameDao.upsertMatch(updated)
    runCatching { cloudRepo.createOrUpdateGameMatch(updated, isCreate = false) }
    incrementQuestProgress("q_3", 1)
    recordBadgeProgress("game_explorer", 1)
    Result.success(updated)
  }

  suspend fun declineGameMatch(matchId: String) = withContext(Dispatchers.IO) {
    val match = gameDao.getMatchById(matchId) ?: return@withContext
    val updated = match.copy(status = "DECLINED", updatedAt = System.currentTimeMillis())
    gameDao.upsertMatch(updated)
    runCatching { cloudRepo.createOrUpdateGameMatch(updated, isCreate = false) }
  }

  suspend fun submitGameMove(
    matchId: String,
    moveIndexOrCol: Int,
    chessToIdx: Int = -1,
    chessPromotion: Char = 'Q'
  ): Result<GameMatchEntity> = withContext(Dispatchers.IO) {
    val me = getCurrentUser() ?: return@withContext Result.failure(Exception("Sign in required"))
    val match = gameDao.getMatchById(matchId) ?: return@withContext Result.failure(Exception("Match not found."))
    if (match.status != "ACTIVE") return@withContext Result.failure(Exception("Match is not active or has ended."))
    if (match.turnUserId != me.id) return@withContext Result.failure(Exception("It is your opponent's turn."))

    val now = System.currentTimeMillis()
    val elapsed = (now - match.lastMoveAt).coerceIn(0L, 120_000L)
    var whiteTime = match.whiteTimeMs
    var blackTime = match.blackTimeMs
    if (me.id == match.challengerId) {
      whiteTime = (whiteTime - elapsed).coerceAtLeast(0L)
    } else {
      blackTime = (blackTime - elapsed).coerceAtLeast(0L)
    }

    var nextBoardJson: String
    var nextTurn = if (me.id == match.challengerId) match.opponentId else match.challengerId
    var nextStatus = "ACTIVE"
    var winnerId: String? = null

    when (match.gameType) {
      "TIC_TAC_TOE" -> {
        val state = MiniGameEngines.TicTacToeState.fromJson(match.boardStateJson)
        val moved = MiniGameEngines.playTicTacToeMove(state, moveIndexOrCol)
          ?: return@withContext Result.failure(Exception("Invalid Tic Tac Toe move."))
        nextBoardJson = moved.toJson()
        if (moved.winnerSymbol != null) {
          nextStatus = "FINISHED"
          winnerId = when (moved.winnerSymbol) {
            "X" -> match.challengerId
            "O" -> match.opponentId
            else -> "DRAW"
          }
        }
      }
      "CONNECT_FOUR" -> {
        val state = MiniGameEngines.ConnectFourState.fromJson(match.boardStateJson)
        val moved = MiniGameEngines.playConnectFourMove(state, moveIndexOrCol)
          ?: return@withContext Result.failure(Exception("Column full or invalid move."))
        nextBoardJson = moved.toJson()
        if (moved.winnerPlayer != null) {
          nextStatus = "FINISHED"
          winnerId = when (moved.winnerPlayer) {
            1 -> match.challengerId
            2 -> match.opponentId
            else -> "DRAW"
          }
        }
      }
      "REVERSI" -> {
        val state = MiniGameEngines.ReversiState.fromJson(match.boardStateJson)
        val moved = MiniGameEngines.playReversiMove(state, moveIndexOrCol)
          ?: return@withContext Result.failure(Exception("Illegal Reversi move."))
        nextBoardJson = moved.toJson()
        nextTurn = if (moved.nextPlayer == 1) match.challengerId else match.opponentId
        if (moved.winnerPlayer != null) {
          nextStatus = "FINISHED"
          winnerId = when (moved.winnerPlayer) {
            1 -> match.challengerId
            2 -> match.opponentId
            else -> "DRAW"
          }
        }
      }
      "CHESS" -> {
        val state = MiniGameEngines.ChessState.fromJson(match.boardStateJson)
        val expectedColor = if (me.id == match.challengerId) "W" else "B"
        if (state.turn != expectedColor) return@withContext Result.failure(Exception("Not your piece turn."))
        val moved = MiniGameEngines.playChessMove(state, moveIndexOrCol, chessToIdx, chessPromotion)
          ?: return@withContext Result.failure(Exception("Illegal chess move!"))
        nextBoardJson = moved.toJson()
        when (moved.status) {
          "WHITE_WIN" -> {
            nextStatus = "FINISHED"
            winnerId = match.challengerId
          }
          "BLACK_WIN" -> {
            nextStatus = "FINISHED"
            winnerId = match.opponentId
          }
          "DRAW_STALEMATE", "DRAW_50" -> {
            nextStatus = "FINISHED"
            winnerId = "DRAW"
          }
        }
      }
      else -> return@withContext Result.failure(Exception("Unsupported game."))
    }

    val updated = match.copy(
      status = nextStatus,
      turnUserId = nextTurn,
      boardStateJson = nextBoardJson,
      winnerId = winnerId,
      whiteTimeMs = whiteTime,
      blackTimeMs = blackTime,
      lastMoveAt = now,
      drawOfferedBy = null,
      updatedAt = now
    )
    gameDao.upsertMatch(updated)
    runCatching { cloudRepo.createOrUpdateGameMatch(updated, isCreate = false) }
    if (nextStatus == "FINISHED") {
      finalizeMatchOutcome(updated)
    }
    Result.success(updated)
  }

  suspend fun resignGameMatch(matchId: String) = withContext(Dispatchers.IO) {
    val me = getCurrentUser() ?: return@withContext
    val match = gameDao.getMatchById(matchId) ?: return@withContext
    if (match.status != "ACTIVE") return@withContext
    val winner = if (me.id == match.challengerId) match.opponentId else match.challengerId
    val updated = match.copy(status = "FINISHED", winnerId = winner, updatedAt = System.currentTimeMillis())
    gameDao.upsertMatch(updated)
    runCatching { cloudRepo.createOrUpdateGameMatch(updated, isCreate = false) }
    finalizeMatchOutcome(updated)
  }

  suspend fun offerOrAcceptDraw(matchId: String) = withContext(Dispatchers.IO) {
    val me = getCurrentUser() ?: return@withContext
    val match = gameDao.getMatchById(matchId) ?: return@withContext
    if (match.status != "ACTIVE") return@withContext
    if (match.drawOfferedBy != null && match.drawOfferedBy != me.id) {
      val updated = match.copy(status = "FINISHED", winnerId = "DRAW", updatedAt = System.currentTimeMillis())
      gameDao.upsertMatch(updated)
      runCatching { cloudRepo.createOrUpdateGameMatch(updated, isCreate = false) }
      finalizeMatchOutcome(updated)
    } else {
      val updated = match.copy(drawOfferedBy = me.id, updatedAt = System.currentTimeMillis())
      gameDao.upsertMatch(updated)
      runCatching { cloudRepo.createOrUpdateGameMatch(updated, isCreate = false) }
    }
  }

  private suspend fun finalizeMatchOutcome(match: GameMatchEntity) {
    val scoreA = when (match.winnerId) {
      match.challengerId -> 1.0
      match.opponentId -> 0.0
      else -> 0.5
    }
    val ratingA = gameDao.getRating(match.challengerId, match.gameType)
      ?: GameRatingEntity(
        id = "${match.challengerId}_${match.gameType}",
        userId = match.challengerId,
        username = match.challengerName,
        displayName = match.challengerName,
        gameType = match.gameType
      )
    val ratingB = gameDao.getRating(match.opponentId, match.gameType)
      ?: GameRatingEntity(
        id = "${match.opponentId}_${match.gameType}",
        userId = match.opponentId,
        username = match.opponentName,
        displayName = match.opponentName,
        gameType = match.gameType
      )

    val (newEloA, newEloB) = if (match.mode == "CLASSIC") {
      ratingA.elo to ratingB.elo
    } else {
      val deltaA = MiniGameEngines.computeEloDelta(ratingA.elo, ratingB.elo, scoreA)
      (ratingA.elo + deltaA).coerceAtLeast(100) to (ratingB.elo - deltaA).coerceAtLeast(100)
    }

    val nextA = ratingA.copy(
      elo = newEloA,
      wins = ratingA.wins + if (scoreA == 1.0) 1 else 0,
      losses = ratingA.losses + if (scoreA == 0.0) 1 else 0,
      draws = ratingA.draws + if (scoreA == 0.5) 1 else 0,
      updatedAt = System.currentTimeMillis()
    )
    val nextB = ratingB.copy(
      elo = newEloB,
      wins = ratingB.wins + if (scoreA == 0.0) 1 else 0,
      losses = ratingB.losses + if (scoreA == 1.0) 1 else 0,
      draws = ratingB.draws + if (scoreA == 0.5) 1 else 0,
      updatedAt = System.currentTimeMillis()
    )
    gameDao.upsertRating(nextA)
    gameDao.upsertRating(nextB)
    runCatching {
      cloudRepo.upsertGameRating(nextA)
      cloudRepo.upsertGameRating(nextB)
    }

    if (match.gameType == "CHESS") incrementQuestProgress("q_5", 1)
    if (match.winnerId == _currentUserId.value) {
      if (match.gameType == "CHESS") recordBadgeProgress("chess_master", 1)
      if (match.gameType == "TIC_TAC_TOE") recordBadgeProgress("ttt_pro", 1)
      if (newEloA >= 1300 || newEloB >= 1300) recordBadgeProgress("grandmaster", 1300, setAbsolute = true)
      awardXp(60L)
    }
  }

  suspend fun createTournament(name: String, gameType: String): Result<TournamentEntity> = withContext(Dispatchers.IO) {
    val me = getCurrentUser() ?: return@withContext Result.failure(Exception("Sign in required"))
    val clean = name.trim()
    if (clean.length < 2) return@withContext Result.failure(Exception("Tournament name must be at least 2 characters."))
    val t = TournamentEntity(
      id = "trn_${UUID.randomUUID().toString().take(8)}",
      name = clean,
      gameType = gameType,
      creatorId = me.id,
      status = "OPEN",
      participantsCsv = me.id,
      bracketJson = "[]"
    )
    gameDao.upsertTournament(t)
    runCatching { cloudRepo.upsertTournament(t) }
    Result.success(t)
  }

  suspend fun joinTournament(tournamentId: String): Result<TournamentEntity> = withContext(Dispatchers.IO) {
    val me = getCurrentUser() ?: return@withContext Result.failure(Exception("Sign in required"))
    val t = gameDao.getTournamentById(tournamentId) ?: return@withContext Result.failure(Exception("Tournament not found."))
    val parts = t.participantsCsv.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableList()
    if (!parts.contains(me.id)) parts.add(me.id)
    val nextStatus = if (parts.size >= 2 && t.status == "OPEN") "IN_PROGRESS" else t.status
    val updated = t.copy(participantsCsv = parts.joinToString(","), status = nextStatus)
    gameDao.upsertTournament(updated)
    runCatching { cloudRepo.upsertTournament(updated) }
    Result.success(updated)
  }

  // --- QUESTS, REDEEM CODES & MARKETPLACE ---

  fun getQuests(): Flow<List<QuestEntity>> = questDao.getAllQuests()
  fun getRedeemCodes(): Flow<List<RedeemCodeEntity>> = adminModerationDao.getAllRedeemCodes()

  private suspend fun incrementQuestProgress(questId: String, count: Int) {
    val quest = questDao.getQuestById(questId) ?: return
    if (quest.isClaimed) return
    val newCount = (quest.currentCount + count).coerceAtMost(quest.targetCount)
    if (newCount != quest.currentCount) {
      questDao.updateQuest(quest.copy(currentCount = newCount))
    }
  }

  suspend fun notifyVoiceUsedQuest() = withContext(Dispatchers.IO) {
    incrementQuestProgress("q_6", 1)
    recordBadgeProgress("voice_champion", 1)
  }

  suspend fun claimQuestReward(questId: String): Result<Long> = withContext(Dispatchers.IO) {
    val user = getCurrentUser() ?: return@withContext Result.failure(Exception("Sign in required"))
    val quest = questDao.getQuestById(questId) ?: return@withContext Result.failure(Exception("Quest not found"))
    if (quest.isClaimed) return@withContext Result.failure(Exception("Quest reward already claimed."))
    if (quest.currentCount < quest.targetCount) return@withContext Result.failure(Exception("Quest not completed yet."))

    questDao.updateQuest(quest.copy(isClaimed = true))
    if (!user.isOwner) {
      val nextBal = user.xitBalance + quest.rewardXit
      userDao.updateXitBalance(user.id, nextBal)
      runCatching { cloudRepo.upsertPublicProfile(user.copy(xitBalance = nextBal), isCreate = false) }
    }
    recordBadgeProgress("xit_claimer", 1)
    recordBadgeProgress("daily_active", 1)
    recordBadgeProgress("xchat_pioneer", 1)
    awardXp(50L)
    logAudit("CLAIM_QUEST", "@${user.username} claimed ${quest.rewardXit} XIT from '${quest.title}'")
    Result.success(quest.rewardXit)
  }

  suspend fun redeemCode(rawCode: String): Result<String> = withContext(Dispatchers.IO) {
    val user = getCurrentUser() ?: return@withContext Result.failure(Exception("Sign in required"))
    val clean = rawCode.trim().uppercase()
    if (clean.isBlank()) return@withContext Result.failure(Exception("Enter a redeem code."))
    val codeEntity = adminModerationDao.getRedeemCodeByCode(clean)
      ?: return@withContext Result.failure(Exception("Redeem code '$clean' not found."))
    if (!codeEntity.isActive) return@withContext Result.failure(Exception("Redeem code is inactive."))
    if (codeEntity.usedCount >= codeEntity.maxUses) return@withContext Result.failure(Exception("Redeem code limit reached."))
    val usedBy = codeEntity.usedByCsv.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableList()
    if (usedBy.contains(user.id)) return@withContext Result.failure(Exception("You already redeemed this code."))

    usedBy.add(user.id)
    val updatedCode = codeEntity.copy(usedCount = codeEntity.usedCount + 1, usedByCsv = usedBy.joinToString(","))
    adminModerationDao.upsertRedeemCode(updatedCode)
    runCatching { cloudRepo.upsertRedeemCode(updatedCode) }

    val nextXit = if (user.isOwner) user.xitBalance else user.xitBalance + codeEntity.rewardXit
    val nextBoosts = if (user.isOwner) user.boostBalance else user.boostBalance + codeEntity.rewardBoosts
    val badges = user.equippedBadges.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableSet()
    codeEntity.rewardBadgeId?.takeIf { it.isNotBlank() }?.let { badges.add(it) }
    val updatedUser = user.copy(xitBalance = nextXit, boostBalance = nextBoosts, equippedBadges = badges.joinToString(","))
    userDao.updateUser(updatedUser)
    runCatching { cloudRepo.upsertPublicProfile(updatedUser, isCreate = false) }
    recordBadgeProgress("xit_claimer", 1)
    logAudit("REDEEM_CODE", "@${user.username} redeemed code $clean (+${codeEntity.rewardXit} XIT)")
    Result.success("Redeemed! +${codeEntity.rewardXit} XIT" + if (codeEntity.rewardBoosts > 0) " +${codeEntity.rewardBoosts} Boost" else "")
  }

  suspend fun createRedeemCode(code: String, rewardXit: Long, rewardBoosts: Int, maxUses: Int): Result<RedeemCodeEntity> = withContext(Dispatchers.IO) {
    val clean = code.trim().uppercase()
    if (clean.length < 3) return@withContext Result.failure(Exception("Code must be at least 3 characters."))
    val rc = RedeemCodeEntity(
      id = "rc_${UUID.randomUUID().toString().take(8)}",
      code = clean,
      rewardXit = rewardXit,
      rewardBoosts = rewardBoosts,
      maxUses = maxUses
    )
    adminModerationDao.upsertRedeemCode(rc)
    runCatching { cloudRepo.upsertRedeemCode(rc) }
    logAudit("CREATE_REDEEM_CODE", "Admin created redeem code $clean ($rewardXit XIT, max $maxUses)")
    Result.success(rc)
  }

  suspend fun transferXit(recipientUsername: String, amount: Long): Result<Unit> = withContext(Dispatchers.IO) {
    val sender = getCurrentUser() ?: return@withContext Result.failure(Exception("Sign in required"))
    if (amount <= 0) return@withContext Result.failure(Exception("Amount must be greater than 0 XIT."))
    if (!sender.isOwner && sender.xitBalance < amount) {
      return@withContext Result.failure(Exception("Insufficient XIT balance."))
    }
    val clean = recipientUsername.trim().removePrefix("@").lowercase()
    val recipient = userDao.getUserByUsername(clean)
      ?: cloudRepo.findUserByUsernameOnce(clean)?.also { userDao.insertUser(it) }
      ?: return@withContext Result.failure(Exception("Recipient @$clean not found."))

    if (!sender.isOwner) {
      val newSenderBal = sender.xitBalance - amount
      userDao.updateXitBalance(sender.id, newSenderBal)
      runCatching { cloudRepo.upsertPublicProfile(sender.copy(xitBalance = newSenderBal), isCreate = false) }
    }
    val newRecipientBal = recipient.xitBalance + amount
    userDao.updateXitBalance(recipient.id, newRecipientBal)
    runCatching { cloudRepo.adminUpdateUserFields(recipient.id, xitBalance = newRecipientBal) }
    logAudit("TRANSFER_XIT", "@${sender.username} transferred $amount XIT to @${recipient.username}")
    Result.success(Unit)
  }

  fun getMarketplaceItems(): Flow<List<MarketplaceItemEntity>> = marketplaceDao.getAllItems()
  fun getUserInventory(userId: String): Flow<List<UserInventoryEntity>> = marketplaceDao.getUserInventory(userId)

  suspend fun buyMarketplaceItem(item: MarketplaceItemEntity): Result<Unit> = withContext(Dispatchers.IO) {
    val user = getCurrentUser() ?: return@withContext Result.failure(Exception("Sign in required"))
    if (item.isAstralOnly && !user.subscriptionTier.equals("ASTRAL", ignoreCase = true) && !user.isOwner) {
      return@withContext Result.failure(Exception("This item requires Astral tier."))
    }
    if (!user.isOwner && user.xitBalance < item.priceXit) {
      return@withContext Result.failure(Exception("Insufficient XIT balance to purchase ${item.name}."))
    }
    if (!user.isOwner) {
      val nextBal = user.xitBalance - item.priceXit
      userDao.updateXitBalance(user.id, nextBal)
      runCatching { cloudRepo.upsertPublicProfile(user.copy(xitBalance = nextBal), isCreate = false) }
    }
    marketplaceDao.insertInventory(
      UserInventoryEntity(
        id = "${user.id}_${item.id}",
        userId = user.id,
        itemId = item.id,
        isEquipped = false
      )
    )
    recordBadgeProgress("legendary", 1)
    logAudit("BUY_ITEM", "@${user.username} purchased ${item.name} for ${item.priceXit} XIT")
    Result.success(Unit)
  }

  suspend fun equipItem(itemId: String, category: String) = withContext(Dispatchers.IO) {
    val user = getCurrentUser() ?: return@withContext
    val allMarket = marketplaceDao.getAllItems().firstOrNull().orEmpty()
    val sameCategoryIds = allMarket.filter {
      it.category == category ||
        (category in listOf("DECORATION", "EFFECT") && it.category in listOf("DECORATION", "EFFECT"))
    }.map { it.id }.toSet()
    marketplaceDao.getUserInventory(user.id).firstOrNull().orEmpty().forEach { inv ->
      if (inv.itemId == itemId) {
        marketplaceDao.setEquipped(user.id, inv.itemId, true)
      } else if (inv.isEquipped && inv.itemId in sameCategoryIds) {
        marketplaceDao.setEquipped(user.id, inv.itemId, false)
      }
    }
    val updated = when (category) {
      "FRAME" -> user.copy(equippedFrame = itemId)
      "NAMEPLATE" -> user.copy(equippedNameplate = itemId)
      "DECORATION", "EFFECT" -> user.copy(equippedEffect = itemId)
      "TEXT_EFFECT" -> {
        val effectKey = itemId.removePrefix("txt_").uppercase()
        user.copy(displayNameEffect = effectKey)
      }
      "CHAT_EFFECT" -> user.copy(chatBubbleBgCsv = "0xFF13161D,0xFF232938")
      "BACKGROUND_THEME" -> user.copy(wallpaperMode = "GRADIENT", wallpaperGradientCsv = "0xFF07080B,0xFF1F1A10,0xFFEAB308")
      else -> user
    }
    userDao.updateUser(updated)
    runCatching { cloudRepo.upsertPublicProfile(updated, isCreate = false) }
  }

  suspend fun unequipItem(itemId: String, category: String) = withContext(Dispatchers.IO) {
    val user = getCurrentUser() ?: return@withContext
    marketplaceDao.setEquipped(user.id, itemId, false)
    val updated = when (category) {
      "FRAME" -> if (user.equippedFrame == itemId) user.copy(equippedFrame = null) else user
      "NAMEPLATE" -> if (user.equippedNameplate == itemId) user.copy(equippedNameplate = null) else user
      "DECORATION", "EFFECT" -> if (user.equippedEffect == itemId) user.copy(equippedEffect = null) else user
      "TEXT_EFFECT" -> user.copy(displayNameEffect = "SOLID")
      "CHAT_EFFECT" -> user.copy(chatBubbleBgCsv = "0xFF1C2029,0xFF2B303D")
      "BACKGROUND_THEME" -> user.copy(wallpaperMode = "MARBLE", wallpaperGradientCsv = "0xFF07080B,0xFF111318,0xFF1E222A")
      else -> user
    }
    userDao.updateUser(updated)
    runCatching { cloudRepo.upsertPublicProfile(updated, isCreate = false) }
  }

  // --- PAYMENTS, OWNER, VERIFIED ADMIN RBAC, LOCK SCREEN & REPORTS ---

  suspend fun submitPaymentRequest(
    targetTier: String,
    senderName: String,
    senderAccount: String,
    slipUri: String?
  ): Result<PaymentRequestEntity> = withContext(Dispatchers.IO) {
    val user = getCurrentUser() ?: return@withContext Result.failure(Exception("Sign in required"))
    val amountStr = when (targetTier) {
      "ASTRAL" -> "Rp 70.000"
      "BOOST_7" -> "Rp 120.000"
      else -> "Rp 35.000"
    }
    val req = PaymentRequestEntity(
      id = "pay_${UUID.randomUUID().toString().take(8)}",
      userId = user.id,
      username = user.username,
      targetTier = targetTier,
      senderName = senderName,
      senderAccount = senderAccount,
      destinationNumber = "088212365499",
      slipUri = slipUri,
      status = "PENDING",
      amountIdr = amountStr
    )
    paymentRequestDao.insertPaymentRequest(req)
    logAudit("SUBMIT_PAYMENT", "Payment request $targetTier ($amountStr) by @${user.username} to 088212365499")
    Result.success(req)
  }

  fun getPaymentRequests(): Flow<List<PaymentRequestEntity>> = paymentRequestDao.getAllPaymentRequests()

  suspend fun verifyCurrentUserAdminRole(): String = withContext(Dispatchers.IO) {
    val role = cloudRepo.checkVerifiedAdminRole()
    val cur = getCurrentUser()
    if (cur != null && role != "NONE" && cur.adminRole != role) {
      userDao.updateUser(cur.copy(adminRole = role))
    }
    role
  }

  suspend fun registerOwnerInCloud(keyInput: String) = withContext(Dispatchers.IO) {
    runCatching { cloudRepo.registerAdminRecord(keyInput) }
    val current = getCurrentUser() ?: return@withContext
    val promoted = current.copy(
      isOwner = true,
      adminRole = "OWNER",
      subscriptionTier = "ASTRAL",
      boostBalance = 999999,
      xitBalance = 999999999L
    )
    userDao.updateUser(promoted)
    runCatching { cloudRepo.upsertPublicProfile(promoted, isCreate = false) }
  }

  suspend fun assignAdminRole(targetUserId: String, role: String) = withContext(Dispatchers.IO) {
    cloudRepo.assignAdminRoleRecord(targetUserId, role)
    cloudRepo.adminUpdateUserFields(targetUserId, adminRole = role)
    userDao.getUserById(targetUserId)?.let { u ->
      userDao.updateUser(u.copy(adminRole = role))
    }
    logAudit("ASSIGN_ADMIN_ROLE", "Admin role for $targetUserId updated to $role")
  }

  fun getAllRestrictions(): Flow<List<UserRestrictionEntity>> = adminModerationDao.getAllRestrictions()
  fun getActiveRestrictionForUserFlow(userId: String): Flow<UserRestrictionEntity?> =
    adminModerationDao.getActiveRestrictionForUserFlow(userId)

  suspend fun applyUserRestriction(
    targetUserId: String,
    reason: String,
    customMessage: String,
    durationMinutes: Long
  ): Result<UserRestrictionEntity> = withContext(Dispatchers.IO) {
    val verifiedRole = cloudRepo.checkVerifiedAdminRole()
    if (verifiedRole == "NONE") {
      return@withContext Result.failure(Exception("Admin permissions are not verified on backend."))
    }
    val admin = getCurrentUser() ?: return@withContext Result.failure(Exception("Sign in required"))
    val target = userDao.getUserById(targetUserId) ?: return@withContext Result.failure(Exception("User not found."))
    val now = System.currentTimeMillis()
    val expiresAt = now + (durationMinutes.coerceAtLeast(1L) * 60_000L)
    val r = UserRestrictionEntity(
      id = "rst_${UUID.randomUUID().toString().take(8)}",
      userId = target.id,
      username = target.username,
      adminId = admin.id,
      adminRole = verifiedRole,
      reason = reason.trim().ifBlank { "Community guidelines violation" },
      customMessage = customMessage.trim().ifBlank { "Your XChat access is temporarily restricted." },
      startedAt = now,
      expiresAt = expiresAt,
      isActive = true,
      appealStatus = "NONE",
      appealMessage = "",
      updatedAt = now
    )
    adminModerationDao.upsertRestriction(r)
    userDao.updateUser(target.copy(isLocked = true, lockReason = r.reason, lockMessage = r.customMessage, lockStartedAt = now, lockExpiresAt = expiresAt))
    runCatching {
      cloudRepo.upsertRestrictionRemote(r)
      cloudRepo.adminUpdateUserFields(target.id, isLocked = true)
    }
    logAudit("LOCK_SCREEN", "XChat Lock Screen applied to @${target.username} for ${durationMinutes}m ($verifiedRole)")
    Result.success(r)
  }

  suspend fun liftRestriction(restriction: UserRestrictionEntity, approveAppeal: Boolean = true) = withContext(Dispatchers.IO) {
    val nextAppeal = if (restriction.appealStatus == "PENDING") {
      if (approveAppeal) "APPROVED" else "REJECTED"
    } else restriction.appealStatus
    val updated = restriction.copy(isActive = !approveAppeal && restriction.isActive, appealStatus = nextAppeal, updatedAt = System.currentTimeMillis())
    adminModerationDao.upsertRestriction(updated)
    if (approveAppeal) {
      userDao.getUserById(restriction.userId)?.let { u ->
        userDao.updateUser(u.copy(isLocked = false))
      }
      runCatching { cloudRepo.adminUpdateUserFields(restriction.userId, isLocked = false) }
    }
    runCatching { cloudRepo.upsertRestrictionRemote(updated) }
    logAudit("LIFT_LOCK_SCREEN", "Restriction for @${restriction.username} updated (active=${updated.isActive}, appeal=$nextAppeal)")
  }

  suspend fun submitRestrictionAppeal(restriction: UserRestrictionEntity, message: String) = withContext(Dispatchers.IO) {
    val clean = message.trim()
    if (clean.isBlank()) return@withContext
    val updated = restriction.copy(appealStatus = "PENDING", appealMessage = clean, updatedAt = System.currentTimeMillis())
    adminModerationDao.upsertRestriction(updated)
    runCatching { cloudRepo.submitRestrictionAppealRemote(restriction.id, clean) }
  }

  suspend fun clearExpiredRestrictionIfNeeded(restriction: UserRestrictionEntity) = withContext(Dispatchers.IO) {
    if (restriction.isActive && System.currentTimeMillis() >= restriction.expiresAt) {
      adminModerationDao.upsertRestriction(restriction.copy(isActive = false, updatedAt = System.currentTimeMillis()))
      userDao.getUserById(restriction.userId)?.let { u ->
        userDao.updateUser(u.copy(isLocked = false))
      }
      runCatching { cloudRepo.clearExpiredRestrictionRemote(restriction.id) }
    }
  }

  fun getAllReports(): Flow<List<ReportEntity>> = adminModerationDao.getAllReports()

  suspend fun submitReport(targetUserId: String?, targetServerId: String?, targetMessageId: String?, reason: String, details: String) = withContext(Dispatchers.IO) {
    val me = getCurrentUser() ?: return@withContext
    val rep = ReportEntity(
      id = "rep_${UUID.randomUUID().toString().take(8)}",
      reporterId = me.id,
      reporterName = me.displayName,
      targetUserId = targetUserId,
      targetServerId = targetServerId,
      targetMessageId = targetMessageId,
      reason = reason,
      details = details,
      status = "OPEN"
    )
    adminModerationDao.upsertReport(rep)
    runCatching { cloudRepo.createOrUpdateReportRemote(rep, isCreate = true) }
  }

  suspend fun resolveReport(report: ReportEntity, status: String, note: String) = withContext(Dispatchers.IO) {
    val admin = getCurrentUser() ?: return@withContext
    val updated = report.copy(status = status, handledBy = admin.username, resolutionNote = note, updatedAt = System.currentTimeMillis())
    adminModerationDao.upsertReport(updated)
    runCatching { cloudRepo.createOrUpdateReportRemote(updated, isCreate = false) }
    logAudit("RESOLVE_REPORT", "Report ${report.id} marked $status by @${admin.username}")
  }

  // --- PAYMENT & ADMIN ACCOUNT ACTIONS ---

  suspend fun approvePaymentRequest(req: PaymentRequestEntity) = withContext(Dispatchers.IO) {
    paymentRequestDao.updateStatus(req.id, "APPROVED")
    if (req.targetTier == "BOOST_7") {
      val user = userDao.getUserById(req.userId)
      if (user != null) {
        val nextBoosts = if (user.isOwner) 999999 else user.boostBalance + 7
        userDao.updateBoostBalance(user.id, nextBoosts)
        runCatching { cloudRepo.adminUpdateUserFields(user.id, boostBalance = nextBoosts) }
      }
      logAudit("APPROVE_PAYMENT", "Approved 7 Server Boosts package for @${req.username}")
    } else {
      userDao.updateSubscriptionTier(req.userId, req.targetTier)
      runCatching { cloudRepo.adminUpdateUserFields(req.userId, subscriptionTier = req.targetTier) }
      logAudit("APPROVE_PAYMENT", "Approved ${req.targetTier} tier for @${req.username}")
    }
  }

  suspend fun rejectPaymentRequest(req: PaymentRequestEntity) = withContext(Dispatchers.IO) {
    paymentRequestDao.updateStatus(req.id, "REJECTED")
    logAudit("REJECT_PAYMENT", "Payment request ${req.id} rejected")
  }

  suspend fun grantXit(userId: String, amount: Long) = withContext(Dispatchers.IO) {
    val user = userDao.getUserById(userId) ?: return@withContext
    val newBal = if (user.isOwner) 999999999L else (user.xitBalance + amount).coerceAtLeast(0)
    userDao.updateXitBalance(userId, newBal)
    runCatching { cloudRepo.adminUpdateUserFields(userId, xitBalance = newBal) }
    logAudit("GRANT_XIT", "Admin granted $amount XIT to @${user.username}")
  }

  suspend fun grantBoosts(userId: String, amount: Int) = withContext(Dispatchers.IO) {
    val user = userDao.getUserById(userId) ?: return@withContext
    val newBoosts = if (user.isOwner) 999999 else (user.boostBalance + amount).coerceAtLeast(0)
    userDao.updateBoostBalance(userId, newBoosts)
    runCatching { cloudRepo.adminUpdateUserFields(userId, boostBalance = newBoosts) }
    logAudit("GRANT_BOOSTS", "Admin granted +$amount Server Boosts to @${user.username}")
  }

  suspend fun grantSubscription(userId: String, tier: String) = withContext(Dispatchers.IO) {
    val user = userDao.getUserById(userId) ?: return@withContext
    userDao.updateSubscriptionTier(userId, tier)
    runCatching { cloudRepo.adminUpdateUserFields(userId, subscriptionTier = tier) }
    logAudit("GRANT_SUBSCRIPTION", "Admin updated @${user.username} tier to $tier")
  }

  suspend fun toggleBanUser(userId: String, isBanned: Boolean) = withContext(Dispatchers.IO) {
    val user = userDao.getUserById(userId) ?: return@withContext
    userDao.setBanStatus(userId, isBanned)
    runCatching { cloudRepo.adminUpdateUserFields(userId, isBanned = isBanned) }
    logAudit("BAN_USER", "Banned status for @${user.username} set to $isBanned")
  }

  suspend fun updateUserBadges(userId: String, badgesCsv: String) = withContext(Dispatchers.IO) {
    val user = userDao.getUserById(userId) ?: return@withContext
    userDao.updateEquippedBadges(userId, badgesCsv)
    runCatching { cloudRepo.adminUpdateUserFields(userId, equippedBadges = badgesCsv) }
    logAudit("GRANT_BADGES", "Admin updated @${user.username} badges: [$badgesCsv]")
  }

  suspend fun grantBadgeByUsername(username: String, badgeId: String): Result<UserEntity> = withContext(Dispatchers.IO) {
    val cleanUsername = username.trim().removePrefix("@").lowercase()
    val user = if (cleanUsername.isBlank() || cleanUsername == "self") {
      getCurrentUser()
    } else {
      userDao.getUserByUsername(cleanUsername)
        ?: cloudRepo.findUserByUsernameOnce(cleanUsername)?.also { userDao.insertUser(it) }
    } ?: return@withContext Result.failure(Exception("User @$cleanUsername not found."))
    val existing = user.equippedBadges.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableSet()
    existing.add(badgeId)
    val csv = existing.joinToString(",")
    val progMap = BadgeCatalog.parseProgressMap(user.unlockedBadgesProgressJson).toMutableMap()
    val def = BadgeCatalog.getBadge(badgeId)
    if (def != null) {
      progMap[def.progressKey] = maxOf(progMap[def.progressKey] ?: 0, def.targetProgress)
      progMap[def.id] = maxOf(progMap[def.id] ?: 0, def.targetProgress)
    }
    val progJson = BadgeCatalog.serializeProgressMap(progMap)
    val updated = user.copy(equippedBadges = csv, unlockedBadgesProgressJson = progJson)
    userDao.updateEquippedBadgesAndProgress(user.id, csv, progJson)
    if (user.id == _currentUserId.value) {
      runCatching { cloudRepo.upsertPublicProfile(updated, isCreate = false) }
    }
    runCatching {
      cloudRepo.adminUpdateUserFields(
        targetUserId = user.id,
        equippedBadges = csv,
        unlockedBadgesProgressJson = progJson
      )
    }
    logAudit("GRANT_BADGE", "Admin granted badge '$badgeId' to @${user.username}")
    Result.success(updated)
  }

  suspend fun grantAllBadgesByUsername(username: String, allBadgeIds: List<String> = BadgeCatalog.badges.map { it.id }): Result<UserEntity> = withContext(Dispatchers.IO) {
    val cleanUsername = username.trim().removePrefix("@").lowercase()
    val user = if (cleanUsername.isBlank() || cleanUsername == "self") {
      getCurrentUser()
    } else {
      userDao.getUserByUsername(cleanUsername)
        ?: cloudRepo.findUserByUsernameOnce(cleanUsername)?.also { userDao.insertUser(it) }
    } ?: return@withContext Result.failure(Exception("User @$cleanUsername not found."))

    val mergedIds = user.equippedBadges.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableSet()
    allBadgeIds.forEach { if (it.isNotBlank()) mergedIds.add(it) }
    BadgeCatalog.badges.forEach { mergedIds.add(it.id) }
    val csv = mergedIds.joinToString(",")

    val progMap = BadgeCatalog.parseProgressMap(user.unlockedBadgesProgressJson).toMutableMap()
    BadgeCatalog.badges.forEach { def ->
      progMap[def.progressKey] = maxOf(progMap[def.progressKey] ?: 0, def.targetProgress)
      progMap[def.id] = maxOf(progMap[def.id] ?: 0, def.targetProgress)
    }
    val progJson = BadgeCatalog.serializeProgressMap(progMap)

    val updated = user.copy(equippedBadges = csv, unlockedBadgesProgressJson = progJson)
    userDao.updateEquippedBadgesAndProgress(user.id, csv, progJson)
    if (user.id == _currentUserId.value) {
      runCatching { cloudRepo.upsertPublicProfile(updated, isCreate = false) }
    }
    runCatching {
      cloudRepo.adminUpdateUserFields(
        targetUserId = user.id,
        equippedBadges = csv,
        unlockedBadgesProgressJson = progJson
      )
    }
    logAudit("GRANT_ALL_BADGES", "Admin granted ALL badges (${mergedIds.size}) with full quest progress to @${user.username}")
    Result.success(updated)
  }

  suspend fun toggleInvisibleInServer(serverId: String): Result<Boolean> = withContext(Dispatchers.IO) {
    val me = getCurrentUser() ?: return@withContext Result.failure(Exception("Sign in required"))
    if (serverId.isBlank()) return@withContext Result.failure(Exception("No server selected"))
    val set = me.invisibleServerIdsCsv.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableSet()
    val nowInvisible = if (set.contains(serverId)) {
      set.remove(serverId)
      false
    } else {
      set.add(serverId)
      true
    }
    val nextCsv = set.joinToString(",")
    val updated = me.copy(invisibleServerIdsCsv = nextCsv)
    userDao.updateInvisibleServers(me.id, nextCsv)
    runCatching { cloudRepo.upsertPublicProfile(updated, isCreate = false) }
    runCatching { cloudRepo.adminUpdateUserFields(me.id, invisibleServerIdsCsv = nextCsv) }
    logAudit("INVISIBLE_SERVER", "@${me.username} set server $serverId invisible=$nowInvisible")
    Result.success(nowInvisible)
  }

  suspend fun deleteUserAccount(targetUserId: String): Result<Unit> = withContext(Dispatchers.IO) {
    if (targetUserId == _currentUserId.value) {
      return@withContext Result.failure(Exception("Cannot delete your own active Owner session."))
    }
    val target = userDao.getUserById(targetUserId)
    userDao.deleteUserById(targetUserId)
    runCatching { cloudRepo.deleteUserRemote(targetUserId) }
    logAudit("DELETE_ACCOUNT", "Owner deleted user account ${target?.username ?: targetUserId}")
    Result.success(Unit)
  }

  suspend fun broadcastAnnouncement(title: String, messageText: String) = withContext(Dispatchers.IO) {
    val owner = getCurrentUser() ?: return@withContext
    val annMsg = MessageEntity(
      id = "ann_${UUID.randomUUID().toString().take(8)}",
      channelId = "ch_s1_ann",
      senderId = owner.id,
      senderName = "OFFICIAL ANNOUNCEMENT",
      senderTier = "ASTRAL",
      content = "[ANNOUNCEMENT] $title\n\n$messageText",
      isPinned = true
    )
    messageDao.insertMessage(annMsg)
    runCatching { cloudRepo.sendChannelMessage(annMsg) }
    logAudit("BROADCAST", "Announcement broadcast: $title")
  }

  // --- NOTIFICATIONS & AUDIT LOGS ---

  fun getNotifications(userId: String): Flow<List<NotificationEntity>> = notificationDao.getNotifications(userId)

  suspend fun markAllNotificationsRead(userId: String) = withContext(Dispatchers.IO) {
    notificationDao.markAllAsRead(userId)
  }

  suspend fun pushLocalAndRemoteNotification(targetUserId: String, title: String, message: String, type: String) {
    val id = "ntf_${UUID.randomUUID().toString().take(8)}"
    if (targetUserId == _currentUserId.value) {
      notificationDao.insertNotification(
        NotificationEntity(id = id, userId = targetUserId, title = title, message = message, type = type)
      )
    } else {
      runCatching { cloudRepo.sendRemoteNotification(targetUserId, title, message, type) }
    }
  }

  fun getAuditLogs(): Flow<List<AuditLogEntity>> = auditLogDao.getAuditLogs()

  suspend fun logAudit(action: String, details: String) {
    val actor = getCurrentUser()?.username ?: "system"
    val id = "log_${UUID.randomUUID().toString().take(8)}"
    auditLogDao.insertLog(
      AuditLogEntity(
        id = id,
        actorUsername = actor,
        action = action,
        details = details
      )
    )
    runCatching { cloudRepo.writeAdminLogRemote(id, action, details) }
  }

  fun getProfileVisitors(userId: String): Flow<List<ProfileVisitorEntity>> = profileVisitorDao.getVisitors(userId)
}
