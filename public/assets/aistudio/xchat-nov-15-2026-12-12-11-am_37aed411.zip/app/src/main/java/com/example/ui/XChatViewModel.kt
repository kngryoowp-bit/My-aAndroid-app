package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.GlobalSearchResult
import com.example.data.repository.XChatRepository
import com.example.ui.components.BadgeCatalog
import com.example.ui.theme.AppLocalization
import com.example.ui.theme.trCode
import com.example.utils.AppActivityTracker
import com.example.utils.AudioPlayerManager
import com.example.utils.AudioPlayerUiState
import com.example.utils.CloudMediaHelper
import com.example.utils.GifResultItem
import com.example.utils.GifSearchClient
import com.example.utils.IpDetectionResult
import com.example.utils.IpLanguageDetector
import com.example.utils.MediaStorageHelper
import com.example.utils.PickedFileInfo
import com.example.utils.RtcCallUiState
import com.example.utils.ScreenShareBus
import com.example.utils.SoundEffectType
import com.example.utils.SoundEffectsEngine
import com.example.utils.SoundSettingsState
import com.example.utils.VideoTrimHelper
import com.example.utils.VoiceMediaForegroundService
import com.example.utils.WebRtcCallManager
import com.example.utils.XChatNotificationHelper
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.security.MessageDigest

sealed class ScreenDestination {
  object Landing : ScreenDestination()
  object Login : ScreenDestination()
  object Register : ScreenDestination()
  object Main : ScreenDestination()
}

enum class MainTab {
  HOME,
  CHANNELS,
  DMS,
  EXPLORE,
  GAMES,
  MARKET,
  PROFILE,
  SETTINGS,
  OWNER_DASHBOARD
}

data class VoiceState(
  val isInVoice: Boolean = false,
  val serverId: String = "",
  val channelId: String = "",
  val channelName: String = "",
  val isMuted: Boolean = false,
  val isDeafened: Boolean = false,
  val isCameraOn: Boolean = false,
  val isScreenSharing: Boolean = false,
  val lastSoundTriggered: String? = null
)

data class InAppBannerNotification(
  val id: String,
  val title: String,
  val body: String,
  val isDm: Boolean,
  val targetId: String,
  val timestamp: Long = System.currentTimeMillis()
)

class XChatViewModel(application: Application) : AndroidViewModel(application) {
  val repository = XChatRepository(application)

  private val syncJobs = mutableListOf<Job>()
  private var boundUid: String? = null
  private var typingSendJob: Job? = null
  private var typingClearJob: Job? = null
  private var lastTypingSentAt: Long = 0L
  private var voiceHeartbeatJob: Job? = null
  private val seenIncomingNotifIds = mutableSetOf<String>()

  private val _currentScreen = MutableStateFlow<ScreenDestination>(
    if (repository.currentUserId.value != null) ScreenDestination.Main else ScreenDestination.Landing
  )
  val currentScreen = _currentScreen.asStateFlow()

  private val _activeTab = MutableStateFlow(MainTab.HOME)
  val activeTab = _activeTab.asStateFlow()

  val currentUser: StateFlow<UserEntity?> = repository.getCurrentUserFlow()
    .stateIn(viewModelScope, SharingStarted.Eagerly, null)

  private val _isOwnerDashboardUnlocked = MutableStateFlow(repository.isOwnerKeyUnlocked())
  val isOwnerDashboardUnlocked = _isOwnerDashboardUnlocked.asStateFlow()

  private val _verifiedAdminRole = MutableStateFlow("NONE")
  val verifiedAdminRole = _verifiedAdminRole.asStateFlow()
  val isVerifiedAdmin: StateFlow<Boolean> = combine(_verifiedAdminRole, _isOwnerDashboardUnlocked, currentUser) { role, unlocked, user ->
    role != "NONE" || unlocked || user?.isOwner == true || (user?.adminRole != null && user.adminRole != "NONE")
  }.stateIn(viewModelScope, SharingStarted.Eagerly, false)

  private val _isFloatingAdminOpen = MutableStateFlow(false)
  val isFloatingAdminOpen = _isFloatingAdminOpen.asStateFlow()

  private val _inspectedProfileUser = MutableStateFlow<UserEntity?>(null)
  val inspectedProfileUser = _inspectedProfileUser.asStateFlow()

  // IP Detection & Language State
  private val _detectedIpInfo = MutableStateFlow<IpDetectionResult?>(null)
  val detectedIpInfo = _detectedIpInfo.asStateFlow()

  private val _manualLangOverride = MutableStateFlow<String?>(null)
  val activeLanguageCode: StateFlow<String> = combine(
    currentUser,
    _detectedIpInfo,
    _manualLangOverride
  ) { user, ipInfo, manual ->
    when {
      manual == "AUTO" -> ipInfo?.recommendedLang ?: "en"
      manual != null -> manual
      user != null && user.languageCode != "AUTO" -> user.languageCode
      ipInfo != null -> ipInfo.recommendedLang
      else -> "en"
    }
  }.stateIn(viewModelScope, SharingStarted.Eagerly, "en")

  val isViewingDm = MutableStateFlow(false)

  fun setIsViewingDm(viewing: Boolean) {
    isViewingDm.value = viewing
  }

  val servers: StateFlow<List<ServerEntity>> = repository.getServers()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val joinedServerIds: StateFlow<List<String>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.getJoinedServerIds(user.id) else flowOf(emptyList())
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private val _selectedServerId = MutableStateFlow(repository.getSavedSelectedServerId())
  val selectedServerId = _selectedServerId.asStateFlow()

  val currentCategories: StateFlow<List<ChannelCategoryEntity>> = _selectedServerId
    .flatMapLatest { serverId -> repository.getCategories(serverId) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val currentChannels: StateFlow<List<ChannelEntity>> = _selectedServerId
    .flatMapLatest { serverId -> repository.getChannels(serverId) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val currentServerRoles: StateFlow<List<ServerRoleEntity>> = _selectedServerId
    .flatMapLatest { serverId -> repository.getServerRoles(serverId) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val currentServerMembers: StateFlow<List<ServerMemberEntity>> = _selectedServerId
    .flatMapLatest { serverId -> repository.getServerMembers(serverId) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private val _selectedChannelId = MutableStateFlow(repository.getSavedSelectedChannelId())
  val selectedChannelId = _selectedChannelId.asStateFlow()

  val currentMessages: StateFlow<List<MessageEntity>> = _selectedChannelId
    .flatMapLatest { channelId -> repository.getMessages(channelId) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Forum state
  val currentForumPosts: StateFlow<List<ForumPostEntity>> = _selectedChannelId
    .flatMapLatest { channelId -> repository.getForumPosts(channelId) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private val _activeForumPostId = MutableStateFlow<String?>(null)
  val activeForumPostId = _activeForumPostId.asStateFlow()

  val currentForumReplies: StateFlow<List<ForumReplyEntity>> = _activeForumPostId
    .flatMapLatest { postId ->
      if (postId != null) repository.getForumReplies(postId) else flowOf(emptyList())
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Direct messages
  val friends: StateFlow<List<FriendEntity>> = currentUser
    .flatMapLatest { user -> if (user != null) repository.getFriends(user.id) else flowOf(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private val _activeDmUserId = MutableStateFlow<String?>("usr_alex")
  val activeDmUserId = _activeDmUserId.asStateFlow()

  private val _openDmThreadSignal = MutableStateFlow(0L)
  val openDmThreadSignal = _openDmThreadSignal.asStateFlow()

  fun consumeOpenDmThreadSignal() {
    _openDmThreadSignal.value = 0L
  }

  val activeDmMessages: StateFlow<List<DirectMessageEntity>> = combine(currentUser, _activeDmUserId) { user, otherId ->
    if (user != null && otherId != null) {
      if (user.id < otherId) "dm_${user.id}_$otherId" else "dm_${otherId}_${user.id}"
    } else null
  }.flatMapLatest { convId ->
    if (convId != null) repository.getDirectMessages(convId) else flowOf(emptyList())
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Quests & Marketplace
  val quests: StateFlow<List<QuestEntity>> = repository.getQuests()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val marketplaceItems: StateFlow<List<MarketplaceItemEntity>> = repository.getMarketplaceItems()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val userInventory: StateFlow<List<UserInventoryEntity>> = currentUser
    .flatMapLatest { user -> if (user != null) repository.getUserInventory(user.id) else flowOf(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Users, Owner dashboard & visitors
  val allUsers: StateFlow<List<UserEntity>> = repository.getAllUsers()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val typingUsersInCurrentChannel: StateFlow<List<UserEntity>> = combine(
    allUsers,
    _selectedChannelId,
    _selectedServerId,
    currentUser
  ) { users, chId, srvId, me ->
    val cutoff = System.currentTimeMillis() - 8_000L
    users.filter { u ->
      val isInv = u.invisibleServerIdsCsv.split(",").map { s -> s.trim() }.contains(srvId)
      u.id != me?.id &&
        !isInv &&
        u.typingChannelId == chId &&
        u.typingUpdatedAt >= cutoff
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val isActiveDmPeerTyping: StateFlow<Boolean> = combine(
    allUsers,
    _activeDmUserId,
    currentUser
  ) { users, peerId, me ->
    if (me == null || peerId == null) return@combine false
    val convId = if (me.id < peerId) "dm_${me.id}_$peerId" else "dm_${peerId}_${me.id}"
    val peer = users.firstOrNull { it.id == peerId } ?: return@combine false
    peer.typingChannelId == convId && peer.typingUpdatedAt >= (System.currentTimeMillis() - 8_000L)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

  val paymentRequests: StateFlow<List<PaymentRequestEntity>> = repository.getPaymentRequests()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val auditLogs: StateFlow<List<AuditLogEntity>> = repository.getAuditLogs()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val profileVisitors: StateFlow<List<ProfileVisitorEntity>> = currentUser
    .flatMapLatest { user -> if (user != null) repository.getProfileVisitors(user.id) else flowOf(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private val _voiceState = MutableStateFlow(VoiceState())
  val voiceState = _voiceState.asStateFlow()

  val voiceParticipants: StateFlow<List<VoiceParticipantModel>> = combine(
    _voiceState.flatMapLatest { vs ->
      if (vs.isInVoice && vs.serverId.isNotBlank() && vs.channelId.isNotBlank()) {
        repository.observeVoiceParticipants(vs.serverId, vs.channelId).catch { emit(emptyList()) }
      } else {
        flowOf(emptyList())
      }
    },
    _voiceState,
    allUsers,
    currentUser
  ) { participants, vs, users, me ->
    val invisibleIds = users.filter { u ->
      u.id != me?.id &&
        u.invisibleServerIdsCsv.split(",").map { s -> s.trim() }.contains(vs.serverId)
    }.map { it.id }.toSet()
    participants.filter { it.userId !in invisibleIds }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val savedProfileThemes: StateFlow<List<SavedProfileThemeEntity>> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.getSavedProfileThemes(user.id) else flowOf(emptyList())
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val mutedUserIds: StateFlow<Set<String>> = repository.mutedUserIds
  val mutedServerIds: StateFlow<Set<String>> = repository.mutedServerIds

  // V2.0 Social Follows & My Games/Apps
  val myFollowing: StateFlow<List<UserFollowEntity>> = currentUser
    .flatMapLatest { user -> if (user != null) repository.getFollowingFlow(user.id) else flowOf(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val myFollowers: StateFlow<List<UserFollowEntity>> = currentUser
    .flatMapLatest { user -> if (user != null) repository.getFollowersFlow(user.id) else flowOf(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val inspectedUserFollowers: StateFlow<List<UserFollowEntity>> = _inspectedProfileUser
    .flatMapLatest { user -> if (user != null) repository.getFollowersFlow(user.id) else flowOf(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val inspectedUserFollowing: StateFlow<List<UserFollowEntity>> = _inspectedProfileUser
    .flatMapLatest { user -> if (user != null) repository.getFollowingFlow(user.id) else flowOf(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val myGamesApps: StateFlow<List<UserGameAppEntity>> = currentUser
    .flatMapLatest { user -> if (user != null) repository.getUserGamesApps(user.id) else flowOf(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val inspectedUserGamesApps: StateFlow<List<UserGameAppEntity>> = _inspectedProfileUser
    .flatMapLatest { user -> if (user != null) repository.getUserGamesApps(user.id) else flowOf(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // V2.0 Stickers & GIFs
  val stickerPacks: StateFlow<List<StickerPackEntity>> = repository.getStickerPacks()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val allStickers: StateFlow<List<StickerEntity>> = repository.getAllStickers()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val gifFavorites: StateFlow<List<GifFavoriteEntity>> = currentUser
    .flatMapLatest { user -> if (user != null) repository.getGifFavorites(user.id) else flowOf(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val gifSearchResults = MutableStateFlow<List<GifResultItem>>(GifSearchClient.curatedGifs)
  val isSearchingGifs = MutableStateFlow(false)

  // V2.0 Music Player & Playlists
  val audioState: StateFlow<AudioPlayerUiState> = AudioPlayerManager.state
  val soundState: StateFlow<SoundSettingsState> = SoundEffectsEngine.state
  val playlists: StateFlow<List<PlaylistEntity>> = currentUser
    .flatMapLatest { user -> if (user != null) repository.getPlaylistsForUser(user.id) else flowOf(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  private val _selectedPlaylistId = MutableStateFlow<String?>(null)
  val selectedPlaylistId = _selectedPlaylistId.asStateFlow()
  val tracksForActivePlaylist: StateFlow<List<AudioTrackEntity>> = combine(_selectedPlaylistId, playlists) { selId, list ->
    selId ?: list.firstOrNull()?.id
  }.flatMapLatest { plId ->
    if (plId != null) repository.getTracksForPlaylist(plId) else flowOf(emptyList())
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val allUserTracks: StateFlow<List<AudioTrackEntity>> = currentUser
    .flatMapLatest { user -> if (user != null) repository.getAllTracksForUser(user.id) else flowOf(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // V2.0 WebRTC Real Bilateral Calls
  val rtcCallState: StateFlow<RtcCallUiState> = WebRtcCallManager.callState
  val localVideoTrack = WebRtcCallManager.localVideoTrack
  val remoteVideoTracks = WebRtcCallManager.remoteVideoTracks

  // V2.0 Mini Games & Tournaments
  val allMatches: StateFlow<List<GameMatchEntity>> = repository.getAllMatches()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val gameRatings: StateFlow<List<GameRatingEntity>> = repository.getAllGameRatings()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val tournaments: StateFlow<List<TournamentEntity>> = repository.getAllTournaments()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  private val _activeMatchId = MutableStateFlow<String?>(null)
  val activeMatchId = _activeMatchId.asStateFlow()

  // V2.0 Moderation, Lock Screen, Reports, Redeem, Notifications, Global Search
  val activeRestriction: StateFlow<UserRestrictionEntity?> = currentUser
    .flatMapLatest { user ->
      if (user != null) repository.getActiveRestrictionForUserFlow(user.id) else flowOf(null)
    }
    .stateIn(viewModelScope, SharingStarted.Eagerly, null)
  val allRestrictions: StateFlow<List<UserRestrictionEntity>> = repository.getAllRestrictions()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val reports: StateFlow<List<ReportEntity>> = repository.getAllReports()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val redeemCodes: StateFlow<List<RedeemCodeEntity>> = repository.getRedeemCodes()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val notifications: StateFlow<List<NotificationEntity>> = currentUser
    .flatMapLatest { user -> if (user != null) repository.getNotifications(user.id) else flowOf(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val globalSearchQuery = MutableStateFlow("")
  val globalSearchResult = MutableStateFlow(GlobalSearchResult())

  private val _inAppNotification = MutableStateFlow<InAppBannerNotification?>(null)
  val inAppNotification = _inAppNotification.asStateFlow()

  private val _isAppLocked = MutableStateFlow(repository.hasAppLockPin())
  val isAppLocked = _isAppLocked.asStateFlow()

  private val _hasAppPin = MutableStateFlow(repository.hasAppLockPin())
  val hasAppPin = _hasAppPin.asStateFlow()

  val messageText = MutableStateFlow("")
  val attachedFile = MutableStateFlow<PickedFileInfo?>(null)
  val replyingToMessage = MutableStateFlow<MessageEntity?>(null)
  val searchQuery = MutableStateFlow("")
  val searchResults = MutableStateFlow<List<MessageEntity>>(emptyList())
  val feedbackMessage = MutableStateFlow<String?>(null)
  val isUploadingMedia = MutableStateFlow(false)
  private val _profileSyncError = MutableStateFlow<String?>(null)
  val profileSyncError = _profileSyncError.asStateFlow()

  init {
    viewModelScope.launch {
      if (_detectedIpInfo.value == null) {
        _detectedIpInfo.value = IpLanguageDetector.detectIpAndLanguage()
      }
    }

    AudioPlayerManager.onTrackChangedListener = { track, isPlaying, _, _ ->
      if (currentUser.value != null) {
        viewModelScope.launch {
          repository.updateListeningStatus(
            title = track?.title,
            artist = track?.artist,
            coverUri = track?.coverUri,
            sourceUrl = track?.sourceUri,
            isPlaying = isPlaying
          )
        }
      }
    }

    // Auto-select first channel when server changes
    viewModelScope.launch {
      currentChannels.collect { channels ->
        if (channels.isNotEmpty() && channels.none { it.id == _selectedChannelId.value }) {
          val firstText = channels.firstOrNull { it.type == "text" } ?: channels.first()
          _selectedChannelId.value = firstText.id
          repository.saveSelectedChannelId(firstText.id)
        }
      }
    }

    // Auto-expire XChat Lock Screen restriction when deadline passes
    viewModelScope.launch {
      while (isActive) {
        val rst = activeRestriction.value
        if (rst != null && rst.isActive && System.currentTimeMillis() >= rst.expiresAt) {
          repository.clearExpiredRestrictionIfNeeded(rst)
        }
        delay(1000L)
      }
    }

    // Sync server voice room WebRTC peers whenever participant list changes
    viewModelScope.launch {
      voiceParticipants.collect { list ->
        val vs = _voiceState.value
        val meId = currentUser.value?.id
        if (vs.isInVoice && meId != null && vs.serverId.isNotBlank() && vs.channelId.isNotBlank()) {
          WebRtcCallManager.syncServerVoicePeers(
            context = getApplication(),
            serverId = vs.serverId,
            channelId = vs.channelId,
            myId = meId,
            participantIds = list.map { it.userId }
          )
        }
      }
    }
  }

  fun retryBindAuthenticatedUser() {
    boundUid = null
    _profileSyncError.value = null
    bindAuthenticatedUser(detectedIp = _detectedIpInfo.value)
  }

  fun bindAuthenticatedUser(
    preferredUsername: String? = null,
    preferredDisplayName: String? = null,
    detectedIp: IpDetectionResult? = null
  ) {
    if (detectedIp != null) {
      _detectedIpInfo.value = detectedIp
    }
    val fbUser = Firebase.auth.currentUser ?: return
    if (boundUid == fbUser.uid && syncJobs.isNotEmpty() && currentUser.value != null) return
    boundUid = fbUser.uid
    _profileSyncError.value = null

    viewModelScope.launch {
      val res = repository.syncAuthenticatedUser(preferredUsername, preferredDisplayName)
      if (res.isSuccess) {
        _profileSyncError.value = null
        _selectedServerId.value = repository.getSavedSelectedServerId()
        _selectedChannelId.value = repository.getSavedSelectedChannelId()
        _isOwnerDashboardUnlocked.value = repository.isOwnerKeyUnlocked()
        _verifiedAdminRole.value = repository.verifyCurrentUserAdminRole()
        val hasPin = repository.hasAppLockPin()
        _hasAppPin.value = hasPin
        _isAppLocked.value = hasPin
        _currentScreen.value = ScreenDestination.Main
        startCloudSync(fbUser.uid)
        startPresenceHeartbeat()
        WebRtcCallManager.observeIncomingCalls(getApplication(), fbUser.uid)
      } else {
        boundUid = null
        val errMsg = res.exceptionOrNull()?.message ?: trCode(activeLanguageCode.value, "Failed to sync account", "Gagal menyinkronkan akun", "Gagal menyegerakkan akaun", "アカウントの同期に失敗しました")
        _profileSyncError.value = errMsg
        feedbackMessage.value = errMsg
      }
    }
  }

  private fun stopCloudSync() {
    syncJobs.forEach { it.cancel() }
    syncJobs.clear()
  }

  private fun startCloudSync(uid: String) {
    stopCloudSync()
    val cloud = repository.cloudRepo
    val syncStartMs = System.currentTimeMillis()

    syncJobs += viewModelScope.launch {
      cloud.observePublicUsers()
        .catch { }
        .collect { users -> repository.upsertCloudUsers(users) }
    }
    syncJobs += viewModelScope.launch {
      cloud.observePublicServers()
        .catch { }
        .collect { srvs -> repository.upsertCloudServers(srvs) }
    }
    syncJobs += viewModelScope.launch {
      cloud.observeSavedThemes(uid)
        .catch { }
        .collect { themes -> repository.upsertCloudSavedThemes(themes) }
    }
    syncJobs += viewModelScope.launch {
      cloud.observeDirectMessagesForUser()
        .catch { }
        .collect { dms ->
          repository.upsertCloudDMs(dms)
          dms.filter { dm ->
            dm.senderId != uid &&
              !dm.isRead &&
              dm.timestamp >= syncStartMs - 5_000L &&
              seenIncomingNotifIds.add(dm.id)
          }.forEach { dm ->
            if (!mutedUserIds.value.contains(dm.senderId)) {
              val isCurrentlyViewingSameDm = _activeTab.value == MainTab.DMS && _activeDmUserId.value == dm.senderId
              if (!isCurrentlyViewingSameDm) {
                val preview = dm.content.ifBlank { dm.attachmentName ?: trCode(activeLanguageCode.value, "Attachment", "Lampiran", "Lampiran", "添付ファイル") }
                emitNotification(
                  id = dm.id,
                  title = "${dm.senderName} (DM)",
                  body = preview,
                  isDm = true,
                  targetId = dm.senderId
                )
              }
            }
          }
        }
    }
    syncJobs += viewModelScope.launch {
      cloud.observeFriendshipsForUser()
        .catch { }
        .collect { frs -> repository.upsertCloudFriends(frs) }
    }
    syncJobs += viewModelScope.launch {
      _selectedServerId.flatMapLatest { serverId ->
        cloud.observeServerChannels(serverId).catch { emit(emptyList()) }
      }.collect { chs -> repository.upsertCloudChannels(chs) }
    }
    syncJobs += viewModelScope.launch {
      _selectedServerId.flatMapLatest { serverId ->
        cloud.observeServerRoles(serverId).catch { emit(emptyList()) }
      }.collect { roles -> repository.upsertCloudRoles(roles) }
    }
    syncJobs += viewModelScope.launch {
      _selectedServerId.flatMapLatest { serverId ->
        cloud.observeServerMembers(serverId).catch { emit(emptyList()) }
      }.collect { members -> repository.upsertCloudMembers(members) }
    }
    syncJobs += viewModelScope.launch {
      _selectedChannelId.flatMapLatest { channelId ->
        cloud.observeChannelMessages(channelId).catch { emit(emptyList()) }
      }.collect { msgs ->
        repository.upsertCloudMessages(msgs)
        val curSrv = _selectedServerId.value
        msgs.filter { msg ->
          msg.senderId != uid &&
            msg.timestamp >= syncStartMs - 5_000L &&
            seenIncomingNotifIds.add(msg.id)
        }.forEach { msg ->
          if (!mutedUserIds.value.contains(msg.senderId) && !mutedServerIds.value.contains(curSrv)) {
            val isViewingSameChannel = _activeTab.value == MainTab.CHANNELS && _selectedChannelId.value == msg.channelId
            if (!isViewingSameChannel) {
              emitNotification(
                id = msg.id,
                title = msg.senderName,
                body = msg.content.ifBlank { msg.attachmentName ?: trCode(activeLanguageCode.value, "Attachment", "Lampiran", "Lampiran", "添付ファイル") },
                isDm = false,
                targetId = msg.channelId
              )
            }
          }
        }
      }
    }
    syncJobs += viewModelScope.launch {
      _selectedChannelId.flatMapLatest { channelId ->
        cloud.observeForumPosts(channelId).catch { emit(emptyList()) }
      }.collect { posts -> repository.upsertCloudForumPosts(posts) }
    }
    syncJobs += viewModelScope.launch {
      combine(_selectedChannelId, _activeForumPostId) { chId, pId -> chId to pId }
        .flatMapLatest { (chId, pId) ->
          if (pId != null) cloud.observeForumReplies(chId, pId).catch { emit(emptyList()) }
          else flowOf(emptyList())
        }
        .collect { replies -> repository.upsertCloudForumReplies(replies) }
    }
    syncJobs += viewModelScope.launch {
      _selectedServerId.flatMapLatest { serverId ->
        cloud.observeServerCategories(serverId).catch { emit(emptyList()) }
      }.collect { cats -> repository.upsertCloudCategories(cats) }
    }
    syncJobs += viewModelScope.launch {
      combine(cloud.observeMyFollows(uid), cloud.observeMyFollowers(uid)) { a, b -> a + b }
        .catch { }
        .collect { list -> repository.upsertCloudFollows(list) }
    }
    syncJobs += viewModelScope.launch {
      cloud.observeUserNotifications(uid)
        .catch { }
        .collect { list -> repository.upsertCloudNotifications(list) }
    }
    syncJobs += viewModelScope.launch {
      combine(cloud.observeSharedStickerPacks(), cloud.observeSharedStickers()) { p, s -> p to s }
        .catch { }
        .collect { (packs, stks) -> repository.upsertCloudStickers(packs, stks) }
    }
    syncJobs += viewModelScope.launch {
      cloud.observeGameMatchesForUser(uid)
        .catch { }
        .collect { matches -> repository.upsertCloudMatches(matches) }
    }
    syncJobs += viewModelScope.launch {
      cloud.observePublicGameRatings()
        .catch { }
        .collect { ratings -> repository.upsertCloudRatings(ratings) }
    }
    syncJobs += viewModelScope.launch {
      cloud.observeTournaments()
        .catch { }
        .collect { trns -> repository.upsertCloudTournaments(trns) }
    }
    syncJobs += viewModelScope.launch {
      cloud.observeRestrictionsForUser(uid)
        .catch { }
        .collect { list ->
          repository.upsertCloudRestrictions(list)
          list.filter { it.isActive && System.currentTimeMillis() >= it.expiresAt }
            .forEach { repository.clearExpiredRestrictionIfNeeded(it) }
        }
    }
  }

  private fun emitNotification(id: String, title: String, body: String, isDm: Boolean, targetId: String) {
    SoundEffectsEngine.play(if (isDm) SoundEffectType.MESSAGE_RECEIVED else SoundEffectType.NOTIFICATION)
    val banner = InAppBannerNotification(id = id, title = title, body = body, isDm = isDm, targetId = targetId)
    _inAppNotification.value = banner
    XChatNotificationHelper.showIncomingMessageNotification(
      context = getApplication(),
      title = title,
      body = body,
      isDm = isDm,
      targetId = targetId
    )
    viewModelScope.launch {
      delay(4500L)
      if (_inAppNotification.value?.id == id) {
        _inAppNotification.value = null
      }
    }
  }

  fun dismissInAppNotification() {
    _inAppNotification.value = null
  }

  fun openNotificationTarget(notif: InAppBannerNotification) {
    _inAppNotification.value = null
    if (notif.isDm) {
      _activeDmUserId.value = notif.targetId
      _openDmThreadSignal.value = System.currentTimeMillis()
      _activeTab.value = MainTab.DMS
    } else {
      _selectedChannelId.value = notif.targetId
      _activeTab.value = MainTab.CHANNELS
    }
  }

  fun handleNotificationLaunchIntent(navType: String?, targetId: String?) {
    if (navType.isNullOrBlank() || targetId.isNullOrBlank()) return
    if (navType == "dm") {
      _activeDmUserId.value = targetId
      _openDmThreadSignal.value = System.currentTimeMillis()
      _activeTab.value = MainTab.DMS
    } else if (navType == "channel") {
      _selectedChannelId.value = targetId
      _activeTab.value = MainTab.CHANNELS
    }
  }

  private fun startPresenceHeartbeat() {
    syncJobs += viewModelScope.launch {
      var tick = 0
      while (isActive) {
        if (tick % 4 == 0) {
          repository.sendPresenceHeartbeat()
        }
        val me = currentUser.value
        if (me != null) {
          val connections = AppActivityTracker.parseConnections(me.connectionsJson)
          val detected = AppActivityTracker.detectForegroundConnectedApp(
            context = getApplication(),
            connections = connections,
            previousPkg = me.activeAppPackage,
            previousStartedAt = me.activeAppStartedAt
          )
          if (detected != null) {
            repository.updateActiveAppState(detected.appName, detected.packageName, detected.startedAt)
          } else if (me.activeAppName != null && System.currentTimeMillis() - me.activeAppStartedAt > 120_000L) {
            repository.updateActiveAppState(null, null, 0L)
          }
        }
        tick++
        delay(10_000L)
      }
    }
  }

  fun onUserTyping(targetChannelOrDmId: String) {
    val now = System.currentTimeMillis()
    if (now - lastTypingSentAt >= 2500L) {
      lastTypingSentAt = now
      typingSendJob?.cancel()
      typingSendJob = viewModelScope.launch {
        repository.setTypingChannel(targetChannelOrDmId)
      }
    }
    typingClearJob?.cancel()
    typingClearJob = viewModelScope.launch {
      delay(6_000L)
      repository.setTypingChannel(null)
    }
  }

  fun clearTyping() {
    typingClearJob?.cancel()
    viewModelScope.launch {
      repository.setTypingChannel(null)
    }
  }

  fun isUserAstral(): Boolean {
    val u = currentUser.value ?: return false
    return u.isOwner || u.subscriptionTier.equals("ASTRAL", ignoreCase = true)
  }

  fun isGifUri(uri: Uri): Boolean {
    return MediaStorageHelper.isGifUri(getApplication(), uri)
  }

  fun prepareAndPickMedia(
    uri: Uri,
    maxDim: Int = 512,
    preserveTransparency: Boolean = false,
    allowGifFree: Boolean = false,
    onReady: (String) -> Unit
  ) {
    viewModelScope.launch {
      isUploadingMedia.value = true
      try {
        val isGif = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
          isGifUri(uri)
        }
        if (isGif && !allowGifFree && !isUserAstral()) {
          feedbackMessage.value = AppLocalization.forCode(activeLanguageCode.value).astralRequiredGif
          return@launch
        }
        val cloudUri = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
          val localPath = MediaStorageHelper.persistPickedMedia(getApplication(), uri)
          CloudMediaHelper.prepareCloudMediaUri(
            context = getApplication(),
            sourceUriString = localPath,
            maxDimensionPx = maxDim,
            preserveTransparency = preserveTransparency
          )
        }
        if (cloudUri.startsWith("file://") && isGif) {
          feedbackMessage.value = trCode(activeLanguageCode.value, "GIF >420KB prepared for local preview.", "GIF >420KB disiapkan dalam preview lokal.", "GIF >420KB disediakan untuk pratonton tempatan.", "420KB超のGIFをローカルプレビュー用に準備しました。")
        }
        onReady(cloudUri)
      } catch (e: Exception) {
        feedbackMessage.value = "${trCode(activeLanguageCode.value, "Failed to process media", "Gagal memproses media", "Gagal memproses media", "メディアの処理に失敗しました")}: ${e.message ?: "error"}"
      } finally {
        isUploadingMedia.value = false
      }
    }
  }

  fun prepareAndPickAttachment(
    uri: Uri,
    onReady: (PickedFileInfo) -> Unit
  ) {
    viewModelScope.launch {
      isUploadingMedia.value = true
      try {
        val isGif = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
          isGifUri(uri)
        }
        if (isGif && !isUserAstral()) {
          feedbackMessage.value = AppLocalization.forCode(activeLanguageCode.value).astralRequiredGif
          return@launch
        }
        val cloudFile = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
          val picked = MediaStorageHelper.persistPickedFile(getApplication(), uri)
          CloudMediaHelper.uploadPickedFile(getApplication(), picked)
        }
        onReady(cloudFile)
      } catch (e: Exception) {
        feedbackMessage.value = "${trCode(activeLanguageCode.value, "Failed to process attachment", "Gagal memproses lampiran", "Gagal memproses lampiran", "添付ファイルの処理に失敗しました")}: ${e.message ?: "error"}"
      } finally {
        isUploadingMedia.value = false
      }
    }
  }

  fun tryPersistMediaFromUri(uri: Uri, onBlocked: ((String) -> Unit)? = null): String? {
    val isGif = isGifUri(uri)
    if (isGif && !isUserAstral()) {
      val msg = AppLocalization.forCode(activeLanguageCode.value).astralRequiredGif
      feedbackMessage.value = msg
      onBlocked?.invoke(msg)
      return null
    }
    return MediaStorageHelper.persistPickedMedia(getApplication(), uri)
  }

  fun tryPersistPickedFile(uri: Uri): PickedFileInfo? {
    val isGif = isGifUri(uri)
    if (isGif && !isUserAstral()) {
      feedbackMessage.value = AppLocalization.forCode(activeLanguageCode.value).astralRequiredGif
      return null
    }
    return MediaStorageHelper.persistPickedFile(getApplication(), uri)
  }

  fun setLanguage(langCode: String) {
    _manualLangOverride.value = langCode
    viewModelScope.launch {
      repository.updateAppearanceAndLanguage(languageCode = langCode)
      val resolved = if (langCode == "AUTO") (_detectedIpInfo.value?.recommendedLang ?: "en") else langCode
      feedbackMessage.value = when (resolved.lowercase()) {
        "id" -> if (langCode == "AUTO") "Bahasa diatur otomatis sesuai IP (${_detectedIpInfo.value?.countryCode ?: "ID"})" else "Bahasa aplikasi diubah ke Bahasa Indonesia"
        "ms" -> if (langCode == "AUTO") "Bahasa ditetapkan automatik mengikut IP (${_detectedIpInfo.value?.countryCode ?: "MY"})" else "Bahasa ditukar ke Bahasa Melayu"
        "ja" -> if (langCode == "AUTO") "IPに基づいて言語が自動設定されました (${_detectedIpInfo.value?.countryCode ?: "JP"})" else "言語を日本語に変更しました"
        else -> if (langCode == "AUTO") "Language set automatically by IP (${_detectedIpInfo.value?.countryCode ?: "EN"})" else "Language changed to English"
      }
    }
  }

  fun updateAppThemeAndFont(themeId: String, gradientCsv: String, fontKey: String, accentColorHex: Long? = null) {
    viewModelScope.launch {
      repository.updateAppearanceAndLanguage(
        appThemeId = themeId,
        appThemeGradientCsv = gradientCsv,
        appFontKey = fontKey,
        accentColorHex = accentColorHex
      )
      SoundEffectsEngine.play(SoundEffectType.BUTTON)
      feedbackMessage.value = when (activeLanguageCode.value.lowercase()) {
        "en" -> "App theme & typography updated!"
        "ms" -> "Tema & fon aplikasi berjaya dikemas kini!"
        "ja" -> "アプリテーマとフォントを更新しました！"
        else -> "Tema, aksen & font aplikasi berhasil diperbarui!"
      }
    }
  }

  fun updateCustomWallpaper(
    mode: String,
    uri: String?,
    gradientCsv: String,
    blur: Float,
    opacity: Float,
    brightness: Float,
    tintHex: Long
  ) {
    viewModelScope.launch {
      repository.updateCustomWallpaper(mode, uri, gradientCsv, blur, opacity, brightness, tintHex)
      feedbackMessage.value = trCode(activeLanguageCode.value, "Custom wallpaper updated!", "Wallpaper & latar belakang kustom berhasil diperbarui!", "Wallpaper & latar tersuai dikemas kini!", "カスタム壁紙を更新しました！")
    }
  }

  fun setSoundMasterEnabled(enabled: Boolean) {
    SoundEffectsEngine.setMasterEnabled(enabled)
    viewModelScope.launch { repository.updateSoundAndPerfSettings(soundEnabled = enabled) }
  }

  fun setSoundVolume(volume: Float) {
    SoundEffectsEngine.setVolume(volume)
    viewModelScope.launch { repository.updateSoundAndPerfSettings(soundVolume = volume) }
  }

  fun toggleSoundTypeMuted(type: SoundEffectType) {
    SoundEffectsEngine.toggleEffectMuted(type)
    val csv = SoundEffectsEngine.state.value.mutedTypes.joinToString(",") { it.name }
    viewModelScope.launch { repository.updateSoundAndPerfSettings(mutedSoundCategoriesCsv = csv) }
  }

  fun setLowPerfMode(enabled: Boolean) {
    viewModelScope.launch {
      repository.updateSoundAndPerfSettings(lowPerfMode = enabled)
      feedbackMessage.value = if (enabled) {
        trCode(activeLanguageCode.value, "Low Performance mode enabled.", "Mode Performa Rendah diaktifkan.", "Mod Prestasi Rendah diaktifkan.", "省電力モードが有効になりました。")
      } else {
        trCode(activeLanguageCode.value, "Full visual mode enabled.", "Mode Visual Penuh diaktifkan.", "Mod Visual Penuh diaktifkan.", "フルビジュアルモードが有効になりました。")
      }
    }
  }

  fun updateNotificationPrefs(prefsJson: String) {
    viewModelScope.launch {
      repository.updateSoundAndPerfSettings(notifPrefsJson = prefsJson)
    }
  }

  fun updateChatBubbleBackground(bgCsv: String, imageUri: String?, clearImage: Boolean = false) {
    viewModelScope.launch {
      repository.updateAppearanceAndLanguage(
        chatBubbleBgCsv = bgCsv,
        chatBubbleImageUri = imageUri,
        clearChatBubbleImage = clearImage
      )
      feedbackMessage.value = trCode(activeLanguageCode.value, "Chat bubble background updated!", "Latar belakang pesan chat Anda berhasil diperbarui!", "Latar buih sembang berjaya dikemas kini!", "チャット吹き出しの背景を更新しました！")
    }
  }

  fun navigateTo(screen: ScreenDestination) {
    _currentScreen.value = screen
  }

  fun setActiveTab(tab: MainTab) {
    _activeTab.value = tab
  }

  fun selectServer(serverId: String) {
    _selectedServerId.value = serverId
    repository.saveSelectedServerId(serverId)
    viewModelScope.launch {
      repository.ensureServerMembership(serverId)
    }
  }

  fun selectChannel(channel: ChannelEntity) {
    if (channel.type == "voice") {
      joinVoiceChannel(channel.id, channel.name)
    } else {
      _selectedChannelId.value = channel.id
      _activeForumPostId.value = null
      repository.saveSelectedChannelId(channel.id)
    }
  }

  fun selectDmUser(friendId: String) {
    _activeDmUserId.value = friendId
    markActiveDmConversationAsRead(friendId)
  }

  fun markActiveDmConversationAsRead(peerId: String? = _activeDmUserId.value) {
    val me = currentUser.value ?: return
    val otherId = peerId ?: return
    val convId = if (me.id < otherId) "dm_${me.id}_$otherId" else "dm_${otherId}_${me.id}"
    viewModelScope.launch {
      repository.markConversationAsRead(convId)
    }
  }

  fun markActiveChannelMessagesRead(messages: List<MessageEntity>) {
    val chId = _selectedChannelId.value
    if (chId.isBlank() || messages.isEmpty()) return
    viewModelScope.launch {
      repository.markChannelMessagesAsRead(chId, messages)
    }
  }

  fun toggleMuteUser(userId: String) {
    val nowMuted = repository.toggleMuteUser(userId)
    feedbackMessage.value = if (nowMuted) {
      trCode(activeLanguageCode.value, "Notifications muted for this user.", "Notifikasi pengguna ini disenyapkan.", "Pemberitahuan pengguna disenyapkan.", "このユーザーの通知をミュートしました。")
    } else {
      trCode(activeLanguageCode.value, "Notifications enabled for this user.", "Notifikasi pengguna ini diaktifkan.", "Pemberitahuan pengguna diaktifkan.", "このユーザーの通知を有効にしました。")
    }
  }

  fun toggleMuteServer(serverId: String) {
    val nowMuted = repository.toggleMuteServer(serverId)
    feedbackMessage.value = if (nowMuted) {
      trCode(activeLanguageCode.value, "Server notifications muted.", "Notifikasi server ini disenyapkan.", "Pemberitahuan pelayan disenyapkan.", "サーバー通知をミュートしました。")
    } else {
      trCode(activeLanguageCode.value, "Server notifications enabled.", "Notifikasi server ini diaktifkan.", "Pemberitahuan pelayan diaktifkan.", "サーバー通知を有効にしました。")
    }
  }

  fun sendMessage() {
    val text = messageText.value.trim()
    val attachment = attachedFile.value
    if (text.isEmpty() && attachment == null) return

    val reply = replyingToMessage.value
    viewModelScope.launch {
      val res = repository.sendMessage(
        channelId = _selectedChannelId.value,
        content = text,
        attachmentUri = attachment?.uri,
        attachmentName = attachment?.fileName,
        attachmentMimeType = attachment?.mimeType,
        attachmentSizeBytes = attachment?.sizeBytes ?: 0L,
        replyToId = reply?.id,
        replyToSnippet = reply?.content?.take(40)
      )
      if (res.isSuccess) {
        SoundEffectsEngine.play(SoundEffectType.MESSAGE_SENT)
        messageText.value = ""
        attachedFile.value = null
        replyingToMessage.value = null
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message
      }
    }
  }

  fun sendVideo7sMessage(videoFile: java.io.File, durationMs: Long, caption: String = "") {
    if (durationMs > VideoTrimHelper.MAX_VIDEO_DURATION_MS) {
      feedbackMessage.value = trCode(activeLanguageCode.value, "Video duration cannot exceed 7 seconds!", "Durasi video tidak boleh lebih dari 7 detik!", "Tempoh video tidak boleh melebihi 7 saat!", "動画の長さは7秒以内にしてください！")
      return
    }
    viewModelScope.launch {
      isUploadingMedia.value = true
      try {
        val picked = PickedFileInfo(
          uri = "file://${videoFile.absolutePath}",
          fileName = videoFile.name,
          mimeType = "video/mp4",
          sizeBytes = videoFile.length()
        )
        val uploaded = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
          CloudMediaHelper.uploadPickedFile(getApplication(), picked)
        }
        val res = repository.sendMessage(
          channelId = _selectedChannelId.value,
          content = caption.ifBlank { "🎬 Video (${durationMs / 1000.0}s)" },
          attachmentUri = uploaded.uri,
          attachmentName = uploaded.fileName,
          attachmentMimeType = "video/mp4",
          attachmentSizeBytes = uploaded.sizeBytes,
          attachmentDurationMs = durationMs
        )
        if (res.isSuccess) SoundEffectsEngine.play(SoundEffectType.MESSAGE_SENT)
        else feedbackMessage.value = res.exceptionOrNull()?.message
      } finally {
        isUploadingMedia.value = false
      }
    }
  }

  fun sendVideo7sDm(videoFile: java.io.File, durationMs: Long, caption: String = "") {
    if (durationMs > VideoTrimHelper.MAX_VIDEO_DURATION_MS) {
      feedbackMessage.value = trCode(activeLanguageCode.value, "Video duration cannot exceed 7 seconds!", "Durasi video tidak boleh lebih dari 7 detik!", "Tempoh video tidak boleh melebihi 7 saat!", "動画の長さは7秒以内にしてください！")
      return
    }
    val user = currentUser.value ?: return
    val otherId = _activeDmUserId.value ?: return
    val convId = if (user.id < otherId) "dm_${user.id}_$otherId" else "dm_${otherId}_${user.id}"
    viewModelScope.launch {
      isUploadingMedia.value = true
      try {
        val picked = PickedFileInfo(
          uri = "file://${videoFile.absolutePath}",
          fileName = videoFile.name,
          mimeType = "video/mp4",
          sizeBytes = videoFile.length()
        )
        val uploaded = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
          CloudMediaHelper.uploadPickedFile(getApplication(), picked)
        }
        val res = repository.sendDirectMessage(
          conversationId = convId,
          receiverId = otherId,
          content = caption.ifBlank { "🎬 Video (${durationMs / 1000.0}s)" },
          attachmentUri = uploaded.uri,
          attachmentName = uploaded.fileName,
          attachmentMimeType = "video/mp4",
          attachmentSizeBytes = uploaded.sizeBytes,
          attachmentDurationMs = durationMs
        )
        if (res.isSuccess) SoundEffectsEngine.play(SoundEffectType.MESSAGE_SENT)
      } finally {
        isUploadingMedia.value = false
      }
    }
  }

  fun sendStickerMessage(sticker: StickerEntity) {
    viewModelScope.launch {
      repository.sendMessage(
        channelId = _selectedChannelId.value,
        content = sticker.overlayText.ifBlank { sticker.name },
        attachmentUri = sticker.imageUri,
        attachmentName = sticker.name,
        attachmentMimeType = "image/png",
        stickerId = sticker.id
      )
      SoundEffectsEngine.play(SoundEffectType.MESSAGE_SENT)
    }
  }

  fun sendStickerDm(sticker: StickerEntity) {
    val user = currentUser.value ?: return
    val otherId = _activeDmUserId.value ?: return
    val convId = if (user.id < otherId) "dm_${user.id}_$otherId" else "dm_${otherId}_${user.id}"
    viewModelScope.launch {
      repository.sendDirectMessage(
        conversationId = convId,
        receiverId = otherId,
        content = sticker.overlayText.ifBlank { sticker.name },
        attachmentUri = sticker.imageUri,
        attachmentName = sticker.name,
        attachmentMimeType = "image/png",
        stickerId = sticker.id
      )
      SoundEffectsEngine.play(SoundEffectType.MESSAGE_SENT)
    }
  }

  fun sendGifMessage(gif: GifResultItem) {
    viewModelScope.launch {
      repository.saveGifRecord(gif.gifUrl, gif.previewUrl, gif.title, gif.category, isFavorite = false, isRecent = true)
      repository.sendMessage(
        channelId = _selectedChannelId.value,
        content = gif.title,
        attachmentUri = gif.gifUrl,
        attachmentName = "${gif.title}.gif",
        attachmentMimeType = "image/gif"
      )
      SoundEffectsEngine.play(SoundEffectType.MESSAGE_SENT)
    }
  }

  fun sendGifDm(gif: GifResultItem) {
    val user = currentUser.value ?: return
    val otherId = _activeDmUserId.value ?: return
    val convId = if (user.id < otherId) "dm_${user.id}_$otherId" else "dm_${otherId}_${user.id}"
    viewModelScope.launch {
      repository.saveGifRecord(gif.gifUrl, gif.previewUrl, gif.title, gif.category, isFavorite = false, isRecent = true)
      repository.sendDirectMessage(
        conversationId = convId,
        receiverId = otherId,
        content = gif.title,
        attachmentUri = gif.gifUrl,
        attachmentName = "${gif.title}.gif",
        attachmentMimeType = "image/gif"
      )
      SoundEffectsEngine.play(SoundEffectType.MESSAGE_SENT)
    }
  }

  fun sendLocationMessage(lat: Double, lng: Double, label: String, liveMinutes: Int = 0) {
    val liveUntil = if (liveMinutes > 0) System.currentTimeMillis() + (liveMinutes * 60_000L) else 0L
    viewModelScope.launch {
      repository.sendMessage(
        channelId = _selectedChannelId.value,
        content = "📍 Location: $label",
        locationLat = lat,
        locationLng = lng,
        locationLabel = label,
        locationLiveUntil = liveUntil
      )
      SoundEffectsEngine.play(SoundEffectType.MESSAGE_SENT)
    }
  }

  fun sendLocationDm(lat: Double, lng: Double, label: String, liveMinutes: Int = 0) {
    val user = currentUser.value ?: return
    val otherId = _activeDmUserId.value ?: return
    val convId = if (user.id < otherId) "dm_${user.id}_$otherId" else "dm_${otherId}_${user.id}"
    val liveUntil = if (liveMinutes > 0) System.currentTimeMillis() + (liveMinutes * 60_000L) else 0L
    viewModelScope.launch {
      repository.sendDirectMessage(
        conversationId = convId,
        receiverId = otherId,
        content = "📍 Location: $label",
        locationLat = lat,
        locationLng = lng,
        locationLabel = label,
        locationLiveUntil = liveUntil
      )
      SoundEffectsEngine.play(SoundEffectType.MESSAGE_SENT)
    }
  }

  fun forwardMessageToChannel(msg: MessageEntity, targetChannelId: String) {
    viewModelScope.launch {
      repository.sendMessage(
        channelId = targetChannelId,
        content = msg.content,
        attachmentUri = msg.attachmentUri,
        attachmentName = msg.attachmentName,
        attachmentMimeType = msg.attachmentMimeType,
        attachmentSizeBytes = msg.attachmentSizeBytes,
        attachmentDurationMs = msg.attachmentDurationMs,
        forwardedFromId = msg.senderId,
        forwardedFromName = msg.senderName,
        locationLat = msg.locationLat,
        locationLng = msg.locationLng,
        locationLabel = msg.locationLabel,
        stickerId = msg.stickerId
      )
      SoundEffectsEngine.play(SoundEffectType.MESSAGE_SENT)
      feedbackMessage.value = trCode(activeLanguageCode.value, "Message forwarded!", "Pesan berhasil diteruskan!", "Mesej berjaya dimajukan!", "メッセージを転送しました！")
    }
  }

  fun forwardMessageToDm(content: String, senderId: String, senderName: String, receiverId: String, attachmentUri: String? = null, attachmentName: String? = null, attachmentMimeType: String? = null) {
    val me = currentUser.value ?: return
    val convId = if (me.id < receiverId) "dm_${me.id}_$receiverId" else "dm_${receiverId}_${me.id}"
    viewModelScope.launch {
      repository.sendDirectMessage(
        conversationId = convId,
        receiverId = receiverId,
        content = content,
        attachmentUri = attachmentUri,
        attachmentName = attachmentName,
        attachmentMimeType = attachmentMimeType,
        forwardedFromId = senderId,
        forwardedFromName = senderName
      )
      SoundEffectsEngine.play(SoundEffectType.MESSAGE_SENT)
      feedbackMessage.value = trCode(activeLanguageCode.value, "Forwarded to DM!", "Pesan berhasil diteruskan ke DM!", "Berjaya dimajukan ke DM!", "DMに転送しました！")
    }
  }

  fun sendDm(content: String, attachment: PickedFileInfo? = null, replyToId: String? = null, replyToSnippet: String? = null) {
    val user = currentUser.value ?: return
    val otherId = _activeDmUserId.value ?: return
    val convId = if (user.id < otherId) "dm_${user.id}_$otherId" else "dm_${otherId}_${user.id}"
    viewModelScope.launch {
      val res = repository.sendDirectMessage(
        conversationId = convId,
        receiverId = otherId,
        content = content,
        attachmentUri = attachment?.uri,
        attachmentName = attachment?.fileName,
        attachmentMimeType = attachment?.mimeType,
        attachmentSizeBytes = attachment?.sizeBytes ?: 0L,
        replyToId = replyToId,
        replyToSnippet = replyToSnippet
      )
      if (res.isSuccess) SoundEffectsEngine.play(SoundEffectType.MESSAGE_SENT)
    }
  }

  fun editDm(dmId: String, newContent: String) {
    viewModelScope.launch {
      repository.editDirectMessage(dmId, newContent)
      feedbackMessage.value = trCode(activeLanguageCode.value, "DM updated", "DM diperbarui", "DM dikemas kini", "DMを更新しました")
    }
  }

  fun deleteDm(dmId: String) {
    viewModelScope.launch {
      repository.deleteDirectMessage(dmId)
      feedbackMessage.value = trCode(activeLanguageCode.value, "DM deleted", "DM dihapus", "DM dipadam", "DMを削除しました")
    }
  }

  fun reactDm(dmId: String, emojiKey: String) {
    viewModelScope.launch { repository.addDmReaction(dmId, emojiKey) }
  }

  fun addReaction(messageId: String, reactionType: String) {
    viewModelScope.launch {
      repository.addReaction(messageId, reactionType)
    }
  }

  fun deleteMessage(messageId: String) {
    viewModelScope.launch {
      repository.deleteMessage(messageId)
      feedbackMessage.value = trCode(activeLanguageCode.value, "Message deleted", "Pesan berhasil dihapus", "Mesej berjaya dipadam", "メッセージを削除しました")
    }
  }

  fun editMessage(messageId: String, newContent: String) {
    viewModelScope.launch {
      repository.editMessage(messageId, newContent)
      feedbackMessage.value = trCode(activeLanguageCode.value, "Message updated", "Pesan berhasil diedit", "Mesej berjaya disunting", "メッセージを編集しました")
    }
  }

  fun claimQuestReward(questId: String) {
    viewModelScope.launch {
      val res = repository.claimQuestReward(questId)
      feedbackMessage.value = if (res.isSuccess) {
        trCode(activeLanguageCode.value, "Claimed +${res.getOrNull()} XIT!", "Berhasil klaim +${res.getOrNull()} XIT!", "Berjaya tuntut +${res.getOrNull()} XIT!", "+${res.getOrNull()} XIT を受け取りました！")
      } else {
        res.exceptionOrNull()?.message ?: trCode(activeLanguageCode.value, "Failed to claim reward", "Gagal klaim hadiah", "Gagal menuntut ganjaran", "報酬の受け取りに失敗しました")
      }
    }
  }

  fun togglePin(messageId: String) {
    viewModelScope.launch {
      repository.togglePinMessage(messageId)
      feedbackMessage.value = trCode(activeLanguageCode.value, "Pin status updated", "Status sematan diperbarui", "Status sematan dikemas kini", "ピン留め状態を更新しました")
    }
  }

  fun performSearch(query: String) {
    searchQuery.value = query
    if (query.isBlank()) {
      searchResults.value = emptyList()
      return
    }
    viewModelScope.launch {
      searchResults.value = repository.searchMessages(_selectedChannelId.value, query)
    }
  }

  // Forums
  fun openForumPost(postId: String?) {
    _activeForumPostId.value = postId
  }

  fun createForumPost(
    channelId: String,
    title: String,
    content: String,
    imageUri: String?,
    tagLabel: String,
    tagEmoji: String,
    isPinned: Boolean = false,
    onDone: () -> Unit = {}
  ) {
    viewModelScope.launch {
      val res = repository.createForumPost(channelId, title, content, imageUri, tagLabel, tagEmoji, isPinned)
      if (res.isSuccess) {
        feedbackMessage.value = trCode(activeLanguageCode.value, "Forum thread '$title' created!", "Thread forum '$title' berhasil dibuat!", "Utas forum '$title' berjaya dicipta!", "フォーラムスレッド「$title」を作成しました！")
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message ?: trCode(activeLanguageCode.value, "Failed to create thread", "Gagal membuat thread", "Gagal mencipta utas", "スレッド作成に失敗しました")
      }
    }
  }

  fun toggleForumReaction(post: ForumPostEntity) {
    viewModelScope.launch {
      repository.toggleForumPostReaction(post)
    }
  }

  fun addForumReply(channelId: String, postId: String, content: String, onDone: () -> Unit = {}) {
    viewModelScope.launch {
      val res = repository.addForumReply(channelId, postId, content)
      if (res.isSuccess) {
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message ?: trCode(activeLanguageCode.value, "Failed to send reply", "Gagal mengirim balasan", "Gagal menghantar balasan", "返信の送信に失敗しました")
      }
    }
  }

  // Voice & WebRTC Bilateral Calls + Diagnostics
  fun joinVoiceChannel(channelId: String, channelName: String) {
    val srvId = _selectedServerId.value
    val myId = currentUser.value?.id ?: return
    _voiceState.value = VoiceState(
      isInVoice = true,
      serverId = srvId,
      channelId = channelId,
      channelName = channelName
    )
    ScreenShareBus.startMicLevelMonitor(getApplication()) { _voiceState.value.isMuted || _voiceState.value.isDeafened }
    WebRtcCallManager.joinServerVoiceMesh(
      context = getApplication(),
      serverId = srvId,
      channelId = channelId,
      channelName = channelName,
      myId = myId,
      participantIds = voiceParticipants.value.map { it.userId }
    )
    syncVoiceParticipantNow()
    voiceHeartbeatJob?.cancel()
    voiceHeartbeatJob = viewModelScope.launch {
      repository.notifyVoiceUsedQuest()
      while (isActive && _voiceState.value.isInVoice) {
        syncVoiceParticipantNow()
        delay(4_000L)
      }
    }
    feedbackMessage.value = trCode(activeLanguageCode.value, "Joined voice channel $channelName", "Bergabung ke ruang suara $channelName", "Menyertai saluran suara $channelName", "ボイスチャンネル $channelName に参加しました")
  }

  private fun syncVoiceParticipantNow() {
    val vs = _voiceState.value
    if (!vs.isInVoice || vs.serverId.isBlank() || vs.channelId.isBlank()) return
    val speaking = !vs.isMuted && !vs.isDeafened && ScreenShareBus.micLevel.value > 0.14f
    viewModelScope.launch {
      repository.joinOrUpdateVoiceParticipant(
        serverId = vs.serverId,
        channelId = vs.channelId,
        isMuted = vs.isMuted,
        isDeafened = vs.isDeafened,
        isCameraOn = vs.isCameraOn,
        isScreenSharing = vs.isScreenSharing,
        isSpeaking = speaking,
        audioQuality = rtcCallState.value.qualityLabel
      )
    }
  }

  fun leaveVoice() {
    val prev = _voiceState.value
    voiceHeartbeatJob?.cancel()
    voiceHeartbeatJob = null
    ScreenShareBus.stopMicLevelMonitor()
    if (rtcCallState.value.callType == "SERVER_VOICE") {
      WebRtcCallManager.cleanupAllPeers()
    }
    if (prev.isScreenSharing) {
      VoiceMediaForegroundService.stopScreenShare(getApplication())
    }
    _voiceState.value = VoiceState(isInVoice = false)
    if (prev.serverId.isNotBlank() && prev.channelId.isNotBlank()) {
      viewModelScope.launch {
        repository.leaveVoiceParticipant(prev.serverId, prev.channelId)
      }
    }
    feedbackMessage.value = trCode(activeLanguageCode.value, "Left voice channel", "Meninggalkan kanal suara", "Meninggalkan saluran suara", "ボイスチャンネルから退出しました")
  }

  fun toggleMute() {
    val next = !_voiceState.value.isMuted
    _voiceState.value = _voiceState.value.copy(isMuted = next)
    WebRtcCallManager.setMuted(next)
    syncVoiceParticipantNow()
  }

  fun toggleDeafen() {
    val cur = _voiceState.value
    val nextDeafen = !cur.isDeafened
    _voiceState.value = cur.copy(isDeafened = nextDeafen, isMuted = nextDeafen)
    WebRtcCallManager.setDeafened(nextDeafen)
    WebRtcCallManager.setMuted(nextDeafen)
    syncVoiceParticipantNow()
  }

  fun setCameraActive(enabled: Boolean) {
    _voiceState.value = _voiceState.value.copy(isCameraOn = enabled)
    WebRtcCallManager.setCameraEnabled(getApplication(), enabled)
    syncVoiceParticipantNow()
  }

  fun toggleCamera() {
    setCameraActive(!_voiceState.value.isCameraOn)
  }

  fun setScreenSharingActive(enabled: Boolean) {
    _voiceState.value = _voiceState.value.copy(isScreenSharing = enabled)
    if (!enabled) {
      VoiceMediaForegroundService.stopScreenShare(getApplication())
    }
    syncVoiceParticipantNow()
  }

  fun toggleScreenShare() {
    setScreenSharingActive(!_voiceState.value.isScreenSharing)
  }

  fun playSoundboard(soundId: String, soundName: String) {
    _voiceState.value = _voiceState.value.copy(lastSoundTriggered = soundName)
    ScreenShareBus.playSoundboardCue(soundId)
    feedbackMessage.value = trCode(activeLanguageCode.value, "Playing sound: $soundName", "Memutar suara: $soundName", "Memainkan bunyi: $soundName", "効果音を再生中: $soundName")
  }

  // 1:1 Bilateral WebRTC DM Voice & Video Calls
  fun startDmCall(peerUser: UserEntity, isVideo: Boolean) {
    val me = currentUser.value ?: return
    WebRtcCallManager.startOutgoingDmCall(
      context = getApplication(),
      callerId = me.id,
      callerName = me.displayName,
      callerAvatarUri = me.avatarUri,
      calleeId = peerUser.id,
      calleeName = peerUser.displayName,
      isVideo = isVideo
    )
    viewModelScope.launch { repository.notifyVoiceUsedQuest() }
  }

  fun acceptIncomingCall() {
    val myId = currentUser.value?.id ?: return
    WebRtcCallManager.acceptIncomingDmCall(getApplication(), myId)
  }

  fun declineOrEndDmCall() {
    WebRtcCallManager.declineOrEndCall(getApplication())
  }

  fun toggleCallMute() {
    WebRtcCallManager.setMuted(!rtcCallState.value.isMuted)
  }

  fun toggleCallSpeaker() {
    WebRtcCallManager.setSpeakerphone(getApplication(), !rtcCallState.value.isSpeakerOn)
  }

  fun toggleCallCamera() {
    WebRtcCallManager.setCameraEnabled(getApplication(), !rtcCallState.value.isCameraOn)
  }

  fun toggleMicLoopbackTest() {
    WebRtcCallManager.toggleMicLoopbackTest(getApplication())
  }

  fun playSpeakerTestTone() {
    WebRtcCallManager.playSpeakerDiagnosticsTone()
  }

  // Saved Profile Themes (Equip / Unequip / Delete)
  fun saveCurrentProfileTheme(name: String, onDone: () -> Unit = {}) {
    viewModelScope.launch {
      val res = repository.saveCurrentProfileTheme(name)
      if (res.isSuccess) {
        feedbackMessage.value = trCode(activeLanguageCode.value, "Profile theme '${res.getOrThrow().name}' saved & equipped!", "Tema profil '${res.getOrThrow().name}' berhasil disimpan & dipasang!", "Tema profil '${res.getOrThrow().name}' berjaya disimpan & dipasang!", "プロフィールテーマ「${res.getOrThrow().name}」を保存＆装備しました！")
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message ?: trCode(activeLanguageCode.value, "Failed to save theme", "Gagal menyimpan tema", "Gagal menyimpan tema", "テーマの保存に失敗しました")
      }
    }
  }

  fun equipSavedProfileTheme(themeId: String) {
    viewModelScope.launch {
      val res = repository.equipSavedProfileTheme(themeId)
      feedbackMessage.value = if (res.isSuccess) {
        trCode(activeLanguageCode.value, "Profile theme equipped!", "Tema profil berhasil dipasang!", "Tema profil berjaya dipasang!", "プロフィールテーマを装備しました！")
      } else {
        res.exceptionOrNull()?.message ?: trCode(activeLanguageCode.value, "Failed to equip theme", "Gagal memasang tema", "Gagal memasang tema", "テーマの装備に失敗しました")
      }
    }
  }

  fun unequipSavedProfileTheme() {
    viewModelScope.launch {
      repository.unequipSavedProfileTheme()
      feedbackMessage.value = trCode(activeLanguageCode.value, "Profile theme unequipped.", "Tema profil dilepas, kembali ke gaya standar.", "Tema profil ditanggalkan.", "プロフィールテーマを外しました。")
    }
  }

  fun deleteSavedProfileTheme(theme: SavedProfileThemeEntity) {
    viewModelScope.launch {
      repository.deleteSavedProfileTheme(theme)
      feedbackMessage.value = trCode(activeLanguageCode.value, "Theme '${theme.name}' deleted.", "Tema '${theme.name}' dihapus.", "Tema '${theme.name}' dipadam.", "テーマ「${theme.name}」を削除しました。")
    }
  }

  // Profile Connections & Live Activity
  fun addOrVerifyConnection(platformId: String, handle: String, onDone: () -> Unit = {}) {
    if (handle.isBlank()) {
      feedbackMessage.value = trCode(activeLanguageCode.value, "Username / account ID cannot be empty.", "Username / ID akun tidak boleh kosong.", "Nama pengguna / ID akaun tidak boleh kosong.", "ユーザー名 / アカウントIDを入力してください。")
      return
    }
    viewModelScope.launch {
      val verified = AppActivityTracker.verifyAndBuildConnection(platformId, handle)
      val currentList = AppActivityTracker.parseConnections(currentUser.value?.connectionsJson).toMutableList()
      currentList.removeAll { it.platformId == platformId }
      currentList.add(verified)
      repository.updateUserConnections(AppActivityTracker.serializeConnections(currentList))
      feedbackMessage.value = if (verified.verified) {
        trCode(activeLanguageCode.value, "${verified.platformName} (@${verified.handle}) verified!", "Koneksi ${verified.platformName} (@${verified.handle}) terverifikasi!", "Sambungan ${verified.platformName} (@${verified.handle}) disahkan!", "${verified.platformName} (@${verified.handle}) を連携・認証しました！")
      } else {
        trCode(activeLanguageCode.value, "${verified.platformName} (@${verified.handle}) added!", "Koneksi ${verified.platformName} (@${verified.handle}) ditambahkan!", "Sambungan ${verified.platformName} (@${verified.handle}) ditambah!", "${verified.platformName} (@${verified.handle}) を追加しました！")
      }
      onDone()
    }
  }

  fun removeConnection(platformId: String) {
    viewModelScope.launch {
      val currentList = AppActivityTracker.parseConnections(currentUser.value?.connectionsJson)
        .filterNot { it.platformId == platformId }
      repository.updateUserConnections(AppActivityTracker.serializeConnections(currentList))
      feedbackMessage.value = trCode(activeLanguageCode.value, "Connection removed.", "Koneksi dihapus.", "Sambungan dipadam.", "連携を解除しました。")
    }
  }

  // Security & App Lock PIN
  fun setAppPin(pin: String): Boolean {
    if (pin.length !in 4..6 || !pin.all { it.isDigit() }) {
      feedbackMessage.value = trCode(activeLanguageCode.value, "PIN must be 4–6 digits.", "PIN harus berupa 4–6 digit angka.", "PIN mestilah 4–6 digit nombor.", "PINは4〜6桁の数字にしてください。")
      return false
    }
    repository.setAppLockPin(pin)
    _hasAppPin.value = true
    _isAppLocked.value = false
    feedbackMessage.value = trCode(activeLanguageCode.value, "XChat security PIN enabled!", "PIN Keamanan XChat aktif!", "PIN Keselamatan XChat diaktifkan!", "XChatセキュリティPINを有効にしました！")
    return true
  }

  fun unlockWithPin(pin: String): Boolean {
    val ok = repository.verifyAppLockPin(pin)
    if (ok) _isAppLocked.value = false
    return ok
  }

  fun clearAppPin() {
    repository.clearAppLockPin()
    _hasAppPin.value = false
    _isAppLocked.value = false
    feedbackMessage.value = trCode(activeLanguageCode.value, "App Lock PIN disabled.", "PIN Kunci Aplikasi dinonaktifkan.", "PIN Kunci Aplikasi dinyahaktifkan.", "アプリロックPINを無効にしました。")
  }

  fun updateAccountPassword(newPassword: String, onDone: () -> Unit = {}) {
    if (newPassword.length < 8) {
      feedbackMessage.value = trCode(activeLanguageCode.value, "Password must be at least 8 characters.", "Kata sandi minimal 8 karakter.", "Kata laluan minimum 8 aksara.", "パスワードは8文字以上にしてください。")
      return
    }
    val user = Firebase.auth.currentUser
    if (user == null) {
      feedbackMessage.value = trCode(activeLanguageCode.value, "Please sign in first.", "Harus masuk akun terlebih dahulu.", "Sila log masuk dahulu.", "先にログインしてください。")
      return
    }
    viewModelScope.launch {
      try {
        user.updatePassword(newPassword).await()
        feedbackMessage.value = trCode(activeLanguageCode.value, "Account password updated!", "Kata sandi akun berhasil diperbarui!", "Kata laluan berjaya dikemas kini!", "パスワードを更新しました！")
        onDone()
      } catch (e: Exception) {
        val email = user.email
        if (!email.isNullOrBlank()) {
          runCatching { Firebase.auth.sendPasswordResetEmail(email).await() }
          feedbackMessage.value = trCode(activeLanguageCode.value, "Password reset link sent to $email.", "Link atur ulang kata sandi telah dikirim ke $email.", "Pautan tetapan semula kata laluan dihantar ke $email.", "$email 宛にパスワード再設定リンクを送信しました。")
        } else {
          feedbackMessage.value = e.localizedMessage ?: trCode(activeLanguageCode.value, "Failed to update password.", "Gagal memperbarui kata sandi.", "Gagal mengemas kini kata laluan.", "パスワードの更新に失敗しました。")
        }
      }
    }
  }

  fun sendPasswordResetEmail() {
    val email = Firebase.auth.currentUser?.email ?: currentUser.value?.email
    if (email.isNullOrBlank()) {
      feedbackMessage.value = trCode(activeLanguageCode.value, "Account email not found.", "Email akun tidak ditemukan.", "Emel akaun tidak dijumpai.", "アカウントのメールアドレスが見つかりません。")
      return
    }
    viewModelScope.launch {
      try {
        Firebase.auth.sendPasswordResetEmail(email).await()
        feedbackMessage.value = trCode(activeLanguageCode.value, "Password reset email sent to $email.", "Email reset kata sandi dikirim ke $email.", "Emel tetapan semula kata laluan dihantar ke $email.", "$email に再設定メールを送信しました。")
      } catch (e: Exception) {
        feedbackMessage.value = e.localizedMessage ?: trCode(activeLanguageCode.value, "Failed to send reset email.", "Gagal mengirim email reset.", "Gagal menghantar emel tetapan semula.", "再設定メールの送信に失敗しました。")
      }
    }
  }

  // Profile & Presence
  fun updateProfile(
    displayName: String,
    bio: String,
    pronouns: String,
    avatarUri: String?,
    bannerUri: String?,
    profileColor: Long,
    bubbleStyle: String,
    displayNameFont: String,
    displayNameColorsCsv: String,
    displayNameEffect: String,
    profileBgColorsCsv: String,
    equippedBadges: String? = null,
    presenceStatus: String? = null,
    statusTag: String? = null,
    equippedEffect: String? = null
  ) {
    viewModelScope.launch {
      repository.updateProfile(
        displayName = displayName,
        bio = bio,
        pronouns = pronouns,
        avatarUri = avatarUri,
        bannerUri = bannerUri,
        profileColor = profileColor,
        bubbleStyle = bubbleStyle,
        displayNameFont = displayNameFont,
        displayNameColorsCsv = displayNameColorsCsv,
        displayNameEffect = displayNameEffect,
        profileBgColorsCsv = profileBgColorsCsv,
        equippedBadges = equippedBadges,
        presenceStatus = presenceStatus,
        statusTag = statusTag,
        equippedEffect = equippedEffect
      )
      feedbackMessage.value = trCode(activeLanguageCode.value, "Profile & style saved!", "Profil & gaya berhasil disimpan secara real-time!", "Profil & gaya berjaya disimpan!", "プロフィールとスタイルを保存しました！")
    }
  }

  fun updatePresence(presenceStatus: String, statusTag: String) {
    viewModelScope.launch {
      repository.sendPresenceHeartbeat(status = presenceStatus, statusTag = statusTag)
      feedbackMessage.value = "${trCode(activeLanguageCode.value, "Presence updated", "Status kehadiran diperbarui", "Status kehadiran dikemas kini", "ステータスを更新しました")}: $presenceStatus"
    }
  }

  fun openUserProfile(userId: String) {
    viewModelScope.launch {
      val user = repository.getUserById(userId)
      _inspectedProfileUser.value = user
      if (user != null) {
        repository.recordProfileVisit(user.id)
      }
    }
  }

  fun closeUserProfile() {
    _inspectedProfileUser.value = null
  }

  fun startDmWithUser(userId: String) {
    viewModelScope.launch {
      repository.ensureFriendForDm(userId)
      _activeDmUserId.value = userId
      _openDmThreadSignal.value = System.currentTimeMillis()
      _inspectedProfileUser.value = null
      _activeTab.value = MainTab.DMS
    }
  }

  fun unlockOwnerDashboard(keyInput: String): Boolean {
    val expectedHash = "ce0f6602acd6389de048bd0d20e65b74c08f669af0a1b1112c8a88534829944a"
    val digest = MessageDigest.getInstance("SHA-256")
      .digest(keyInput.trim().toByteArray(Charsets.UTF_8))
      .joinToString("") { "%02x".format(it) }
    val matched = MessageDigest.isEqual(digest.toByteArray(), expectedHash.toByteArray())
    if (matched) {
      _isOwnerDashboardUnlocked.value = true
      _verifiedAdminRole.value = "OWNER"
      repository.saveOwnerKeyUnlocked(true)
      viewModelScope.launch {
        repository.registerOwnerInCloud(keyInput.trim())
      }
    }
    return matched
  }

  fun toggleFloatingAdminPanel() {
    SoundEffectsEngine.play(SoundEffectType.POPUP)
    _isFloatingAdminOpen.value = !_isFloatingAdminOpen.value
  }

  fun lockOwnerDashboard() {
    _isOwnerDashboardUnlocked.value = false
    repository.saveOwnerKeyUnlocked(false)
  }

  fun logout() {
    stopCloudSync()
    WebRtcCallManager.cleanupAllPeers()
    typingSendJob?.cancel()
    typingClearJob?.cancel()
    boundUid = null
    _profileSyncError.value = null
    _isOwnerDashboardUnlocked.value = false
    _verifiedAdminRole.value = "NONE"
    _isFloatingAdminOpen.value = false
    repository.saveOwnerKeyUnlocked(false)
    repository.setCurrentUserId(null)
    _currentScreen.value = ScreenDestination.Landing
  }

  // Server management
  fun createServer(
    name: String,
    desc: String,
    serverType: String,
    serverTag: String,
    serverGenre: String,
    supportedGame: String?,
    customInviteCode: String?,
    onDone: () -> Unit
  ) {
    viewModelScope.launch {
      val res = repository.createServer(
        name = name,
        description = desc,
        serverType = serverType,
        serverTag = serverTag,
        serverGenre = serverGenre,
        supportedGame = supportedGame,
        customInviteCode = customInviteCode
      )
      if (res.isSuccess) {
        val srv = res.getOrThrow()
        _selectedServerId.value = srv.id
        repository.saveSelectedServerId(srv.id)
        feedbackMessage.value = trCode(activeLanguageCode.value, "Server '$name' created!", "Server '$name' berhasil dibuat!", "Pelayan '$name' berjaya dicipta!", "サーバー「$name」を作成しました！")
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message
      }
    }
  }

  fun joinServer(code: String, onDone: () -> Unit) {
    viewModelScope.launch {
      val res = repository.joinServerByInviteCode(code)
      if (res.isSuccess) {
        val s = res.getOrThrow()
        _selectedServerId.value = s.id
        repository.saveSelectedServerId(s.id)
        feedbackMessage.value = trCode(activeLanguageCode.value, "Joined ${s.name}!", "Berhasil bergabung ke ${s.name}!", "Berjaya menyertai ${s.name}!", "${s.name} に参加しました！")
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message
      }
    }
  }

  fun createCategory(serverId: String, name: String, onDone: () -> Unit = {}) {
    viewModelScope.launch {
      val res = repository.createCategory(serverId, name)
      if (res.isSuccess) {
        feedbackMessage.value = trCode(activeLanguageCode.value, "Category '${res.getOrThrow().name}' created!", "Kategori '${res.getOrThrow().name}' dibuat!", "Kategori '${res.getOrThrow().name}' dicipta!", "カテゴリー「${res.getOrThrow().name}」を作成しました！")
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message
      }
    }
  }

  fun toggleCategoryCollapsed(category: ChannelCategoryEntity) {
    viewModelScope.launch {
      repository.updateCategory(category.copy(isCollapsed = !category.isCollapsed))
    }
  }

  fun deleteCategory(category: ChannelCategoryEntity) {
    viewModelScope.launch {
      repository.deleteCategory(category)
      feedbackMessage.value = trCode(activeLanguageCode.value, "Category '${category.name}' deleted.", "Kategori '${category.name}' dihapus.", "Kategori '${category.name}' dipadam.", "カテゴリー「${category.name}」を削除しました。")
    }
  }

  fun moveChannelToCategory(channel: ChannelEntity, newCategoryId: String) {
    viewModelScope.launch {
      repository.moveChannelToCategory(channel, newCategoryId)
      feedbackMessage.value = trCode(activeLanguageCode.value, "Channel #${channel.name} moved.", "Kanal #${channel.name} dipindahkan.", "Saluran #${channel.name} dialihkan.", "#${channel.name} を移動しました。")
    }
  }

  fun toggleServerVanish(serverId: String, vanish: Boolean) {
    viewModelScope.launch {
      val res = repository.toggleServerVanish(serverId, vanish)
      feedbackMessage.value = if (res.isSuccess) {
        if (vanish) {
          trCode(activeLanguageCode.value, "Vanish Server ON!", "Mode Vanish Server AKTIF!", "Mod Vanish Pelayan AKTIF!", "サーバー非表示モード ON！")
        } else {
          trCode(activeLanguageCode.value, "Vanish Server OFF.", "Mode Vanish Server dinonaktifkan.", "Mod Vanish Pelayan dimatikan.", "サーバー非表示モード OFF。")
        }
      } else {
        res.exceptionOrNull()?.message
      }
    }
  }

  fun createChannel(serverId: String, name: String, description: String, type: String, categoryId: String = "", onDone: () -> Unit = {}) {
    viewModelScope.launch {
      val res = repository.createChannel(serverId, name, description, type, categoryId)
      if (res.isSuccess) {
        val ch = res.getOrThrow()
        if (ch.type != "voice") {
          _selectedChannelId.value = ch.id
          repository.saveSelectedChannelId(ch.id)
        }
        feedbackMessage.value = trCode(activeLanguageCode.value, "Channel '${ch.name}' ($type) created!", "Kanal '${ch.name}' ($type) berhasil dibuat!", "Saluran '${ch.name}' ($type) dicipta!", "チャンネル「${ch.name}」を作成しました！")
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message ?: trCode(activeLanguageCode.value, "Failed to create channel", "Gagal membuat kanal", "Gagal mencipta saluran", "チャンネル作成に失敗しました")
      }
    }
  }

  fun updateServerAppearance(
    serverId: String,
    name: String,
    description: String,
    iconUri: String?,
    bannerUri: String?,
    serverTag: String? = null,
    serverTagIcon: String? = null,
    supportedGame: String? = null,
    onDone: () -> Unit = {}
  ) {
    viewModelScope.launch {
      val res = repository.updateServerAppearance(
        serverId = serverId,
        name = name,
        description = description,
        iconUri = iconUri,
        bannerUri = bannerUri,
        serverTag = serverTag,
        serverTagIcon = serverTagIcon,
        supportedGame = supportedGame
      )
      if (res.isSuccess) {
        feedbackMessage.value = trCode(activeLanguageCode.value, "Server settings saved!", "Tampilan & info server berhasil disimpan!", "Tetapan pelayan disimpan!", "サーバー設定を保存しました！")
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message ?: trCode(activeLanguageCode.value, "Failed to update server", "Gagal memperbarui server", "Gagal mengemas kini pelayan", "サーバーの更新に失敗しました")
      }
    }
  }

  fun boostServer(serverId: String) {
    viewModelScope.launch {
      val res = repository.boostServer(serverId)
      if (res.isSuccess) {
        val s = res.getOrThrow()
        feedbackMessage.value = "Server '${s.name}' Boosted! (Total: ${s.boostCount} Boosts • Level ${s.boostLevel})"
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message ?: trCode(activeLanguageCode.value, "Failed to boost server", "Gagal boost server", "Gagal boost pelayan", "ブーストに失敗しました")
      }
    }
  }

  fun createOrUpdateServerRole(
    serverId: String,
    roleId: String? = null,
    name: String,
    colorHex: Long,
    iconUri: String? = null,
    chromaKeyColorsCsv: String = "",
    permissionsCsv: String,
    onDone: () -> Unit = {}
  ) {
    viewModelScope.launch {
      val res = repository.createOrUpdateServerRole(
        serverId = serverId,
        roleId = roleId,
        name = name,
        colorHex = colorHex,
        iconUri = iconUri,
        chromaKeyColorsCsv = chromaKeyColorsCsv,
        permissionsCsv = permissionsCsv
      )
      if (res.isSuccess) {
        feedbackMessage.value = if (roleId == null) {
          trCode(activeLanguageCode.value, "Role '$name' created!", "Role '$name' berhasil dibuat!", "Peranan '$name' dicipta!", "ロール「$name」を作成しました！")
        } else {
          trCode(activeLanguageCode.value, "Role '$name' updated!", "Role '$name' diperbarui!", "Peranan '$name' dikemas kini!", "ロール「$name」を更新しました！")
        }
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message ?: trCode(activeLanguageCode.value, "Failed to save role", "Gagal menyimpan role", "Gagal menyimpan peranan", "ロールの保存に失敗しました")
      }
    }
  }

  fun createServerRole(serverId: String, name: String, colorHex: Long, permissionsCsv: String, onDone: () -> Unit = {}) {
    createOrUpdateServerRole(serverId, null, name, colorHex, null, "", permissionsCsv, onDone)
  }

  fun deleteServerRole(role: ServerRoleEntity) {
    viewModelScope.launch {
      repository.deleteServerRole(role)
      feedbackMessage.value = trCode(activeLanguageCode.value, "Role '${role.name}' deleted", "Role '${role.name}' dihapus", "Peranan '${role.name}' dipadam", "ロール「${role.name}」を削除しました")
    }
  }

  fun assignRoleToUser(serverId: String, userId: String, role: ServerRoleEntity) {
    viewModelScope.launch {
      repository.assignRoleToUser(serverId, userId, role)
      feedbackMessage.value = trCode(activeLanguageCode.value, "Role '${role.name}' assigned!", "Role '${role.name}' diterapkan!", "Peranan '${role.name}' diberikan!", "ロール「${role.name}」を付与しました！")
    }
  }

  // Indonesian payment submission (088212365499)
  fun submitPayment(tier: String, senderName: String, senderAccount: String, slipUri: String?, onDone: () -> Unit) {
    viewModelScope.launch {
      val res = repository.submitPaymentRequest(tier, senderName, senderAccount, slipUri)
      if (res.isSuccess) {
        feedbackMessage.value = trCode(activeLanguageCode.value, "Payment proof submitted! Waiting for Owner verification.", "Bukti pembayaran berhasil dikirim! Menunggu verifikasi Owner.", "Bukti bayaran dihantar! Menunggu pengesahan Pemilik.", "支払い証明を送信しました！オーナー確認待ちです。")
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message
      }
    }
  }

  // Owner Actions
  fun approvePayment(req: PaymentRequestEntity) {
    viewModelScope.launch {
      repository.approvePaymentRequest(req)
      feedbackMessage.value = if (req.targetTier == "BOOST_7") {
        trCode(activeLanguageCode.value, "@${req.username} approved! +7 Server Boosts added.", "Pembayaran @${req.username} disetujui! +7 Server Boost ditambahkan.", "Bayaran @${req.username} diluluskan! +7 Server Boost ditambah.", "@${req.username} の支払いを承認し、7ブーストを付与しました。")
      } else {
        trCode(activeLanguageCode.value, "@${req.username} approved! ${req.targetTier} is active.", "Pembayaran @${req.username} disetujui! Tier ${req.targetTier} aktif.", "Bayaran @${req.username} diluluskan! Tier ${req.targetTier} aktif.", "@${req.username} の支払いを承認し、${req.targetTier} を有効化しました。")
      }
    }
  }

  fun rejectPayment(req: PaymentRequestEntity) {
    viewModelScope.launch {
      repository.rejectPaymentRequest(req)
      feedbackMessage.value = trCode(activeLanguageCode.value, "@${req.username} payment rejected.", "Pembayaran @${req.username} ditolak.", "Bayaran @${req.username} ditolak.", "@${req.username} の支払いを却下しました。")
    }
  }

  fun grantXit(userId: String, amount: Long) {
    viewModelScope.launch {
      repository.grantXit(userId, amount)
      feedbackMessage.value = trCode(activeLanguageCode.value, "Granted +$amount XIT!", "Berhasil memberikan $amount XIT", "Berjaya memberi $amount XIT", "+$amount XIT を付与しました")
    }
  }

  fun grantBoosts(userId: String, amount: Int) {
    viewModelScope.launch {
      repository.grantBoosts(userId, amount)
      feedbackMessage.value = trCode(activeLanguageCode.value, "Granted +$amount Server Boosts!", "Berhasil memberikan +$amount Server Boost", "Berjaya memberi +$amount Server Boost", "+$amount サーバーブーストを付与しました")
    }
  }

  fun grantSubscription(userId: String, tier: String) {
    viewModelScope.launch {
      repository.grantSubscription(userId, tier)
      feedbackMessage.value = "Subscription tier updated to $tier"
    }
  }

  fun toggleBan(userId: String, isBanned: Boolean) {
    viewModelScope.launch {
      repository.toggleBanUser(userId, isBanned)
      feedbackMessage.value = "Account status updated"
    }
  }

  fun toggleInvisibleInServer(serverId: String) {
    viewModelScope.launch {
      val res = repository.toggleInvisibleInServer(serverId)
      if (res.isSuccess) {
        val inv = res.getOrThrow()
        feedbackMessage.value = if (inv) "Invisible mode ON for this server." else "Invisible mode OFF for this server."
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message
      }
    }
  }

  fun deleteUserAccount(userId: String, onDone: () -> Unit = {}) {
    viewModelScope.launch {
      val res = repository.deleteUserAccount(userId)
      if (res.isSuccess) {
        feedbackMessage.value = "Account deleted."
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message
      }
    }
  }

  fun updateUserBadges(userId: String, badgesCsv: String) {
    viewModelScope.launch {
      repository.updateUserBadges(userId, badgesCsv)
      feedbackMessage.value = "User badges updated!"
    }
  }

  fun grantBadgeByUsername(username: String, badgeId: String, onDone: () -> Unit = {}) {
    viewModelScope.launch {
      val res = repository.grantBadgeByUsername(username, badgeId)
      if (res.isSuccess) {
        val u = res.getOrThrow()
        val bName = BadgeCatalog.getBadge(badgeId)?.name ?: badgeId
        feedbackMessage.value = "Badge '$bName' granted to @${u.username}!"
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message ?: "Failed to grant badge"
      }
    }
  }

  fun grantAllBadgesByUsername(username: String, onDone: () -> Unit = {}) {
    viewModelScope.launch {
      val allIds = BadgeCatalog.badges.map { it.id }
      val target = username.trim().ifBlank { "@self" }
      val res = repository.grantAllBadgesByUsername(target, allIds)
      if (res.isSuccess) {
        val u = res.getOrThrow()
        feedbackMessage.value = "ALL badges (${allIds.size}) unlocked & granted to @${u.username}!"
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message ?: "Failed to grant all badges"
      }
    }
  }

  fun grantAllBadgesToSelf(onDone: () -> Unit = {}) {
    grantAllBadgesByUsername("@self", onDone)
  }

  fun broadcastAnnouncement(title: String, message: String, onDone: () -> Unit) {
    viewModelScope.launch {
      repository.broadcastAnnouncement(title, message)
      feedbackMessage.value = "Announcement broadcast to all servers!"
      onDone()
    }
  }

  fun buyItem(item: MarketplaceItemEntity) {
    viewModelScope.launch {
      val res = repository.buyMarketplaceItem(item)
      feedbackMessage.value = if (res.isSuccess) "Purchased ${item.name}!" else res.exceptionOrNull()?.message
    }
  }

  fun equipItem(itemId: String, category: String) {
    viewModelScope.launch {
      repository.equipItem(itemId, category)
      feedbackMessage.value = "Equipped to profile!"
    }
  }

  fun unequipItem(itemId: String, category: String) {
    viewModelScope.launch {
      repository.unequipItem(itemId, category)
      feedbackMessage.value = "Unequipped from profile!"
    }
  }

  fun addFriend(username: String, onDone: () -> Unit) {
    viewModelScope.launch {
      val res = repository.addFriendByUsername(username)
      if (res.isSuccess) {
        SoundEffectsEngine.play(SoundEffectType.FRIEND_REQUEST)
        feedbackMessage.value = trCode(activeLanguageCode.value, "Added @$username as a friend!", "Berhasil menambahkan @$username sebagai teman!", "Berjaya menambah @$username sebagai rakan!", "@$username をフレンドに追加しました！")
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message
      }
    }
  }

  fun transferXit(recipient: String, amount: Long, onDone: () -> Unit) {
    viewModelScope.launch {
      val res = repository.transferXit(recipient, amount)
      if (res.isSuccess) {
        feedbackMessage.value = trCode(activeLanguageCode.value, "Transferred $amount XIT to @$recipient!", "Berhasil mentransfer $amount XIT ke @$recipient!", "Berjaya memindahkan $amount XIT ke @$recipient!", "@$recipient に $amount XIT を送金しました！")
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message
      }
    }
  }

  // ==================== V2.0 SOCIAL, MEDIA, MUSIC, GAMES, MODERATION & SEARCH ====================

  fun toggleFollowUser(targetUserId: String) {
    viewModelScope.launch {
      val res = repository.toggleFollowUser(targetUserId)
      if (res.isSuccess) {
        SoundEffectsEngine.play(SoundEffectType.BUTTON)
        feedbackMessage.value = if (res.getOrThrow()) {
          trCode(activeLanguageCode.value, "Following user!", "Berhasil mengikuti pengguna!", "Berjaya mengikuti pengguna!", "フォローしました！")
        } else {
          trCode(activeLanguageCode.value, "Unfollowed user.", "Berhenti mengikuti pengguna.", "Berhenti mengikuti pengguna.", "フォロー解除しました。")
        }
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message
      }
    }
  }

  fun saveGameApp(item: UserGameAppEntity, onDone: () -> Unit = {}) {
    viewModelScope.launch {
      repository.saveUserGameApp(item)
      feedbackMessage.value = trCode(activeLanguageCode.value, "${item.name} saved to profile!", "${item.name} disimpan ke profil!", "${item.name} disimpan ke profil!", "${item.name} をプロフィールに保存しました！")
      onDone()
    }
  }

  fun deleteGameApp(item: UserGameAppEntity) {
    viewModelScope.launch {
      repository.deleteUserGameApp(item)
      feedbackMessage.value = trCode(activeLanguageCode.value, "${item.name} removed.", "${item.name} dihapus dari profil.", "${item.name} dipadam dari profil.", "${item.name} を削除しました。")
    }
  }

  fun swapGameAppOrder(first: UserGameAppEntity, second: UserGameAppEntity) {
    viewModelScope.launch { repository.swapUserGameAppOrder(first, second) }
  }

  // Stickers & GIFs
  fun saveCustomSticker(
    name: String,
    packName: String,
    imageUri: String,
    overlayText: String,
    textColorHex: Long,
    outlineColorHex: Long,
    hasGlow: Boolean,
    hasShadow: Boolean,
    isShared: Boolean = true,
    onDone: () -> Unit = {}
  ) {
    viewModelScope.launch {
      val res = repository.saveCustomSticker(name, packName, imageUri, overlayText, textColorHex, outlineColorHex, hasGlow, hasShadow, isShared)
      if (res.isSuccess) {
        SoundEffectsEngine.play(SoundEffectType.POPUP)
        feedbackMessage.value = trCode(activeLanguageCode.value, "Sticker '${res.getOrThrow().name}' saved!", "Sticker '${res.getOrThrow().name}' tersimpan ke koleksi!", "Pelekat '${res.getOrThrow().name}' disimpan!", "スタンプ「${res.getOrThrow().name}」を保存しました！")
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message
      }
    }
  }

  fun toggleStickerFavorite(sticker: StickerEntity) {
    viewModelScope.launch { repository.toggleStickerFavorite(sticker) }
  }

  fun deleteSticker(sticker: StickerEntity) {
    viewModelScope.launch { repository.deleteSticker(sticker) }
  }

  fun searchGifs(query: String, category: String = "Trending") {
    viewModelScope.launch {
      isSearchingGifs.value = true
      try {
        gifSearchResults.value = GifSearchClient.search(query, category)
      } finally {
        isSearchingGifs.value = false
      }
    }
  }

  fun toggleGifFavorite(gif: GifResultItem) {
    viewModelScope.launch {
      val existing = gifFavorites.value.firstOrNull { it.gifUrl == gif.gifUrl }
      val nextFav = !(existing?.isFavorite ?: false)
      repository.saveGifRecord(gif.gifUrl, gif.previewUrl, gif.title, gif.category, isFavorite = nextFav, isRecent = existing?.isRecent ?: false)
      feedbackMessage.value = if (nextFav) {
        trCode(activeLanguageCode.value, "GIF added to Favorites", "GIF ditambahkan ke Favorit", "GIF ditambah ke Kegemaran", "GIFをお気に入りに追加しました")
      } else {
        trCode(activeLanguageCode.value, "GIF removed from Favorites", "GIF dihapus dari Favorit", "GIF dibuang daripada Kegemaran", "GIFをお気に入りから削除しました")
      }
    }
  }

  // Music Player & Playlists
  fun selectPlaylist(playlistId: String) {
    _selectedPlaylistId.value = playlistId
  }

  fun createPlaylist(name: String, onDone: () -> Unit = {}) {
    viewModelScope.launch {
      val res = repository.createPlaylist(name)
      if (res.isSuccess) {
        _selectedPlaylistId.value = res.getOrThrow().id
        feedbackMessage.value = trCode(activeLanguageCode.value, "Playlist '${res.getOrThrow().name}' created!", "Playlist '${res.getOrThrow().name}' dibuat!", "Senarai main '${res.getOrThrow().name}' dicipta!", "プレイリスト「${res.getOrThrow().name}」を作成しました！")
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message
      }
    }
  }

  fun renamePlaylist(playlist: PlaylistEntity, newName: String) {
    viewModelScope.launch { repository.renamePlaylist(playlist, newName) }
  }

  fun deletePlaylist(playlist: PlaylistEntity) {
    viewModelScope.launch { repository.deletePlaylist(playlist) }
  }

  fun addTrackToPlaylist(
    playlistId: String,
    title: String,
    artist: String,
    sourceUri: String,
    sourceType: String,
    coverUri: String? = null,
    durationMs: Long = 0L,
    autoPlay: Boolean = false,
    onDone: () -> Unit = {}
  ) {
    viewModelScope.launch {
      val res = repository.addTrackToPlaylist(playlistId, title, artist, sourceUri, sourceType, coverUri, durationMs)
      if (res.isSuccess) {
        val added = res.getOrThrow()
        _selectedPlaylistId.value = added.playlistId
        if (autoPlay) {
          AudioPlayerManager.playSingleTrack(getApplication(), added)
        }
        feedbackMessage.value = "Track '${added.title}' added to playlist!"
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message
      }
    }
  }

  fun deleteTrack(track: AudioTrackEntity) {
    viewModelScope.launch { repository.deleteTrack(track) }
  }

  fun swapTrackOrder(first: AudioTrackEntity, second: AudioTrackEntity) {
    viewModelScope.launch { repository.swapTrackOrder(first, second) }
  }

  fun playPlaylist(tracks: List<AudioTrackEntity>, startIndex: Int = 0) {
    AudioPlayerManager.playPlaylist(getApplication(), tracks, startIndex)
  }

  fun playSingleTrack(track: AudioTrackEntity) {
    AudioPlayerManager.playSingleTrack(getApplication(), track)
  }

  fun toggleMusicPlayPause() {
    AudioPlayerManager.togglePlayPause(getApplication())
  }

  fun nextMusicTrack() {
    AudioPlayerManager.nextTrack(getApplication())
  }

  fun prevMusicTrack() {
    AudioPlayerManager.previousTrack(getApplication())
  }

  fun seekMusicTo(posMs: Long) {
    AudioPlayerManager.seekTo(posMs)
  }

  fun setMusicVolume(vol: Float) {
    AudioPlayerManager.setVolume(vol)
  }

  fun toggleMusicShuffle() {
    AudioPlayerManager.toggleShuffle()
  }

  fun cycleMusicRepeat() {
    AudioPlayerManager.cycleRepeatMode()
  }

  fun openExternalMusicService(track: AudioTrackEntity) {
    AudioPlayerManager.openExternalOfficialService(getApplication(), track)
  }

  fun setListeningPrivacy(privacy: String) {
    val cur = audioState.value
    viewModelScope.launch {
      repository.updateListeningStatus(
        title = cur.currentTrack?.title,
        artist = cur.currentTrack?.artist,
        coverUri = cur.currentTrack?.coverUri,
        sourceUrl = cur.currentTrack?.sourceUri,
        isPlaying = cur.isPlaying,
        privacy = privacy
      )
      feedbackMessage.value = "${trCode(activeLanguageCode.value, "Listening privacy", "Privasi Status Mendengarkan", "Privasi Status Mendengar", "リスニング公開範囲")}: $privacy"
    }
  }

  // Mini Games & Tournaments
  fun openMatch(matchId: String?) {
    _activeMatchId.value = matchId
    if (matchId != null) _activeTab.value = MainTab.GAMES
  }

  fun createGameMatch(
    gameType: String,
    mode: String,
    opponentId: String,
    channelOrConvId: String,
    isDm: Boolean,
    tournamentId: String? = null,
    onDone: (GameMatchEntity) -> Unit = {}
  ) {
    viewModelScope.launch {
      val res = repository.createGameMatch(gameType, mode, opponentId, channelOrConvId, isDm, tournamentId)
      if (res.isSuccess) {
        val m = res.getOrThrow()
        SoundEffectsEngine.play(SoundEffectType.GAME_INVITE)
        _activeMatchId.value = m.id
        feedbackMessage.value = trCode(activeLanguageCode.value, "$gameType ($mode) invite sent!", "Undangan $gameType ($mode) dikirim!", "Jemputan $gameType ($mode) dihantar!", "$gameType ($mode) の招待を送信しました！")
        onDone(m)
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message
      }
    }
  }

  fun acceptGameMatch(matchId: String) {
    viewModelScope.launch {
      val res = repository.acceptGameMatch(matchId)
      if (res.isSuccess) {
        SoundEffectsEngine.play(SoundEffectType.BUTTON)
        _activeMatchId.value = matchId
        _activeTab.value = MainTab.GAMES
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message
      }
    }
  }

  fun declineGameMatch(matchId: String) {
    viewModelScope.launch {
      repository.declineGameMatch(matchId)
      if (_activeMatchId.value == matchId) _activeMatchId.value = null
    }
  }

  fun submitGameMove(matchId: String, moveIndexOrCol: Int, chessToIdx: Int = -1, chessPromotion: Char = 'Q') {
    viewModelScope.launch {
      val res = repository.submitGameMove(matchId, moveIndexOrCol, chessToIdx, chessPromotion)
      if (res.isSuccess) {
        SoundEffectsEngine.play(SoundEffectType.BUTTON)
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message
      }
    }
  }

  fun resignGameMatch(matchId: String) {
    viewModelScope.launch {
      repository.resignGameMatch(matchId)
      feedbackMessage.value = trCode(activeLanguageCode.value, "You resigned the match.", "Anda menyerah pada pertandingan ini.", "Anda menyerah kalah.", "投了しました。")
    }
  }

  fun offerOrAcceptDraw(matchId: String) {
    viewModelScope.launch {
      repository.offerOrAcceptDraw(matchId)
      feedbackMessage.value = trCode(activeLanguageCode.value, "Draw offer sent / accepted.", "Permintaan seri (Draw) dikirim / diterima.", "Tawaran seri dihantar / diterima.", "引き分けを提案・承諾しました。")
    }
  }

  fun createTournament(name: String, gameType: String, onDone: () -> Unit = {}) {
    viewModelScope.launch {
      val res = repository.createTournament(name, gameType)
      if (res.isSuccess) {
        feedbackMessage.value = trCode(activeLanguageCode.value, "Tournament '${res.getOrThrow().name}' created!", "Turnamen '${res.getOrThrow().name}' dibuat!", "Kejohanan '${res.getOrThrow().name}' dicipta!", "トーナメント「${res.getOrThrow().name}」を作成しました！")
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message
      }
    }
  }

  fun joinTournament(tournamentId: String) {
    viewModelScope.launch {
      val res = repository.joinTournament(tournamentId)
      feedbackMessage.value = if (res.isSuccess) {
        trCode(activeLanguageCode.value, "Joined tournament!", "Berhasil bergabung ke turnamen!", "Berjaya menyertai kejohanan!", "トーナメントに参加しました！")
      } else {
        res.exceptionOrNull()?.message
      }
    }
  }

  // Redeem Codes, Lock Screen Restrictions, Reports, Admin Roles, Global Search & Notifications
  fun redeemCode(code: String, onDone: () -> Unit = {}) {
    viewModelScope.launch {
      val res = repository.redeemCode(code)
      if (res.isSuccess) {
        SoundEffectsEngine.play(SoundEffectType.POPUP)
        feedbackMessage.value = res.getOrThrow()
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message
      }
    }
  }

  fun createRedeemCode(code: String, rewardXit: Long, rewardBoosts: Int, maxUses: Int, onDone: () -> Unit = {}) {
    viewModelScope.launch {
      val res = repository.createRedeemCode(code, rewardXit, rewardBoosts, maxUses)
      if (res.isSuccess) {
        feedbackMessage.value = trCode(activeLanguageCode.value, "Redeem code ${res.getOrThrow().code} created!", "Kode redeem ${res.getOrThrow().code} dibuat!", "Kod tebus ${res.getOrThrow().code} dicipta!", "引き換えコード ${res.getOrThrow().code} を作成しました！")
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message
      }
    }
  }

  fun assignAdminRole(targetUserId: String, role: String) {
    viewModelScope.launch {
      repository.assignAdminRole(targetUserId, role)
      feedbackMessage.value = "${trCode(activeLanguageCode.value, "Admin role updated to", "Role admin diperbarui menjadi", "Peranan admin dikemas kini kepada", "管理者ロールを更新しました:")} $role"
    }
  }

  fun applyUserRestriction(targetUserId: String, reason: String, customMessage: String, durationMinutes: Long, onDone: () -> Unit = {}) {
    viewModelScope.launch {
      val res = repository.applyUserRestriction(targetUserId, reason, customMessage, durationMinutes)
      if (res.isSuccess) {
        feedbackMessage.value = trCode(activeLanguageCode.value, "XChat Lock applied for $durationMinutes min.", "XChat Lock Screen diterapkan selama $durationMinutes menit.", "Skrin Kunci XChat dikenakan selama $durationMinutes minit.", "XChatロックを $durationMinutes 分間適用しました。")
        onDone()
      } else {
        feedbackMessage.value = res.exceptionOrNull()?.message
      }
    }
  }

  fun liftRestriction(restriction: UserRestrictionEntity, approve: Boolean = true) {
    viewModelScope.launch {
      repository.liftRestriction(restriction, approve)
      feedbackMessage.value = if (approve) {
        trCode(activeLanguageCode.value, "Restriction lifted / appeal approved.", "Pembatasan dicabut / banding disetujui.", "Sekatan dibatalkan / rayuan diluluskan.", "制限を解除しました。")
      } else {
        trCode(activeLanguageCode.value, "Appeal rejected.", "Banding ditolak.", "Rayuan ditolak.", "異議申し立てを却下しました。")
      }
    }
  }

  fun submitRestrictionAppeal(restriction: UserRestrictionEntity, message: String) {
    viewModelScope.launch {
      repository.submitRestrictionAppeal(restriction, message)
      feedbackMessage.value = trCode(activeLanguageCode.value, "Appeal sent to XChat Admin team.", "Banding Anda telah dikirim ke tim Admin XChat.", "Rayuan dihantar kepada pasukan Admin XChat.", "異議申し立てをXChat管理者に送信しました。")
    }
  }

  fun submitReport(targetUserId: String?, targetServerId: String?, targetMessageId: String?, reason: String, details: String, onDone: () -> Unit = {}) {
    viewModelScope.launch {
      repository.submitReport(targetUserId, targetServerId, targetMessageId, reason, details)
      feedbackMessage.value = trCode(activeLanguageCode.value, "Report submitted to moderation queue.", "Laporan terkirim ke antrean moderasi Admin.", "Laporan dihantar ke barisan semakan.", "通報をモデレーションキューに送信しました。")
      onDone()
    }
  }

  fun resolveReport(report: ReportEntity, status: String, note: String) {
    viewModelScope.launch {
      repository.resolveReport(report, status, note)
      feedbackMessage.value = "Laporan ditandai $status."
    }
  }

  fun markAllNotificationsRead() {
    val uid = currentUser.value?.id ?: return
    viewModelScope.launch { repository.markAllNotificationsRead(uid) }
  }

  fun performGlobalSearch(query: String) {
    globalSearchQuery.value = query
    viewModelScope.launch {
      globalSearchResult.value = repository.globalSearch(query)
    }
  }

  override fun onCleared() {
    super.onCleared()
    stopCloudSync()
    voiceHeartbeatJob?.cancel()
  }
}
