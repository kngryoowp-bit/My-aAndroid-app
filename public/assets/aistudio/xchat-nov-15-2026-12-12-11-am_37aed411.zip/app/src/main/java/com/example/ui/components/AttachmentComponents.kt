package com.example.ui.components

import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.widget.VideoView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.ui.theme.LocalStrings
import com.example.ui.theme.tr
import com.example.utils.CloudMediaHelper
import com.example.utils.MediaStorageHelper
import kotlinx.coroutines.launch

@Composable
fun MessageAttachmentView(
  uri: String,
  fileName: String?,
  mimeType: String?,
  sizeBytes: Long,
  onDownload: () -> Unit,
  onOpen: () -> Unit,
  modifier: Modifier = Modifier,
  attachmentDurationMs: Long = 0L,
  stickerId: String? = null,
  locationLat: Double? = null,
  locationLng: Double? = null,
  locationLabel: String? = null,
  locationLiveUntil: Long = 0L
) {
  val context = LocalContext.current
  val strings = LocalStrings.current
  val scope = rememberCoroutineScope()
  val isLocation = locationLat != null && locationLng != null
  val isSticker = !stickerId.isNullOrBlank() || mimeType?.equals("image/x-xchat-sticker", ignoreCase = true) == true
  val isImage = !isLocation && (isSticker || MediaStorageHelper.isImageAttachment(mimeType, fileName, uri))
  val isVideo = !isLocation && !isSticker && MediaStorageHelper.isVideoAttachment(mimeType, fileName, uri)
  val displayName = remember(uri, fileName) {
    fileName?.takeIf { it.isNotBlank() }
      ?: Uri.parse(uri).lastPathSegment?.substringAfter('_', "attachment")
      ?: "attachment"
  }
  val ext = remember(displayName) {
    displayName.substringAfterLast('.', "").uppercase().takeIf { it.isNotBlank() && it.length <= 6 } ?: "FILE"
  }

  var showImageLightbox by remember { mutableStateOf(false) }
  var isVideoPlayingInline by remember { mutableStateOf(false) }
  var isVideoFullscreen by remember { mutableStateOf(false) }
  var isVideoMuted by remember { mutableStateOf(false) }
  var isPreparingVideo by remember { mutableStateOf(false) }
  var localVideoPath by remember(uri) { mutableStateOf<String?>(null) }

  if (isLocation && locationLat != null && locationLng != null) {
    val isLiveActive = locationLiveUntil > System.currentTimeMillis()
    val coordsText = String.format(java.util.Locale.US, "%.5f, %.5f", locationLat, locationLng)
    Surface(
      modifier = modifier.fillMaxWidth(),
      shape = RoundedCornerShape(12.dp),
      color = Color(0xFF10151F).copy(alpha = 0.85f),
      border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.45f)),
      onClick = {
        val labelEnc = Uri.encode(locationLabel?.ifBlank { "XChat Location" } ?: "XChat Location")
        val geoUri = Uri.parse("geo:$locationLat,$locationLng?q=$locationLat,$locationLng($labelEnc)")
        val intent = Intent(Intent.ACTION_VIEW, geoUri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
      }
    ) {
      Row(
        modifier = Modifier.padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Box(
          modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(Color(0xFF0EA5E9).copy(alpha = 0.22f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Filled.LocationOn, contentDescription = tr("Location", "Lokasi", "Lokasi", "位置情報"), tint = Color(0xFF38BDF8), modifier = Modifier.size(24.dp))
        }
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
              text = locationLabel?.takeIf { it.isNotBlank() } ?: tr("Shared Location", "Lokasi Dibagikan", "Lokasi Dikongsi", "共有された位置情報"),
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            if (isLiveActive) {
              Surface(shape = RoundedCornerShape(4.dp), color = Color(0xFF10B981).copy(alpha = 0.22f)) {
                Text("LIVE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF34D399), modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp))
              }
            }
          }
          Text(coordsText, fontSize = 11.sp, color = Color.White.copy(alpha = 0.72f))
          Text(tr("Tap to open in Maps", "Ketuk untuk buka di Peta", "Ketik untuk buka di Peta", "タップしてマップで開く"), fontSize = 10.sp, color = Color(0xFF38BDF8), fontWeight = FontWeight.SemiBold)
        }
        Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = tr("Open Map", "Buka Peta", "Buka Peta", "マップを開く"), tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
      }
    }
    return
  }

  if (isSticker) {
    val stickerReq = remember(uri) {
      val resolved = CloudMediaHelper.resolveCoilModel(uri, context)
      ImageRequest.Builder(context).data(resolved).allowHardware(false).crossfade(false).build()
    }
    Box(
      modifier = modifier
        .size(144.dp)
        .clip(RoundedCornerShape(14.dp))
        .clickable { showImageLightbox = true },
      contentAlignment = Alignment.Center
    ) {
      AsyncImage(
        model = stickerReq,
        contentDescription = displayName,
        contentScale = ContentScale.Fit,
        modifier = Modifier.fillMaxSize().padding(4.dp)
      )
    }
    if (showImageLightbox) {
      Dialog(
        onDismissRequest = { showImageLightbox = false },
        properties = DialogProperties(usePlatformDefaultWidth = false)
      ) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.92f)).clickable { showImageLightbox = false }, contentAlignment = Alignment.Center) {
          AsyncImage(model = stickerReq, contentDescription = displayName, contentScale = ContentScale.Fit, modifier = Modifier.size(280.dp))
        }
      }
    }
    return
  }

  if (isImage) {
    val attRequest = remember(uri) {
      val resolved = CloudMediaHelper.resolveCoilModel(uri, context)
      ImageRequest.Builder(context)
        .data(resolved)
        .crossfade(false)
        .build()
    }
    Box(
      modifier = modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(10.dp))
        .background(Color(0xFF16171C))
        .clickable { showImageLightbox = true }
    ) {
      AsyncImage(
        model = attRequest,
        contentDescription = displayName,
        modifier = Modifier
          .fillMaxWidth()
          .heightIn(min = 120.dp, max = 240.dp)
          .clip(RoundedCornerShape(10.dp)),
        contentScale = ContentScale.Crop
      )
      Row(
        modifier = Modifier
          .align(Alignment.TopEnd)
          .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        IconButton(
          onClick = { showImageLightbox = true },
          modifier = Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.68f))
        ) {
          Icon(Icons.Filled.Fullscreen, contentDescription = tr("Expand", "Perbesar", "Besarkan", "拡大"), tint = Color.White, modifier = Modifier.size(18.dp))
        }
        IconButton(
          onClick = onDownload,
          modifier = Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.68f))
        ) {
          Icon(Icons.Filled.Download, contentDescription = strings.downloadBtn, tint = Color.White, modifier = Modifier.size(18.dp))
        }
      }
    }

    if (showImageLightbox) {
      Dialog(
        onDismissRequest = { showImageLightbox = false },
        properties = DialogProperties(usePlatformDefaultWidth = false)
      ) {
        var scale by remember { mutableFloatStateOf(1f) }
        var offset by remember { mutableStateOf(Offset.Zero) }

        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.96f))
        ) {
          AsyncImage(
            model = attRequest,
            contentDescription = displayName,
            contentScale = ContentScale.Fit,
            modifier = Modifier
              .fillMaxSize()
              .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                  val newScale = (scale * zoom).coerceIn(1f, 4f)
                  scale = newScale
                  offset = if (newScale > 1f) offset + pan else Offset.Zero
                }
              }
              .graphicsLayer(
                scaleX = scale,
                scaleY = scale,
                translationX = offset.x,
                translationY = offset.y
              )
          )

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .align(Alignment.TopCenter)
              .background(Color.Black.copy(alpha = 0.6f))
              .statusBarsPadding()
              .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = displayName,
              color = Color.White,
              fontSize = 14.sp,
              fontWeight = FontWeight.SemiBold,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
              modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onDownload) {
              Icon(Icons.Filled.Download, contentDescription = strings.downloadBtn, tint = Color.White)
            }
            IconButton(onClick = { showImageLightbox = false }) {
              Icon(Icons.Filled.Close, contentDescription = strings.close, tint = Color.White)
            }
          }
        }
      }
    }
  } else if (isVideo) {
    fun launchInlineVideo(openFullscreen: Boolean) {
      if (localVideoPath != null) {
        isVideoPlayingInline = true
        if (openFullscreen) isVideoFullscreen = true
      } else {
        scope.launch {
          isPreparingVideo = true
          val cached = CloudMediaHelper.ensureLocalCachedFile(context, uri, displayName).getOrNull()
          localVideoPath = cached?.absolutePath ?: CloudMediaHelper.normalizeCloudUrl(uri)
          isPreparingVideo = false
          isVideoPlayingInline = true
          if (openFullscreen) isVideoFullscreen = true
        }
      }
    }

    Surface(
      modifier = modifier.fillMaxWidth(),
      shape = RoundedCornerShape(10.dp),
      color = Color(0xFF14151A),
      border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.16f))
    ) {
      Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(190.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color.Black),
          contentAlignment = Alignment.Center
        ) {
          if (isVideoPlayingInline && localVideoPath != null && !isVideoFullscreen) {
            InlineVideoPlayerView(
              sourcePathOrUrl = localVideoPath!!,
              isMuted = isVideoMuted,
              onToggleMute = { isVideoMuted = !isVideoMuted },
              onFullscreen = { isVideoFullscreen = true },
              onClose = { isVideoPlayingInline = false }
            )
          } else {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.Center,
              modifier = Modifier
                .fillMaxSize()
                .clickable { launchInlineVideo(openFullscreen = false) }
            ) {
              if (isPreparingVideo) {
                CircularProgressIndicator(modifier = Modifier.size(32.dp), color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(8.dp))
                Text(tr("Loading video...", "Memuat video...", "Memuatkan video...", "動画を読み込み中..."), color = Color.White, fontSize = 11.sp)
              } else {
                Box(
                  modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.9f)),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(Icons.Filled.PlayArrow, contentDescription = tr("Play Video", "Putar Video", "Main Video", "動画を再生"), tint = Color.White, modifier = Modifier.size(30.dp))
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  text = displayName,
                  color = Color.White,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Medium,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                  modifier = Modifier.padding(horizontal = 16.dp)
                )
              }
            }
            if (attachmentDurationMs > 0L) {
              Surface(
                modifier = Modifier.align(Alignment.TopStart).padding(8.dp),
                shape = RoundedCornerShape(6.dp),
                color = Color.Black.copy(alpha = 0.72f)
              ) {
                Text(
                  text = String.format(java.util.Locale.US, "%.1fs • ≤7s", attachmentDurationMs / 1000.0),
                  color = Color(0xFF34D399),
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedButton(
            onClick = { launchInlineVideo(openFullscreen = true) },
            modifier = Modifier.weight(1f).height(36.dp),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.3f))
          ) {
            Icon(Icons.Filled.Fullscreen, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(tr("Fullscreen", "Putar Full", "Skrin Penuh", "全画面再生"), fontSize = 11.sp, color = Color.White)
          }
          Button(
            onClick = onDownload,
            modifier = Modifier.weight(1f).height(36.dp),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
          ) {
            Icon(Icons.Filled.Download, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(strings.downloadBtn, fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    if (isVideoFullscreen && localVideoPath != null) {
      Dialog(
        onDismissRequest = { isVideoFullscreen = false },
        properties = DialogProperties(usePlatformDefaultWidth = false)
      ) {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
        ) {
          InlineVideoPlayerView(
            sourcePathOrUrl = localVideoPath!!,
            isMuted = isVideoMuted,
            onToggleMute = { isVideoMuted = !isVideoMuted },
            onFullscreen = null,
            onClose = { isVideoFullscreen = false },
            modifier = Modifier.fillMaxSize()
          )
        }
      }
    }
  } else {
    val icon = when {
      mimeType?.startsWith("audio/") == true || ext in listOf("MP3", "WAV", "OGG", "M4A", "FLAC") -> Icons.Filled.AudioFile
      ext == "PDF" -> Icons.Filled.PictureAsPdf
      ext in listOf("ZIP", "RAR", "7Z", "TAR", "GZ") -> Icons.Filled.FolderZip
      ext == "APK" -> Icons.Filled.Android
      else -> Icons.Filled.InsertDriveFile
    }
    val sizeText = MediaStorageHelper.formatFileSize(sizeBytes)

    Surface(
      modifier = modifier.fillMaxWidth(),
      shape = RoundedCornerShape(10.dp),
      color = Color.Black.copy(alpha = 0.34f),
      border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.16f))
    ) {
      Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.fillMaxWidth()
        ) {
          Box(
            modifier = Modifier
              .size(40.dp)
              .clip(RoundedCornerShape(8.dp))
              .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.24f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = displayName,
              fontSize = 13.sp,
              fontWeight = FontWeight.SemiBold,
              color = Color.White,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            Text(
              text = "$ext • $sizeText",
              fontSize = 11.sp,
              color = Color.White.copy(alpha = 0.72f),
              maxLines = 1
            )
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedButton(
            onClick = onOpen,
            modifier = Modifier.weight(1f).height(36.dp),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.3f))
          ) {
            Icon(
              Icons.AutoMirrored.Filled.OpenInNew,
              contentDescription = null,
              tint = Color.White,
              modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(strings.openBtn, fontSize = 11.sp, color = Color.White)
          }

          Button(
            onClick = onDownload,
            modifier = Modifier.weight(1f).height(36.dp),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
          ) {
            Icon(Icons.Filled.Download, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(strings.downloadBtn, fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
private fun InlineVideoPlayerView(
  sourcePathOrUrl: String,
  isMuted: Boolean,
  onToggleMute: () -> Unit,
  onFullscreen: (() -> Unit)?,
  onClose: () -> Unit,
  modifier: Modifier = Modifier.fillMaxSize()
) {
  var isPaused by remember { mutableStateOf(false) }
  var videoViewRef by remember { mutableStateOf<VideoView?>(null) }
  var mediaPlayerRef by remember { mutableStateOf<MediaPlayer?>(null) }

  LaunchedEffect(isMuted, mediaPlayerRef) {
    try {
      val vol = if (isMuted) 0f else 1f
      mediaPlayerRef?.setVolume(vol, vol)
    } catch (_: Exception) {
    }
  }

  Box(modifier = modifier.background(Color.Black)) {
    AndroidView(
      modifier = Modifier.fillMaxSize(),
      factory = { ctx ->
        VideoView(ctx).apply {
          if (sourcePathOrUrl.startsWith("/")) {
            setVideoPath(sourcePathOrUrl)
          } else {
            setVideoURI(Uri.parse(sourcePathOrUrl))
          }
          setOnPreparedListener { mp ->
            mediaPlayerRef = mp
            mp.isLooping = true
            val vol = if (isMuted) 0f else 1f
            mp.setVolume(vol, vol)
            start()
          }
          videoViewRef = this
        }
      },
      onRelease = { view ->
        runCatching { view.stopPlayback() }
      }
    )

    Row(
      modifier = Modifier
        .align(Alignment.TopEnd)
        .padding(6.dp),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      IconButton(
        onClick = {
          val vv = videoViewRef
          if (vv != null) {
            if (vv.isPlaying) {
              vv.pause()
              isPaused = true
            } else {
              vv.start()
              isPaused = false
            }
          }
        },
        modifier = Modifier
          .size(32.dp)
          .clip(CircleShape)
          .background(Color.Black.copy(alpha = 0.65f))
      ) {
        Icon(
          if (isPaused) Icons.Filled.PlayArrow else Icons.Filled.Pause,
          contentDescription = "Play/Pause",
          tint = Color.White,
          modifier = Modifier.size(18.dp)
        )
      }
      IconButton(
        onClick = onToggleMute,
        modifier = Modifier
          .size(32.dp)
          .clip(CircleShape)
          .background(Color.Black.copy(alpha = 0.65f))
      ) {
        Icon(
          if (isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
          contentDescription = "Mute",
          tint = Color.White,
          modifier = Modifier.size(18.dp)
        )
      }
      if (onFullscreen != null) {
        IconButton(
          onClick = onFullscreen,
          modifier = Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.65f))
        ) {
          Icon(Icons.Filled.Fullscreen, contentDescription = "Fullscreen", tint = Color.White, modifier = Modifier.size(18.dp))
        }
      }
      IconButton(
        onClick = onClose,
        modifier = Modifier
          .size(32.dp)
          .clip(CircleShape)
          .background(Color.Black.copy(alpha = 0.65f))
      ) {
        Icon(Icons.Filled.Close, contentDescription = LocalStrings.current.close, tint = Color.White, modifier = Modifier.size(18.dp))
      }
    }
  }
}
