package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import org.json.JSONObject

data class BadgeDefinition(
  val id: String,
  val name: String,
  val description: String,
  val icon: ImageVector,
  val primaryColor: Color,
  val secondaryColor: Color,
  val rarity: String,
  val unlockCondition: String = "Special XChat Achievement",
  val targetProgress: Int = 1,
  val progressKey: String = id
)

object BadgeCatalog {
  val badges = listOf(
    BadgeDefinition(
      id = "owner",
      name = "Owner & Creator",
      description = "Primary creator and architect of the XChat ecosystem.",
      icon = Icons.Filled.Security,
      primaryColor = Color(0xFF6366F1),
      secondaryColor = Color(0xFF4338CA),
      rarity = "Mythic",
      unlockCondition = "Verify official Owner key"
    ),
    BadgeDefinition(
      id = "astral",
      name = "XChat Astral",
      description = "Highest subscription tier with full customization.",
      icon = Icons.Filled.Diamond,
      primaryColor = Color(0xFFA855F7),
      secondaryColor = Color(0xFF7E22CE),
      rarity = "Legendary",
      unlockCondition = "Subscribe to XChat Astral tier"
    ),
    BadgeDefinition(
      id = "astrix",
      name = "XChat Astrix",
      description = "Supporter tier with enhanced personalization features.",
      icon = Icons.Filled.WorkspacePremium,
      primaryColor = Color(0xFFEAB308),
      secondaryColor = Color(0xFFCA8A04),
      rarity = "Epic",
      unlockCondition = "Subscribe to XChat Astrix tier"
    ),
    BadgeDefinition(
      id = "developer",
      name = "Developer",
      description = "Software engineer and ecosystem contributor.",
      icon = Icons.Filled.Code,
      primaryColor = Color(0xFF0EA5E9),
      secondaryColor = Color(0xFF0284C7),
      rarity = "Rare",
      unlockCondition = "Awarded to developer contributors"
    ),
    BadgeDefinition(
      id = "programmer",
      name = "Programmer",
      description = "Code enthusiast and systems builder.",
      icon = Icons.Filled.Terminal,
      primaryColor = Color(0xFF10B981),
      secondaryColor = Color(0xFF059669),
      rarity = "Rare",
      unlockCondition = "Add a verified GitHub connection"
    ),
    BadgeDefinition(
      id = "early_supporter",
      name = "Early Supporter",
      description = "Pioneer member who joined during the launch era.",
      icon = Icons.Filled.Star,
      primaryColor = Color(0xFFF97316),
      secondaryColor = Color(0xFFEA580C),
      rarity = "Special",
      unlockCondition = "Joined XChat in the early era"
    ),
    BadgeDefinition(
      id = "server_booster",
      name = "Server Booster",
      description = "Empowers servers with dedicated Server Boosts.",
      icon = Icons.Filled.RocketLaunch,
      primaryColor = Color(0xFFEC4899),
      secondaryColor = Color(0xFFDB2777),
      rarity = "Rare",
      unlockCondition = "Boost at least 1 server",
      targetProgress = 1
    ),
    BadgeDefinition(
      id = "xit_claimer",
      name = "XIT Claimer",
      description = "Prolific collector of virtual XIT currency.",
      icon = Icons.Filled.Paid,
      primaryColor = Color(0xFF8B5CF6),
      secondaryColor = Color(0xFF6D28D9),
      rarity = "Uncommon",
      unlockCondition = "Claim at least 3 Quests / Redeem Codes",
      targetProgress = 3
    ),
    BadgeDefinition(
      id = "gamer",
      name = "Gamer",
      description = "Active challenger in XChat mini games.",
      icon = Icons.Filled.SportsEsports,
      primaryColor = Color(0xFF06B6D4),
      secondaryColor = Color(0xFF0891B2),
      rarity = "Common",
      unlockCondition = "Add at least 1 game to My Games & Apps",
      targetProgress = 1
    ),
    BadgeDefinition(
      id = "event_winner",
      name = "Event Winner",
      description = "Champion of official community competitions.",
      icon = Icons.Filled.EmojiEvents,
      primaryColor = Color(0xFFFBBF24),
      secondaryColor = Color(0xFFD97706),
      rarity = "Legendary",
      unlockCondition = "Win a community event"
    ),
    BadgeDefinition(
      id = "community_contributor",
      name = "Community Contributor",
      description = "Helpful community pillar in forum discussions.",
      icon = Icons.Filled.Groups,
      primaryColor = Color(0xFF14B8A6),
      secondaryColor = Color(0xFF0D9488),
      rarity = "Uncommon",
      unlockCondition = "Post 10 replies in Forum channels",
      targetProgress = 10
    ),
    BadgeDefinition(
      id = "early_bird",
      name = "Early Bird",
      description = "Active in chat early in the morning (05:00 - 08:00).",
      icon = Icons.Filled.WbSunny,
      primaryColor = Color(0xFFF59E0B),
      secondaryColor = Color(0xFFD97706),
      rarity = "Common",
      unlockCondition = "Send a message between 05:00–08:00",
      targetProgress = 1
    ),
    BadgeDefinition(
      id = "night_owl",
      name = "Night Owl",
      description = "Active night watch after midnight (00:00 - 04:00).",
      icon = Icons.Filled.DarkMode,
      primaryColor = Color(0xFF334155),
      secondaryColor = Color(0xFF0F172A),
      rarity = "Common",
      unlockCondition = "Send a message between 00:00–04:00",
      targetProgress = 1
    ),
    BadgeDefinition(
      id = "social_butterfly",
      name = "Social Butterfly",
      description = "Built a close circle of friends on XChat.",
      icon = Icons.Filled.Favorite,
      primaryColor = Color(0xFFF43F5E),
      secondaryColor = Color(0xFFBE123C),
      rarity = "Uncommon",
      unlockCondition = "Add 5 friends on XChat",
      targetProgress = 5
    ),
    BadgeDefinition(
      id = "conversation_master",
      name = "Conversation Master",
      description = "Active speaker across channels and DMs.",
      icon = Icons.Filled.Forum,
      primaryColor = Color(0xFF38BDF8),
      secondaryColor = Color(0xFF0284C7),
      rarity = "Rare",
      unlockCondition = "Send a total of 50 messages",
      targetProgress = 50
    ),
    BadgeDefinition(
      id = "community_builder",
      name = "Community Builder",
      description = "Organizes and grows thriving server structures.",
      icon = Icons.Filled.DomainAdd,
      primaryColor = Color(0xFF10B981),
      secondaryColor = Color(0xFF047857),
      rarity = "Rare",
      unlockCondition = "Create 3 channels or categories in a server",
      targetProgress = 3
    ),
    BadgeDefinition(
      id = "server_founder",
      name = "Server Founder",
      description = "Creator of a new community server on XChat.",
      icon = Icons.Filled.Castle,
      primaryColor = Color(0xFF8B5CF6),
      secondaryColor = Color(0xFF5B21B6),
      rarity = "Uncommon",
      unlockCondition = "Create at least 1 new server",
      targetProgress = 1
    ),
    BadgeDefinition(
      id = "first_friend",
      name = "First Friend",
      description = "First connection made on XChat.",
      icon = Icons.Filled.PersonAdd,
      primaryColor = Color(0xFF22C55E),
      secondaryColor = Color(0xFF15803D),
      rarity = "Common",
      unlockCondition = "Add your first friend",
      targetProgress = 1
    ),
    BadgeDefinition(
      id = "popular_member",
      name = "Popular Member",
      description = "Followed by many community members.",
      icon = Icons.Filled.TrendingUp,
      primaryColor = Color(0xFFEC4899),
      secondaryColor = Color(0xFF9D174D),
      rarity = "Epic",
      unlockCondition = "Reach 10 followers",
      targetProgress = 10
    ),
    BadgeDefinition(
      id = "loyal_member",
      name = "Loyal Member",
      description = "Continuously growing and active in XChat.",
      icon = Icons.Filled.VerifiedUser,
      primaryColor = Color(0xFF64748B),
      secondaryColor = Color(0xFF334155),
      rarity = "Uncommon",
      unlockCondition = "Reach Level 5 on your XChat profile",
      targetProgress = 5
    ),
    BadgeDefinition(
      id = "voice_champion",
      name = "Voice Champion",
      description = "Communicates actively in WebRTC voice & video rooms.",
      icon = Icons.Filled.RecordVoiceOver,
      primaryColor = Color(0xFF2DD4BF),
      secondaryColor = Color(0xFF0F766E),
      rarity = "Rare",
      unlockCondition = "Join 3 Voice Room / Call sessions",
      targetProgress = 3
    ),
    BadgeDefinition(
      id = "music_lover",
      name = "Music Lover",
      description = "Shares tracks and curates playlists.",
      icon = Icons.Filled.LibraryMusic,
      primaryColor = Color(0xFF6366F1),
      secondaryColor = Color(0xFF3730A3),
      rarity = "Uncommon",
      unlockCondition = "Play 5 tracks or create 1 playlist",
      targetProgress = 5
    ),
    BadgeDefinition(
      id = "sticker_artist",
      name = "Sticker Artist",
      description = "Creator of expressive custom stickers.",
      icon = Icons.Filled.StickyNote2,
      primaryColor = Color(0xFFF59E0B),
      secondaryColor = Color(0xFFB45309),
      rarity = "Rare",
      unlockCondition = "Create 3 custom stickers in Sticker Studio",
      targetProgress = 3
    ),
    BadgeDefinition(
      id = "gif_collector",
      name = "GIF Collector",
      description = "Collector of favorite GIFs to liven up chats.",
      icon = Icons.Filled.GifBox,
      primaryColor = Color(0xFFA855F7),
      secondaryColor = Color(0xFF6B21A8),
      rarity = "Uncommon",
      unlockCondition = "Favorite or send 5 GIFs",
      targetProgress = 5
    ),
    BadgeDefinition(
      id = "chess_master",
      name = "Chess Master",
      description = "Master tactician on the XChat chess board.",
      icon = Icons.Filled.Extension,
      primaryColor = Color(0xFFE2E8F0),
      secondaryColor = Color(0xFF475569),
      rarity = "Epic",
      unlockCondition = "Win 3 Chess matches",
      targetProgress = 3
    ),
    BadgeDefinition(
      id = "ttt_pro",
      name = "Tic Tac Toe Pro",
      description = "Quick-thinking Tic Tac Toe strategist.",
      icon = Icons.Filled.GridOn,
      primaryColor = Color(0xFF0EA5E9),
      secondaryColor = Color(0xFF0369A1),
      rarity = "Uncommon",
      unlockCondition = "Win 5 Tic Tac Toe matches",
      targetProgress = 5
    ),
    BadgeDefinition(
      id = "tournament_winner",
      name = "Tournament Winner",
      description = "Champion of XChat mini-game tournaments.",
      icon = Icons.Filled.MilitaryTech,
      primaryColor = Color(0xFFFACC15),
      secondaryColor = Color(0xFFA16207),
      rarity = "Legendary",
      unlockCondition = "Win 1 official Tournament",
      targetProgress = 1
    ),
    BadgeDefinition(
      id = "game_explorer",
      name = "Game Explorer",
      description = "Competed across XChat mini games.",
      icon = Icons.Filled.Casino,
      primaryColor = Color(0xFF22D3EE),
      secondaryColor = Color(0xFF0E7490),
      rarity = "Rare",
      unlockCondition = "Play at least 4 mini-game matches",
      targetProgress = 4
    ),
    BadgeDefinition(
      id = "daily_active",
      name = "Daily Active",
      description = "Consistently completes daily quests.",
      icon = Icons.Filled.CheckCircle,
      primaryColor = Color(0xFF4ADE80),
      secondaryColor = Color(0xFF16A34A),
      rarity = "Common",
      unlockCondition = "Complete 2 Daily Quests",
      targetProgress = 2
    ),
    BadgeDefinition(
      id = "veteran",
      name = "Veteran",
      description = "Seasoned member with long-term contributions.",
      icon = Icons.Filled.Shield,
      primaryColor = Color(0xFF94A3B8),
      secondaryColor = Color(0xFF334155),
      rarity = "Epic",
      unlockCondition = "Reach Level 10 on XChat",
      targetProgress = 10
    ),
    BadgeDefinition(
      id = "explorer",
      name = "Explorer",
      description = "Discovers servers and communities across genres.",
      icon = Icons.Filled.Explore,
      primaryColor = Color(0xFF38BDF8),
      secondaryColor = Color(0xFF1D4ED8),
      rarity = "Common",
      unlockCondition = "Join 3 different servers",
      targetProgress = 3
    ),
    BadgeDefinition(
      id = "trendsetter",
      name = "Trendsetter",
      description = "Always styled with custom visual themes.",
      icon = Icons.Filled.AutoAwesome,
      primaryColor = Color(0xFFF472B6),
      secondaryColor = Color(0xFFBE185D),
      rarity = "Rare",
      unlockCondition = "Save 2 custom profile themes",
      targetProgress = 2
    ),
    BadgeDefinition(
      id = "creator",
      name = "Creator",
      description = "Active forum author and sticker creator.",
      icon = Icons.Filled.Brush,
      primaryColor = Color(0xFFFB7185),
      secondaryColor = Color(0xFFE11D48),
      rarity = "Rare",
      unlockCondition = "Create 3 forum posts or sticker packs",
      targetProgress = 3
    ),
    BadgeDefinition(
      id = "photographer",
      name = "Photographer",
      description = "Shares visual moments and short 7-second clips.",
      icon = Icons.Filled.PhotoCamera,
      primaryColor = Color(0xFF818CF8),
      secondaryColor = Color(0xFF4F46E5),
      rarity = "Uncommon",
      unlockCondition = "Send 5 photos or short videos in chat",
      targetProgress = 5
    ),
    BadgeDefinition(
      id = "supporter",
      name = "Supporter",
      description = "Sends positive reactions and encouragement.",
      icon = Icons.Filled.ThumbUp,
      primaryColor = Color(0xFF34D399),
      secondaryColor = Color(0xFF059669),
      rarity = "Common",
      unlockCondition = "Add 10 message reactions",
      targetProgress = 10
    ),
    BadgeDefinition(
      id = "legendary",
      name = "Legendary",
      description = "Elite achievement with rare collectibles and high rank.",
      icon = Icons.Filled.Whatshot,
      primaryColor = Color(0xFFF97316),
      secondaryColor = Color(0xFF9A3412),
      rarity = "Legendary",
      unlockCondition = "Own 5 Marketplace items & reach Level 15",
      targetProgress = 5
    ),
    BadgeDefinition(
      id = "verified_creator",
      name = "Verified Creator",
      description = "Verified creator publishing public sticker packs.",
      icon = Icons.Filled.Verified,
      primaryColor = Color(0xFF0EA5E9),
      secondaryColor = Color(0xFF0369A1),
      rarity = "Epic",
      unlockCondition = "Publish 2 public Sticker Packs",
      targetProgress = 2
    ),
    BadgeDefinition(
      id = "community_legend",
      name = "Community Legend",
      description = "Legendary figure with massive community reach.",
      icon = Icons.Filled.Public,
      primaryColor = Color(0xFFC084FC),
      secondaryColor = Color(0xFF7E22CE),
      rarity = "Legendary",
      unlockCondition = "Send 200 messages & have 10 friends/followers",
      targetProgress = 200
    ),
    BadgeDefinition(
      id = "grandmaster",
      name = "Grandmaster",
      description = "Reached high ELO rating in the mini-game arena.",
      icon = Icons.Filled.Psychology,
      primaryColor = Color(0xFFF5F7FA),
      secondaryColor = Color(0xFF64748B),
      rarity = "Mythic",
      unlockCondition = "Reach 1300 ELO in Chess / Reversi / Connect 4",
      targetProgress = 1300
    ),
    BadgeDefinition(
      id = "xchat_pioneer",
      name = "XChat Pioneer",
      description = "Explored V2.0 features from day one.",
      icon = Icons.Filled.Bolt,
      primaryColor = Color(0xFFEAB308),
      secondaryColor = Color(0xFF713F12),
      rarity = "Special",
      unlockCondition = "Complete 5 Quests in XChat V2.0",
      targetProgress = 5
    ),
    BadgeDefinition(
      id = "hall_of_fame",
      name = "Hall of Fame",
      description = "Highest honor for full dedication across XChat.",
      icon = Icons.Filled.EmojiFlags,
      primaryColor = Color(0xFFFDE047),
      secondaryColor = Color(0xFFCA8A04),
      rarity = "Mythic",
      unlockCondition = "Unlock at least 15 distinct achievement badges",
      targetProgress = 15
    )
  )

  fun getBadge(id: String): BadgeDefinition? = badges.find { it.id == id }

  fun parseProgressMap(json: String?): Map<String, Int> {
    if (json.isNullOrBlank()) return emptyMap()
    return runCatching {
      val obj = JSONObject(json)
      buildMap {
        obj.keys().forEach { key ->
          put(key, obj.optInt(key, 0))
        }
      }
    }.getOrDefault(emptyMap())
  }

  fun serializeProgressMap(map: Map<String, Int>): String {
    val obj = JSONObject()
    map.forEach { (k, v) -> obj.put(k, v) }
    return obj.toString()
  }
}

@Composable
fun BadgeLogo(
  badgeId: String,
  size: Dp = 22.dp,
  showBorder: Boolean = true,
  modifier: Modifier = Modifier
) {
  val def = BadgeCatalog.getBadge(badgeId) ?: return

  Box(
    modifier = modifier
      .size(size)
      .clip(RoundedCornerShape(6.dp))
      .background(
        Brush.linearGradient(
          colors = listOf(def.primaryColor, def.secondaryColor)
        )
      )
      .then(
        if (showBorder) Modifier.border(1.dp, Color.White.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
        else Modifier
      ),
    contentAlignment = Alignment.Center
  ) {
    Icon(
      imageVector = def.icon,
      contentDescription = def.name,
      tint = Color.White,
      modifier = Modifier.size(size * 0.65f)
    )
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BadgesRow(
  badgeIdsCsv: String,
  badgeSize: Dp = 18.dp,
  spacing: Dp = 4.dp,
  maxCount: Int = Int.MAX_VALUE,
  wrap: Boolean = false,
  modifier: Modifier = Modifier
) {
  val list = badgeIdsCsv.split(",").map { it.trim() }.filter { it.isNotBlank() }.distinct()
  if (list.isEmpty()) return
  val shown = if (maxCount < Int.MAX_VALUE) list.take(maxCount) else list

  if (wrap) {
    FlowRow(
      horizontalArrangement = Arrangement.spacedBy(spacing),
      verticalArrangement = Arrangement.spacedBy(spacing),
      modifier = modifier
    ) {
      shown.forEach { id ->
        BadgeLogo(badgeId = id, size = badgeSize)
      }
    }
  } else {
    Row(
      horizontalArrangement = Arrangement.spacedBy(spacing),
      verticalAlignment = Alignment.CenterVertically,
      modifier = modifier
    ) {
      shown.forEach { id ->
        BadgeLogo(badgeId = id, size = badgeSize)
      }
    }
  }
}
