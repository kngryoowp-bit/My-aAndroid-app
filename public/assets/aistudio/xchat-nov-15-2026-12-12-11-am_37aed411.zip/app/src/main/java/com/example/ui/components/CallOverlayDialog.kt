package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.example.ui.XChatViewModel
import com.example.ui.theme.*
import com.example.utils.RtcConnectionStage
import com.example.utils.WebRtcCallManager
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack

@Composable
fun CallOverlayDialog(
  viewModel: XChatViewModel
) {
  val callState by viewModel.rtcCallState.collectAsState()
  val localVideo by viewModel.localVideoTrack.collectAsState()
  val remoteVideos by viewModel.remoteVideoTracks.collectAsState()
  val context = LocalContext.current

  // Only show full modal call overlay for DM Voice / Video calls (Server Voice uses VoiceScreen)
  if (callState.stage == RtcConnectionStage.IDLE || callState.callType == "SERVER_VOICE") return

  val permLauncher = rememberLauncherForActivityResult(
    ActivityResultContracts.RequestMultiplePermissions()
  ) { granted ->
    val micOk = granted[Manifest.permission.RECORD_AUDIO] == true ||
      ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    if (micOk && callState.isIncoming && callState.stage == RtcConnectionStage.RINGING) {
      viewModel.acceptIncomingCall()
    }
  }

  Dialog(
    onDismissRequest = { },
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(ObsidianBlack.copy(alpha = 0.96f))
        .systemBarsPadding()
        .padding(20.dp)
    ) {
      val firstRemoteTrack = remoteVideos.values.firstOrNull()
      if (firstRemoteTrack != null) {
        WebRtcVideoRendererView(
          videoTrack = firstRemoteTrack,
          mirror = false,
          modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(24.dp))
        )
      }

      // Header Status
      Column(
        modifier = Modifier
          .align(Alignment.TopCenter)
          .padding(top = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Surface(
          color = GlassFillElevated,
          shape = RoundedCornerShape(99.dp),
          border = BorderStroke(1.dp, GlassBorderLight)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Icon(
              imageVector = if (callState.callType == "DM_VIDEO") Icons.Filled.Videocam else Icons.Filled.Call,
              contentDescription = null,
              tint = EmeraldSuccess,
              modifier = Modifier.size(16.dp)
            )
            Text(
              text = "${callState.qualityLabel} • ${formatCallSeconds(callState.callDurationSec)}",
              color = PureWhiteText,
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold
            )
          }
        }

        if (firstRemoteTrack == null) {
          Spacer(modifier = Modifier.height(28.dp))
          UserAvatar(
            avatarUri = callState.peerAvatarUri,
            displayName = callState.peerName.ifBlank { "XChat" },
            size = 96.dp
          )
        }

        Text(
          text = callState.peerName.ifBlank { tr("XChat Call", "Panggilan XChat", "Panggilan XChat", "XChat通話") },
          color = PureWhiteText,
          fontSize = 22.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = when (callState.stage) {
            RtcConnectionStage.RINGING -> if (callState.isIncoming) tr("Incoming call...", "Panggilan masuk...", "Panggilan masuk...", "着信中...") else tr("Calling...", "Memanggil...", "Memanggil...", "発信中...")
            RtcConnectionStage.CONNECTING -> tr("Connecting WebRTC...", "Menghubungkan WebRTC...", "Menyambung WebRTC...", "WebRTC接続中...")
            RtcConnectionStage.CONNECTED -> if (callState.remoteAudioDetected) tr("Connected • Two-Way Audio Active", "Terhubung • Audio Dua Arah Aktif", "Bersambung • Audio Dua Hala Aktif", "接続済み • 双方向音声有効") else tr("Connected", "Terhubung", "Bersambung", "接続済み")
            RtcConnectionStage.RECONNECTING -> tr("Reconnecting network...", "Menyambung ulang jaringan...", "Menyambung semula rangkaian...", "再接続中...")
            RtcConnectionStage.FAILED -> tr("Connection failed", "Gagal terhubung", "Gagal bersambung", "接続失敗")
            else -> tr("Call ended", "Panggilan berakhir", "Panggilan tamat", "通話終了")
          },
          color = SilverAccent,
          fontSize = 14.sp
        )

        callState.errorMessage?.let { err ->
          Surface(
            color = RoseError.copy(alpha = 0.22f),
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, RoseError.copy(alpha = 0.5f))
          ) {
            Text(
              text = err,
              color = PureWhiteText,
              fontSize = 12.sp,
              textAlign = TextAlign.Center,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
          }
        }
      }

      // Local PiP preview if camera active
      if (localVideo != null && callState.isCameraOn) {
        WebRtcVideoRendererView(
          videoTrack = localVideo!!,
          mirror = true,
          modifier = Modifier
            .align(Alignment.TopEnd)
            .padding(top = 64.dp, end = 4.dp)
            .size(width = 110.dp, height = 152.dp)
            .clip(RoundedCornerShape(16.dp))
        )
      }

      // Action Buttons Row at Bottom
      GlassCard(
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .fillMaxWidth()
          .padding(bottom = 12.dp)
      ) {
        if (callState.isIncoming && callState.stage == RtcConnectionStage.RINGING) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              FilledIconButton(
                onClick = { viewModel.declineOrEndDmCall() },
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = RoseError),
                modifier = Modifier.size(62.dp).testTag("call_decline_btn")
              ) {
                Icon(Icons.Filled.CallEnd, contentDescription = tr("Decline Call", "Tolak Panggilan", "Tolak Panggilan", "着信拒否"), tint = Color.White, modifier = Modifier.size(28.dp))
              }
              Spacer(modifier = Modifier.height(6.dp))
              Text(tr("Decline", "Tolak", "Tolak", "拒否"), color = SilverAccent, fontSize = 12.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              FilledIconButton(
                onClick = {
                  val micOk = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                  val camNeeded = callState.callType == "DM_VIDEO"
                  val camOk = !camNeeded || ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                  if (micOk && camOk) {
                    viewModel.acceptIncomingCall()
                  } else {
                    val req = if (camNeeded) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
                    else arrayOf(Manifest.permission.RECORD_AUDIO)
                    permLauncher.launch(req)
                  }
                },
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = EmeraldSuccess),
                modifier = Modifier.size(62.dp).testTag("call_accept_btn")
              ) {
                Icon(Icons.Filled.Call, contentDescription = tr("Accept Call", "Terima Panggilan", "Terima Panggilan", "応答"), tint = Color.White, modifier = Modifier.size(28.dp))
              }
              Spacer(modifier = Modifier.height(6.dp))
              Text(tr("Accept", "Terima", "Terima", "応答"), color = PureWhiteText, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }
        } else {
          Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
          ) {
            IconButton(
              onClick = { viewModel.toggleCallMute() },
              modifier = Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(if (callState.isMuted) RoseError else CharcoalElevated)
            ) {
              Icon(
                if (callState.isMuted) Icons.Filled.MicOff else Icons.Filled.Mic,
                contentDescription = tr("Mute Mic", "Bisukan Mikrofon", "Bisukan Mikrofon", "マイクをミュート"),
                tint = Color.White
              )
            }
            IconButton(
              onClick = { viewModel.toggleCallSpeaker() },
              modifier = Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(if (callState.isSpeakerOn) MaterialTheme.colorScheme.primary else CharcoalElevated)
            ) {
              Icon(
                if (callState.isSpeakerOn) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeOff,
                contentDescription = "Speaker",
                tint = Color.White
              )
            }
            IconButton(
              onClick = {
                val camOk = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                if (camOk) viewModel.toggleCallCamera()
                else permLauncher.launch(arrayOf(Manifest.permission.CAMERA))
              },
              modifier = Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(if (callState.isCameraOn) EmeraldSuccess else CharcoalElevated)
            ) {
              Icon(
                if (callState.isCameraOn) Icons.Filled.Videocam else Icons.Filled.VideocamOff,
                contentDescription = tr("Camera", "Kamera", "Kamera", "カメラ"),
                tint = Color.White
              )
            }
            FilledIconButton(
              onClick = { viewModel.declineOrEndDmCall() },
              colors = IconButtonDefaults.filledIconButtonColors(containerColor = RoseError),
              modifier = Modifier.size(56.dp).testTag("call_hangup_btn")
            ) {
              Icon(Icons.Filled.CallEnd, contentDescription = tr("End Call", "Akhiri Panggilan", "Tamatkan Panggilan", "通話を終了"), tint = Color.White)
            }
          }
        }
      }
    }
  }
}

@Composable
fun WebRtcVideoRendererView(
  videoTrack: VideoTrack,
  mirror: Boolean,
  modifier: Modifier = Modifier
) {
  val eglCtx = remember { WebRtcCallManager.getEglContext() }
  AndroidView(
    modifier = modifier,
    factory = { ctx ->
      SurfaceViewRenderer(ctx).apply {
        if (eglCtx != null) {
          init(eglCtx, null)
          setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
          setMirror(mirror)
          setEnableHardwareScaler(true)
          videoTrack.addSink(this)
        }
      }
    },
    onRelease = { renderer ->
      runCatching {
        videoTrack.removeSink(renderer)
        renderer.release()
      }
    }
  )
}

@Composable
fun VoiceDiagnosticsDialog(
  viewModel: XChatViewModel,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val strings = LocalStrings.current
  val callState by viewModel.rtcCallState.collectAsState()

  val micPermLauncher = rememberLauncherForActivityResult(
    ActivityResultContracts.RequestPermission()
  ) { granted ->
    if (granted) viewModel.toggleMicLoopbackTest()
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = CharcoalSurface,
    titleContentColor = PureWhiteText,
    textContentColor = PureWhiteText,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Filled.GraphicEq, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Text(strings.voiceDiagnostics, fontWeight = FontWeight.Bold, fontSize = 17.sp)
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
          tr(
            "Test microphone (local loopback), speaker tone, and live two-way WebRTC audio status.",
            "Uji mikrofon (loopback lokal), nada speaker, dan status audio WebRTC dua arah secara langsung.",
            "Uji mikrofon (gelung balik tempatan), nada pembesar suara, dan status audio WebRTC dua hala secara langsung.",
            "マイク(ローカルループバック)、スピーカーテスト音、双方向WebRTC音声状態をテストします。"
          ),
          color = SilverAccent,
          fontSize = 12.sp
        )

        GlassCard(modifier = Modifier.fillMaxWidth()) {
          Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("${tr("Connection Quality", "Kualitas Koneksi", "Kualiti Sambungan", "接続品質")}: ${callState.qualityLabel}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(
              "${tr("Connected Peers", "Peer Terhubung", "Rakan Bersambung", "接続ピア")}: ${callState.connectedPeerCount} • Remote Audio: ${if (callState.remoteAudioDetected) tr("Detected", "Terdeteksi", "Dikesan", "検出") else tr("Waiting", "Menunggu", "Menunggu", "待機中")}",
              fontSize = 12.sp,
              color = SilverAccent
            )
            callState.errorMessage?.let {
              Text("${tr("Warning", "Peringatan", "Amaran", "警告")}: $it", color = RoseError, fontSize = 12.sp)
            }
          }
        }

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text("${tr("Microphone Input Level", "Level Input Mikrofon", "Tahap Input Mikrofon", "マイク入力レベル")} (${(callState.loopbackDbLevel * 100).toInt()}%)", fontSize = 12.sp, color = SilverAccent)
          LinearProgressIndicator(
            progress = { callState.loopbackDbLevel.coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Button(
            onClick = {
              if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                viewModel.toggleMicLoopbackTest()
              } else {
                micPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
              }
            },
            colors = ButtonDefaults.buttonColors(
              containerColor = if (callState.isMicLoopbackTesting) RoseError else MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier.weight(1f).height(48.dp)
          ) {
            Text(if (callState.isMicLoopbackTesting) tr("Stop Mic Test", "Hentikan Uji Mic", "Henti Uji Mic", "テスト停止") else strings.micTestBtn, fontSize = 12.sp)
          }
          OutlinedButton(
            onClick = { viewModel.playSpeakerTestTone() },
            modifier = Modifier.weight(1f).height(48.dp)
          ) {
            Text(strings.speakerTestBtn, fontSize = 12.sp)
          }
        }
      }
    },
    confirmButton = {
      TextButton(onClick = {
        if (callState.isMicLoopbackTesting) viewModel.toggleMicLoopbackTest()
        onDismiss()
      }) { Text(strings.close) }
    }
  )
}

private fun formatCallSeconds(sec: Long): String {
  val m = sec / 60
  val s = sec % 60
  return "%02d:%02d".format(m, s)
}
