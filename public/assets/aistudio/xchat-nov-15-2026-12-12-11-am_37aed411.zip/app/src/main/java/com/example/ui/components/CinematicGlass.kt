package com.example.ui.components

import android.os.Build
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.ui.theme.*
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * XChat V2.0 Cinematic Glassmorphism + Free Animated Moving Marble Background Engine.
 * Supports:
 * - "MARBLE": Smooth continuous black & white animated marble veins + light reflections + subtle particles.
 * - "IMAGE" / "GIF" / "VIDEO": User-uploaded custom wallpaper with blur, opacity, brightness, tint.
 * - "GRADIENT": Multi-stop custom user gradient.
 * All modes respect lowPerfMode to keep device framerates silky smooth.
 */
@Composable
fun XChatCinematicBackground(
  wallpaperMode: String = "MARBLE",
  customWallpaperUri: String? = null,
  wallpaperGradientCsv: String = "0xFF07080B,0xFF111318,0xFF1E222A",
  blurRadius: Float = 0f,
  opacity: Float = 0.85f,
  brightness: Float = 0.9f,
  tintHex: Long = 0xFF07080BL,
  lowPerfMode: Boolean = false,
  modifier: Modifier = Modifier
) {
  val themeCfg = LocalAppThemeConfig.current
  val baseBg = themeCfg.background
  val context = LocalContext.current

  Box(modifier = modifier.fillMaxSize().background(baseBg)) {
    when {
      (wallpaperMode == "IMAGE" || wallpaperMode == "GIF" || wallpaperMode == "VIDEO") && !customWallpaperUri.isNullOrBlank() -> {
        val imageMod = if (blurRadius > 0.5f && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
          Modifier.fillMaxSize().blur(blurRadius.coerceIn(0f, 24f).dp)
        } else {
          Modifier.fillMaxSize()
        }
        AsyncImage(
          model = ImageRequest.Builder(context)
            .data(customWallpaperUri)
            .crossfade(true)
            .build(),
          contentDescription = "Wallpaper Kustom XChat",
          contentScale = ContentScale.Crop,
          alpha = opacity.coerceIn(0.15f, 1f),
          modifier = imageMod
        )
      }
      wallpaperMode == "GRADIENT" -> {
        val colors = ColorHelper.parseColorsCsv(
          wallpaperGradientCsv,
          listOf(0xFF07080BL, 0xFF111318L, 0xFF202531L)
        )
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.linearGradient(
                colors = if (colors.size >= 2) colors else listOf(ObsidianBlack, CharcoalElevated)
              )
            )
        )
      }
      else -> {
        MovingMarbleCanvas(lowPerfMode = lowPerfMode, isDark = themeCfg.isDark)
      }
    }

    // Brightness & cinematic glass overlay so foreground text always maintains WCAG contrast
    val dimAlpha = (1f - brightness.coerceIn(0.25f, 1.0f)).coerceIn(0.08f, 0.72f)
    val tintColor = Color(tintHex)
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(
          Brush.verticalGradient(
            colors = listOf(
              tintColor.copy(alpha = dimAlpha * 0.85f),
              tintColor.copy(alpha = (dimAlpha + 0.18f).coerceIn(0.18f, 0.82f))
            )
          )
        )
    )
  }
}

@Composable
fun MovingMarbleCanvas(
  lowPerfMode: Boolean,
  isDark: Boolean = true,
  modifier: Modifier = Modifier
) {
  val phase: Float = if (lowPerfMode) {
    0.35f
  } else {
    val transition = rememberInfiniteTransition(label = "moving_marble")
    val anim by transition.animateFloat(
      initialValue = 0f,
      targetValue = (2.0 * PI).toFloat(),
      animationSpec = infiniteRepeatable(
        animation = tween(durationMillis = 18000, easing = LinearEasing),
        repeatMode = RepeatMode.Restart
      ),
      label = "marble_phase"
    )
    anim
  }

  val baseA = if (isDark) ObsidianBlack else Slate100
  val baseB = if (isDark) CharcoalSurface else Slate200
  val veinLight = if (isDark) Color(0xFFFFFFFF) else Color(0xFF0F172A)
  val veinMid = if (isDark) SilverAccent else Slate500

  Canvas(modifier = modifier.fillMaxSize()) {
    val w = size.width
    val h = size.height

    // Deep atmospheric marble gradient base
    drawRect(
      brush = Brush.radialGradient(
        colors = listOf(baseB, baseA),
        center = Offset(
          w * (0.5f + 0.12f * cos(phase)),
          h * (0.35f + 0.10f * sin(phase))
        ),
        radius = (w.coerceAtLeast(h)) * 0.95f
      )
    )

    // Soft light reflection blooms (monochrome silver / charcoal depth)
    drawCircle(
      brush = Brush.radialGradient(
        colors = listOf(veinLight.copy(alpha = 0.085f), Color.Transparent),
        center = Offset(w * (0.25f + 0.18f * sin(phase)), h * (0.28f + 0.14f * cos(phase))),
        radius = w * 0.72f
      ),
      radius = w * 0.72f,
      center = Offset(w * (0.25f + 0.18f * sin(phase)), h * (0.28f + 0.14f * cos(phase)))
    )

    drawCircle(
      brush = Brush.radialGradient(
        colors = listOf(veinMid.copy(alpha = 0.07f), Color.Transparent),
        center = Offset(w * (0.78f - 0.16f * cos(phase)), h * (0.72f - 0.12f * sin(phase))),
        radius = w * 0.68f
      ),
      radius = w * 0.68f,
      center = Offset(w * (0.78f - 0.16f * cos(phase)), h * (0.72f - 0.12f * sin(phase)))
    )

    // Flowing black-and-white marble veins with continuous distortion
    val veinCount = if (lowPerfMode) 3 else 6
    for (i in 0 until veinCount) {
      val path = Path()
      val yBase = h * (0.12f + i * 0.15f)
      val amp = h * (0.045f + (i % 3) * 0.018f)
      val freq = 1.4f + i * 0.32f
      val offset = phase + i * 1.15f

      path.moveTo(-40f, yBase)
      val steps = if (lowPerfMode) 10 else 18
      for (step in 1..steps) {
        val t = step.toFloat() / steps
        val x = t * (w + 80f) - 40f
        val wave = sin(t * PI.toFloat() * freq + offset) * amp +
          cos(t * PI.toFloat() * (freq * 1.7f) - offset * 0.8f) * (amp * 0.45f)
        val y = yBase + wave
        path.lineTo(x, y)
      }

      drawPath(
        path = path,
        color = veinLight.copy(alpha = if (i % 2 == 0) 0.08f else 0.045f),
        style = Stroke(width = (3f + (i % 3) * 3.5f))
      )
      drawPath(
        path = path,
        color = veinMid.copy(alpha = 0.035f),
        style = Stroke(width = 16f + i * 4f)
      )
    }

    // Subtle animated silver micro-particles (disabled in lowPerfMode)
    if (!lowPerfMode) {
      val particleCount = 14
      for (p in 0 until particleCount) {
        val px = ((p * 0.173f + 0.04f * sin(phase + p)) % 1f) * w
        val py = ((p * 0.241f - 0.035f * cos(phase * 0.9f + p * 1.7f) + 1f) % 1f) * h
        val alpha = 0.08f + 0.07f * ((sin(phase * 2f + p) + 1f) * 0.5f)
        drawCircle(
          color = veinLight.copy(alpha = alpha),
          radius = (1.5f + (p % 3) * 0.9f).dp.toPx(),
          center = Offset(px, py)
        )
      }
    }
  }
}

/**
 * Translucent Obsidian Glass Card with 1dp reflective border and optional tactile press animation.
 */
@Composable
fun GlassCard(
  modifier: Modifier = Modifier,
  shape: Shape = RoundedCornerShape(20.dp),
  containerColor: Color = GlassFillDark,
  borderColor: Color = GlassBorderLight,
  elevation: Dp = 0.dp,
  onClick: (() -> Unit)? = null,
  content: @Composable ColumnScope.() -> Unit
) {
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()
  val scale by animateFloatAsState(
    targetValue = if (isPressed && onClick != null) 0.985f else 1f,
    animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
    label = "glass_press"
  )

  val cardModifier = modifier
    .scale(scale)
    .clip(shape)
    .then(
      if (onClick != null) {
        Modifier.clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
      } else Modifier
    )

  Surface(
    modifier = cardModifier,
    shape = shape,
    color = containerColor,
    tonalElevation = elevation,
    border = BorderStroke(1.dp, borderColor)
  ) {
    Column(modifier = Modifier.fillMaxWidth(), content = content)
  }
}

@Composable
fun GlassSurface(
  modifier: Modifier = Modifier,
  shape: Shape = RoundedCornerShape(16.dp),
  containerColor: Color = GlassFillElevated,
  borderColor: Color = GlassBorderSubtle,
  content: @Composable BoxScope.() -> Unit
) {
  Surface(
    modifier = modifier,
    shape = shape,
    color = containerColor,
    border = BorderStroke(1.dp, borderColor)
  ) {
    Box(content = content)
  }
}
