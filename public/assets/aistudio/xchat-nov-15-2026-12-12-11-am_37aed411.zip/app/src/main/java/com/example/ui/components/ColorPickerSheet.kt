package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ColorHelper

private val QuickSpectrumSwatches = listOf(
  Color(0xFFFDE68A),
  Color(0xFFFACC15),
  Color(0xFFF472B6),
  Color(0xFFC084FC),
  Color(0xFF818CF8),
  Color(0xFF38BDF8),
  Color(0xFF6EE7B7),
  Color(0xFFF43F5E)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PickColorBottomSheet(
  initialColor: Color,
  title: String = "Pick a Color",
  onDismiss: () -> Unit,
  onSelect: (Color) -> Unit
) {
  val initialHsv = remember(initialColor) { ColorHelper.colorToHsv(initialColor) }
  var hue by remember { mutableFloatStateOf(initialHsv[0]) }
  var saturation by remember { mutableFloatStateOf(initialHsv[1]) }
  var value by remember { mutableFloatStateOf(initialHsv[2]) }
  var hexText by remember { mutableStateOf(ColorHelper.toHex6(initialColor)) }

  val currentColor = remember(hue, saturation, value) {
    ColorHelper.hsvToColor(hue, saturation, value)
  }

  fun applyColorFromOutside(c: Color) {
    val hsv = ColorHelper.colorToHsv(c)
    hue = hsv[0]
    saturation = hsv[1]
    value = hsv[2]
    hexText = ColorHelper.toHex6(c)
  }

  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
    contentColor = MaterialTheme.colorScheme.onSurface,
    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp)
        .padding(bottom = 28.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Header Row: Centered title + Select button on right
      Box(modifier = Modifier.fillMaxWidth()) {
        Text(
          text = title,
          fontWeight = FontWeight.Bold,
          fontSize = 18.sp,
          color = MaterialTheme.colorScheme.onSurface,
          modifier = Modifier.align(Alignment.Center)
        )
        Button(
          onClick = { onSelect(currentColor) },
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = Color.White
          ),
          contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
          modifier = Modifier
            .align(Alignment.CenterEnd)
            .height(36.dp)
            .testTag("pick_color_select_btn")
        ) {
          Text("Select", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
      }

      // Hex TextField with live preview swatch
      OutlinedTextField(
        value = hexText,
        onValueChange = { raw ->
          val sanitized = raw.take(7)
          hexText = sanitized
          val parsed = ColorHelper.parseHex6OrNull(sanitized)
          if (parsed != null) {
            val hsv = ColorHelper.colorToHsv(parsed)
            hue = hsv[0]
            saturation = hsv[1]
            value = hsv[2]
          }
        },
        singleLine = true,
        leadingIcon = {
          Box(
            modifier = Modifier
              .size(22.dp)
              .clip(RoundedCornerShape(6.dp))
              .background(currentColor)
              .border(1.dp, Color.White.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
          )
        },
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
          unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
          focusedBorderColor = MaterialTheme.colorScheme.primary,
          unfocusedBorderColor = MaterialTheme.colorScheme.outline
        ),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("pick_color_hex_input")
      )

      // Quick Swatches row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
      ) {
        QuickSpectrumSwatches.forEach { sw ->
          val isMatched = ColorHelper.toHex6(sw) == ColorHelper.toHex6(currentColor)
          Box(
            modifier = Modifier
              .size(30.dp)
              .clip(RoundedCornerShape(8.dp))
              .background(sw)
              .border(
                width = if (isMatched) 2.5.dp else 1.dp,
                color = if (isMatched) Color.White else MaterialTheme.colorScheme.outline,
                shape = RoundedCornerShape(8.dp)
              )
              .clickable { applyColorFromOutside(sw) }
          )
        }
      }

      // 2D Saturation-Value Square
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(210.dp),
        contentAlignment = Alignment.Center
      ) {
        val pureHueColor = remember(hue) { ColorHelper.hsvToColor(hue, 1f, 1f) }
        Canvas(
          modifier = Modifier
            .fillMaxWidth(0.76f)
            .fillMaxHeight()
            .clip(RoundedCornerShape(10.dp))
            .pointerInput(Unit) {
              detectTapGestures { offset ->
                saturation = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                value = 1f - (offset.y / size.height.toFloat()).coerceIn(0f, 1f)
                hexText = ColorHelper.toHex6(ColorHelper.hsvToColor(hue, saturation, value))
              }
            }
            .pointerInput(Unit) {
              detectDragGestures { change, _ ->
                change.consume()
                saturation = (change.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                value = 1f - (change.position.y / size.height.toFloat()).coerceIn(0f, 1f)
                hexText = ColorHelper.toHex6(ColorHelper.hsvToColor(hue, saturation, value))
              }
            }
        ) {
          // Horizontal White -> Pure Hue
          drawRect(
            brush = Brush.horizontalGradient(
              colors = listOf(Color.White, pureHueColor)
            )
          )
          // Vertical Transparent -> Black
          drawRect(
            brush = Brush.verticalGradient(
              colors = listOf(Color.Transparent, Color.Black)
            )
          )

          // Thumb Indicator
          val cx = (saturation * size.width).coerceIn(0f, size.width)
          val cy = ((1f - value) * size.height).coerceIn(0f, size.height)
          drawCircle(
            color = currentColor,
            radius = 11.dp.toPx(),
            center = Offset(cx, cy)
          )
          drawCircle(
            color = Color.White,
            radius = 11.dp.toPx(),
            center = Offset(cx, cy),
            style = Stroke(width = 2.5.dp.toPx())
          )
          drawCircle(
            color = Color.Black.copy(alpha = 0.55f),
            radius = 13.dp.toPx(),
            center = Offset(cx, cy),
            style = Stroke(width = 1.dp.toPx())
          )
        }
      }

      // 360-degree Rainbow Hue Slider
      Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center
      ) {
        val rainbowColors = remember {
          listOf(
            Color(0xFFFF0000),
            Color(0xFFFFFF00),
            Color(0xFF00FF00),
            Color(0xFF00FFFF),
            Color(0xFF0000FF),
            Color(0xFFFF00FF),
            Color(0xFFFF0000)
          )
        }
        Canvas(
          modifier = Modifier
            .fillMaxWidth(0.76f)
            .height(28.dp)
            .clip(RoundedCornerShape(8.dp))
            .pointerInput(Unit) {
              detectTapGestures { offset ->
                hue = ((offset.x / size.width.toFloat()).coerceIn(0f, 1f)) * 360f
                hexText = ColorHelper.toHex6(ColorHelper.hsvToColor(hue, saturation, value))
              }
            }
            .pointerInput(Unit) {
              detectDragGestures { change, _ ->
                change.consume()
                hue = ((change.position.x / size.width.toFloat()).coerceIn(0f, 1f)) * 360f
                hexText = ColorHelper.toHex6(ColorHelper.hsvToColor(hue, saturation, value))
              }
            }
        ) {
          drawRect(
            brush = Brush.horizontalGradient(colors = rainbowColors)
          )
          val hx = ((hue / 360f).coerceIn(0f, 1f)) * size.width
          val thumbW = 18.dp.toPx()
          val left = (hx - thumbW / 2f).coerceIn(2f, size.width - thumbW - 2f)
          drawRoundRect(
            color = ColorHelper.hsvToColor(hue, 1f, 1f),
            topLeft = Offset(left, 2f),
            size = androidx.compose.ui.geometry.Size(thumbW, size.height - 4f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(6.dp.toPx())
          )
          drawRoundRect(
            color = Color.White,
            topLeft = Offset(left, 2f),
            size = androidx.compose.ui.geometry.Size(thumbW, size.height - 4f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(6.dp.toPx()),
            style = Stroke(width = 2.5.dp.toPx())
          )
        }
      }
    }
  }
}
