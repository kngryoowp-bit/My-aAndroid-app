package com.example.ui.components

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.UserEntity
import com.example.ui.theme.AppFontOption
import com.example.ui.theme.tr
import com.example.ui.theme.ColorHelper
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DisplayNameStyleDialog(
  user: UserEntity,
  displayNamePreview: String,
  initialFontKey: String,
  initialEffectKey: String,
  initialColors: List<Color>,
  profileBgColors: List<Color>,
  avatarUri: String?,
  bannerUri: String?,
  profileColor: Long,
  onDismiss: () -> Unit,
  onSaveStyle: (fontKey: String, effectKey: String, colors: List<Color>) -> Unit
) {
  val context = LocalContext.current
  var fontKey by remember { mutableStateOf(initialFontKey) }
  var effectKey by remember { mutableStateOf(initialEffectKey) }
  var colors by remember { mutableStateOf(initialColors.ifEmpty { listOf(Color(0xFFC084FC), Color(0xFF38BDF8)) }) }
  var activeColorIndex by remember { mutableIntStateOf(0) }

  var showColorPicker by remember { mutableStateOf(false) }
  var expandedSection by remember { mutableStateOf<String?>("COLOR") } // "FONT", "EFFECT", "COLOR"

  val activeColorsCsv = remember(colors) {
    colors.take(5).joinToString(",") { ColorHelper.toHexArgLong(it) }
  }
  val bgBrush = remember(profileBgColors) {
    if (profileBgColors.size >= 2) Brush.verticalGradient(profileBgColors.take(3))
    else Brush.verticalGradient(listOf(profileBgColors.firstOrNull() ?: Color(0xFF2B2D31), Color(0xFF1E1F22)))
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Scaffold(
      topBar = {
        TopAppBar(
          title = {
            Text(
              "Change Display Name Style",
              fontWeight = FontWeight.Bold,
              fontSize = 18.sp,
              color = MaterialTheme.colorScheme.onSurface
            )
          },
          navigationIcon = {
            IconButton(onClick = onDismiss) {
              Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
          },
          actions = {
            TextButton(
              onClick = { onSaveStyle(fontKey, effectKey, colors) },
              modifier = Modifier.testTag("display_name_style_save_btn")
            ) {
              Text("Save", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
          },
          colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
        )
      },
      containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        // Overlapping Profile Preview + Chat Message Preview (matching Discord screenshot)
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp)
        ) {
          // Profile Card Preview
          Card(
            modifier = Modifier
              .fillMaxWidth(0.84f)
              .align(Alignment.TopCenter),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent),
            border = CardDefaults.outlinedCardBorder().copy(
              brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.outline, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)))
            )
          ) {
            Column(modifier = Modifier.background(bgBrush)) {
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .height(74.dp)
                  .background(
                    Brush.linearGradient(listOf(Color(profileColor), MaterialTheme.colorScheme.surfaceVariant))
                  )
              ) {
                if (!bannerUri.isNullOrBlank() && (user.subscriptionTier.equals("ASTRAL", ignoreCase = true) || user.isOwner)) {
                  val bannerReq = remember(bannerUri) {
                    val m = com.example.utils.CloudMediaHelper.resolveCoilModel(bannerUri)
                    ImageRequest.Builder(context).data(m).crossfade(false).build()
                  }
                  AsyncImage(
                    model = bannerReq,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                  )
                }
              }

              Box(
                modifier = Modifier
                  .padding(horizontal = 14.dp)
                  .offset(y = (-26).dp)
              ) {
                UserAvatar(
                  avatarUri = avatarUri,
                  displayName = displayNamePreview,
                  size = 56.dp,
                  frameId = user.equippedFrame,
                  isOnline = true,
                  showStatus = true,
                  backgroundColor = profileColor
                )
              }

              Column(
                modifier = Modifier
                  .padding(horizontal = 14.dp)
                  .offset(y = (-16).dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
              ) {
                StyledDisplayName(
                  name = displayNamePreview,
                  fontKey = fontKey,
                  colorsCsv = activeColorsCsv,
                  effectKey = effectKey,
                  fontSize = 20.sp,
                  fontWeight = FontWeight.ExtraBold
                )
                Text(
                  text = "@${user.username} • ${user.pronouns}",
                  fontSize = 12.sp,
                  color = Color.White.copy(alpha = 0.78f)
                )
                if (user.equippedBadges.isNotBlank()) {
                  Spacer(modifier = Modifier.height(2.dp))
                  BadgesRow(badgeIdsCsv = user.equippedBadges, badgeSize = 16.dp, spacing = 4.dp, maxCount = 5)
                }
                Spacer(modifier = Modifier.height(26.dp))
              }
            }
          }

          // Floating Chat Message Preview overlapping bottom-right of Profile Card
          Card(
            modifier = Modifier
              .fillMaxWidth(0.76f)
              .align(Alignment.BottomEnd)
              .padding(top = 158.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            border = CardDefaults.outlinedCardBorder().copy(
              brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.outline, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)))
            )
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              UserAvatar(
                avatarUri = avatarUri,
                displayName = displayNamePreview,
                size = 34.dp,
                frameId = user.equippedFrame,
                backgroundColor = profileColor
              )
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  StyledDisplayName(
                    name = displayNamePreview,
                    fontKey = fontKey,
                    colorsCsv = activeColorsCsv,
                    effectKey = effectKey,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f, fill = false)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("11:31 AM", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(
                  text = "does anyone read this?",
                  fontSize = 13.sp,
                  color = MaterialTheme.colorScheme.onSurface
                )
              }
            }
          }
        }

        // Pill Preview Bar
        Surface(
          modifier = Modifier.fillMaxWidth(0.84f).align(Alignment.CenterHorizontally),
          shape = RoundedCornerShape(12.dp),
          color = MaterialTheme.colorScheme.surface,
          border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(10.dp))
            StyledDisplayName(
              name = displayNamePreview,
              fontKey = fontKey,
              colorsCsv = activeColorsCsv,
              effectKey = effectKey,
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Selector Row 1: Font
        StyleOptionRow(
          label = "Font",
          valuePreview = {
            Text(
              text = AppFontOption.fromKey(fontKey).label,
              fontFamily = AppFontOption.fromKey(fontKey).fontFamily,
              fontSize = 13.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          },
          onClick = { expandedSection = if (expandedSection == "FONT") null else "FONT" }
        )
        if (expandedSection == "FONT") {
          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            AppFontOption.entries.forEach { opt ->
              FilterChip(
                selected = fontKey.equals(opt.key, ignoreCase = true),
                onClick = { fontKey = opt.key },
                label = { Text(opt.label, fontFamily = opt.fontFamily, fontSize = 12.sp) }
              )
            }
          }
        }

        // Selector Row 2: Effect
        StyleOptionRow(
          label = "Effect",
          valuePreview = {
            Text(
              text = DisplayNameEffect.fromKey(effectKey).label,
              fontSize = 13.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          },
          onClick = { expandedSection = if (expandedSection == "EFFECT") null else "EFFECT" }
        )
        if (expandedSection == "EFFECT") {
          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            DisplayNameEffect.entries.forEach { eff ->
              FilterChip(
                selected = effectKey.equals(eff.key, ignoreCase = true),
                onClick = { effectKey = eff.key },
                label = { Text(eff.label, fontSize = 12.sp) }
              )
            }
          }
        }

        // Selector Row 3: Color (opens full HSV PickColorBottomSheet + gradient stops up to 5)
        val activeStopColor = colors.getOrElse(activeColorIndex) { colors.first() }
        StyleOptionRow(
          label = "Color",
          valuePreview = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Box(
                modifier = Modifier
                  .size(18.dp)
                  .clip(RoundedCornerShape(4.dp))
                  .background(activeStopColor)
                  .border(1.dp, Color.White.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
              )
              Text(
                text = ColorHelper.toHex6(activeStopColor),
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          },
          onClick = {
            expandedSection = "COLOR"
            showColorPicker = true
          }
        )

        // Multi-stop gradient dots (up to 5 colors)
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
          Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(tr("Color Gradient (Max 5) — Tap to Pick a Color", "Gradasi Warna (Maks. 5) — Ketuk untuk Pilih Warna", "Gradasi Warna (Maks. 5) — Ketik untuk Pilih Warna", "カラーグラデーション (最大5色) — タップして色を選択"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              colors.forEachIndexed { idx, col ->
                Box(
                  modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(col)
                    .border(
                      width = if (activeColorIndex == idx) 3.dp else 1.dp,
                      color = if (activeColorIndex == idx) Color.White else MaterialTheme.colorScheme.outline,
                      shape = CircleShape
                    )
                    .clickable {
                      activeColorIndex = idx
                      showColorPicker = true
                    },
                  contentAlignment = Alignment.Center
                ) {
                  Text("${idx + 1}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black.copy(alpha = 0.7f))
                }
              }
              if (colors.size < 5) {
                FilledIconButton(
                  onClick = {
                    colors = colors + Color(0xFF38BDF8)
                    activeColorIndex = colors.lastIndex
                    showColorPicker = true
                  },
                  modifier = Modifier.size(36.dp)
                ) {
                  Icon(Icons.Filled.Add, contentDescription = "Add stop", modifier = Modifier.size(16.dp))
                }
              }
              if (colors.size > 1) {
                OutlinedIconButton(
                  onClick = {
                    val rm = activeColorIndex.coerceIn(0, colors.lastIndex)
                    colors = colors.toMutableList().apply { removeAt(rm) }
                    activeColorIndex = activeColorIndex.coerceIn(0, colors.lastIndex)
                  },
                  modifier = Modifier.size(36.dp)
                ) {
                  Icon(Icons.Filled.Remove, contentDescription = "Remove stop", modifier = Modifier.size(16.dp))
                }
              }
            }
          }
        }

        // Bottom Buttons: Surprise Me & Remove Style
        Row(
          modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          FilledTonalButton(
            onClick = {
              val randomFonts = AppFontOption.entries
              val randomEffects = listOf(
                "GRADIENT", "GLOW", "NEON", "SHIMMER", "RAINBOW",
                "FLOATING", "WAVE", "PULSE", "TYPING", "REVERSE_TYPING", "OUTLINE", "POP"
              )
              val palettes = listOf(
                listOf(Color(0xFFF5F7FA), Color(0xFFC4C9D4), Color(0xFF64748B)),
                listOf(Color(0xFFC32AFF), Color(0xFF38BDF8), Color(0xFFF472B6)),
                listOf(Color(0xFFFFE100), Color(0xFFF97316), Color(0xFFF43F5E)),
                listOf(Color(0xFF2DD4BF), Color(0xFF38BDF8), Color(0xFF818CF8), Color(0xFFC084FC)),
                listOf(Color(0xFFA855F7), Color(0xFFEC4899), Color(0xFFFACC15), Color(0xFF22C55E), Color(0xFF38BDF8))
              )
              fontKey = randomFonts.random().key
              effectKey = randomEffects.random()
              colors = palettes.random()
              activeColorIndex = 0
            },
            modifier = Modifier.weight(1f).height(46.dp),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Filled.AutoFixHigh, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Surprise Me", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          }

          OutlinedButton(
            onClick = {
              fontKey = "SANS"
              effectKey = "SOLID"
              colors = listOf(Color(0xFFF2F3F5))
              activeColorIndex = 0
            },
            modifier = Modifier.weight(1f).height(46.dp),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Filled.Clear, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Remove Style", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
          }
        }
      }
    }
  }

  if (showColorPicker) {
    PickColorBottomSheet(
      initialColor = colors.getOrElse(activeColorIndex) { Color(0xFFC32AFF) },
      title = "Pick a Color",
      onDismiss = { showColorPicker = false },
      onSelect = { chosen ->
        val idx = activeColorIndex.coerceIn(0, colors.lastIndex)
        colors = colors.toMutableList().apply { set(idx, chosen) }
        showColorPicker = false
      }
    )
  }
}

@Composable
private fun StyleOptionRow(
  label: String,
  valuePreview: @Composable () -> Unit,
  onClick: () -> Unit
) {
  Surface(
    onClick = onClick,
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(14.dp),
    color = MaterialTheme.colorScheme.surface,
    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text(label, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
      Row(verticalAlignment = Alignment.CenterVertically) {
        valuePreview()
        Spacer(modifier = Modifier.width(6.dp))
        Icon(
          Icons.AutoMirrored.Filled.KeyboardArrowRight,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.size(18.dp)
        )
      }
    }
  }
}
