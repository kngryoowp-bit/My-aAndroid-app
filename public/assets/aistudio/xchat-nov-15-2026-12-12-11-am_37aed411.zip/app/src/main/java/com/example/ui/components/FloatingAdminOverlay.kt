package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserEntity
import com.example.ui.MainTab
import com.example.ui.XChatViewModel
import com.example.ui.theme.*
import kotlin.math.roundToInt

/**
 * Draggable & Minimizable Floating Admin Panel strictly gated by verified RBAC (isVerifiedAdmin).
 * Never visible to ordinary users.
 */
@Composable
fun FloatingAdminOverlay(
  viewModel: XChatViewModel,
  modifier: Modifier = Modifier
) {
  val isVerifiedAdmin by viewModel.isVerifiedAdmin.collectAsState()
  if (!isVerifiedAdmin) return

  val isExpanded by viewModel.isFloatingAdminOpen.collectAsState()
  val role by viewModel.verifiedAdminRole.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()
  val allUsers by viewModel.allUsers.collectAsState()
  val servers by viewModel.servers.collectAsState()
  val selectedServerId by viewModel.selectedServerId.collectAsState()
  val restrictions by viewModel.allRestrictions.collectAsState()
  val reports by viewModel.reports.collectAsState()
  val strings = LocalStrings.current

  var offsetX by remember { mutableFloatStateOf(16f) }
  var offsetY by remember { mutableFloatStateOf(140f) }
  var panelTab by remember { mutableIntStateOf(0) } // 0=Admin, 1=Appeals, 2=Redeem

  var selectedInvisibleSrvId by remember(selectedServerId) { mutableStateOf(selectedServerId) }
  var deleteConfirmTarget by remember { mutableStateOf<UserEntity?>(null) }

  var targetUserQuery by remember { mutableStateOf("") }
  var lockReason by remember { mutableStateOf("Community rules violation") }
  var lockMsg by remember { mutableStateOf("Your account is temporarily under review.") }
  var lockMinutesText by remember { mutableStateOf("15") }

  var newCode by remember { mutableStateOf("") }
  var newCodeXit by remember { mutableStateOf("300") }
  var newCodeBoost by remember { mutableStateOf("1") }

  val invisibleSrvSet = remember(currentUser?.invisibleServerIdsCsv) {
    currentUser?.invisibleServerIdsCsv.orEmpty()
      .split(",")
      .map { it.trim() }
      .filter { it.isNotBlank() }
      .toSet()
  }

  Box(modifier = modifier.fillMaxSize()) {
    Box(
      modifier = Modifier
        .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
        .pointerInput(Unit) {
          detectDragGestures { change, dragAmount ->
            change.consume()
            offsetX = (offsetX + dragAmount.x).coerceIn(0f, 900f)
            offsetY = (offsetY + dragAmount.y).coerceIn(0f, 1800f)
          }
        }
    ) {
      if (!isExpanded) {
        Surface(
          onClick = { viewModel.toggleFloatingAdminPanel() },
          shape = RoundedCornerShape(99.dp),
          color = ObsidianBlack.copy(alpha = 0.88f),
          border = BorderStroke(1.2.dp, SilverAccent.copy(alpha = 0.7f)),
          shadowElevation = 10.dp,
          modifier = Modifier.testTag("floating_admin_pill")
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Icon(Icons.Filled.AdminPanelSettings, contentDescription = strings.adminFloatingPanelTitle, tint = AmberWarning, modifier = Modifier.size(18.dp))
            Text(
              text = if (role == "NONE") "ADMIN" else role,
              color = PureWhiteText,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      } else {
        GlassCard(
          containerColor = ObsidianBlack.copy(alpha = 0.95f),
          borderColor = SilverAccent.copy(alpha = 0.55f),
          modifier = Modifier
            .width(336.dp)
            .heightIn(max = 510.dp)
            .testTag("floating_admin_panel")
        ) {
          Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
              Icon(Icons.Filled.Security, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                "${strings.adminFloatingPanelTitle} ($role)",
                color = PureWhiteText,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                modifier = Modifier.weight(1f)
              )
              IconButton(
                onClick = {
                  viewModel.toggleFloatingAdminPanel()
                  viewModel.setActiveTab(MainTab.OWNER_DASHBOARD)
                },
                modifier = Modifier.size(32.dp)
              ) {
                Icon(Icons.Filled.OpenInFull, contentDescription = strings.ownerDashboard, tint = SilverAccent, modifier = Modifier.size(16.dp))
              }
              IconButton(
                onClick = { viewModel.toggleFloatingAdminPanel() },
                modifier = Modifier.size(32.dp)
              ) {
                Icon(Icons.Filled.Minimize, contentDescription = "Minimize", tint = SilverAccent, modifier = Modifier.size(18.dp))
              }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              FilterChip(selected = panelTab == 0, onClick = { panelTab = 0 }, label = { Text(strings.modTabLabel, fontSize = 11.sp) })
              FilterChip(selected = panelTab == 1, onClick = { panelTab = 1 }, label = { Text("${strings.appealsTabLabel} (${restrictions.count { it.appealStatus == "PENDING" }})", fontSize = 11.sp) })
              FilterChip(selected = panelTab == 2, onClick = { panelTab = 2 }, label = { Text(strings.redeemTabLabel, fontSize = 11.sp) })
            }

            Column(
              modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 370.dp)
                .verticalScroll(rememberScrollState()),
              verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              when (panelTab) {
                0 -> {
                  // Invisible Mode in Selected Server
                  Surface(
                    color = CharcoalElevated,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                      val isInvActive = invisibleSrvSet.contains(selectedInvisibleSrvId)
                      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Icon(
                          if (isInvActive) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                          contentDescription = null,
                          tint = if (isInvActive) AmberWarning else SilverAccent,
                          modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                          strings.invisibleServerHeader,
                          fontWeight = FontWeight.Bold,
                          fontSize = 10.sp,
                          color = PureWhiteText,
                          modifier = Modifier.weight(1f)
                        )
                        Text(
                          if (isInvActive) strings.invisibleActiveBadge else strings.invisibleOffBadge,
                          fontWeight = FontWeight.Bold,
                          fontSize = 9.sp,
                          color = if (isInvActive) AmberWarning else EmeraldSuccess
                        )
                      }
                      Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                      ) {
                        servers.forEach { srv ->
                          val srvInv = invisibleSrvSet.contains(srv.id)
                          FilterChip(
                            selected = selectedInvisibleSrvId == srv.id,
                            onClick = { selectedInvisibleSrvId = srv.id },
                            label = {
                              Text(
                                if (srvInv) "${srv.name} (Off-Radar)" else srv.name,
                                fontSize = 10.sp
                              )
                            }
                          )
                        }
                      }
                      Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                          onClick = { viewModel.toggleInvisibleInServer(selectedInvisibleSrvId) },
                          enabled = selectedInvisibleSrvId.isNotBlank(),
                          colors = ButtonDefaults.buttonColors(
                            containerColor = if (isInvActive) AmberWarning else MaterialTheme.colorScheme.primary
                          ),
                          modifier = Modifier.weight(1f).height(34.dp).testTag("floating_toggle_invisible_btn"),
                          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                          Text(
                            strings.toggleInvisibleBtn,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isInvActive) ObsidianBlack else Color.White
                          )
                        }
                        FilledTonalButton(
                          onClick = { viewModel.grantAllBadgesToSelf() },
                          modifier = Modifier.weight(1f).height(34.dp).testTag("floating_all_badges_me_btn"),
                          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                          Text(strings.giveAllBadgesMeBtn, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                      }
                    }
                  }

                  OutlinedTextField(
                    value = targetUserQuery,
                    onValueChange = { targetUserQuery = it },
                    label = { Text(strings.searchTargetHint) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                  )
                  val matched = remember(targetUserQuery, allUsers) {
                    if (targetUserQuery.isBlank()) allUsers.filter { !it.isOwner }.take(3)
                    else allUsers.filter {
                      it.username.contains(targetUserQuery, ignoreCase = true) ||
                        it.displayName.contains(targetUserQuery, ignoreCase = true)
                    }.take(3)
                  }
                  OutlinedTextField(
                    value = lockReason,
                    onValueChange = { lockReason = it },
                    label = { Text(strings.lockReasonLabel) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                  )
                  OutlinedTextField(
                    value = lockMsg,
                    onValueChange = { lockMsg = it },
                    label = { Text(strings.lockMsgLabel) },
                    modifier = Modifier.fillMaxWidth()
                  )
                  OutlinedTextField(
                    value = lockMinutesText,
                    onValueChange = { lockMinutesText = it.filter { c -> c.isDigit() } },
                    label = { Text(strings.durationMinutesLabel) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                  )

                  matched.forEach { u ->
                    Surface(
                      color = CharcoalElevated,
                      shape = RoundedCornerShape(10.dp),
                      modifier = Modifier.fillMaxWidth()
                    ) {
                      Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("@${u.username} • ${u.displayName} (${u.subscriptionTier})", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = PureWhiteText)
                        Row(
                          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                          horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                          Button(
                            onClick = {
                              val mins = lockMinutesText.toLongOrNull()?.coerceAtLeast(1L) ?: 15L
                              viewModel.applyUserRestriction(u.id, lockReason, lockMsg, mins)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AmberWarning),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                          ) {
                            Text("Lock ${lockMinutesText}m", fontSize = 10.sp, color = ObsidianBlack, fontWeight = FontWeight.Bold)
                          }
                          OutlinedButton(
                            onClick = { viewModel.grantXit(u.id, 250L) },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                          ) {
                            Text("+250 XIT", fontSize = 10.sp)
                          }
                          OutlinedButton(
                            onClick = { viewModel.grantSubscription(u.id, "ASTRAL") },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                          ) {
                            Text(strings.giftAstralBtn, fontSize = 10.sp, color = AstralViolet, fontWeight = FontWeight.Bold)
                          }
                          OutlinedButton(
                            onClick = { viewModel.grantSubscription(u.id, "ASTRIX") },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                          ) {
                            Text(strings.giftAstrixBtn, fontSize = 10.sp, color = AstrixGold, fontWeight = FontWeight.Bold)
                          }
                          OutlinedButton(
                            onClick = { viewModel.grantSubscription(u.id, "FREE") },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                          ) {
                            Text(strings.giftFreeBtn, fontSize = 10.sp, color = SilverAccent)
                          }
                        }
                        Row(
                          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                          horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                          FilledTonalButton(
                            onClick = { viewModel.grantAllBadgesByUsername(u.username) },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                          ) {
                            Text(strings.allBadgesBtn, fontSize = 10.sp)
                          }
                          OutlinedButton(
                            onClick = { viewModel.toggleBan(u.id, !u.isBanned) },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                          ) {
                            Text(if (u.isBanned) "Unban" else "Ban", fontSize = 10.sp, color = RoseError)
                          }
                          if (!u.isOwner && u.id != currentUser?.id) {
                            OutlinedButton(
                              onClick = { deleteConfirmTarget = u },
                              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                              modifier = Modifier.height(30.dp)
                            ) {
                              Text(strings.deleteAccountBtn, fontSize = 10.sp, color = RoseError, fontWeight = FontWeight.Bold)
                            }
                          }
                        }
                      }
                    }
                  }
                }
                1 -> {
                  val pendingAppeals = restrictions.filter { it.isActive || it.appealStatus == "PENDING" }
                  if (pendingAppeals.isEmpty() && reports.isEmpty()) {
                    Text(strings.noAppealsReportsMsg, fontSize = 12.sp, color = SilverMuted)
                  }
                  pendingAppeals.forEach { r ->
                    Surface(color = CharcoalElevated, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                      Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("@${r.username} • ${r.appealStatus}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("${strings.lockReasonLabel}: ${r.reason}", fontSize = 11.sp, color = SilverAccent)
                        if (r.appealMessage.isNotBlank()) {
                          Text("${strings.appealsTabLabel}: ${r.appealMessage}", fontSize = 11.sp, color = CyanInfo)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                          Button(
                            onClick = { viewModel.liftRestriction(r, approve = true) },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            modifier = Modifier.height(30.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp)
                          ) { Text(strings.liftOrApproveBtn, fontSize = 10.sp) }
                          if (r.appealStatus == "PENDING") {
                            OutlinedButton(
                              onClick = { viewModel.liftRestriction(r, approve = false) },
                              modifier = Modifier.height(30.dp),
                              contentPadding = PaddingValues(horizontal = 10.dp)
                            ) { Text(strings.rejectBtn, fontSize = 10.sp, color = RoseError) }
                          }
                        }
                      }
                    }
                  }
                  reports.filter { it.status == "OPEN" }.forEach { rep ->
                    Surface(color = CharcoalElevated, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                      Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("${strings.reportMessage}: ${rep.reason}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("${rep.reporterName}: ${rep.details}", fontSize = 11.sp, color = SilverAccent)
                        Button(
                          onClick = { viewModel.resolveReport(rep, "RESOLVED", "Resolved via Floating Admin") },
                          modifier = Modifier.height(30.dp),
                          contentPadding = PaddingValues(horizontal = 10.dp)
                        ) { Text(strings.resolveDoneBtn, fontSize = 10.sp) }
                      }
                    }
                  }
                }
                2 -> {
                  OutlinedTextField(
                    value = newCode,
                    onValueChange = { newCode = it.uppercase() },
                    label = { Text(strings.newRedeemCodeLabel) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                  )
                  Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                      value = newCodeXit,
                      onValueChange = { newCodeXit = it.filter { c -> c.isDigit() } },
                      label = { Text("XIT") },
                      singleLine = true,
                      modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                      value = newCodeBoost,
                      onValueChange = { newCodeBoost = it.filter { c -> c.isDigit() } },
                      label = { Text("Boost") },
                      singleLine = true,
                      modifier = Modifier.weight(1f)
                    )
                  }
                  Button(
                    onClick = {
                      viewModel.createRedeemCode(
                        code = newCode,
                        rewardXit = newCodeXit.toLongOrNull() ?: 250L,
                        rewardBoosts = newCodeBoost.toIntOrNull() ?: 0,
                        maxUses = 100
                      ) { newCode = "" }
                    },
                    enabled = newCode.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(42.dp)
                  ) {
                    Text(strings.createRedeemBtn, fontSize = 12.sp)
                  }
                }
              }
            }
          }
        }
      }
    }

    deleteConfirmTarget?.let { target ->
      AlertDialog(
        onDismissRequest = { deleteConfirmTarget = null },
        title = { Text(strings.confirmDeleteTitle, fontWeight = FontWeight.Bold) },
        text = { Text("${strings.confirmDeleteMsg} @${target.username}?") },
        confirmButton = {
          Button(
            onClick = {
              viewModel.deleteUserAccount(target.id)
              deleteConfirmTarget = null
            },
            colors = ButtonDefaults.buttonColors(containerColor = RoseError)
          ) { Text(strings.deleteAccountBtn, color = Color.White) }
        },
        dismissButton = {
          TextButton(onClick = { deleteConfirmTarget = null }) { Text(strings.cancel) }
        }
      )
    }
  }
}
