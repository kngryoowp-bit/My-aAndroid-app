package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.ChannelEntity
import com.example.data.model.ForumPostEntity
import com.example.data.model.UserEntity
import com.example.ui.XChatViewModel
import com.example.ui.theme.*
import com.example.utils.CloudMediaHelper
import java.text.NumberFormat
import java.util.Locale

private val ForumTagOptions = listOf(
  "Meta" to "❗",
  "Games" to "🎮",
  "Guide" to "📘",
  "Dev" to "💻",
  "Media" to "🎬",
  "Discussion" to "💬"
)

private enum class ForumSortOption {
  RECENT,
  TOP_REACTED,
  MOST_REPLIED
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ForumChannelScreen(
  viewModel: XChatViewModel,
  serverName: String,
  channel: ChannelEntity,
  allUsers: List<UserEntity>,
  onOpenServerMenu: () -> Unit
) {
  val context = LocalContext.current
  val strings = LocalStrings.current
  val posts by viewModel.currentForumPosts.collectAsState()
  val replies by viewModel.currentForumReplies.collectAsState()
  val activePostId by viewModel.activeForumPostId.collectAsState()
  val isUploadingMedia by viewModel.isUploadingMedia.collectAsState()
  val recentLabel = tr("Latest", "Terbaru", "Terkini", "最新")
  val topReactedLabel = tr("Top Reacted", "Reaksi Terbanyak", "Reaksi Terbanyak", "リアクション順")
  val mostRepliedLabel = tr("Most Discussed", "Diskusi Terbanyak", "Perbincangan Terbanyak", "返信順")
  fun sortLabelFor(opt: ForumSortOption) = when (opt) {
    ForumSortOption.RECENT -> recentLabel
    ForumSortOption.TOP_REACTED -> topReactedLabel
    ForumSortOption.MOST_REPLIED -> mostRepliedLabel
  }

  var showSearchBar by remember { mutableStateOf(false) }
  var searchText by remember { mutableStateOf("") }
  var sortOption by remember { mutableStateOf(ForumSortOption.RECENT) }
  var showSortMenu by remember { mutableStateOf(false) }
  var selectedTagFilter by remember { mutableStateOf<String?>(null) }
  var showTagsSheet by remember { mutableStateOf(false) }
  var showCreateDialog by remember { mutableStateOf(false) }

  val filteredPosts = remember(posts, searchText, sortOption, selectedTagFilter) {
    posts
      .filter { p ->
        (selectedTagFilter == null || p.tagLabel.equals(selectedTagFilter, ignoreCase = true)) &&
          (searchText.isBlank() ||
            p.title.contains(searchText, ignoreCase = true) ||
            p.content.contains(searchText, ignoreCase = true) ||
            p.authorName.contains(searchText, ignoreCase = true))
      }
      .sortedWith(
        compareByDescending<ForumPostEntity> { it.isPinned }.thenComparator { a, b ->
          when (sortOption) {
            ForumSortOption.RECENT -> b.createdAt.compareTo(a.createdAt)
            ForumSortOption.TOP_REACTED -> b.reactionCount.compareTo(a.reactionCount)
            ForumSortOption.MOST_REPLIED -> b.replyCount.compareTo(a.replyCount)
          }
        }
      )
  }

  val inspectedPost = remember(posts, activePostId) {
    posts.firstOrNull { it.id == activePostId }
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    Column(modifier = Modifier.fillMaxSize()) {
      // Top Bar styled like Discord Forum header
      Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
      ) {
        Column {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            IconButton(
              onClick = onOpenServerMenu,
              modifier = Modifier.size(40.dp).testTag("forum_menu_btn")
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = tr("Open Server Menu", "Buka Server Menu", "Buka Menu Pelayan", "サーバーメニューを開く"),
                tint = MaterialTheme.colorScheme.onSurface
              )
            }
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
              imageVector = Icons.Filled.Forum,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = channel.name,
              fontSize = 17.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.width(2.dp))
            Icon(
              imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.weight(1f))
            IconButton(
              onClick = { showSearchBar = !showSearchBar },
              modifier = Modifier.size(40.dp)
            ) {
              Icon(
                imageVector = if (showSearchBar) Icons.Filled.Close else Icons.Filled.Search,
                contentDescription = tr("Search Threads", "Cari Thread", "Cari Topik", "スレッド検索"),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          if (showSearchBar) {
            OutlinedTextField(
              value = searchText,
              onValueChange = { searchText = it },
              placeholder = { Text(tr("Search topics in #${channel.name}...", "Cari topik di #${channel.name}...", "Cari topik di #${channel.name}...", "#${channel.name} のトピックを検索..."), fontSize = 13.sp) },
              leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
              singleLine = true,
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
            )
          }

          // Filter row: Sort & View + Tags
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box {
              Surface(
                onClick = { showSortMenu = true },
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(Icons.Filled.SwapVert, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurface)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = "${tr("Sort & View", "Urutkan", "Susun", "並び替え")} · ${sortLabelFor(sortOption)}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                  )
                }
              }

              DropdownMenu(
                expanded = showSortMenu,
                onDismissRequest = { showSortMenu = false }
              ) {
                ForumSortOption.entries.forEach { opt ->
                  DropdownMenuItem(
                    text = { Text(sortLabelFor(opt)) },
                    onClick = {
                      sortOption = opt
                      showSortMenu = false
                    },
                    trailingIcon = {
                      if (sortOption == opt) Icon(Icons.Filled.Check, contentDescription = null)
                    }
                  )
                }
              }
            }

            Surface(
              onClick = { showTagsSheet = true },
              shape = RoundedCornerShape(10.dp),
              color = if (selectedTagFilter != null) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
              border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (selectedTagFilter != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
              )
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Filled.LocalOffer, contentDescription = null, modifier = Modifier.size(15.dp), tint = MaterialTheme.colorScheme.onSurface)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = selectedTagFilter ?: "Tags",
                  fontSize = 13.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = MaterialTheme.colorScheme.onSurface
                )
              }
            }
          }
        }
      }

      if (showTagsSheet) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          FilterChip(
            selected = selectedTagFilter == null,
            onClick = { selectedTagFilter = null; showTagsSheet = false },
            label = { Text(tr("All Tags", "Semua Tag", "Semua Tag", "すべてのタグ"), fontSize = 12.sp) }
          )
          ForumTagOptions.forEach { (tag, emoji) ->
            FilterChip(
              selected = selectedTagFilter == tag,
              onClick = {
                selectedTagFilter = if (selectedTagFilter == tag) null else tag
                showTagsSheet = false
              },
              label = { Text("$emoji $tag", fontSize = 12.sp) }
            )
          }
        }
      }

      if (filteredPosts.isEmpty()) {
        Box(
          modifier = Modifier.fillMaxSize().padding(24.dp),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Filled.Forum, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp))
            Text(tr("No forum threads in #${channel.name} yet", "Belum ada thread forum di #${channel.name}", "Belum ada topik forum di #${channel.name}", "#${channel.name} にスレッドがありません"), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            Text(tr("Tap the + button at bottom right to start a discussion.", "Tekan tombol + di kanan bawah untuk memulai topik diskusi baru.", "Ketik butang + di kanan bawah untuk mulakan topik baharu.", "右下の＋ボタンから新しいスレッドを作成できます。"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 84.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          items(filteredPosts, key = { it.id }) { post ->
            val liveAuthor = allUsers.firstOrNull { it.id == post.authorId }
            ForumThreadCard(
              post = post,
              authorDisplayName = liveAuthor?.displayName ?: post.authorName,
              onClick = { viewModel.openForumPost(post.id) },
              onReactClick = { viewModel.toggleForumReaction(post) }
            )
          }
        }
      }
    }

    // Floating '+' Create Forum Post FAB
    FloatingActionButton(
      onClick = { showCreateDialog = true },
      containerColor = MaterialTheme.colorScheme.surfaceVariant,
      contentColor = MaterialTheme.colorScheme.onSurface,
      shape = RoundedCornerShape(16.dp),
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(16.dp)
        .testTag("create_forum_post_fab")
    ) {
      Icon(Icons.Filled.Add, contentDescription = tr("Create Forum Thread", "Buat Thread Forum", "Cipta Topik Forum", "スレッド作成"))
    }
  }

  // Create Forum Post Dialog
  if (showCreateDialog) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var selectedTag by remember { mutableStateOf(ForumTagOptions.first()) }
    var pickedCoverUri by remember { mutableStateOf<String?>(null) }
    var isPinned by remember { mutableStateOf(false) }

    val coverPicker = rememberLauncherForActivityResult(
      contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
      if (uri != null) {
        viewModel.prepareAndPickMedia(uri, maxDim = 960) { cloudUri ->
          pickedCoverUri = cloudUri
        }
      }
    }

    AlertDialog(
      onDismissRequest = { showCreateDialog = false },
      title = { Text(tr("Create Thread in #${channel.name}", "Buat Thread di #${channel.name}", "Cipta Topik di #${channel.name}", "#${channel.name} にスレッド作成"), fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text(tr("Thread Title", "Judul Thread", "Tajuk Topik", "スレッドタイトル")) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = content,
            onValueChange = { content = it },
            label = { Text(tr("Discussion Content", "Isi Pembahasan", "Kandungan Perbincangan", "本文")) },
            minLines = 3,
            maxLines = 5,
            modifier = Modifier.fillMaxWidth()
          )
          Text(tr("Select Thread Tag:", "Pilih Tag Thread:", "Pilih Tag Topik:", "タグを選択:"), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            ForumTagOptions.forEach { pair ->
              FilterChip(
                selected = selectedTag == pair,
                onClick = { selectedTag = pair },
                label = { Text("${pair.second} ${pair.first}", fontSize = 11.sp) }
              )
            }
          }
          OutlinedButton(
            onClick = {
              coverPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            },
            enabled = !isUploadingMedia,
            modifier = Modifier.fillMaxWidth()
          ) {
            Icon(Icons.Filled.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              if (isUploadingMedia) tr("Uploading image...", "Mengunggah gambar...", "Memuat naik imej...", "アップロード中...")
              else if (pickedCoverUri != null) tr("Cover Selected (Change)", "Cover Terpilih (Ganti)", "Muka Dipilih (Tukar)", "カバー変更")
              else tr("Add 16:9 Cover (Gallery)", "Tambah Cover 16:9 (Galeri)", "Tambah Muka 16:9 (Galeri)", "16:9 カバー追加"),
              fontSize = 12.sp
            )
          }
          if (!pickedCoverUri.isNullOrBlank()) {
            val coverPreviewReq = remember(pickedCoverUri) {
              ImageRequest.Builder(context)
                .data(CloudMediaHelper.resolveCoilModel(pickedCoverUri))
                .crossfade(false)
                .build()
            }
            AsyncImage(
              model = coverPreviewReq,
              contentDescription = "Cover Preview",
              contentScale = ContentScale.Crop,
              modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF141518))
            )
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(tr("Pin Thread", "Sematkan Thread (Pin)", "Semat Topik (Pin)", "スレッドを固定"), fontSize = 12.sp)
            Switch(checked = isPinned, onCheckedChange = { isPinned = it })
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.createForumPost(
              channelId = channel.id,
              title = title,
              content = content,
              imageUri = pickedCoverUri,
              tagLabel = selectedTag.first,
              tagEmoji = selectedTag.second,
              isPinned = isPinned
            ) {
              showCreateDialog = false
            }
          },
          enabled = title.isNotBlank() && !isUploadingMedia
        ) {
          Text(tr("Post", "Posting", "Hantar", "投稿"))
        }
      },
      dismissButton = {
        TextButton(onClick = { showCreateDialog = false }) { Text(strings.cancel) }
      }
    )
  }

  // Thread Detail & Replies Modal
  if (inspectedPost != null) {
    var replyText by remember { mutableStateOf("") }
    Dialog(
      onDismissRequest = { viewModel.openForumPost(null) },
      properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
      Scaffold(
        topBar = {
          TopAppBar(
            title = {
              Text(
                text = inspectedPost.title,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            },
            navigationIcon = {
              IconButton(onClick = { viewModel.openForumPost(null) }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.close)
              }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
          )
        },
        containerColor = MaterialTheme.colorScheme.background
      ) { innerPadding ->
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
        ) {
          LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            item {
              Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
              ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                  val author = allUsers.firstOrNull { it.id == inspectedPost.authorId }
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    UserAvatar(
                      avatarUri = author?.avatarUri ?: inspectedPost.authorAvatarUri,
                      displayName = author?.displayName ?: inspectedPost.authorName,
                      size = 32.dp,
                      showStatus = true,
                      presenceStatus = author?.presenceStatus ?: "ONLINE",
                      lastSeenAt = author?.lastSeenAt ?: 0L,
                      userId = inspectedPost.authorId
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                      Text(
                        text = author?.displayName ?: inspectedPost.authorName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = RoseError
                      )
                      Text(
                        text = "${formatRelativeTime(inspectedPost.createdAt)} • ${inspectedPost.tagEmoji} ${inspectedPost.tagLabel}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                      )
                    }
                  }
                  Text(
                    text = inspectedPost.title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface
                  )
                  if (!inspectedPost.imageUri.isNullOrBlank()) {
                    val detailImgReq = remember(inspectedPost.imageUri) {
                      ImageRequest.Builder(context)
                        .data(CloudMediaHelper.resolveCoilModel(inspectedPost.imageUri))
                        .crossfade(false)
                        .build()
                    }
                    AsyncImage(
                      model = detailImgReq,
                      contentDescription = inspectedPost.title,
                      contentScale = ContentScale.Crop,
                      modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF141518))
                    )
                  }
                  if (inspectedPost.content.isNotBlank()) {
                    Text(
                      text = inspectedPost.content,
                      fontSize = 14.sp,
                      color = MaterialTheme.colorScheme.onSurface
                    )
                  }
                }
              }
            }

            item {
              Text(
                text = "${tr("REPLIES", "BALASAN", "BALASAN", "返信")} (${replies.size})",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            items(replies, key = { it.id }) { rep ->
              val repUser = allUsers.firstOrNull { it.id == rep.authorId }
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier.padding(12.dp),
                  verticalAlignment = Alignment.Top
                ) {
                  UserAvatar(
                    avatarUri = repUser?.avatarUri ?: rep.authorAvatarUri,
                    displayName = repUser?.displayName ?: rep.authorName,
                    size = 32.dp
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Text(
                        text = repUser?.displayName ?: rep.authorName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                      )
                      Spacer(modifier = Modifier.width(8.dp))
                      Text(
                        text = formatRelativeTime(rep.createdAt),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                      )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                      text = rep.content,
                      fontSize = 13.sp,
                      color = MaterialTheme.colorScheme.onSurface
                    )
                  }
                }
              }
            }
          }

          Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 4.dp) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              OutlinedTextField(
                value = replyText,
                onValueChange = { replyText = it },
                placeholder = { Text(tr("Write a reply to thread...", "Tulis balasan ke thread...", "Tulis balasan ke topik...", "スレッドに返信を入力..."), fontSize = 13.sp) },
                singleLine = true,
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.weight(1f)
              )
              Spacer(modifier = Modifier.width(8.dp))
              IconButton(
                onClick = {
                  viewModel.addForumReply(channel.id, inspectedPost.id, replyText) {
                    replyText = ""
                  }
                },
                enabled = replyText.isNotBlank(),
                modifier = Modifier
                  .size(44.dp)
                  .clip(CircleShape)
                  .background(MaterialTheme.colorScheme.primary)
              ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = strings.sendBtn, tint = Color.White, modifier = Modifier.size(18.dp))
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun ForumThreadCard(
  post: ForumPostEntity,
  authorDisplayName: String,
  onClick: () -> Unit,
  onReactClick: () -> Unit
) {
  val context = LocalContext.current
  val replyFormatted = remember(post.replyCount) {
    NumberFormat.getNumberInstance(Locale.US).format(post.replyCount).replace(",", "")
  }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .clickable(onClick = onClick),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
  ) {
    Column(
      modifier = Modifier.padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      // Header: Pin icon + Author + Relative time
      Row(verticalAlignment = Alignment.CenterVertically) {
        if (post.isPinned) {
          Box(
            modifier = Modifier
              .size(22.dp)
              .clip(CircleShape)
              .background(Color(0xFF5865F2)),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Filled.PushPin, contentDescription = "Pinned", tint = Color.White, modifier = Modifier.size(12.dp))
          }
          Spacer(modifier = Modifier.width(8.dp))
        }
        Text(
          text = authorDisplayName,
          fontSize = 13.sp,
          fontWeight = FontWeight.SemiBold,
          color = RoseError
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = formatRelativeTime(post.createdAt),
          fontSize = 12.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      // Bold Thread Title
      Text(
        text = post.title,
        fontSize = 16.sp,
        fontWeight = FontWeight.ExtraBold,
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis
      )

      // 16:9 Cover Banner with bottom-left translucent Tag Pill overlay
      val cardBrush = when (post.tagLabel.lowercase()) {
        "meta" -> Brush.linearGradient(listOf(Color(0xFF0EA5E9), Color(0xFF4F46E5)))
        "games" -> Brush.linearGradient(listOf(Color(0xFF7C3AED), Color(0xFFEC4899)))
        "dev" -> Brush.linearGradient(listOf(Color(0xFF059669), Color(0xFF0284C7)))
        else -> Brush.linearGradient(listOf(Color(0xFF312E81), Color(0xFF6D28D9)))
      }

      Box(
        modifier = Modifier
          .fillMaxWidth()
          .aspectRatio(16f / 9f)
          .clip(RoundedCornerShape(12.dp))
          .background(if (!post.imageUri.isNullOrBlank()) Brush.linearGradient(listOf(Color(0xFF141518), Color(0xFF1E1F22))) else cardBrush)
      ) {
        if (!post.imageUri.isNullOrBlank()) {
          val cardImgReq = remember(post.imageUri) {
            ImageRequest.Builder(context)
              .data(CloudMediaHelper.resolveCoilModel(post.imageUri))
              .crossfade(false)
              .build()
          }
          AsyncImage(
            model = cardImgReq,
            contentDescription = post.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
          )
        } else {
          Column(
            modifier = Modifier
              .fillMaxSize()
              .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(
              text = post.title.uppercase(),
              color = Color.White,
              fontSize = 20.sp,
              fontWeight = FontWeight.Black,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis
            )
            if (post.content.isNotBlank()) {
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = post.content,
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 12.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
              )
            }
          }
        }

        // Translucent bottom-left tag badge
        Surface(
          color = Color.Black.copy(alpha = 0.65f),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .align(Alignment.BottomStart)
            .padding(8.dp)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(post.tagEmoji, fontSize = 11.sp)
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = post.tagLabel,
              color = Color.White,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }

      // Bottom Footer: replyCount left, reactionCount pill right
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Filled.ChatBubble,
            contentDescription = tr("Replies", "Balasan", "Balasan", "返信"),
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = replyFormatted,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Surface(
          onClick = onReactClick,
          shape = RoundedCornerShape(10.dp),
          color = MaterialTheme.colorScheme.surfaceVariant
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(post.reactionEmoji, fontSize = 13.sp)
            Spacer(modifier = Modifier.width(5.dp))
            Text(
              text = "${post.reactionCount}",
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
        }
      }
    }
  }
}

private fun formatRelativeTime(createdAt: Long): String {
  val diff = (System.currentTimeMillis() - createdAt).coerceAtLeast(0L)
  val mins = diff / 60_000L
  val hours = mins / 60L
  val days = hours / 24L
  return when {
    mins < 1L -> "just now"
    mins < 60L -> "${mins}m ago"
    hours < 24L -> "${hours}h ago"
    else -> "${days}d ago"
  }
}
