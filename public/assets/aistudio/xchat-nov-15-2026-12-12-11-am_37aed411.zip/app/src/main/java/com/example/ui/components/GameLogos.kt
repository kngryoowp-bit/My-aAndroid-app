package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class SupportedGame(
  val id: String,
  val name: String,
  val genre: String,
  val primaryColor: Color,
  val secondaryColor: Color
)

object GameCatalog {
  val games = listOf(
    SupportedGame("minecraft", "Minecraft", "Sandbox", Color(0xFF4CAF50), Color(0xFF5D4037)),
    SupportedGame("mobile_legends", "Mobile Legends", "MOBA", Color(0xFF2563EB), Color(0xFFF59E0B)),
    SupportedGame("valorant", "Valorant", "FPS / Shooter", Color(0xFFFF4655), Color(0xFF1F2937)),
    SupportedGame("genshin", "Genshin Impact", "RPG / Open World", Color(0xFF38BDF8), Color(0xFFFDE047)),
    SupportedGame("pubg", "PUBG Mobile", "Battle Royale", Color(0xFFF59E0B), Color(0xFF292524)),
    SupportedGame("roblox", "Roblox", "Sandbox", Color(0xFF334155), Color(0xFF94A3B8)),
    SupportedGame("free_fire", "Free Fire", "Battle Royale", Color(0xFFEA580C), Color(0xFFFACC15)),
    SupportedGame("gta_v", "GTA V", "Action / RP", Color(0xFF16A34A), Color(0xFF111827)),
    SupportedGame("lol", "League of Legends", "MOBA", Color(0xFF0D9488), Color(0xFFEAB308)),
    SupportedGame("apex", "Apex Legends", "FPS / Battle Royale", Color(0xFFDC2626), Color(0xFF18181B)),
    SupportedGame("fortnite", "Fortnite", "Battle Royale", Color(0xFF2563EB), Color(0xFFA855F7)),
    SupportedGame("marvel_rivals", "Marvel Rivals", "Hero Shooter", Color(0xFFE11D48), Color(0xFFFACC15)),
    SupportedGame("honkai_sr", "Honkai: Star Rail", "Turn-Based RPG", Color(0xFF6366F1), Color(0xFFEC4899)),
    SupportedGame("wuthering_waves", "Wuthering Waves", "Action RPG", Color(0xFF0284C7), Color(0xFF0F172A)),
    SupportedGame("dota2", "Dota 2", "MOBA", Color(0xFFB91C1C), Color(0xFF1F2937)),
    SupportedGame("cs2", "Counter-Strike 2", "Tactical FPS", Color(0xFFF97316), Color(0xFF1E3A8A)),
    SupportedGame("overwatch2", "Overwatch 2", "Hero Shooter", Color(0xFFF59E0B), Color(0xFF475569)),
    SupportedGame("brawl_stars", "Brawl Stars", "Arena Brawler", Color(0xFFFACC15), Color(0xFFDC2626)),
    SupportedGame("clash_royale", "Clash Royale", "Strategy", Color(0xFF3B82F6), Color(0xFFF59E0B)),
    SupportedGame("ea_fc", "EA FC", "Sports / Football", Color(0xFF16A34A), Color(0xFF0F172A)),
    SupportedGame("efootball", "eFootball", "Sports / Football", Color(0xFF1D4ED8), Color(0xFFFACC15)),
    SupportedGame("codm", "Call of Duty Mobile", "FPS / Shooter", Color(0xFF475569), Color(0xFFF59E0B))
  )

  fun find(idOrName: String?): SupportedGame? {
    if (idOrName.isNullOrBlank()) return null
    val clean = idOrName.trim()
    return games.find {
      it.id.equals(clean, ignoreCase = true) || it.name.equals(clean, ignoreCase = true)
    }
  }

  fun findMany(csv: String?): List<SupportedGame> {
    if (csv.isNullOrBlank()) return emptyList()
    return csv.split(",")
      .mapNotNull { find(it) }
      .distinctBy { it.id }
  }
}

@Composable
fun GameLogo(
  gameIdOrName: String,
  size: Dp = 24.dp,
  modifier: Modifier = Modifier
) {
  val game = GameCatalog.find(gameIdOrName)
  val primary = game?.primaryColor ?: Color(0xFF8B5CF6)
  val secondary = game?.secondaryColor ?: Color(0xFF4C1D95)

  Box(
    modifier = modifier
      .size(size)
      .clip(RoundedCornerShape(6.dp))
      .background(Brush.linearGradient(listOf(primary, secondary)))
      .border(1.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(6.dp)),
    contentAlignment = Alignment.Center
  ) {
    Canvas(modifier = Modifier.fillMaxSize().padding(3.dp)) {
      val w = this.size.width
      val h = this.size.height

      when (game?.id) {
        "minecraft" -> {
          drawRect(color = Color(0xFF65C466), topLeft = Offset.Zero, size = Size(w, h * 0.32f))
          drawRect(color = Color(0xFF795548), topLeft = Offset(0f, h * 0.32f), size = Size(w, h * 0.68f))
          drawRect(color = Color(0xFF1B1B1B), topLeft = Offset(w * 0.18f, h * 0.36f), size = Size(w * 0.22f, h * 0.22f))
          drawRect(color = Color(0xFF1B1B1B), topLeft = Offset(w * 0.60f, h * 0.36f), size = Size(w * 0.22f, h * 0.22f))
          drawRect(color = Color(0xFF1B1B1B), topLeft = Offset(w * 0.38f, h * 0.56f), size = Size(w * 0.24f, h * 0.22f))
          drawRect(color = Color(0xFF1B1B1B), topLeft = Offset(w * 0.28f, h * 0.68f), size = Size(w * 0.14f, h * 0.20f))
          drawRect(color = Color(0xFF1B1B1B), topLeft = Offset(w * 0.58f, h * 0.68f), size = Size(w * 0.14f, h * 0.20f))
        }
        "valorant" -> {
          val p1 = Path().apply {
            moveTo(w * 0.12f, h * 0.2f); lineTo(w * 0.55f, h * 0.8f); lineTo(w * 0.35f, h * 0.8f); lineTo(w * 0.12f, h * 0.45f); close()
          }
          val p2 = Path().apply {
            moveTo(w * 0.88f, h * 0.2f); lineTo(w * 0.88f, h * 0.45f); lineTo(w * 0.68f, h * 0.72f); lineTo(w * 0.52f, h * 0.72f); close()
          }
          drawPath(p1, Color.White); drawPath(p2, Color.White)
        }
        "roblox" -> {
          rotate(degrees = 15f) {
            drawRect(color = Color.White, topLeft = Offset(w * 0.16f, h * 0.16f), size = Size(w * 0.68f, h * 0.68f))
            drawRect(color = primary, topLeft = Offset(w * 0.38f, h * 0.38f), size = Size(w * 0.24f, h * 0.24f))
          }
        }
        "genshin", "honkai_sr" -> {
          val star = Path().apply {
            moveTo(w * 0.5f, h * 0.05f); lineTo(w * 0.62f, h * 0.38f); lineTo(w * 0.95f, h * 0.5f)
            lineTo(w * 0.62f, h * 0.62f); lineTo(w * 0.5f, h * 0.95f); lineTo(w * 0.38f, h * 0.62f)
            lineTo(w * 0.05f, h * 0.5f); lineTo(w * 0.38f, h * 0.38f); close()
          }
          drawPath(star, Color.White)
        }
        "mobile_legends" -> {
          val shield = Path().apply {
            moveTo(w * 0.5f, h * 0.08f); lineTo(w * 0.88f, h * 0.24f); lineTo(w * 0.78f, h * 0.72f)
            lineTo(w * 0.5f, h * 0.92f); lineTo(w * 0.22f, h * 0.72f); lineTo(w * 0.12f, h * 0.24f); close()
          }
          drawPath(shield, Color.White.copy(alpha = 0.28f))
          drawRect(color = Color(0xFFFDE047), topLeft = Offset(w * 0.44f, h * 0.16f), size = Size(w * 0.12f, h * 0.68f))
          drawRect(color = Color(0xFFFDE047), topLeft = Offset(w * 0.30f, h * 0.60f), size = Size(w * 0.40f, h * 0.10f))
        }
        "apex" -> {
          val delta = Path().apply {
            moveTo(w * 0.5f, h * 0.10f); lineTo(w * 0.90f, h * 0.88f); lineTo(w * 0.68f, h * 0.88f)
            lineTo(w * 0.5f, h * 0.48f); lineTo(w * 0.32f, h * 0.88f); lineTo(w * 0.10f, h * 0.88f); close()
          }
          drawPath(delta, Color.White)
        }
        "pubg", "codm" -> {
          drawCircle(color = Color.White, radius = w * 0.35f, style = Stroke(width = w * 0.10f))
          drawLine(Color.White, Offset(w * 0.5f, h * 0.05f), Offset(w * 0.5f, h * 0.32f), strokeWidth = w * 0.09f)
          drawLine(Color.White, Offset(w * 0.5f, h * 0.68f), Offset(w * 0.5f, h * 0.95f), strokeWidth = w * 0.09f)
          drawLine(Color.White, Offset(w * 0.05f, h * 0.5f), Offset(w * 0.32f, h * 0.5f), strokeWidth = w * 0.09f)
          drawLine(Color.White, Offset(w * 0.68f, h * 0.5f), Offset(w * 0.95f, h * 0.5f), strokeWidth = w * 0.09f)
        }
        "fortnite" -> {
          drawRect(color = Color.White, topLeft = Offset(w * 0.25f, h * 0.12f), size = Size(w * 0.20f, h * 0.76f))
          drawRect(color = Color.White, topLeft = Offset(w * 0.25f, h * 0.12f), size = Size(w * 0.54f, h * 0.18f))
          drawRect(color = Color.White, topLeft = Offset(w * 0.25f, h * 0.42f), size = Size(w * 0.42f, h * 0.16f))
        }
        "marvel_rivals" -> {
          drawCircle(color = Color.White, radius = w * 0.36f, style = Stroke(width = w * 0.11f))
          val bolt = Path().apply {
            moveTo(w * 0.55f, h * 0.14f); lineTo(w * 0.30f, h * 0.52f); lineTo(w * 0.50f, h * 0.52f)
            lineTo(w * 0.42f, h * 0.86f); lineTo(w * 0.70f, h * 0.46f); lineTo(w * 0.50f, h * 0.46f); close()
          }
          drawPath(bolt, Color(0xFFFACC15))
        }
        "dota2" -> {
          drawRect(color = Color.White.copy(alpha = 0.25f), topLeft = Offset(w * 0.14f, h * 0.14f), size = Size(w * 0.72f, h * 0.72f))
          drawLine(Color.White, Offset(w * 0.18f, h * 0.18f), Offset(w * 0.82f, h * 0.82f), strokeWidth = w * 0.18f)
          drawCircle(Color.White, radius = w * 0.12f, center = Offset(w * 0.72f, h * 0.28f))
          drawCircle(Color.White, radius = w * 0.12f, center = Offset(w * 0.28f, h * 0.72f))
        }
        "cs2" -> {
          drawCircle(color = Color.White, radius = w * 0.38f, style = Stroke(width = w * 0.10f))
          drawCircle(color = Color(0xFFFACC15), radius = w * 0.14f)
        }
        "overwatch2" -> {
          drawArc(
            color = Color.White,
            startAngle = -55f,
            sweepAngle = 290f,
            useCenter = false,
            style = Stroke(width = w * 0.13f)
          )
          drawLine(Color(0xFFF97316), Offset(w * 0.5f, h * 0.55f), Offset(w * 0.28f, h * 0.28f), strokeWidth = w * 0.11f)
          drawLine(Color(0xFFF97316), Offset(w * 0.5f, h * 0.55f), Offset(w * 0.72f, h * 0.28f), strokeWidth = w * 0.11f)
        }
        "ea_fc", "efootball" -> {
          drawCircle(color = Color.White, radius = w * 0.38f, style = Stroke(width = w * 0.10f))
          val hex = Path().apply {
            moveTo(w * 0.5f, h * 0.28f); lineTo(w * 0.70f, h * 0.42f); lineTo(w * 0.62f, h * 0.68f)
            lineTo(w * 0.38f, h * 0.68f); lineTo(w * 0.30f, h * 0.42f); close()
          }
          drawPath(hex, Color.White)
        }
        "clash_royale", "brawl_stars" -> {
          val crown = Path().apply {
            moveTo(w * 0.12f, h * 0.78f); lineTo(w * 0.12f, h * 0.28f); lineTo(w * 0.36f, h * 0.52f)
            lineTo(w * 0.50f, h * 0.16f); lineTo(w * 0.64f, h * 0.52f); lineTo(w * 0.88f, h * 0.28f)
            lineTo(w * 0.88f, h * 0.78f); close()
          }
          drawPath(crown, Color.White)
        }
        "wuthering_waves" -> {
          val wave = Path().apply {
            moveTo(w * 0.08f, h * 0.65f); lineTo(w * 0.30f, h * 0.30f); lineTo(w * 0.50f, h * 0.62f)
            lineTo(w * 0.72f, h * 0.24f); lineTo(w * 0.92f, h * 0.65f)
          }
          drawPath(wave, Color.White, style = Stroke(width = w * 0.14f))
        }
        else -> {
          val crest = Path().apply {
            moveTo(w * 0.5f, h * 0.08f); lineTo(w * 0.84f, h * 0.52f)
            lineTo(w * 0.5f, h * 0.92f); lineTo(w * 0.16f, h * 0.52f); close()
          }
          drawPath(crest, Color.White)
        }
      }
    }
  }
}

@Composable
fun GameBadgePill(gameIdOrName: String) {
  val game = GameCatalog.find(gameIdOrName) ?: return
  Row(
    verticalAlignment = Alignment.CenterVertically,
    modifier = Modifier
      .clip(RoundedCornerShape(6.dp))
      .background(game.primaryColor.copy(alpha = 0.18f))
      .border(1.dp, game.primaryColor.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
      .padding(horizontal = 6.dp, vertical = 3.dp)
  ) {
    GameLogo(gameIdOrName = game.id, size = 16.dp)
    Spacer(modifier = Modifier.width(5.dp))
    Text(
      text = game.name,
      fontSize = 10.sp,
      fontWeight = FontWeight.Bold,
      color = Color.White
    )
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MultiGameBadgesRow(
  supportedGamesCsv: String?,
  modifier: Modifier = Modifier
) {
  val list = GameCatalog.findMany(supportedGamesCsv)
  if (list.isEmpty()) return
  FlowRow(
    modifier = modifier,
    horizontalArrangement = Arrangement.spacedBy(6.dp),
    verticalArrangement = Arrangement.spacedBy(6.dp)
  ) {
    list.forEach { game ->
      GameBadgePill(gameIdOrName = game.id)
    }
  }
}
