package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.MainTab
import com.example.ui.XChatViewModel
import com.example.ui.theme.*
import org.json.JSONObject

@Composable
fun GlobalSearchDialog(
  viewModel: XChatViewModel,
  onDismiss: () -> Unit
) {
  val strings = LocalStrings.current
  val query by viewModel.globalSearchQuery.collectAsState()
  val result by viewModel.globalSearchResult.collectAsState()
  var categoryFilter by remember { mutableStateOf("ALL") }

  LaunchedEffect(Unit) {
    if (query.isNotBlank()) viewModel.performGlobalSearch(query)
  }

  val categories = listOf(
    "ALL" to tr("All", "Semua", "Semua", "すべて"),
    "USER" to tr("Users", "Pengguna", "Pengguna", "ユーザー"),
    "SERVER" to "Server",
    "CHANNEL" to tr("Channels", "Kanal", "Saluran", "チャンネル"),
    "MESSAGE" to tr("Messages", "Pesan", "Mesej", "メッセージ"),
    "STICKER" to "Sticker",
    "GAME" to tr("Games", "Game", "Permainan", "ゲーム")
  )

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    GlassCard(
      containerColor = ObsidianBlack.copy(alpha = 0.95f),
      modifier = Modifier
        .fillMaxWidth(0.94f)
        .fillMaxHeight(0.84f)
    ) {
      Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
          Icon(Icons.Filled.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(8.dp))
          Text(strings.globalSearchTitle, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = PureWhiteText, modifier = Modifier.weight(1f))
          IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, contentDescription = strings.close, tint = PureWhiteText) }
        }

        OutlinedTextField(
          value = query,
          onValueChange = { viewModel.performGlobalSearch(it) },
          placeholder = { Text(tr("Search users, servers, channels, messages, stickers, games...", "Cari pengguna, server, kanal, pesan, sticker, game...", "Cari pengguna, pelayan, saluran, mesej, pelekat, permainan...", "ユーザー、サーバー、チャンネル、メッセージ、スタンプ、ゲームを検索...")) },
          singleLine = true,
          leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
          modifier = Modifier.fillMaxWidth().testTag("global_search_input")
        )

        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          categories.forEach { (key, label) ->
            FilterChip(
              selected = categoryFilter == key,
              onClick = { categoryFilter = key },
              label = { Text(label, fontSize = 11.sp) }
            )
          }
        }

        val userBadge = tr("User", "Pengguna", "Pengguna", "ユーザー")
        LazyColumn(
          modifier = Modifier.weight(1f).fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          if (categoryFilter == "ALL" || categoryFilter == "USER") {
            items(result.users, key = { "u_${it.id}" }) { u ->
              Surface(
                color = CharcoalElevated,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().clickable {
                  viewModel.openUserProfile(u.id)
                  onDismiss()
                }
              ) {
                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                  UserAvatar(u.avatarUri, u.displayName, size = 36.dp)
                  Spacer(modifier = Modifier.width(10.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(u.displayName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PureWhiteText)
                    Text("@${u.username} • Lv.${u.level}", fontSize = 11.sp, color = SilverAccent)
                  }
                  Text(userBadge, fontSize = 10.sp, color = CyanInfo)
                }
              }
            }
          }

          if (categoryFilter == "ALL" || categoryFilter == "SERVER") {
            items(result.servers, key = { "s_${it.id}" }) { srv ->
              Surface(
                color = CharcoalElevated,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().clickable {
                  viewModel.selectServer(srv.id)
                  viewModel.setActiveTab(MainTab.CHANNELS)
                  onDismiss()
                }
              ) {
                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Filled.Dns, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                  Spacer(modifier = Modifier.width(10.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(srv.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PureWhiteText)
                    Text(srv.description, fontSize = 11.sp, color = SilverAccent, maxLines = 1, overflow = TextOverflow.Ellipsis)
                  }
                  Text("Server", fontSize = 10.sp, color = EmeraldSuccess)
                }
              }
            }
          }

          if (categoryFilter == "ALL" || categoryFilter == "CHANNEL") {
            items(result.channels, key = { "c_${it.id}" }) { ch ->
              Surface(
                color = CharcoalElevated,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().clickable {
                  viewModel.selectServer(ch.serverId)
                  viewModel.selectChannel(ch)
                  viewModel.setActiveTab(MainTab.CHANNELS)
                  onDismiss()
                }
              ) {
                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Filled.Tag, contentDescription = null, tint = SilverAccent)
                  Spacer(modifier = Modifier.width(10.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text("#${ch.name}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PureWhiteText)
                    Text(ch.description, fontSize = 11.sp, color = SilverAccent, maxLines = 1, overflow = TextOverflow.Ellipsis)
                  }
                  Text(ch.type.uppercase(), fontSize = 10.sp, color = AmberWarning)
                }
              }
            }
          }

          if (categoryFilter == "ALL" || categoryFilter == "MESSAGE") {
            items(result.messages, key = { "m_${it.id}" }) { msg ->
              Surface(
                color = CharcoalElevated,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(modifier = Modifier.padding(10.dp)) {
                  Text(msg.senderName, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = PureWhiteText)
                  Text(msg.content, fontSize = 12.sp, color = SilverAccent, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
              }
            }
            items(result.dms, key = { "dm_${it.id}" }) { dm ->
              Surface(
                color = CharcoalElevated,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(modifier = Modifier.padding(10.dp)) {
                  Text("${dm.senderName} (DM)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = PureWhiteText)
                  Text(dm.content, fontSize = 12.sp, color = SilverAccent, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
              }
            }
          }

          if (categoryFilter == "ALL" || categoryFilter == "STICKER") {
            items(result.stickers, key = { "stk_${it.id}" }) { stk ->
              Surface(color = CharcoalElevated, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Filled.StickyNote2, contentDescription = null, tint = AmberWarning)
                  Spacer(modifier = Modifier.width(10.dp))
                  Text(stk.name, fontWeight = FontWeight.SemiBold, color = PureWhiteText, fontSize = 13.sp)
                }
              }
            }
          }

          if (categoryFilter == "ALL" || categoryFilter == "GAME") {
            items(result.games, key = { "g_$it" }) { gameName ->
              Surface(
                color = CharcoalElevated,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().clickable {
                  viewModel.setActiveTab(MainTab.GAMES)
                  onDismiss()
                }
              ) {
                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Filled.SportsEsports, contentDescription = null, tint = CyanInfo)
                  Spacer(modifier = Modifier.width(10.dp))
                  Text("Mini Game: $gameName", fontWeight = FontWeight.Bold, color = PureWhiteText, fontSize = 13.sp)
                }
              }
            }
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationCenterSheet(
  viewModel: XChatViewModel,
  onDismiss: () -> Unit
) {
  val strings = LocalStrings.current
  val notifications by viewModel.notifications.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()

  val initialPrefs = remember(currentUser?.notifPrefsJson) {
    runCatching { JSONObject(currentUser?.notifPrefsJson.orEmpty()) }.getOrNull() ?: JSONObject()
  }
  var msgEnabled by remember(initialPrefs) { mutableStateOf(initialPrefs.optBoolean("messages", true)) }
  var mentionEnabled by remember(initialPrefs) { mutableStateOf(initialPrefs.optBoolean("mentions", true)) }
  var gameEnabled by remember(initialPrefs) { mutableStateOf(initialPrefs.optBoolean("games", true)) }
  var friendEnabled by remember(initialPrefs) { mutableStateOf(initialPrefs.optBoolean("friends", true)) }

  fun savePrefs() {
    val obj = JSONObject().apply {
      put("messages", msgEnabled)
      put("mentions", mentionEnabled)
      put("games", gameEnabled)
      put("friends", friendEnabled)
    }
    viewModel.updateNotificationPrefs(obj.toString())
  }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    containerColor = CharcoalSurface,
    contentColor = PureWhiteText,
    sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp)
        .padding(bottom = 24.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Filled.Notifications, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(8.dp))
        Text(strings.notificationCenterTitle, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
        TextButton(onClick = { viewModel.markAllNotificationsRead() }) {
          Text(tr("Mark All Read", "Tandai Dibaca", "Tandai Dibaca", "すべて既読"))
        }
      }

      GlassCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Text(tr("Notification Preferences by Category", "Preferensi Notifikasi Per Kategori", "Keutamaan Pemberitahuan Mengikut Kategori", "カテゴリ別通知設定"), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = SilverAccent)
          Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(tr("Messages & DMs", "Pesan & DM", "Mesej & DM", "メッセージ・DM"), modifier = Modifier.weight(1f), fontSize = 13.sp)
            Switch(checked = msgEnabled, onCheckedChange = { msgEnabled = it; savePrefs() })
          }
          Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(tr("Mentions (@mention)", "Sebutan (@mention)", "Sebutan (@mention)", "メンション (@mention)"), modifier = Modifier.weight(1f), fontSize = 13.sp)
            Switch(checked = mentionEnabled, onCheckedChange = { mentionEnabled = it; savePrefs() })
          }
          Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(tr("Mini Game Invites", "Undangan Mini Game", "Jemputan Permainan Mini", "ミニゲーム招待"), modifier = Modifier.weight(1f), fontSize = 13.sp)
            Switch(checked = gameEnabled, onCheckedChange = { gameEnabled = it; savePrefs() })
          }
          Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(tr("Friend & Follower Requests", "Permintaan Teman & Follower", "Permintaan Rakan & Pengikut", "フレンド＆フォロー通知"), modifier = Modifier.weight(1f), fontSize = 13.sp)
            Switch(checked = friendEnabled, onCheckedChange = { friendEnabled = it; savePrefs() })
          }
        }
      }

      if (notifications.isEmpty()) {
        Box(modifier = Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
          Text(tr("No new notifications yet.", "Belum ada notifikasi baru.", "Belum ada pemberitahuan baharu.", "新しい通知はありません。"), color = SilverMuted, fontSize = 13.sp)
        }
      } else {
        val newBadgeLabel = tr("New", "Baru", "Baharu", "新着")
        LazyColumn(
          modifier = Modifier.fillMaxWidth().heightIn(max = 280.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          items(notifications, key = { it.id }) { notif ->
            Surface(
              color = if (notif.isRead) CharcoalElevated.copy(alpha = 0.6f) else CharcoalElevated,
              shape = RoundedCornerShape(12.dp),
              border = BorderStroke(1.dp, if (notif.isRead) GlassBorderSubtle else MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(notif.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                  if (!notif.isRead) {
                    Badge(containerColor = MaterialTheme.colorScheme.primary) { Text(newBadgeLabel, fontSize = 9.sp) }
                  }
                }
                Text(notif.message, fontSize = 12.sp, color = SilverAccent)
              }
            }
          }
        }
      }
    }
  }
}
