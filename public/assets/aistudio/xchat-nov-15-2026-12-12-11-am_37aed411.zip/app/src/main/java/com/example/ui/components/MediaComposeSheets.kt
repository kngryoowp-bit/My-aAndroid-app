package com.example.ui.components

import android.Manifest
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.GifFavoriteEntity
import com.example.data.model.StickerEntity
import com.example.ui.XChatViewModel
import com.example.ui.theme.*
import com.example.utils.CloudMediaHelper
import com.example.utils.GifResultItem
import com.example.utils.GifSearchClient
import com.example.utils.LocationCandidate
import com.example.utils.LocationHelper
import com.example.utils.VideoInspectionResult
import com.example.utils.VideoTrimHelper
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StickerStudioSheet(
  viewModel: XChatViewModel,
  onSendSticker: (StickerEntity) -> Unit,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val strings = LocalStrings.current
  val stickers by viewModel.allStickers.collectAsState()
  var selectedTab by remember { mutableIntStateOf(0) } // 0=Koleksi, 1=Buat Baru

  var stickerName by remember { mutableStateOf("") }
  var packName by remember { mutableStateOf("Custom Pack") }
  var imageUri by remember { mutableStateOf<String?>(null) }
  var overlayText by remember { mutableStateOf("") }
  var textColor by remember { mutableStateOf(Color.White) }
  var outlineColor by remember { mutableStateOf(Color.Black) }
  var hasGlow by remember { mutableStateOf(true) }
  var hasShadow by remember { mutableStateOf(true) }
  var isShared by remember { mutableStateOf(true) }
  var removeBgChroma by remember { mutableStateOf(false) }
  var chromaHexCsv by remember { mutableStateOf("#FFFFFF,#00FF00") }
  var showTextPicker by remember { mutableStateOf(false) }
  var showOutlinePicker by remember { mutableStateOf(false) }

  val mediaPicker = rememberLauncherForActivityResult(
    ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      viewModel.prepareAndPickMedia(uri, maxDim = 512, preserveTransparency = true, allowGifFree = true) { cloudUri ->
        imageUri = cloudUri
      }
    }
  }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    containerColor = CharcoalSurface,
    contentColor = PureWhiteText,
    sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp)
        .padding(bottom = 24.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Filled.StickyNote2, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          strings.stickerCreatorTitle,
          fontWeight = FontWeight.Bold,
          fontSize = 18.sp,
          modifier = Modifier.weight(1f)
        )
        IconButton(onClick = onDismiss) {
          Icon(Icons.Filled.Close, contentDescription = strings.close)
        }
      }

      TabRow(
        selectedTabIndex = selectedTab,
        containerColor = CharcoalElevated,
        contentColor = PureWhiteText,
        modifier = Modifier.clip(RoundedCornerShape(12.dp))
      ) {
        Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("${tr("Pick Sticker", "Pilih Sticker", "Pilih Pelekat", "スタンプ選択")} (${stickers.size})") })
        Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text(strings.createSticker) })
      }

      if (selectedTab == 0) {
        if (stickers.isEmpty()) {
          GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(
              modifier = Modifier.padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = SilverAccent, modifier = Modifier.size(36.dp))
              Text(tr("No stickers in collection yet.", "Belum ada sticker di koleksi.", "Belum ada pelekat dalam koleksi.", "コレクションにスタンプがありません。"), color = SilverAccent, fontSize = 13.sp)
              Button(onClick = { selectedTab = 1 }) { Text(tr("Create First Sticker", "Buat Sticker Pertama", "Cipta Pelekat Pertama", "最初のスタンプを作成")) }
            }
          }
        } else {
          LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier
              .fillMaxWidth()
              .heightIn(min = 200.dp, max = 380.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            items(stickers, key = { it.id }) { stk ->
              StickerGridTile(
                sticker = stk,
                onSend = {
                  onSendSticker(stk)
                  onDismiss()
                },
                onToggleFav = { viewModel.toggleStickerFavorite(stk) }
              )
            }
          }
        }
      } else {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 460.dp)
            .verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          // Live sticker preview
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(150.dp)
              .clip(RoundedCornerShape(16.dp))
              .background(GlassFillDark)
              .border(1.dp, GlassBorderLight, RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
          ) {
            if (imageUri != null) {
              if (removeBgChroma) {
                RoleIconImage(
                  iconUri = imageUri,
                  chromaKeyColorsCsv = chromaHexCsv,
                  size = 112.dp
                )
              } else {
                AsyncImage(
                  model = CloudMediaHelper.resolveCoilModel(imageUri, context),
                  contentDescription = "Preview Sticker",
                  contentScale = ContentScale.Fit,
                  modifier = Modifier.size(112.dp).clip(RoundedCornerShape(12.dp))
                )
              }
            } else {
              TextButton(
                onClick = {
                  mediaPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
              ) {
                Icon(Icons.Filled.AddPhotoAlternate, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(tr("Pick Sticker Image from Gallery", "Pilih Gambar Sticker dari Galeri", "Pilih Imej Pelekat dari Galeri", "ギャラリーからスタンプ画像を選択"))
              }
            }
            if (overlayText.isNotBlank()) {
              Text(
                text = overlayText,
                style = TextStyle(
                  color = textColor,
                  fontSize = 18.sp,
                  fontWeight = FontWeight.ExtraBold,
                  shadow = if (hasGlow || hasShadow) {
                    Shadow(color = if (hasGlow) textColor else outlineColor, blurRadius = if (hasGlow) 14f else 6f)
                  } else null
                ),
                modifier = Modifier
                  .align(Alignment.BottomCenter)
                  .padding(bottom = 10.dp)
              )
            }
          }

          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
              onClick = { mediaPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
              modifier = Modifier.weight(1f).height(48.dp)
            ) {
              Icon(Icons.Filled.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(tr("Change Image", "Ganti Gambar", "Tukar Imej", "画像を変更"))
            }
            FilterChip(
              selected = removeBgChroma,
              onClick = { removeBgChroma = !removeBgChroma },
              label = { Text(tr("Remove BG", "Hapus Latar", "Buang Latar", "背景透過")) },
              leadingIcon = { Icon(Icons.Filled.AutoFixHigh, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
          }

          OutlinedTextField(
            value = stickerName,
            onValueChange = { stickerName = it },
            label = { Text(tr("Sticker Name", "Nama Sticker", "Nama Pelekat", "スタンプ名")) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = packName,
            onValueChange = { packName = it },
            label = { Text(tr("Sticker Pack Name", "Nama Sticker Pack", "Nama Pek Pelekat", "スタンプパック名")) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = overlayText,
            onValueChange = { overlayText = it.take(32) },
            label = { Text(tr("Overlay Text (Optional)", "Teks Overlay (Opsional)", "Teks Tindihan (Pilihan)", "オーバーレイ文字(任意)")) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            OutlinedButton(onClick = { showTextPicker = true }, modifier = Modifier.weight(1f)) {
              Box(modifier = Modifier.size(14.dp).clip(CircleShape).background(textColor))
              Spacer(modifier = Modifier.width(6.dp))
              Text(tr("Text Color", "Warna Teks", "Warna Teks", "文字色"), fontSize = 12.sp)
            }
            OutlinedButton(onClick = { showOutlinePicker = true }, modifier = Modifier.weight(1f)) {
              Box(modifier = Modifier.size(14.dp).clip(CircleShape).background(outlineColor))
              Spacer(modifier = Modifier.width(6.dp))
              Text(tr("Shadow Color", "Warna Bayangan", "Warna Bayang", "影の色"), fontSize = 12.sp)
            }
          }

          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = hasGlow, onClick = { hasGlow = !hasGlow }, label = { Text("Glow") })
            FilterChip(selected = hasShadow, onClick = { hasShadow = !hasShadow }, label = { Text("Shadow") })
            FilterChip(selected = isShared, onClick = { isShared = !isShared }, label = { Text(tr("Share Publicly", "Bagikan Publik", "Kongsi Umum", "公開共有")) })
          }

          Button(
            onClick = {
              val uri = imageUri ?: return@Button
              viewModel.saveCustomSticker(
                name = stickerName.ifBlank { "Custom Sticker" },
                packName = packName.ifBlank { "Custom Pack" },
                imageUri = uri,
                overlayText = overlayText,
                textColorHex = textColor.value.toLong(),
                outlineColorHex = outlineColor.value.toLong(),
                hasGlow = hasGlow,
                hasShadow = hasShadow,
                isShared = isShared
              ) {
                selectedTab = 0
                stickerName = ""
                overlayText = ""
              }
            },
            enabled = imageUri != null,
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_custom_sticker_btn")
          ) {
            Icon(Icons.Filled.Check, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(tr("Save to Sticker Collection", "Simpan ke Koleksi Sticker", "Simpan ke Koleksi Pelekat", "コレクションに保存"))
          }
        }
      }
    }
  }

  if (showTextPicker) {
    PickColorBottomSheet(
      initialColor = textColor,
      title = tr("Pick Text Color", "Pilih Warna Teks Sticker", "Pilih Warna Teks", "文字色を選択"),
      onDismiss = { showTextPicker = false },
      onSelect = {
        textColor = it
        showTextPicker = false
      }
    )
  }
  if (showOutlinePicker) {
    PickColorBottomSheet(
      initialColor = outlineColor,
      title = tr("Pick Shadow Color", "Pilih Warna Bayangan", "Pilih Warna Bayang", "影の色を選択"),
      onDismiss = { showOutlinePicker = false },
      onSelect = {
        outlineColor = it
        showOutlinePicker = false
      }
    )
  }
}

@Composable
private fun StickerGridTile(
  sticker: StickerEntity,
  onSend: () -> Unit,
  onToggleFav: () -> Unit
) {
  val context = LocalContext.current
  Surface(
    shape = RoundedCornerShape(12.dp),
    color = GlassFillDark,
    border = BorderStroke(1.dp, GlassBorderSubtle),
    modifier = Modifier
      .aspectRatio(1f)
      .clickable(onClick = onSend)
  ) {
    Box(modifier = Modifier.fillMaxSize().padding(6.dp)) {
      AsyncImage(
        model = CloudMediaHelper.resolveCoilModel(sticker.imageUri, context),
        contentDescription = sticker.name,
        contentScale = ContentScale.Fit,
        modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(8.dp))
      )
      if (sticker.overlayText.isNotBlank()) {
        Text(
          text = sticker.overlayText,
          color = Color(sticker.textColorHex),
          fontSize = 11.sp,
          fontWeight = FontWeight.ExtraBold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier
            .align(Alignment.BottomCenter)
            .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(4.dp))
            .padding(horizontal = 4.dp, vertical = 1.dp)
        )
      }
      IconButton(
        onClick = onToggleFav,
        modifier = Modifier.align(Alignment.TopEnd).size(24.dp)
      ) {
        Icon(
          imageVector = if (sticker.isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
          contentDescription = "Favorit",
          tint = if (sticker.isFavorite) RoseError else SilverAccent,
          modifier = Modifier.size(16.dp)
        )
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GifSearchSheet(
  viewModel: XChatViewModel,
  onSendGif: (GifResultItem) -> Unit,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val strings = LocalStrings.current
  val results by viewModel.gifSearchResults.collectAsState()
  val favorites by viewModel.gifFavorites.collectAsState()
  val isSearching by viewModel.isSearchingGifs.collectAsState()

  var query by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("Trending") }
  val favCatKey = "Favorites"

  val favUrls = remember(favorites) { favorites.filter { it.isFavorite }.map { it.gifUrl }.toSet() }
  val displayed = remember(selectedCategory, results, favorites) {
    if (selectedCategory == favCatKey) {
      favorites.filter { it.isFavorite }.map {
        GifResultItem(it.id, it.title, it.previewUrl, it.gifUrl, it.category)
      }
    } else {
      results
    }
  }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    containerColor = CharcoalSurface,
    contentColor = PureWhiteText,
    sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp)
        .padding(bottom = 24.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Filled.GifBox, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(8.dp))
        Text(strings.searchGif, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
        IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, contentDescription = strings.close) }
      }

      OutlinedTextField(
        value = query,
        onValueChange = {
          query = it
          viewModel.searchGifs(it, selectedCategory)
        },
        placeholder = { Text(tr("Search GIFs (e.g. cat, anime, gg)...", "Cari GIF (misal: kucing, anime, gg)...", "Cari GIF (cth: kucing, anime, gg)...", "GIFを検索 (例: cat, anime, gg)...")) },
        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
        trailingIcon = {
          if (query.isNotEmpty()) {
            IconButton(onClick = {
              query = ""
              viewModel.searchGifs("", selectedCategory)
            }) { Icon(Icons.Filled.Clear, contentDescription = tr("Clear", "Hapus", "Padam", "クリア")) }
          }
        },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().testTag("gif_search_input")
      )

      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        (GifSearchClient.categories + favCatKey).forEach { cat ->
          val label = if (cat == favCatKey) tr("Favorites", "Favorit", "Kegemaran", "お気に入り") else cat
          FilterChip(
            selected = selectedCategory == cat,
            onClick = {
              selectedCategory = cat
              if (cat != favCatKey) viewModel.searchGifs(query, cat)
            },
            label = { Text(label, fontSize = 12.sp) }
          )
        }
      }

      if (isSearching) {
        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
      }

      if (displayed.isEmpty()) {
        Box(modifier = Modifier.fillMaxWidth().height(160.dp), contentAlignment = Alignment.Center) {
          Text(tr("No GIFs in this category.", "Tidak ada GIF di kategori ini.", "Tiada GIF dalam kategori ini.", "このカテゴリにGIFがありません。"), color = SilverMuted)
        }
      } else {
        LazyVerticalGrid(
          columns = GridCells.Fixed(2),
          modifier = Modifier.fillMaxWidth().heightIn(min = 220.dp, max = 380.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          items(displayed, key = { it.id + it.gifUrl }) { item ->
            val isFav = favUrls.contains(item.gifUrl)
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = GlassFillDark,
              border = BorderStroke(1.dp, GlassBorderSubtle),
              modifier = Modifier
                .height(128.dp)
                .clickable {
                  onSendGif(item)
                  onDismiss()
                }
            ) {
              Box(modifier = Modifier.fillMaxSize()) {
                AsyncImage(
                  model = CloudMediaHelper.resolveCoilModel(item.previewUrl, context),
                  contentDescription = item.title,
                  contentScale = ContentScale.Crop,
                  modifier = Modifier.fillMaxSize()
                )
                IconButton(
                  onClick = { viewModel.toggleGifFavorite(item) },
                  modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(4.dp)
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.6f))
                ) {
                  Icon(
                    imageVector = if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = "Favorit GIF",
                    tint = if (isFav) RoseError else Color.White,
                    modifier = Modifier.size(16.dp)
                  )
                }
                Text(
                  text = item.title,
                  color = Color.White,
                  fontSize = 10.sp,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                  modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 6.dp, vertical = 3.dp)
                )
              }
            }
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Video7sTrimSheet(
  onSendTrimmedVideo: (File, Long, String) -> Unit,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val strings = LocalStrings.current
  val scope = rememberCoroutineScope()

  var pickedUri by remember { mutableStateOf<Uri?>(null) }
  var inspection by remember { mutableStateOf<VideoInspectionResult?>(null) }
  var startSec by remember { mutableFloatStateOf(0f) }
  var endSec by remember { mutableFloatStateOf(7f) }
  var caption by remember { mutableStateOf("") }
  var isProcessing by remember { mutableStateOf(false) }
  var errorText by remember { mutableStateOf<String?>(null) }

  val videoPicker = rememberLauncherForActivityResult(
    ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      pickedUri = uri
      errorText = null
      scope.launch {
        val info = VideoTrimHelper.inspectVideo(context, uri)
        inspection = info
        val totalSec = (info.durationMs / 1000f).coerceAtLeast(1f)
        startSec = 0f
        endSec = totalSec.coerceAtMost(7f)
      }
    }
  }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    containerColor = CharcoalSurface,
    contentColor = PureWhiteText,
    sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp)
        .padding(bottom = 24.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Filled.Movie, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(8.dp))
        Text(strings.sendVideo7s, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
        IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, contentDescription = strings.close) }
      }

      Text(
        tr(
          "XChat enforces a strict 7.0s max per video clip for instant playback & bandwidth savings.",
          "XChat memberlakukan batas ketat maksimal 7,0 detik per klip video agar pemutaran tetap instan & hemat kuota.",
          "XChat menetapkan had ketat maksimum 7.0 saat setiap klip video supaya mainan pantas & jimat data.",
          "XChatは高速再生とデータ節約のため、動画クリップを最大7.0秒に制限しています。"
        ),
        color = SilverAccent,
        fontSize = 12.sp
      )

      Button(
        onClick = { videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
        modifier = Modifier.fillMaxWidth().height(48.dp)
      ) {
        Icon(Icons.Filled.VideoLibrary, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text(if (pickedUri == null) tr("Pick Video from Gallery", "Pilih Video dari Galeri", "Pilih Video dari Galeri", "ギャラリーから動画を選択") else tr("Change Video", "Ganti Video Lain", "Tukar Video Lain", "別の動画を選択"))
      }

      inspection?.let { info ->
        val totalSec = (info.durationMs / 1000f).coerceAtLeast(1f)
        GlassCard(modifier = Modifier.fillMaxWidth()) {
          Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (!info.thumbnailPath.isNullOrBlank()) {
              AsyncImage(
                model = File(info.thumbnailPath),
                contentDescription = "Video Thumbnail",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().height(140.dp).clip(RoundedCornerShape(10.dp))
              )
            }
            Text(
              "${tr("Original duration", "Durasi asli", "Tempoh asal", "元の長さ")}: ${String.format(Locale.US, "%.1f", totalSec)}s • ${tr("Resolution", "Resolusi", "Resolusi", "解像度")}: ${info.width}x${info.height}",
              fontSize = 12.sp,
              color = SilverAccent
            )
            if (info.needsTrim) {
              Text(
                tr("Video > 7s! Drag the range slider below to trim to max 7.0s:", "Video > 7 detik! Geser rentang di bawah untuk memotong maksimal 7,0 detik:", "Video > 7 saat! Seret julat di bawah untuk potong maksimum 7.0 saat:", "7秒超過！下のスライダーで最大7.0秒にトリミングしてください:"),
                fontSize = 12.sp,
                color = AmberWarning,
                fontWeight = FontWeight.SemiBold
              )
            }
            RangeSlider(
              value = startSec..endSec,
              onValueChange = { range ->
                var s = range.start.coerceIn(0f, (totalSec - 0.5f).coerceAtLeast(0f))
                var e = range.endInclusive.coerceIn(s + 0.5f, totalSec)
                if (e - s > 7f) {
                  if (kotlin.math.abs(s - startSec) > 0.01f) e = (s + 7f).coerceAtMost(totalSec)
                  else s = (e - 7f).coerceAtLeast(0f)
                }
                startSec = s
                endSec = e
              },
              valueRange = 0f..totalSec
            )
            Text(
              "${tr("Selected range", "Rentang terpilih", "Julat dipilih", "選択範囲")}: ${String.format(Locale.US, "%.1f", startSec)}s – ${String.format(Locale.US, "%.1f", endSec)}s (${String.format(Locale.US, "%.1f", (endSec - startSec).coerceAtMost(7f))}s)",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = EmeraldSuccess
            )
          }
        }
      }

      OutlinedTextField(
        value = caption,
        onValueChange = { caption = it },
        label = { Text(tr("Video Caption (Optional)", "Keterangan Video (Opsional)", "Keterangan Video (Pilihan)", "キャプション(任意)")) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
      )

      errorText?.let {
        Text(it, color = RoseError, fontSize = 12.sp)
      }

      Button(
        onClick = {
          val uri = pickedUri ?: return@Button
          isProcessing = true
          errorText = null
          scope.launch {
            val sMs = (startSec * 1000L).toLong()
            val eMs = ((endSec * 1000L).toLong()).coerceAtMost(sMs + VideoTrimHelper.MAX_VIDEO_DURATION_MS)
            val res = VideoTrimHelper.trimVideoToMax7s(context, uri, sMs, eMs)
            isProcessing = false
            if (res.isSuccess) {
              val (file, dur) = res.getOrThrow()
              onSendTrimmedVideo(file, dur, caption.trim())
              onDismiss()
            } else {
              errorText = res.exceptionOrNull()?.message ?: "Failed to trim video."
            }
          }
        },
        enabled = pickedUri != null && !isProcessing,
        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("trim_send_video_btn")
      ) {
        if (isProcessing) {
          CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
          Spacer(modifier = Modifier.width(8.dp))
          Text(tr("Trimming Video <= 7s...", "Memotong Video <= 7 Detik...", "Memotong Video <= 7 Saat...", "動画を7秒以内に処理中..."))
        } else {
          Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text(tr("Trim & Send Video (Max 7s)", "Potong & Kirim Video (Maks 7 dtk)", "Potong & Hantar Video (Maks 7s)", "トリミングして送信 (最大7秒)"))
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocationShareSheet(
  onSendLocation: (lat: Double, lng: Double, label: String, liveMinutes: Int) -> Unit,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val strings = LocalStrings.current
  val scope = rememberCoroutineScope()

  var hasPermission by remember { mutableStateOf(LocationHelper.hasLocationPermission(context)) }
  var candidate by remember { mutableStateOf<LocationCandidate?>(null) }
  var customLabel by remember { mutableStateOf("") }
  var manualLat by remember { mutableStateOf("-6.200000") }
  var manualLng by remember { mutableStateOf("106.816666") }
  var liveMinutes by remember { mutableIntStateOf(0) } // 0=Statis, 15, 30, 60
  var isFetching by remember { mutableStateOf(false) }
  var statusMsg by remember { mutableStateOf<String?>(null) }

  val permLauncher = rememberLauncherForActivityResult(
    ActivityResultContracts.RequestMultiplePermissions()
  ) { result ->
    hasPermission = result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
      result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
    if (hasPermission) {
      scope.launch {
        isFetching = true
        val res = LocationHelper.fetchCurrentLocationWithPreview(context)
        isFetching = false
        if (res.isSuccess) {
          val loc = res.getOrThrow()
          candidate = loc
          customLabel = loc.label
          manualLat = String.format(Locale.US, "%.6f", loc.latitude)
          manualLng = String.format(Locale.US, "%.6f", loc.longitude)
          statusMsg = null
        } else {
          statusMsg = res.exceptionOrNull()?.message
        }
      }
    } else {
      statusMsg = "Location permission denied. You can still enter coordinates manually."
    }
  }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    containerColor = CharcoalSurface,
    contentColor = PureWhiteText,
    sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp)
        .padding(bottom = 24.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Filled.LocationOn, contentDescription = null, tint = EmeraldSuccess)
        Spacer(modifier = Modifier.width(8.dp))
        Text(strings.shareLocation, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
        IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, contentDescription = strings.close) }
      }

      GlassCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(
            tr(
              "XChat Location Privacy: Your location is NEVER collected automatically or in the background. It is only shared when you tap Share Location below.",
              "Privasi Lokasi XChat: Lokasi TIDAK PERNAH diambil otomatis atau di latar belakang. Lokasi hanya dibagikan saat Anda menekan tombol Kirim Lokasi di bawah.",
              "Privasi Lokasi XChat: Lokasi TIDAK PERNAH diambil secara automatik atau di latar belakang. Lokasi hanya dikongsi apabila anda menekan butang Kongsi Lokasi di bawah.",
              "XChat位置情報プライバシー: 位置情報は自動またはバックグラウンドで取得されません。下の送信ボタンを押した時のみ共有されます。"
            ),
            color = SilverAccent,
            fontSize = 12.sp
          )
        }
      }

      Button(
        onClick = {
          if (!hasPermission) {
            permLauncher.launch(
              arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
              )
            )
          } else {
            scope.launch {
              isFetching = true
              val res = LocationHelper.fetchCurrentLocationWithPreview(context)
              isFetching = false
              if (res.isSuccess) {
                val loc = res.getOrThrow()
                candidate = loc
                customLabel = loc.label
                manualLat = String.format(Locale.US, "%.6f", loc.latitude)
                manualLng = String.format(Locale.US, "%.6f", loc.longitude)
                statusMsg = null
              } else {
                statusMsg = res.exceptionOrNull()?.message
              }
            }
          }
        },
        enabled = !isFetching,
        modifier = Modifier.fillMaxWidth().height(48.dp)
      ) {
        if (isFetching) {
          CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
          Spacer(modifier = Modifier.width(8.dp))
          Text(tr("Fetching GPS Coordinates...", "Mengambil Koordinat GPS...", "Mengambil Koordinat GPS...", "GPS座標を取得中..."))
        } else {
          Icon(Icons.Filled.MyLocation, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text(tr("Get Current Location", "Ambil Lokasi Saat Ini", "Ambil Lokasi Semasa", "現在地を取得"))
        }
      }

      statusMsg?.let { Text(it, color = AmberWarning, fontSize = 12.sp) }

      OutlinedTextField(
        value = customLabel,
        onValueChange = { customLabel = it },
        label = { Text(tr("Place Label / Address", "Label Tempat / Alamat", "Label Tempat / Alamat", "場所ラベル / 住所")) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
      )

      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
          value = manualLat,
          onValueChange = { manualLat = it },
          label = { Text("Latitude") },
          singleLine = true,
          modifier = Modifier.weight(1f)
        )
        OutlinedTextField(
          value = manualLng,
          onValueChange = { manualLng = it },
          label = { Text("Longitude") },
          singleLine = true,
          modifier = Modifier.weight(1f)
        )
      }

      Text(tr("Share Duration:", "Durasi Berbagi:", "Tempoh Kongsi:", "共有時間:"), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = SilverAccent)
      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf(0 to tr("Static", "Statis", "Statik", "固定"), 15 to "Live 15m", 30 to "Live 30m", 60 to "Live 60m").forEach { (mins, label) ->
          FilterChip(
            selected = liveMinutes == mins,
            onClick = { liveMinutes = mins },
            label = { Text(label, fontSize = 11.sp) }
          )
        }
      }

      val parsedLat = manualLat.toDoubleOrNull() ?: candidate?.latitude
      val parsedLng = manualLng.toDoubleOrNull() ?: candidate?.longitude
      if (parsedLat != null && parsedLng != null) {
        GlassSurface(modifier = Modifier.fillMaxWidth()) {
          Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Filled.Map, contentDescription = null, tint = EmeraldSuccess)
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(customLabel.ifBlank { tr("Selected Location Pin", "Titik Lokasi Dipilih", "Titik Lokasi Dipilih", "選択された位置") }, fontWeight = FontWeight.Bold, fontSize = 13.sp)
              Text(
                "${tr("Coordinates", "Koordinat", "Koordinat", "座標")}: ${String.format(Locale.US, "%.5f", parsedLat)}, ${String.format(Locale.US, "%.5f", parsedLng)}",
                fontSize = 11.sp,
                color = SilverAccent
              )
            }
          }
        }
      }

      Button(
        onClick = {
          val lat = parsedLat ?: return@Button
          val lng = parsedLng ?: return@Button
          val label = customLabel.ifBlank { String.format(Locale.US, "%.5f, %.5f", lat, lng) }
          onSendLocation(lat, lng, label, liveMinutes)
          onDismiss()
        },
        enabled = parsedLat != null && parsedLng != null,
        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("confirm_send_location_btn")
      ) {
        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text(tr("Share Location to Chat", "Bagikan Lokasi ke Chat", "Kongsi Lokasi ke Sembang", "チャットに位置を共有"))
      }
    }
  }
}
