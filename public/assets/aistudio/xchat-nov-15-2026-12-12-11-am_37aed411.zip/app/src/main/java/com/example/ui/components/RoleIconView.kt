package com.example.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.util.LruCache
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.UserEntity
import com.example.ui.theme.*
import com.example.utils.CloudMediaHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

object RoleIconChromaProcessor {
  private val cache = LruCache<String, ImageBitmap>(48)

  fun parseChromaColors(csv: String): List<Int> {
    if (csv.isBlank()) return emptyList()
    return csv.split(",").mapNotNull { token ->
      val clean = token.trim().removePrefix("#").removePrefix("0x").removePrefix("0X")
      when (clean.length) {
        6 -> clean.toIntOrNull(16)?.let { 0xFF000000.toInt() or it }
        8 -> clean.toLongOrNull(16)?.toInt()
        else -> null
      }
    }
  }

  suspend fun loadProcessedBitmap(
    context: Context,
    uriString: String,
    chromaCsv: String,
    tolerance: Float = 0.25f
  ): ImageBitmap? {
    val cacheKey = "${uriString.hashCode()}_${chromaCsv}_${(tolerance * 100).toInt()}"
    cache.get(cacheKey)?.let { return it }

    return withContext(Dispatchers.IO) {
      try {
        val rawBitmap = decodeBitmap(context, uriString) ?: return@withContext null
        val scaled = if (rawBitmap.width > 128 || rawBitmap.height > 128) {
          val ratio = 128f / maxOf(rawBitmap.width, rawBitmap.height)
          Bitmap.createScaledBitmap(
            rawBitmap,
            (rawBitmap.width * ratio).toInt().coerceAtLeast(1),
            (rawBitmap.height * ratio).toInt().coerceAtLeast(1),
            true
          )
        } else {
          rawBitmap
        }
        val keyColors = parseChromaColors(chromaCsv)
        val processed = if (keyColors.isEmpty()) {
          scaled
        } else {
          applyChromaKey(scaled, keyColors, tolerance)
        }
        val imageBitmap = processed.asImageBitmap()
        cache.put(cacheKey, imageBitmap)
        imageBitmap
      } catch (_: Exception) {
        null
      }
    }
  }

  private fun decodeBitmap(context: Context, raw: String): Bitmap? {
    return when {
      raw.startsWith("data:image/", ignoreCase = true) && raw.contains("base64,") -> {
        val b64 = raw.substringAfter("base64,")
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
      }
      raw.startsWith("http://") || raw.startsWith("https://") -> {
        val conn = (URL(raw).openConnection() as HttpURLConnection).apply {
          connectTimeout = 8000
          readTimeout = 8000
          setRequestProperty("User-Agent", "XChat-Android/2.0")
        }
        conn.inputStream.use { BitmapFactory.decodeStream(it) }
      }
      raw.startsWith("content://") -> {
        context.contentResolver.openInputStream(Uri.parse(raw))?.use {
          BitmapFactory.decodeStream(it)
        }
      }
      raw.startsWith("file://") -> {
        val path = Uri.parse(raw).path ?: return null
        BitmapFactory.decodeFile(path)
      }
      else -> {
        val f = File(raw)
        if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
      }
    }
  }

  private fun applyChromaKey(src: Bitmap, keyColors: List<Int>, tolerance: Float): Bitmap {
    val w = src.width
    val h = src.height
    val argb = if (src.config == Bitmap.Config.ARGB_8888) src.copy(Bitmap.Config.ARGB_8888, true)
    else src.copy(Bitmap.Config.ARGB_8888, true)
    argb.setHasAlpha(true)

    val pixels = IntArray(w * h)
    argb.getPixels(pixels, 0, w, 0, 0, w, h)

    val maxDist = (tolerance.coerceIn(0.05f, 0.7f) * 441.67f)
    val featherStart = maxDist * 0.78f

    for (i in pixels.indices) {
      val px = pixels[i]
      val a = (px ushr 24) and 0xFF
      if (a == 0) continue
      val r = (px ushr 16) and 0xFF
      val g = (px ushr 8) and 0xFF
      val b = px and 0xFF

      var minDist = Float.MAX_VALUE
      for (kc in keyColors) {
        val kr = (kc ushr 16) and 0xFF
        val kg = (kc ushr 8) and 0xFF
        val kb = kc and 0xFF
        val dr = (r - kr).toFloat()
        val dg = (g - kg).toFloat()
        val db = (b - kb).toFloat()
        val dist = sqrt(dr * dr + dg * dg + db * db)
        if (dist < minDist) minDist = dist
      }

      if (minDist <= featherStart) {
        pixels[i] = px and 0x00FFFFFF
      } else if (minDist < maxDist) {
        val factor = ((minDist - featherStart) / (maxDist - featherStart)).coerceIn(0f, 1f)
        val newA = (a * factor).toInt().coerceIn(0, 255)
        pixels[i] = (newA shl 24) or (px and 0x00FFFFFF)
      }
    }
    argb.setPixels(pixels, 0, w, 0, 0, w, h)
    return argb
  }
}

@Composable
fun RoleIconImage(
  iconUri: String?,
  chromaKeyColorsCsv: String = "",
  tolerance: Float = 0.25f,
  size: Dp = 18.dp,
  modifier: Modifier = Modifier
) {
  if (iconUri.isNullOrBlank()) return
  val context = LocalContext.current
  var processed by remember(iconUri, chromaKeyColorsCsv, tolerance) {
    mutableStateOf<ImageBitmap?>(null)
  }

  LaunchedEffect(iconUri, chromaKeyColorsCsv, tolerance) {
    processed = RoleIconChromaProcessor.loadProcessedBitmap(context, iconUri, chromaKeyColorsCsv, tolerance)
  }

  if (processed != null) {
    Image(
      bitmap = processed!!,
      contentDescription = "Role Icon",
      contentScale = ContentScale.Fit,
      modifier = modifier
        .size(size)
        .clip(RoundedCornerShape(4.dp))
    )
  } else {
    AsyncImage(
      model = CloudMediaHelper.resolveCoilModel(iconUri),
      contentDescription = "Role Icon",
      contentScale = ContentScale.Fit,
      modifier = modifier
        .size(size)
        .clip(RoundedCornerShape(4.dp))
    )
  }
}

object ServerTagIconCatalog {
  val presets: List<Pair<String, ImageVector>> = listOf(
    "shield" to Icons.Filled.Shield,
    "bolt" to Icons.Filled.Bolt,
    "star" to Icons.Filled.AutoAwesome,
    "crown" to Icons.Filled.WorkspacePremium,
    "gamepad" to Icons.Filled.SportsEsports,
    "fire" to Icons.Filled.LocalFireDepartment,
    "code" to Icons.Filled.Terminal,
    "diamond" to Icons.Filled.Diamond
  )

  fun vectorFor(key: String?): ImageVector {
    return presets.firstOrNull { it.first.equals(key, ignoreCase = true) }?.second ?: Icons.Filled.Shield
  }

  fun isCustomImage(iconKeyOrUri: String?): Boolean {
    if (iconKeyOrUri.isNullOrBlank()) return false
    return iconKeyOrUri.startsWith("http") ||
      iconKeyOrUri.startsWith("data:") ||
      iconKeyOrUri.startsWith("content:") ||
      iconKeyOrUri.startsWith("file:") ||
      iconKeyOrUri.startsWith("/")
  }
}

@Composable
fun ServerTagPill(
  tagText: String?,
  tagIconKeyOrUri: String?,
  modifier: Modifier = Modifier
) {
  val cleanTag = tagText?.trim()?.removePrefix("#").orEmpty()
  if (cleanTag.isBlank()) return

  Surface(
    color = DiscordElevated,
    shape = RoundedCornerShape(6.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, DiscordDivider),
    modifier = modifier
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      if (ServerTagIconCatalog.isCustomImage(tagIconKeyOrUri)) {
        AsyncImage(
          model = CloudMediaHelper.resolveCoilModel(tagIconKeyOrUri),
          contentDescription = null,
          contentScale = ContentScale.Crop,
          modifier = Modifier.size(12.dp).clip(RoundedCornerShape(3.dp))
        )
      } else {
        Icon(
          imageVector = ServerTagIconCatalog.vectorFor(tagIconKeyOrUri),
          contentDescription = null,
          tint = PurplePrimary,
          modifier = Modifier.size(12.dp)
        )
      }
      Spacer(modifier = Modifier.width(4.dp))
      Text(
        text = cleanTag.take(12),
        color = DiscordTextPrimary,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
      )
    }
  }
}

object ProfileEffectCatalog {
  data class EffectOption(val id: String, val label: String, val desc: String)

  val options = listOf(
    EffectOption("", "None", "No animated profile overlay"),
    EffectOption("eff_sparkles", "Astral Sparkles", "Sparkling star particles on your profile card"),
    EffectOption("eff_cyber_rain", "Cyber Rain", "Futuristic neon purple and cyan rain"),
    EffectOption("eff_void_aura", "Void Aura", "Rotating obsidian aura waves")
  )
}

@Composable
fun AnimatedProfileEffectOverlay(
  effectId: String?,
  modifier: Modifier = Modifier
) {
  if (effectId.isNullOrBlank()) return
  val infiniteTransition = rememberInfiniteTransition(label = "profile_effect")
  val phase by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 4200, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "effect_phase"
  )

  Canvas(modifier = modifier) {
    val w = size.width
    val h = size.height
    if (w <= 0f || h <= 0f) return@Canvas

    when (effectId) {
      "eff_sparkles" -> {
        val count = 14
        for (i in 0 until count) {
          val seedX = ((i * 73 + 19) % 100) / 100f
          val baseY = ((i * 41 + 7) % 100) / 100f
          val y = ((baseY - phase + 1f) % 1f) * h
          val x = seedX * w + sin((phase * 6.28f + i).toDouble()).toFloat() * 8f
          val alpha = (0.35f + 0.65f * kotlin.math.abs(sin((phase * 6.28f + i * 0.7f).toDouble())).toFloat())
          val col = if (i % 2 == 0) AmberWarning.copy(alpha = alpha) else PurplePrimary.copy(alpha = alpha)
          drawCircle(color = col, radius = if (i % 3 == 0) 4.2f else 2.6f, center = Offset(x, y))
        }
      }
      "eff_cyber_rain" -> {
        val drops = 18
        for (i in 0 until drops) {
          val x = ((i * 59 + 11) % 100) / 100f * w
          val yProgress = (((i * 29) % 100) / 100f + phase * (1f + (i % 3) * 0.35f)) % 1f
          val startY = yProgress * h
          val len = 26f + (i % 4) * 10f
          val col = if (i % 2 == 0) CyanInfo.copy(alpha = 0.55f) else PurpleLight.copy(alpha = 0.55f)
          drawLine(
            color = col,
            start = Offset(x, startY),
            end = Offset(x - 6f, startY + len),
            strokeWidth = 2.4f
          )
        }
      }
      "eff_void_aura" -> {
        val cx = w * 0.8f
        val cy = h * 0.45f
        for (rIdx in 1..3) {
          val p = (phase + rIdx * 0.33f) % 1f
          val radius = p * (maxOf(w, h) * 0.55f)
          val alpha = (1f - p) * 0.55f
          drawCircle(
            color = if (rIdx % 2 == 0) PurplePrimary.copy(alpha = alpha) else Color(0xFFEC4899).copy(alpha = alpha),
            radius = radius,
            center = Offset(cx, cy),
            style = Stroke(width = 3f)
          )
        }
        for (j in 0 until 8) {
          val angle = (phase * 6.283f) + j * 0.785f
          val dist = 36f + (j % 3) * 18f
          drawCircle(
            color = AstralViolet.copy(alpha = 0.7f),
            radius = 3.5f,
            center = Offset(cx + cos(angle) * dist, cy + sin(angle) * dist)
          )
        }
      }
    }
  }
}

fun isUserOnlineNow(user: UserEntity?): Boolean {
  if (user == null) return false
  if (user.presenceStatus.equals("OFFLINE", ignoreCase = true)) return false
  val isDemoNpc = user.id in setOf("usr_alex", "usr_sarah", "usr_admin")
  if (isDemoNpc) return true
  if (user.lastSeenAt <= 0L) return user.presenceStatus.equals("ONLINE", ignoreCase = true)
  return (System.currentTimeMillis() - user.lastSeenAt) <= 180_000L
}

fun presenceColorFor(presenceStatus: String, isOnlineRecent: Boolean = true): Color {
  if (!isOnlineRecent && presenceStatus.equals("ONLINE", ignoreCase = true)) return DiscordTextMuted
  return when (presenceStatus.uppercase()) {
    "ONLINE" -> EmeraldSuccess
    "IDLE" -> AmberWarning
    "DND" -> RoseError
    "OFFLINE" -> DiscordTextMuted
    else -> EmeraldSuccess
  }
}

fun presenceLabelFor(presenceStatus: String, isOnlineRecent: Boolean = true): String {
  if (!isOnlineRecent && presenceStatus.equals("ONLINE", ignoreCase = true)) return "Offline"
  return when (presenceStatus.uppercase()) {
    "ONLINE" -> "Online"
    "IDLE" -> "Idle"
    "DND" -> "Do Not Disturb"
    "OFFLINE" -> "Offline"
    else -> "Online"
  }
}

@Composable
fun OnlineStatusDot(
  presenceStatus: String,
  lastSeenAt: Long = 0L,
  userId: String = "",
  size: Dp = 10.dp,
  modifier: Modifier = Modifier
) {
  val isRecent = userId in setOf("usr_alex", "usr_sarah", "usr_admin") ||
    lastSeenAt <= 0L ||
    (System.currentTimeMillis() - lastSeenAt) <= 180_000L
  val color = presenceColorFor(presenceStatus, isRecent)
  Box(
    modifier = modifier
      .size(size)
      .clip(CircleShape)
      .background(color)
      .border(1.5.dp, DiscordDeep, CircleShape)
  )
}

@Composable
fun TypingIndicatorBar(
  typingUsers: List<UserEntity>,
  modifier: Modifier = Modifier
) {
  if (typingUsers.isEmpty()) return

  val infiniteTransition = rememberInfiniteTransition(label = "typing_dots")
  val dotPhase by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 3f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 900, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "dot_phase"
  )

  val text = when (typingUsers.size) {
    1 -> "${typingUsers[0].displayName} is typing..."
    2 -> "${typingUsers[0].displayName} and ${typingUsers[1].displayName} are typing..."
    else -> "Several people are typing..."
  }

  Row(
    modifier = modifier
      .fillMaxWidth()
      .background(DiscordSurface.copy(alpha = 0.88f))
      .padding(horizontal = 14.dp, vertical = 4.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
      repeat(3) { idx ->
        val active = (dotPhase.toInt() % 3) == idx
        Box(
          modifier = Modifier
            .size(if (active) 6.dp else 4.5.dp)
            .clip(CircleShape)
            .background(if (active) PurplePrimary else DiscordTextMuted)
        )
      }
    }
    Spacer(modifier = Modifier.width(8.dp))
    Text(
      text = text,
      color = DiscordTextSecondary,
      fontSize = 11.sp,
      fontWeight = FontWeight.Medium,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis
    )
  }
}
