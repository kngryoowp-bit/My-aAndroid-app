package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.ChannelCategoryEntity
import com.example.data.model.ChannelEntity
import com.example.data.model.ServerEntity
import com.example.data.model.ServerMemberEntity
import com.example.data.model.ServerRoleEntity
import com.example.data.model.UserEntity
import com.example.ui.XChatViewModel
import com.example.ui.theme.*
import com.example.utils.CloudMediaHelper

@Composable
fun AddChannelDialog(
  serverId: String,
  viewModel: XChatViewModel,
  categories: List<ChannelCategoryEntity> = emptyList(),
  initialCategoryId: String = "",
  onDismiss: () -> Unit
) {
  val s = LocalStrings.current
  var channelName by remember { mutableStateOf("") }
  var channelDesc by remember { mutableStateOf("") }
  var selectedType by remember { mutableStateOf("text") }
  var selectedCategoryId by remember { mutableStateOf(initialCategoryId.ifBlank { categories.firstOrNull()?.id ?: "" }) }

  val channelTypes = listOf(
    Triple("text", "Text (#)", Icons.Filled.Tag),
    Triple("voice", "Voice", Icons.Filled.VolumeUp),
    Triple("announcements", "Announcements", Icons.Filled.Campaign),
    Triple("rules", "Rules", Icons.Filled.Gavel),
    Triple("forums", "Forums", Icons.Filled.Forum),
    Triple("media", "Media", Icons.Filled.PermMedia)
  )

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Create New Channel", fontWeight = FontWeight.Bold) },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Text("Select Channel Type:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          channelTypes.forEach { (typeKey, label, icon) ->
            FilterChip(
              selected = selectedType == typeKey,
              onClick = { selectedType = typeKey },
              leadingIcon = { Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp)) },
              label = { Text(label, fontSize = 11.sp) }
            )
          }
        }

        OutlinedTextField(
          value = channelName,
          onValueChange = { channelName = it },
          label = { Text("Channel Name (e.g. general, rules, voice-1)") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        OutlinedTextField(
          value = channelDesc,
          onValueChange = { channelDesc = it },
          label = { Text("Channel Description / Topic") },
          modifier = Modifier.fillMaxWidth(),
          maxLines = 2
        )

        if (categories.isNotEmpty()) {
          Text("Channel Category:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            categories.forEach { cat ->
              FilterChip(
                selected = selectedCategoryId == cat.id,
                onClick = { selectedCategoryId = cat.id },
                label = { Text(cat.name, fontSize = 11.sp) }
              )
            }
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (channelName.isNotBlank()) {
            viewModel.createChannel(serverId, channelName, channelDesc, selectedType, selectedCategoryId) {
              onDismiss()
            }
          }
        }
      ) {
        Text(s.createBtn)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text(s.cancel) }
    }
  )
}

@Composable
fun ServerManageDialog(
  server: ServerEntity,
  currentUser: UserEntity?,
  roles: List<ServerRoleEntity>,
  members: List<ServerMemberEntity>,
  allUsers: List<UserEntity>,
  initialTab: Int = 0,
  viewModel: XChatViewModel,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val s = LocalStrings.current
  val isUploading by viewModel.isUploadingMedia.collectAsState()
  val isVerifiedAdmin by viewModel.isVerifiedAdmin.collectAsState()
  val categories by viewModel.currentCategories.collectAsState()
  val channels by viewModel.currentChannels.collectAsState()
  var selectedTab by remember { mutableIntStateOf(initialTab) } // 0: Server/Boost, 1: Roles, 2: Kategori & Vanish
  var newCategoryName by remember { mutableStateOf("") }

  var editName by remember(server.id) { mutableStateOf(server.name) }
  var editDesc by remember(server.id) { mutableStateOf(server.description) }
  var editIconUri by remember(server.id) { mutableStateOf(server.iconUri) }
  var editBannerUri by remember(server.id) { mutableStateOf(server.bannerUri) }
  var editServerTag by remember(server.id) { mutableStateOf(server.serverTag) }
  var editServerTagIcon by remember(server.id) { mutableStateOf(server.serverTagIcon) }
  var editGameIds by remember(server.id) {
    mutableStateOf(GameCatalog.findMany(server.supportedGame).map { it.id }.toSet())
  }

  // Role builder / editor state
  var editingRoleId by remember { mutableStateOf<String?>(null) }
  var newRoleName by remember { mutableStateOf("") }
  var newRoleColor by remember { mutableStateOf(Color(0xFF8B5CF6)) }
  var newRoleIconUri by remember { mutableStateOf<String?>(null) }
  var roleChromaColors by remember { mutableStateOf<List<String>>(emptyList()) }
  var chromaTolerance by remember { mutableFloatStateOf(0.25f) }
  var showRoleColorPicker by remember { mutableStateOf(false) }
  var showChromaColorPicker by remember { mutableStateOf(false) }
  var permManageChannels by remember { mutableStateOf(false) }
  var permManageMessages by remember { mutableStateOf(false) }
  var permManageRoles by remember { mutableStateOf(false) }
  var assignTargetUser by remember { mutableStateOf<UserEntity?>(null) }

  val iconPicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      viewModel.prepareAndPickMedia(uri, maxDim = 320, preserveTransparency = true) { cloudUri ->
        editIconUri = cloudUri
      }
    }
  }

  val bannerPicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      viewModel.prepareAndPickMedia(uri, maxDim = 960) { cloudUri ->
        editBannerUri = cloudUri
      }
    }
  }

  val tagIconPicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      viewModel.prepareAndPickMedia(uri, maxDim = 128, preserveTransparency = true) { cloudUri ->
        editServerTagIcon = cloudUri
      }
    }
  }

  val roleIconPicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      viewModel.prepareAndPickMedia(uri, maxDim = 192, preserveTransparency = true) { cloudUri ->
        newRoleIconUri = cloudUri
      }
    }
  }

  val isOwner = currentUser?.isOwner == true
  val canBanner = server.boostLevel >= 1 || isOwner
  val canCustomTag = server.boostCount >= 3 || isOwner
  val canRoleIcon = server.boostCount >= 5 || isOwner
  val mutedServerIds by viewModel.mutedServerIds.collectAsState()
  val isServerMuted = mutedServerIds.contains(server.id)

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Column {
        Text("Manage Server", fontWeight = FontWeight.Bold)
        Text(
          text = "Boost Level ${server.boostLevel} • ${server.boostCount} Boosts",
          fontSize = 11.sp,
          color = AstralViolet,
          fontWeight = FontWeight.SemiBold
        )
        if (isUploading) {
          Spacer(modifier = Modifier.height(6.dp))
          LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }
      }
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .heightIn(max = 480.dp)
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          FilterChip(
            selected = selectedTab == 0,
            onClick = { selectedTab = 0 },
            label = { Text("Info, Tag & Boost", fontSize = 11.sp) }
          )
          FilterChip(
            selected = selectedTab == 1,
            onClick = { selectedTab = 1 },
            label = { Text("Roles (${roles.size})", fontSize = 11.sp) }
          )
          FilterChip(
            selected = selectedTab == 2,
            onClick = { selectedTab = 2 },
            label = { Text("Categories (${categories.size})", fontSize = 11.sp) }
          )
        }

        if (selectedTab == 0) {
          // Server Banner & Icon Preview
          val bannerModel = remember(editBannerUri) { CloudMediaHelper.resolveCoilModel(editBannerUri) }
          val bannerReq = remember(bannerModel) {
            bannerModel?.let { ImageRequest.Builder(context).data(it).crossfade(false).build() }
          }
          val iconModel = remember(editIconUri) { CloudMediaHelper.resolveCoilModel(editIconUri) }
          val iconReq = remember(iconModel) {
            iconModel?.let { ImageRequest.Builder(context).data(it).crossfade(false).build() }
          }
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(100.dp)
              .clip(RoundedCornerShape(12.dp))
              .then(
                if (bannerReq != null) Modifier.background(Color(0xFF141518))
                else Modifier.background(AppThemeAccentBrush())
              )
          ) {
            if (bannerReq != null) {
              AsyncImage(
                model = bannerReq,
                contentDescription = "Server Banner",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
              )
            }
            Row(
              modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(48.dp)
                  .clip(CircleShape)
                  .background(if (iconReq != null) Color(0xFF1E1F22) else MaterialTheme.colorScheme.surface)
                  .border(2.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
              ) {
                if (iconReq != null) {
                  AsyncImage(
                    model = iconReq,
                    contentDescription = "Server Icon",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                  )
                } else {
                  Text(editName.take(2).uppercase(), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                }
              }
              Spacer(modifier = Modifier.width(8.dp))
              Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.Black.copy(alpha = 0.6f))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                  Text(editName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
                }
                ServerTagPill(tagText = editServerTag, tagIconKeyOrUri = editServerTagIcon)
              }
            }
          }

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(
              onClick = { iconPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(8.dp)
            ) {
              Icon(Icons.Filled.AccountCircle, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Server Icon", fontSize = 11.sp)
            }
            FilledTonalButton(
              onClick = {
                if (!canBanner) {
                  viewModel.feedbackMessage.value = "Server Banner requires Boost Level 1 (min 2 Boosts)!"
                } else {
                  bannerPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
              },
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(8.dp)
            ) {
              Icon(if (canBanner) Icons.Filled.Image else Icons.Filled.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Server Banner", fontSize = 11.sp)
            }
          }

          FilledTonalButton(
            onClick = { viewModel.toggleMuteServer(server.id) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp)
          ) {
            Icon(
              if (isServerMuted) Icons.Filled.NotificationsOff else Icons.Filled.NotificationsActive,
              contentDescription = null,
              modifier = Modifier.size(16.dp),
              tint = if (isServerMuted) AmberWarning else MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              if (isServerMuted) s.unmuteServerNotif else s.muteServerNotif,
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold
            )
          }

          // Server Boost Action Card
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = AstralViolet.copy(alpha = 0.14f),
            border = androidx.compose.foundation.BorderStroke(1.dp, AstralViolet.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Filled.RocketLaunch, contentDescription = null, tint = AstralViolet, modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("Server Boost Level ${server.boostLevel}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                }
                Text(
                  text = if (isOwner) "∞ Boosts" else "Balance: ${currentUser?.boostBalance ?: 0}",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = AstralViolet
                )
              }
              Text(
                text = "Total Boosts: ${server.boostCount} (2 Boosts: Banner • 3 Boosts: Custom Tag • 5 Boosts: Gallery Role Icon)",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Button(
                onClick = { viewModel.boostServer(server.id) },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = AstralViolet),
                shape = RoundedCornerShape(8.dp)
              ) {
                Icon(Icons.Filled.RocketLaunch, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  if (isOwner) "Boost Server (+1 • Unlimited)" else "Boost This Server (1 Boost)",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }

          OutlinedTextField(
            value = editName,
            onValueChange = { editName = it },
            label = { Text("Server Name") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
          )

          OutlinedTextField(
            value = editDesc,
            onValueChange = { editDesc = it },
            label = { Text("Server Description") },
            modifier = Modifier.fillMaxWidth(),
            maxLines = 2
          )

          // Custom Server Tag & Icon (>= 3 Boosts)
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
            border = androidx.compose.foundation.BorderStroke(1.dp, if (canCustomTag) MaterialTheme.colorScheme.primary.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text("Custom Server Tag & Icon", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (canCustomTag) EmeraldSuccess.copy(alpha = 0.2f) else AstralViolet.copy(alpha = 0.2f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                  Text(
                    if (canCustomTag) "UNLOCKED (≥3 BOOSTS)" else "NEEDS 3 BOOSTS",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (canCustomTag) EmeraldSuccess else AstralViolet
                  )
                }
              }

              OutlinedTextField(
                value = editServerTag,
                onValueChange = { if (canCustomTag) editServerTag = it.take(14) },
                enabled = canCustomTag,
                label = { Text("Server Tag Text (max 14 chars)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
              )

              Text("Select Tag Icon (Preset or Gallery):", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                ServerTagIconCatalog.presets.forEach { (key, vec) ->
                  val isSel = editServerTagIcon.equals(key, ignoreCase = true)
                  FilterChip(
                    selected = isSel,
                    onClick = {
                      if (canCustomTag) editServerTagIcon = key
                      else viewModel.feedbackMessage.value = "Custom Server Tag requires at least 3 Boosts!"
                    },
                    leadingIcon = { Icon(vec, contentDescription = key, modifier = Modifier.size(15.dp)) },
                    label = { Text(key.replaceFirstChar { it.uppercase() }, fontSize = 10.sp) }
                  )
                }
                FilledTonalButton(
                  onClick = {
                    if (canCustomTag) {
                      tagIconPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    } else {
                      viewModel.feedbackMessage.value = "Custom Server Tag requires at least 3 Boosts!"
                    }
                  },
                  contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                  modifier = Modifier.height(32.dp)
                ) {
                  Icon(if (canCustomTag) Icons.Filled.PhotoLibrary else Icons.Filled.Lock, contentDescription = null, modifier = Modifier.size(14.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Gallery", fontSize = 10.sp)
                }
              }
            }
          }

          // Multi-Select Supported Games
          HorizontalDivider(color = MaterialTheme.colorScheme.outline)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("Supported Games (Multi-select):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("${editGameIds.size} selected", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
          }
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            GameCatalog.games.chunked(2).forEach { pair ->
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                pair.forEach { gm ->
                  val isSel = editGameIds.contains(gm.id)
                  Surface(
                    onClick = { editGameIds = if (isSel) editGameIds - gm.id else editGameIds + gm.id },
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(
                      1.dp,
                      if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                    ),
                    modifier = Modifier.weight(1f)
                  ) {
                    Row(
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      GameLogo(gameIdOrName = gm.id, size = 18.dp)
                      Spacer(modifier = Modifier.width(6.dp))
                      Text(
                        text = gm.name,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                      )
                      if (isSel) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(13.dp))
                      }
                    }
                  }
                }
                if (pair.size == 1) Spacer(modifier = Modifier.weight(1f))
              }
            }
          }
        } else {
          // Tab 1: Role Builder with Gallery Icon (>= 5 Boosts) & Multi-Color Chroma Key
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = if (editingRoleId == null) "Create New Role:" else "Edit Role:",
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp
            )
            if (editingRoleId != null) {
              TextButton(
                onClick = {
                  editingRoleId = null
                  newRoleName = ""
                  newRoleColor = Color(0xFF8B5CF6)
                  newRoleIconUri = null
                  roleChromaColors = emptyList()
                  permManageChannels = false
                  permManageMessages = false
                  permManageRoles = false
                },
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
              ) {
                Text("Cancel Edit", fontSize = 11.sp)
              }
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedTextField(
              value = newRoleName,
              onValueChange = { newRoleName = it },
              label = { Text("Role Name (e.g. VIP Squad)") },
              modifier = Modifier.weight(1f),
              singleLine = true
            )
            Box(
              modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(newRoleColor)
                .border(2.dp, Color.White.copy(alpha = 0.7f), RoundedCornerShape(10.dp))
                .clickable { showRoleColorPicker = true }
            )
          }

          // Role Icon Gallery + Multi-Color Chroma Key (>= 5 Boosts)
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
            border = androidx.compose.foundation.BorderStroke(1.dp, if (canRoleIcon) MaterialTheme.colorScheme.primary.copy(alpha = 0.45f) else MaterialTheme.colorScheme.outline),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text("Role Icon & Chroma Key", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (canRoleIcon) EmeraldSuccess.copy(alpha = 0.2f) else AstralViolet.copy(alpha = 0.2f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                  Text(
                    if (canRoleIcon) "UNLOCKED (≥5 BOOSTS)" else "NEEDS 5 BOOSTS",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (canRoleIcon) EmeraldSuccess else AstralViolet
                  )
                }
              }

              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                if (!newRoleIconUri.isNullOrBlank()) {
                  Box(
                    modifier = Modifier
                      .size(42.dp)
                      .clip(RoundedCornerShape(8.dp))
                      .background(Color(0xFF1E1F22))
                      .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                  ) {
                    RoleIconImage(
                      iconUri = newRoleIconUri,
                      chromaKeyColorsCsv = roleChromaColors.joinToString(","),
                      tolerance = chromaTolerance,
                      size = 34.dp
                    )
                  }
                }
                FilledTonalButton(
                  onClick = {
                    if (canRoleIcon) {
                      roleIconPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    } else {
                      viewModel.feedbackMessage.value = "Gallery Role Icon requires at least 5 Boosts!"
                    }
                  },
                  modifier = Modifier.weight(1f),
                  shape = RoundedCornerShape(8.dp)
                ) {
                  Icon(if (canRoleIcon) Icons.Filled.AddPhotoAlternate else Icons.Filled.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(if (newRoleIconUri == null) "Pick Gallery Icon" else "Change Icon", fontSize = 11.sp)
                }
                if (!newRoleIconUri.isNullOrBlank()) {
                  IconButton(onClick = { newRoleIconUri = null }, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Filled.Close, contentDescription = "Remove Icon", tint = RoseError, modifier = Modifier.size(16.dp))
                  }
                }
              }

              // Multi-Color Chroma Key Selector
              Text("Multi-Color Chroma Key (Remove Background):", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                val quickChromas = listOf(
                  "#00FF00" to "Green",
                  "#FFFFFF" to "White",
                  "#000000" to "Black",
                  "#0000FF" to "Blue"
                )
                quickChromas.forEach { (hex, label) ->
                  val active = roleChromaColors.any { it.equals(hex, ignoreCase = true) }
                  FilterChip(
                    selected = active,
                    onClick = {
                      roleChromaColors = if (active) {
                        roleChromaColors.filterNot { it.equals(hex, ignoreCase = true) }
                      } else {
                        roleChromaColors + hex
                      }
                    },
                    leadingIcon = {
                      val c = ColorHelper.parseHex6OrNull(hex) ?: Color.Green
                      Box(
                        modifier = Modifier
                          .size(12.dp)
                          .clip(CircleShape)
                          .background(c)
                          .border(1.dp, Color.White, CircleShape)
                      )
                    },
                    label = { Text(label, fontSize = 10.sp) }
                  )
                }
                FilledTonalButton(
                  onClick = { showChromaColorPicker = true },
                  contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                  modifier = Modifier.height(32.dp)
                ) {
                  Icon(Icons.Filled.Colorize, contentDescription = null, modifier = Modifier.size(14.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("+ More Color", fontSize = 10.sp)
                }
              }

              if (roleChromaColors.isNotEmpty()) {
                Row(
                  modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                  horizontalArrangement = Arrangement.spacedBy(6.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  roleChromaColors.forEach { hex ->
                    val chipCol = ColorHelper.parseHex6OrNull(hex) ?: Color.Green
                    Surface(
                      onClick = { roleChromaColors = roleChromaColors.filterNot { it.equals(hex, ignoreCase = true) } },
                      shape = RoundedCornerShape(16.dp),
                      color = MaterialTheme.colorScheme.surface,
                      border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                      Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                      ) {
                        Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(chipCol))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(hex, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.Filled.Close, contentDescription = "Remove", modifier = Modifier.size(11.dp), tint = RoseError)
                      }
                    }
                  }
                }
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text("Tolerance: ${(chromaTolerance * 100).toInt()}%", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Spacer(modifier = Modifier.width(8.dp))
                  Slider(
                    value = chromaTolerance,
                    onValueChange = { chromaTolerance = it },
                    valueRange = 0.08f..0.55f,
                    modifier = Modifier.weight(1f)
                  )
                }
              }
            }
          }

          Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = permManageChannels, onClick = { permManageChannels = !permManageChannels }, label = { Text("Manage Channels", fontSize = 10.sp) })
            FilterChip(selected = permManageMessages, onClick = { permManageMessages = !permManageMessages }, label = { Text("Moderate Chat", fontSize = 10.sp) })
            FilterChip(selected = permManageRoles, onClick = { permManageRoles = !permManageRoles }, label = { Text("Manage Roles", fontSize = 10.sp) })
          }

          Button(
            onClick = {
              if (newRoleName.isNotBlank()) {
                val perms = mutableListOf("SEND_MESSAGES")
                if (permManageChannels) perms.add("MANAGE_CHANNELS")
                if (permManageMessages) perms.add("MANAGE_MESSAGES")
                if (permManageRoles) perms.add("MANAGE_ROLES")
                val hexLong = newRoleColor.toArgb().toLong() and 0xFFFFFFFFL
                viewModel.createOrUpdateServerRole(
                  serverId = server.id,
                  roleId = editingRoleId,
                  name = newRoleName,
                  colorHex = hexLong,
                  iconUri = if (canRoleIcon) newRoleIconUri else null,
                  chromaKeyColorsCsv = roleChromaColors.joinToString(","),
                  permissionsCsv = perms.joinToString(",")
                ) {
                  editingRoleId = null
                  newRoleName = ""
                  newRoleIconUri = null
                  roleChromaColors = emptyList()
                }
              }
            },
            enabled = newRoleName.isNotBlank() && !isUploading,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp)
          ) {
            Icon(if (editingRoleId == null) Icons.Filled.Add else Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(if (editingRoleId == null) "Add Role" else "Save Role Changes", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }

          HorizontalDivider(color = MaterialTheme.colorScheme.outline)
          Text("Server Roles (${roles.size}):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
          roles.forEach { role ->
            val rColor = Color(role.colorHex)
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              if (!role.iconUri.isNullOrBlank()) {
                RoleIconImage(
                  iconUri = role.iconUri,
                  chromaKeyColorsCsv = role.chromaKeyColorsCsv,
                  size = 20.dp
                )
              } else {
                Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(rColor))
              }
              Spacer(modifier = Modifier.width(8.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(role.name, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                Text(role.permissionsCsv, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
              }
              IconButton(
                onClick = {
                  editingRoleId = role.id
                  newRoleName = role.name
                  newRoleColor = Color(role.colorHex)
                  newRoleIconUri = role.iconUri
                  roleChromaColors = role.chromaKeyColorsCsv.split(",").map { it.trim() }.filter { it.isNotBlank() }
                  permManageChannels = role.permissionsCsv.contains("MANAGE_CHANNELS")
                  permManageMessages = role.permissionsCsv.contains("MANAGE_MESSAGES")
                  permManageRoles = role.permissionsCsv.contains("MANAGE_ROLES")
                },
                modifier = Modifier.size(28.dp)
              ) {
                Icon(Icons.Filled.Edit, contentDescription = "Edit", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
              }
              if (!role.name.equals("Owner", ignoreCase = true)) {
                IconButton(onClick = { viewModel.deleteServerRole(role) }, modifier = Modifier.size(28.dp)) {
                  Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete", tint = RoseError, modifier = Modifier.size(16.dp))
                }
              }
            }
          }

          HorizontalDivider(color = MaterialTheme.colorScheme.outline)
          Text("Assign Member Roles:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
          allUsers.filter { usr ->
            val isInv = usr.invisibleServerIdsCsv.split(",").map { it.trim() }.contains(server.id)
            !isInv || usr.id == currentUser?.id
          }.forEach { usr ->
            val mem = members.find { it.userId == usr.id }
            val isSelfInvisible = usr.id == currentUser?.id && usr.invisibleServerIdsCsv.split(",").map { it.trim() }.contains(server.id)
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .clickable { assignTargetUser = usr }
                .padding(vertical = 6.dp, horizontal = 4.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                UserAvatar(
                  avatarUri = usr.avatarUri,
                  displayName = usr.displayName,
                  size = 28.dp,
                  showStatus = true,
                  presenceStatus = usr.presenceStatus,
                  lastSeenAt = usr.lastSeenAt,
                  userId = usr.id
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(
                    if (isSelfInvisible) "${usr.displayName} (Invisible)" else usr.displayName,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp
                  )
                  Text("@${usr.username}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }
              val roleBadgeColor = Color(mem?.roleColor ?: 0xFF949BA4)
              Row(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(roleBadgeColor.copy(alpha = 0.2f))
                  .padding(horizontal = 8.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                if (!mem?.roleIconUri.isNullOrBlank()) {
                  RoleIconImage(
                    iconUri = mem?.roleIconUri,
                    chromaKeyColorsCsv = mem?.roleChromaColorsCsv ?: "",
                    size = 14.dp
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                }
                Text(mem?.role ?: "Not Joined", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = roleBadgeColor)
              }
            }
          }
        }
        if (selectedTab == 2) {
          Text("Create New Channel Category:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            OutlinedTextField(
              value = newCategoryName,
              onValueChange = { newCategoryName = it },
              label = { Text("Category Name (e.g. GAMING)") },
              singleLine = true,
              modifier = Modifier.weight(1f)
            )
            Button(
              onClick = {
                if (newCategoryName.isNotBlank()) {
                  viewModel.createCategory(server.id, newCategoryName) {
                    newCategoryName = ""
                  }
                }
              },
              enabled = newCategoryName.isNotBlank(),
              shape = RoundedCornerShape(10.dp)
            ) {
              Text("Add")
            }
          }

          categories.forEach { cat ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Folder, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(cat.name, fontWeight = FontWeight.Bold, fontSize = 12.sp)
              }
              IconButton(onClick = { viewModel.deleteCategory(cat) }, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete Category", tint = RoseError, modifier = Modifier.size(16.dp))
              }
            }
          }

          if (categories.isNotEmpty() && channels.isNotEmpty()) {
            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
            Text("Move Channel to Category:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            channels.forEach { ch ->
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(8.dp))
                  .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                  .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
              ) {
                Text("#${ch.name} (${ch.type})", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(
                  modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                  horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                  categories.forEach { cat ->
                    FilterChip(
                      selected = ch.categoryId == cat.id,
                      onClick = { viewModel.moveChannelToCategory(ch, cat.id) },
                      label = { Text(cat.name, fontSize = 10.sp) }
                    )
                  }
                }
              }
            }
          }

          if (isVerifiedAdmin) {
            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = if (server.isVanished) RoseError.copy(alpha = 0.16f) else MaterialTheme.colorScheme.surfaceVariant,
              border = androidx.compose.foundation.BorderStroke(1.dp, if (server.isVanished) RoseError else MaterialTheme.colorScheme.outline),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(s.vanishServerBtn, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = if (server.isVanished) RoseError else MaterialTheme.colorScheme.onSurface)
                  Text("Hide this server from non-admin public lists.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(
                  checked = server.isVanished,
                  onCheckedChange = { vanish -> viewModel.toggleServerVanish(server.id, vanish) }
                )
              }
            }
          }
        }
      }
    },
    confirmButton = {
      if (selectedTab == 0) {
        Button(
          onClick = {
            viewModel.updateServerAppearance(
              serverId = server.id,
              name = editName,
              description = editDesc,
              iconUri = editIconUri,
              bannerUri = editBannerUri,
              serverTag = editServerTag,
              serverTagIcon = editServerTagIcon,
              supportedGame = editGameIds.joinToString(",")
            ) {
              onDismiss()
            }
          },
          enabled = !isUploading
        ) {
          Text(s.save)
        }
      } else {
        TextButton(onClick = onDismiss) { Text(s.close) }
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text(s.close) }
    }
  )

  if (showRoleColorPicker) {
    PickColorBottomSheet(
      initialColor = newRoleColor,
      title = "Pick a Role Color",
      onDismiss = { showRoleColorPicker = false },
      onSelect = { chosen ->
        newRoleColor = chosen
        showRoleColorPicker = false
      }
    )
  }

  if (showChromaColorPicker) {
    PickColorBottomSheet(
      initialColor = Color(0xFF00FF00),
      title = "Pick Chroma Key Color",
      onDismiss = { showChromaColorPicker = false },
      onSelect = { chosen ->
        val hex = ColorHelper.toHex6(chosen)
        if (roleChromaColors.none { it.equals(hex, ignoreCase = true) }) {
          roleChromaColors = roleChromaColors + hex
        }
        showChromaColorPicker = false
      }
    )
  }

  if (assignTargetUser != null) {
    val u = assignTargetUser!!
    AlertDialog(
      onDismissRequest = { assignTargetUser = null },
      title = { Text("Select Role for @${u.username}", fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          roles.forEach { r ->
            val col = Color(r.colorHex)
            Surface(
              onClick = {
                viewModel.assignRoleToUser(server.id, u.id, r)
                assignTargetUser = null
              },
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.surfaceVariant,
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                if (!r.iconUri.isNullOrBlank()) {
                  RoleIconImage(iconUri = r.iconUri, chromaKeyColorsCsv = r.chromaKeyColorsCsv, size = 18.dp)
                } else {
                  Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(col))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(r.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { assignTargetUser = null }) { Text(s.cancel) }
      }
    )
  }
}
