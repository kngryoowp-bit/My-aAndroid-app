package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AppFontOption
import com.example.ui.theme.ColorHelper
import kotlin.math.roundToInt
import kotlin.math.sin

enum class DisplayNameEffect(val key: String, val label: String) {
  SOLID("SOLID", "Solid"),
  GRADIENT("GRADIENT", "Gradient"),
  GLOW("GLOW", "Soft Glow"),
  NEON("NEON", "Neon"),
  FLOATING("FLOATING", "Floating"),
  WAVE("WAVE", "Wave"),
  PULSE("PULSE", "Pulse"),
  SHIMMER("SHIMMER", "Shimmer"),
  RAINBOW("RAINBOW", "Rainbow"),
  TYPING("TYPING", "Typing"),
  REVERSE_TYPING("REVERSE_TYPING", "Reverse Typing"),
  OUTLINE("OUTLINE", "Outline"),
  POP("POP", "Toon Pop");

  companion object {
    fun fromKey(key: String?): DisplayNameEffect =
      entries.find { it.key.equals(key, ignoreCase = true) } ?: GRADIENT
  }
}

@Composable
fun StyledDisplayName(
  name: String,
  fontKey: String = "SERIF",
  colorsCsv: String = "",
  effectKey: String = "GRADIENT",
  fontSize: TextUnit = 16.sp,
  fontWeight: FontWeight = FontWeight.Bold,
  maxLines: Int = 1,
  lowPerfMode: Boolean = false,
  modifier: Modifier = Modifier
) {
  val fontFamily = AppFontOption.fromKey(fontKey).fontFamily
  val defaultColor = MaterialTheme.colorScheme.onSurface
  val parsedColors = ColorHelper.parseColorsCsv(colorsCsv, listOf(defaultColor.value.toLong()))
  val rawEffect = DisplayNameEffect.fromKey(effectKey)
  val effect = if (lowPerfMode && rawEffect in setOf(
      DisplayNameEffect.FLOATING,
      DisplayNameEffect.WAVE,
      DisplayNameEffect.PULSE,
      DisplayNameEffect.SHIMMER,
      DisplayNameEffect.RAINBOW,
      DisplayNameEffect.TYPING,
      DisplayNameEffect.REVERSE_TYPING
    )
  ) {
    if (parsedColors.size >= 2) DisplayNameEffect.GRADIENT else DisplayNameEffect.SOLID
  } else {
    rawEffect
  }
  val primaryColor = parsedColors.firstOrNull() ?: defaultColor

  val animatedEffects = setOf(
    DisplayNameEffect.FLOATING,
    DisplayNameEffect.WAVE,
    DisplayNameEffect.PULSE,
    DisplayNameEffect.SHIMMER,
    DisplayNameEffect.RAINBOW,
    DisplayNameEffect.TYPING,
    DisplayNameEffect.REVERSE_TYPING
  )

  val phase = if (!lowPerfMode && effect in animatedEffects) {
    val inf = rememberInfiniteTransition(label = "display_name_${effect.key}")
    val value by inf.animateFloat(
      initialValue = 0f,
      targetValue = 1f,
      animationSpec = infiniteRepeatable(
        animation = tween(
          durationMillis = when (effect) {
            DisplayNameEffect.TYPING, DisplayNameEffect.REVERSE_TYPING -> 3200
            DisplayNameEffect.RAINBOW -> 4200
            DisplayNameEffect.SHIMMER -> 2200
            else -> 2000
          },
          easing = LinearEasing
        ),
        repeatMode = if (effect == DisplayNameEffect.FLOATING || effect == DisplayNameEffect.PULSE) {
          RepeatMode.Reverse
        } else {
          RepeatMode.Restart
        }
      ),
      label = "effect_phase"
    )
    value
  } else 0f

  val rainbowColors = listOf(
    Color(0xFFF43F5E),
    Color(0xFFF59E0B),
    Color(0xFF22C55E),
    Color(0xFF38BDF8),
    Color(0xFFA855F7),
    Color(0xFFF43F5E)
  )

  val displayText = when (effect) {
    DisplayNameEffect.TYPING -> {
      if (name.isEmpty()) "" else {
        val count = ((phase * (name.length + 2)).toInt()).coerceIn(1, name.length)
        name.take(count)
      }
    }
    DisplayNameEffect.REVERSE_TYPING -> {
      if (name.isEmpty()) "" else {
        val len = name.length
        val progress = if (phase <= 0.5f) phase * 2f else (1f - phase) * 2f
        val count = (progress * len).roundToInt().coerceIn(1, len)
        name.take(count)
      }
    }
    else -> name
  }

  val baseColors = if (parsedColors.size >= 2) parsedColors.take(5) else listOf(primaryColor, primaryColor.copy(alpha = 0.72f))

  val foregroundStyle = when (effect) {
    DisplayNameEffect.SOLID -> TextStyle(
      fontFamily = fontFamily,
      fontWeight = fontWeight,
      fontSize = fontSize,
      color = primaryColor
    )
    DisplayNameEffect.GLOW -> TextStyle(
      fontFamily = fontFamily,
      fontWeight = fontWeight,
      fontSize = fontSize,
      color = primaryColor,
      shadow = Shadow(
        color = primaryColor.copy(alpha = 0.72f),
        blurRadius = 14f
      )
    )
    DisplayNameEffect.NEON -> TextStyle(
      fontFamily = fontFamily,
      fontWeight = fontWeight,
      fontSize = fontSize,
      color = Color.White,
      shadow = Shadow(
        color = primaryColor.copy(alpha = 0.98f),
        blurRadius = 24f
      )
    )
    DisplayNameEffect.SHIMMER -> {
      val shift = phase * 320f
      TextStyle(
        fontFamily = fontFamily,
        fontWeight = fontWeight,
        fontSize = fontSize,
        brush = Brush.linearGradient(
          colors = listOf(primaryColor.copy(alpha = 0.65f), Color.White, primaryColor.copy(alpha = 0.65f)),
          start = Offset(shift - 140f, 0f),
          end = Offset(shift + 140f, 60f)
        )
      )
    }
    DisplayNameEffect.RAINBOW -> {
      val shift = phase * 400f
      TextStyle(
        fontFamily = fontFamily,
        fontWeight = fontWeight,
        fontSize = fontSize,
        brush = Brush.linearGradient(
          colors = rainbowColors,
          start = Offset(shift, 0f),
          end = Offset(shift + 280f, 40f)
        )
      )
    }
    DisplayNameEffect.GRADIENT,
    DisplayNameEffect.FLOATING,
    DisplayNameEffect.WAVE,
    DisplayNameEffect.PULSE,
    DisplayNameEffect.TYPING,
    DisplayNameEffect.REVERSE_TYPING,
    DisplayNameEffect.OUTLINE,
    DisplayNameEffect.POP -> {
      if (parsedColors.size >= 2) {
        TextStyle(
          fontFamily = fontFamily,
          fontWeight = fontWeight,
          fontSize = fontSize,
          brush = Brush.linearGradient(baseColors)
        )
      } else {
        TextStyle(
          fontFamily = fontFamily,
          fontWeight = fontWeight,
          fontSize = fontSize,
          color = primaryColor
        )
      }
    }
  }

  val animModifier = when (effect) {
    DisplayNameEffect.FLOATING -> modifier.offset {
      IntOffset(0, ((-3f + 6f * phase).dp.toPx()).roundToInt())
    }
    DisplayNameEffect.WAVE -> modifier.offset {
      val y = sin(phase * 2.0 * Math.PI).toFloat() * 2.5f
      IntOffset(0, y.dp.toPx().roundToInt())
    }
    DisplayNameEffect.PULSE -> modifier.alpha(0.68f + 0.32f * phase)
    else -> modifier
  }

  when (effect) {
    DisplayNameEffect.OUTLINE -> {
      Box(modifier = animModifier) {
        Text(
          text = displayText,
          style = TextStyle(
            fontFamily = fontFamily,
            fontWeight = fontWeight,
            fontSize = fontSize,
            color = Color.Black.copy(alpha = 0.85f),
            drawStyle = Stroke(width = 6f)
          ),
          maxLines = maxLines,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          text = displayText,
          style = foregroundStyle,
          maxLines = maxLines,
          overflow = TextOverflow.Ellipsis
        )
      }
    }
    DisplayNameEffect.POP -> {
      Box(modifier = animModifier) {
        Text(
          text = displayText,
          style = TextStyle(
            fontFamily = fontFamily,
            fontWeight = fontWeight,
            fontSize = fontSize,
            color = Color.Black.copy(alpha = 0.8f)
          ),
          maxLines = maxLines,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.offset(x = 2.dp, y = 2.dp)
        )
        Text(
          text = displayText,
          style = foregroundStyle,
          maxLines = maxLines,
          overflow = TextOverflow.Ellipsis
        )
      }
    }
    else -> {
      Text(
        text = displayText,
        style = foregroundStyle,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
        modifier = animModifier
      )
    }
  }
}
