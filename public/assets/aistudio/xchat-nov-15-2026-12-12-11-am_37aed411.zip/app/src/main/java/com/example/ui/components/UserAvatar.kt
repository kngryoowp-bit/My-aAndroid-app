package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.utils.CloudMediaHelper
import java.io.File

@Composable
fun UserAvatar(
  avatarUri: String?,
  displayName: String,
  size: Dp = 44.dp,
  frameId: String? = null,
  isOnline: Boolean = true,
  showStatus: Boolean = false,
  presenceStatus: String? = null,
  lastSeenAt: Long = 0L,
  userId: String = "",
  backgroundColor: Long = 0xFF8B5CF6,
  lowPerfMode: Boolean = false,
  modifier: Modifier = Modifier
) {
  val initial = displayName.firstOrNull()?.uppercaseChar()?.toString() ?: "X"
  val context = LocalContext.current

  val isAnimatedFrame = !lowPerfMode && frameId != null && frameId in setOf(
    "frame_royal_gold",
    "frame_neon_iris",
    "frame_diamond_crest",
    "frame_obsidian_halo",
    "frame_winter_frost",
    "frame_pulse_crimson"
  )

  val frameRotation = if (isAnimatedFrame) {
    val inf = rememberInfiniteTransition(label = "frame_rot_$frameId")
    val deg by inf.animateFloat(
      initialValue = 0f,
      targetValue = 360f,
      animationSpec = infiniteRepeatable(
        animation = tween(durationMillis = 5200, easing = LinearEasing),
        repeatMode = RepeatMode.Restart
      ),
      label = "frame_deg"
    )
    deg
  } else 0f

  val frameColors: List<Color>? = when (frameId) {
    "frame_royal_gold" -> listOf(Color(0xFFEAB308), Color(0xFFFDE047), Color(0xFFCA8A04), Color(0xFFEAB308))
    "frame_neon_iris" -> listOf(Color(0xFF8B5CF6), Color(0xFFEC4899), Color(0xFF3B82F6), Color(0xFF8B5CF6))
    "frame_diamond_crest" -> listOf(Color(0xFF06B6D4), Color(0xFF67E8F9), Color(0xFF0284C7), Color(0xFF06B6D4))
    "frame_obsidian_halo" -> listOf(Color(0xFFF5F7FA), Color(0xFF94A3B8), Color(0xFF1F2430), Color(0xFFF5F7FA))
    "frame_winter_frost" -> listOf(Color(0xFFE0F2FE), Color(0xFF38BDF8), Color(0xFF818CF8), Color(0xFFE0F2FE))
    "frame_pulse_crimson" -> listOf(Color(0xFFF43F5E), Color(0xFFFB7185), Color(0xFF881337), Color(0xFFF43F5E))
    else -> null
  }

  var recoveredFile by remember(avatarUri) { mutableStateOf<File?>(null) }
  var isLoading by remember(avatarUri) { mutableStateOf(false) }
  var isError by remember(avatarUri) { mutableStateOf(false) }
  var attemptedRecovery by remember(avatarUri) { mutableStateOf(false) }

  val imageRequest = remember(avatarUri, recoveredFile) {
    val model = recoveredFile ?: CloudMediaHelper.resolveCoilModel(avatarUri, context)
    if (model != null) {
      ImageRequest.Builder(context)
        .data(model)
        .allowHardware(false)
        .crossfade(false)
        .build()
    } else null
  }

  LaunchedEffect(isError, avatarUri) {
    if (isError && !attemptedRecovery && !avatarUri.isNullOrBlank() &&
      (avatarUri.startsWith("http://") || avatarUri.startsWith("https://"))
    ) {
      attemptedRecovery = true
      val res = CloudMediaHelper.ensureLocalCachedFile(context, avatarUri, "avatar_${displayName.take(6)}.gif")
      val file = res.getOrNull()
      if (file != null && file.exists() && file.length() > 0L) {
        isError = false
        recoveredFile = file
      }
    }
  }

  Box(
    modifier = modifier.size(size),
    contentAlignment = Alignment.Center
  ) {
    if (frameColors != null) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .rotate(frameRotation)
          .border(3.dp, Brush.sweepGradient(frameColors), CircleShape)
      )
    }

    Box(
      modifier = Modifier
        .fillMaxSize()
        .then(
          if (frameColors == null) Modifier.border(1.5.dp, MaterialTheme.colorScheme.outline, CircleShape)
          else Modifier.padding(3.5.dp)
        )
        .clip(CircleShape)
        .background(
          Brush.linearGradient(
            listOf(
              Color(backgroundColor),
              Color(backgroundColor).copy(alpha = 0.78f)
            )
          )
        ),
      contentAlignment = Alignment.Center
    ) {
      if (imageRequest == null || isError) {
        Text(
          text = initial,
          color = Color.White,
          fontFamily = FontFamily.Serif,
          fontWeight = FontWeight.Bold,
          fontSize = (size.value * 0.42f).sp
        )
      }

      if (imageRequest != null && !isError) {
        AsyncImage(
          model = imageRequest,
          contentDescription = "Avatar $displayName",
          contentScale = ContentScale.Crop,
          onLoading = { isLoading = true },
          onSuccess = {
            isLoading = false
            isError = false
          },
          onError = {
            isLoading = false
            isError = true
          },
          modifier = Modifier.fillMaxSize()
        )
        if (isLoading) {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .background(Color.Black.copy(alpha = 0.35f)),
            contentAlignment = Alignment.Center
          ) {
            CircularProgressIndicator(
              modifier = Modifier.size((size * 0.42f).coerceIn(12.dp, 28.dp)),
              strokeWidth = 2.dp,
              color = Color.White
            )
          }
        }
      }
    }

    if (showStatus) {
      val effectiveStatus = presenceStatus ?: if (isOnline) "ONLINE" else "OFFLINE"
      OnlineStatusDot(
        presenceStatus = effectiveStatus,
        lastSeenAt = lastSeenAt,
        userId = userId,
        size = (size * 0.28f).coerceAtLeast(8.dp),
        modifier = Modifier.align(Alignment.BottomEnd)
      )
    }
  }
}
