package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.ServerMemberEntity
import com.example.data.model.UserEntity
import com.example.data.model.UserGameAppEntity
import com.example.ui.theme.*
import com.example.utils.AppActivityTracker
import com.example.utils.CloudMediaHelper
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun UserProfileFullDialog(
  user: UserEntity,
  isSelf: Boolean,
  memberRole: ServerMemberEntity? = null,
  isUserMuted: Boolean = false,
  followersCount: Int = 0,
  followingCount: Int = 0,
  isFollowing: Boolean = false,
  gamesApps: List<UserGameAppEntity> = emptyList(),
  onToggleFollow: () -> Unit = {},
  onVoiceCall: () -> Unit = {},
  onVideoCall: () -> Unit = {},
  onReportUser: () -> Unit = {},
  onToggleMuteUser: () -> Unit = {},
  onDismiss: () -> Unit,
  onSendDm: () -> Unit,
  onAddFriend: () -> Unit
) {
  val context = LocalContext.current
  val strings = LocalStrings.current
  val isUserAstral = user.subscriptionTier.equals("ASTRAL", ignoreCase = true) || user.isOwner
  val tierDisplay = when (user.subscriptionTier.uppercase()) {
    "VIP", "ASTRAL" -> "ASTRAL"
    "PREM", "ASTRIX" -> "ASTRIX"
    else -> "FREE"
  }
  val isOnlineRecent = isUserOnlineNow(user)
  val presenceText = presenceLabelFor(user.presenceStatus, isOnlineRecent)

  val bgStops = remember(user.profileBgColorsCsv) {
    ColorHelper.parseColorsCsv(
      user.profileBgColorsCsv,
      listOf(0xFF2B2D31L, 0xFF3B2E5AL, 0xFF1E1F22L)
    )
  }
  val profileBgBrush = remember(bgStops) {
    if (bgStops.size >= 2) {
      Brush.verticalGradient(bgStops.take(3))
    } else {
      Brush.verticalGradient(listOf(bgStops.first(), bgStops.first()))
    }
  }
  var recoveredBannerFile by remember(user.bannerUri) { mutableStateOf<java.io.File?>(null) }
  var isBannerLoading by remember(user.bannerUri) { mutableStateOf(false) }
  var isBannerError by remember(user.bannerUri) { mutableStateOf(false) }
  var attemptedBannerRecovery by remember(user.bannerUri) { mutableStateOf(false) }

  val bannerRequest = remember(user.bannerUri, isUserAstral, recoveredBannerFile) {
    if (!user.bannerUri.isNullOrBlank() && isUserAstral) {
      val model = recoveredBannerFile ?: CloudMediaHelper.resolveCoilModel(user.bannerUri, context)
      model?.let {
        ImageRequest.Builder(context)
          .data(it)
          .allowHardware(false)
          .crossfade(false)
          .build()
      }
    } else null
  }
  LaunchedEffect(isBannerError, user.bannerUri) {
    val uri = user.bannerUri
    if (isBannerError && !attemptedBannerRecovery && !uri.isNullOrBlank() &&
      (uri.startsWith("http://") || uri.startsWith("https://"))
    ) {
      attemptedBannerRecovery = true
      val f = CloudMediaHelper.ensureLocalCachedFile(context, uri, "banner_${user.id.take(6)}.gif").getOrNull()
      if (f != null && f.exists() && f.length() > 0L) {
        isBannerError = false
        recoveredBannerFile = f
      }
    }
  }
  val connections = remember(user.connectionsJson) {
    AppActivityTracker.parseConnections(user.connectionsJson)
  }

  // Live elapsed timer for playing game / active app
  var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
  LaunchedEffect(user.activeAppName, user.activeAppStartedAt) {
    if (!user.activeAppName.isNullOrBlank()) {
      while (true) {
        nowMs = System.currentTimeMillis()
        delay(1000L)
      }
    }
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth(0.92f)
        .widthIn(max = 460.dp)
        .heightIn(max = 680.dp)
        .testTag("full_user_profile_dialog"),
      shape = RoundedCornerShape(22.dp),
      colors = CardDefaults.cardColors(containerColor = Color.Transparent),
      border = CardDefaults.outlinedCardBorder().copy(
        brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.outline))
      )
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(profileBgBrush)
          .verticalScroll(rememberScrollState())
      ) {
        // Banner + Profile Effect Overlay
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(136.dp)
            .background(Brush.linearGradient(listOf(Color(user.profileColor), MaterialTheme.colorScheme.surfaceVariant)))
        ) {
          if (bannerRequest != null && !isBannerError) {
            AsyncImage(
              model = bannerRequest,
              contentDescription = "Banner ${user.displayName}",
              contentScale = ContentScale.Crop,
              onLoading = { isBannerLoading = true },
              onSuccess = {
                isBannerLoading = false
                isBannerError = false
              },
              onError = {
                isBannerLoading = false
                isBannerError = true
              },
              modifier = Modifier.fillMaxSize()
            )
            if (isBannerLoading) {
              Box(
                modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.25f)),
                contentAlignment = Alignment.Center
              ) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp, color = Color.White)
              }
            }
          }

          AnimatedProfileEffectOverlay(
            effectId = user.equippedEffect,
            modifier = Modifier.matchParentSize()
          )

          IconButton(
            onClick = onDismiss,
            modifier = Modifier
              .align(Alignment.TopEnd)
              .padding(8.dp)
              .size(34.dp)
              .clip(CircleShape)
              .background(Color.Black.copy(alpha = 0.55f))
          ) {
            Icon(Icons.Filled.Close, contentDescription = strings.close, tint = Color.White, modifier = Modifier.size(18.dp))
          }
        }

        // Overlapping Avatar with real-time presence dot
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp)
            .offset(y = (-36).dp),
          verticalAlignment = Alignment.Bottom,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          UserAvatar(
            avatarUri = user.avatarUri,
            displayName = user.displayName,
            size = 82.dp,
            frameId = user.equippedFrame,
            isOnline = isOnlineRecent,
            showStatus = true,
            presenceStatus = user.presenceStatus,
            lastSeenAt = user.lastSeenAt,
            userId = user.id,
            backgroundColor = user.profileColor
          )

          Row(
            modifier = Modifier.padding(bottom = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            if (user.isOwner) {
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(MaterialTheme.colorScheme.primary)
                  .padding(horizontal = 8.dp, vertical = 3.dp)
              ) {
                Text("OWNER", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
              }
            }
            if (tierDisplay != "FREE") {
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(if (tierDisplay == "ASTRAL") AstralViolet else AstrixGold)
                  .padding(horizontal = 8.dp, vertical = 3.dp)
              ) {
                Text(tierDisplay, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
              }
            }
          }
        }

        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp)
            .offset(y = (-20).dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            StyledDisplayName(
              name = user.displayName,
              fontKey = user.displayNameFont,
              colorsCsv = user.displayNameColorsCsv,
              effectKey = user.displayNameEffect,
              fontSize = 22.sp,
              fontWeight = FontWeight.Bold,
              maxLines = 2
            )
            Text(
              text = "@${user.username} • ${user.pronouns}",
              fontSize = 13.sp,
              color = Color.White.copy(alpha = 0.78f)
            )
            val joinedText = remember(user.createdAt) {
              SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(user.createdAt))
            }
            Row(
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
              ) {
                Text(
                  text = "Lv.${user.level} • ${user.xp} XP",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
              }
              Text(
                text = "${tr("Joined", "Bergabung", "Menyertai", "参加日")} $joinedText",
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.65f)
              )
            }
            Row(
              horizontalArrangement = Arrangement.spacedBy(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text("$followersCount ${strings.followersLabel}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
              Text("$followingCount ${strings.followingLabel}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.85f))
            }

            // Presence & Custom Status Tag Pills
            Row(
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color.Black.copy(alpha = 0.4f),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.14f))
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  OnlineStatusDot(
                    presenceStatus = user.presenceStatus,
                    lastSeenAt = user.lastSeenAt,
                    userId = user.id,
                    size = 8.dp
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = presenceText,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                  )
                }
              }

              if (user.statusTag.isNotBlank()) {
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
                  border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                ) {
                  Text(
                    text = user.statusTag,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                  )
                }
              }
            }

            if (memberRole != null) {
              val roleCol = Color(memberRole.roleColor)
              Row(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(roleCol.copy(alpha = 0.18f))
                  .border(1.dp, roleCol.copy(alpha = 0.65f), RoundedCornerShape(6.dp))
                  .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                if (!memberRole.roleIconUri.isNullOrBlank()) {
                  RoleIconImage(
                    iconUri = memberRole.roleIconUri,
                    chromaKeyColorsCsv = memberRole.roleChromaColorsCsv,
                    size = 16.dp
                  )
                } else {
                  Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(roleCol))
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "Role: ${memberRole.role}",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = Color.White
                )
              }
            }
          }

          // Live Playing / Active App Card with elapsed timer
          if (!user.activeAppName.isNullOrBlank()) {
            val elapsedSec = ((nowMs - user.activeAppStartedAt).coerceAtLeast(0L) / 1000L)
            val mins = (elapsedSec % 3600) / 60
            val secs = elapsedSec % 60
            val hrs = elapsedSec / 3600
            val timerStr = if (hrs > 0) {
              String.format(java.util.Locale.US, "%02d:%02d:%02d", hrs, mins, secs)
            } else {
              String.format(java.util.Locale.US, "%02d:%02d", mins, secs)
            }
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = EmeraldSuccess.copy(alpha = 0.14f),
              border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.5f)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Filled.SportsEsports, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(tr("NOW PLAYING", "SEDANG MEMAINKAN", "SEDANG DIMAINKAN", "プレイ中"), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                  Text(user.activeAppName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
                Text(timerStr, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
              }
            }
          }

          Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color.Black.copy(alpha = 0.34f),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Text(
                text = strings.aboutMeHeader,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.8.sp,
                color = Color.White.copy(alpha = 0.7f)
              )
              Text(
                text = user.bio,
                fontSize = 13.sp,
                color = Color.White,
                lineHeight = 19.sp
              )

              if (user.equippedBadges.isNotBlank()) {
                HorizontalDivider(color = Color.White.copy(alpha = 0.14f))
                Text(
                  text = strings.officialBadgesHeader,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  letterSpacing = 0.8.sp,
                  color = Color.White.copy(alpha = 0.7f)
                )
                BadgesRow(
                  badgeIdsCsv = user.equippedBadges,
                  badgeSize = 26.dp,
                  spacing = 6.dp,
                  wrap = true
                )
              }

              if (connections.isNotEmpty()) {
                HorizontalDivider(color = Color.White.copy(alpha = 0.14f))
                Text(
                  text = strings.connectionsTitle,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  letterSpacing = 0.8.sp,
                  color = Color.White.copy(alpha = 0.7f)
                )
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                  connections.forEach { conn ->
                    Row(
                      modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White.copy(alpha = 0.08f))
                        .padding(horizontal = 10.dp, vertical = 7.dp),
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Icon(Icons.Filled.Link, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                      Spacer(modifier = Modifier.width(8.dp))
                      Column(modifier = Modifier.weight(1f)) {
                        Text("${conn.platformName} • @${conn.handle}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                        if (conn.subtitle.isNotBlank()) {
                          Text(conn.subtitle, fontSize = 10.sp, color = Color.White.copy(alpha = 0.7f))
                        }
                      }
                      if (conn.verified) {
                        Icon(Icons.Filled.Verified, contentDescription = "Verified", tint = EmeraldSuccess, modifier = Modifier.size(16.dp))
                      }
                    }
                  }
                }
              }
              if (gamesApps.isNotEmpty()) {
                HorizontalDivider(color = Color.White.copy(alpha = 0.14f))
                Text(
                  text = "${strings.myGamesAppsHeader} (${gamesApps.size})",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  letterSpacing = 0.8.sp,
                  color = Color.White.copy(alpha = 0.7f)
                )
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                  gamesApps.take(5).forEach { gm ->
                    Row(
                      modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White.copy(alpha = 0.08f))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Icon(Icons.Filled.SportsEsports, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(16.dp))
                      Spacer(modifier = Modifier.width(8.dp))
                      Column(modifier = Modifier.weight(1f)) {
                        Text(gm.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        val meta = listOfNotNull(
                          gm.category.takeIf { it.isNotBlank() },
                          gm.activityStatus.takeIf { it.isNotBlank() },
                          gm.description.takeIf { it.isNotBlank() }
                        ).joinToString(" • ")
                        if (meta.isNotBlank()) {
                          Text(
                            meta,
                            fontSize = 10.sp,
                            color = Color.White.copy(alpha = 0.72f),
                            maxLines = 1
                          )
                        }
                      }
                    }
                  }
                }
              }
            }
          }

          if (!isSelf) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Button(
                onClick = onSendDm,
                modifier = Modifier.weight(1f).height(46.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
              ) {
                Icon(Icons.Filled.ChatBubble, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("DM", fontWeight = FontWeight.Bold, fontSize = 13.sp)
              }
              OutlinedButton(
                onClick = onToggleFollow,
                modifier = Modifier.weight(1f).height(46.dp),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isFollowing) EmeraldSuccess else Color.White.copy(alpha = 0.45f))
              ) {
                Icon(if (isFollowing) Icons.Filled.Check else Icons.Filled.PersonAddAlt1, contentDescription = null, tint = if (isFollowing) EmeraldSuccess else Color.White, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (isFollowing) strings.followingLabel else strings.followBtn, color = if (isFollowing) EmeraldSuccess else Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
              }
              OutlinedButton(
                onClick = onAddFriend,
                modifier = Modifier.height(46.dp),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.45f))
              ) {
                Icon(Icons.Filled.GroupAdd, contentDescription = strings.addFriendBtn, tint = Color.White, modifier = Modifier.size(18.dp))
              }
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              FilledTonalButton(
                onClick = onVoiceCall,
                modifier = Modifier.weight(1f).height(44.dp),
                shape = RoundedCornerShape(10.dp)
              ) {
                Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(strings.callVoiceBtn, fontSize = 12.sp, fontWeight = FontWeight.Bold)
              }
              FilledTonalButton(
                onClick = onVideoCall,
                modifier = Modifier.weight(1f).height(44.dp),
                shape = RoundedCornerShape(10.dp)
              ) {
                Icon(Icons.Filled.Videocam, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(strings.callVideoBtn, fontSize = 12.sp, fontWeight = FontWeight.Bold)
              }
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              OutlinedButton(
                onClick = onToggleMuteUser,
                modifier = Modifier.weight(1f).height(44.dp).testTag("mute_user_notif_button"),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(
                  1.dp,
                  if (isUserMuted) AmberWarning else Color.White.copy(alpha = 0.35f)
                )
              ) {
                Icon(
                  if (isUserMuted) Icons.Filled.NotificationsOff else Icons.Filled.NotificationsActive,
                  contentDescription = null,
                  tint = if (isUserMuted) AmberWarning else Color.White,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (isUserMuted) strings.unmuteUserNotif else strings.muteUserNotif,
                  color = if (isUserMuted) AmberWarning else Color.White,
                  fontWeight = FontWeight.SemiBold,
                  fontSize = 12.sp
                )
              }
              OutlinedButton(
                onClick = onReportUser,
                modifier = Modifier.height(44.dp),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, RoseError.copy(alpha = 0.65f))
              ) {
                Icon(Icons.Filled.Flag, contentDescription = tr("Report", "Laporkan", "Lapor", "報告"), tint = RoseError, modifier = Modifier.size(16.dp))
              }
            }
          }
        }
      }
    }
  }
}
