package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.LockClock
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserRestrictionEntity
import com.example.ui.theme.*
import kotlinx.coroutines.delay

/**
 * In-App Only XChat Lock Screen restriction overlay.
 * Displays live HH:MM:SS countdown, admin role, reason, custom message, and appeal form.
 * Never locks or restricts the Android OS outside the XChat app.
 */
@Composable
fun XChatLockScreenOverlay(
  restriction: UserRestrictionEntity,
  onSubmitAppeal: (String) -> Unit,
  onLogout: () -> Unit,
  modifier: Modifier = Modifier
) {
  val strings = LocalStrings.current
  var remainingMs by remember(restriction.expiresAt) {
    mutableLongStateOf((restriction.expiresAt - System.currentTimeMillis()).coerceAtLeast(0L))
  }
  var appealInput by remember { mutableStateOf("") }

  LaunchedEffect(restriction.expiresAt) {
    while (remainingMs > 0L) {
      delay(1000L)
      remainingMs = (restriction.expiresAt - System.currentTimeMillis()).coerceAtLeast(0L)
    }
  }

  val totalSec = remainingMs / 1000L
  val hrs = totalSec / 3600L
  val mins = (totalSec % 3600L) / 60L
  val secs = totalSec % 60L
  val countdownText = "%02d:%02d:%02d".format(hrs, mins, secs)

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(ObsidianBlack.copy(alpha = 0.96f))
      .systemBarsPadding()
      .padding(24.dp)
      .testTag("xchat_lock_screen_overlay"),
    contentAlignment = Alignment.Center
  ) {
    GlassCard(
      borderColor = RoseError.copy(alpha = 0.65f),
      modifier = Modifier.widthIn(max = 480.dp).fillMaxWidth()
    ) {
      Column(
        modifier = Modifier.padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Icon(
          imageVector = Icons.Filled.LockClock,
          contentDescription = strings.lockScreenRestrictedTitle,
          tint = RoseError,
          modifier = Modifier.size(52.dp)
        )
        Text(
          text = strings.lockScreenRestrictedTitle,
          color = PureWhiteText,
          fontSize = 20.sp,
          fontWeight = FontWeight.Bold,
          textAlign = TextAlign.Center
        )
        Surface(
          color = RoseError.copy(alpha = 0.16f),
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, RoseError.copy(alpha = 0.45f))
        ) {
          Text(
            text = "${tr("Time Remaining", "Sisa Waktu", "Baki Masa", "残り時間")}: $countdownText",
            color = PureWhiteText,
            fontSize = 24.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
          )
        }

        Text(
          text = "${tr("Applied by", "Diterapkan oleh", "Dikenakan oleh", "適用者")}: ${restriction.adminRole} • ${tr("Reason", "Alasan", "Sebab", "理由")}: ${restriction.reason}",
          color = AmberWarning,
          fontSize = 12.sp,
          fontWeight = FontWeight.SemiBold,
          textAlign = TextAlign.Center
        )
        Text(
          text = restriction.customMessage.ifBlank {
            tr(
              "Please review the XChat community guidelines before continuing.",
              "Mohon tinjau kembali aturan komunitas XChat sebelum melanjutkan.",
              "Sila semak semula peraturan komuniti XChat sebelum meneruskan.",
              "続行する前にXChatコミュニティガイドラインをご確認ください。"
            )
          },
          color = SilverAccent,
          fontSize = 13.sp,
          textAlign = TextAlign.Center
        )

        HorizontalDivider(color = GlassBorderSubtle)

        when (restriction.appealStatus) {
          "PENDING" -> {
            Text(
              tr(
                "Your appeal is under review by XChat Admin: \"${restriction.appealMessage}\"",
                "Banding Anda sedang ditinjau oleh Admin XChat: \"${restriction.appealMessage}\"",
                "Rayuan anda sedang disemak oleh Admin XChat: \"${restriction.appealMessage}\"",
                "異議申し立てはXChat管理者により審査中です: \"${restriction.appealMessage}\""
              ),
              color = CyanInfo,
              fontSize = 12.sp,
              textAlign = TextAlign.Center
            )
          }
          "REJECTED" -> {
            Text(
              tr(
                "Previous appeal was rejected. Restriction will automatically lift when the countdown ends.",
                "Banding sebelumnya ditolak. Pembatasan akan otomatis berakhir saat hitung mundur selesai.",
                "Rayuan sebelum ini ditolak. Sekatan akan tamat secara automatik apabila kiraan detik tamat.",
                "前回の異議申し立ては却下されました。カウントダウン終了時に制限が自動解除されます。"
              ),
              color = RoseError,
              fontSize = 12.sp,
              textAlign = TextAlign.Center
            )
          }
          else -> {
            OutlinedTextField(
              value = appealInput,
              onValueChange = { appealInput = it },
              label = { Text(tr("Submit Appeal / Explanation to Admin", "Ajukan Banding / Penjelasan ke Admin", "Hantar Rayuan / Penjelasan kepada Admin", "管理者へ異議申し立てを送信")) },
              minLines = 2,
              modifier = Modifier.fillMaxWidth()
            )
            Button(
              onClick = {
                if (appealInput.isNotBlank()) {
                  onSubmitAppeal(appealInput.trim())
                  appealInput = ""
                }
              },
              enabled = appealInput.isNotBlank(),
              modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
              Icon(Icons.Filled.Send, contentDescription = null)
              Spacer(modifier = Modifier.width(8.dp))
              Text(tr("Submit Appeal", "Kirim Banding", "Hantar Rayuan", "異議を送信"))
            }
          }
        }

        TextButton(
          onClick = onLogout,
          modifier = Modifier.height(48.dp)
        ) {
          Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = SilverAccent)
          Spacer(modifier = Modifier.width(6.dp))
          Text(strings.logout, color = SilverAccent)
        }
      }
    }
  }
}
