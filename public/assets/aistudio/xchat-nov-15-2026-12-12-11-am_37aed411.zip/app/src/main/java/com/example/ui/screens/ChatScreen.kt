package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.ChannelEntity
import com.example.data.model.MessageEntity
import com.example.data.model.ServerEntity
import com.example.data.model.ServerMemberEntity
import com.example.data.model.ServerRoleEntity
import com.example.data.model.UserEntity
import com.example.ui.XChatViewModel
import com.example.ui.components.BadgesRow
import com.example.ui.components.ForumChannelScreen
import com.example.ui.components.GifSearchSheet
import com.example.ui.components.LocationShareSheet
import com.example.ui.components.MessageAttachmentView
import com.example.ui.components.RoleIconImage
import com.example.ui.components.StickerStudioSheet
import com.example.ui.components.StyledDisplayName
import com.example.ui.components.TypingIndicatorBar
import com.example.ui.components.UserAvatar
import com.example.ui.components.Video7sTrimSheet
import com.example.ui.theme.*
import com.example.utils.CloudMediaHelper
import com.example.utils.MediaStorageHelper
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
  viewModel: XChatViewModel,
  serverName: String,
  channel: ChannelEntity,
  activeServer: ServerEntity? = null,
  serverRoles: List<ServerRoleEntity> = emptyList(),
  serverMembers: List<ServerMemberEntity> = emptyList(),
  allUsers: List<UserEntity> = emptyList(),
  onOpenServerMenu: () -> Unit
) {
  if (channel.type.equals("forums", ignoreCase = true)) {
    ForumChannelScreen(
      viewModel = viewModel,
      serverName = serverName,
      channel = channel,
      allUsers = allUsers,
      onOpenServerMenu = onOpenServerMenu
    )
    return
  }

  val context = LocalContext.current
  val s = LocalStrings.current
  val messages by viewModel.currentMessages.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()
  val currentChannels by viewModel.currentChannels.collectAsState()
  val friends by viewModel.friends.collectAsState()
  val messageText by viewModel.messageText.collectAsState()
  val attachedFile by viewModel.attachedFile.collectAsState()
  val replyingTo by viewModel.replyingToMessage.collectAsState()
  val typingUsers by viewModel.typingUsersInCurrentChannel.collectAsState()
  val isUploadingMedia by viewModel.isUploadingMedia.collectAsState()

  val listState = rememberLazyListState()
  val scope = rememberCoroutineScope()

  var showSearchDialog by remember { mutableStateOf(false) }
  var showPinnedDialog by remember { mutableStateOf(false) }
  var showAttachMenu by remember { mutableStateOf(false) }
  var showStickerSheet by remember { mutableStateOf(false) }
  var showGifSheet by remember { mutableStateOf(false) }
  var showVideo7sSheet by remember { mutableStateOf(false) }
  var showLocationSheet by remember { mutableStateOf(false) }
  var showGameInviteDialog by remember { mutableStateOf(false) }
  var contextMenuMessage by remember { mutableStateOf<MessageEntity?>(null) }
  var editMessageTarget by remember { mutableStateOf<MessageEntity?>(null) }
  var editContentText by remember { mutableStateOf("") }
  var forwardTargetMessage by remember { mutableStateOf<MessageEntity?>(null) }
  var reportTargetMessage by remember { mutableStateOf<MessageEntity?>(null) }

  var visibleLimit by remember(channel.id) { mutableIntStateOf(40) }
  val pagedMessages = remember(messages, visibleLimit) {
    if (messages.size > visibleLimit) messages.takeLast(visibleLimit) else messages
  }

  var pendingSaveUri by remember { mutableStateOf<String?>(null) }
  var unreadBelowCount by remember(channel.id) { mutableIntStateOf(0) }
  var lastSeenMsgId by remember(channel.id) { mutableStateOf<String?>(null) }
  var scrollOnNextOwnSend by remember(channel.id) { mutableStateOf(false) }

  val isAtBottom by remember {
    derivedStateOf {
      val info = listState.layoutInfo
      val total = info.totalItemsCount
      if (total == 0) true else (info.visibleItemsInfo.lastOrNull()?.index ?: 0) >= total - 2
    }
  }

  val mediaPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      viewModel.prepareAndPickAttachment(uri) { info ->
        viewModel.attachedFile.value = info
      }
    }
  }

  val anyFilePickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenDocument()
  ) { uri: Uri? ->
    if (uri != null) {
      viewModel.prepareAndPickAttachment(uri) { info ->
        viewModel.attachedFile.value = info
      }
    }
  }

  val createDocLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.CreateDocument("*/*")
  ) { destUri: Uri? ->
    val src = pendingSaveUri
    pendingSaveUri = null
    if (destUri != null && src != null) {
      scope.launch {
        val res = MediaStorageHelper.copyToDestinationUri(context, src, destUri)
        viewModel.feedbackMessage.value = if (res.isSuccess) {
          s.fileSavedMsg
        } else {
          res.exceptionOrNull()?.message ?: "Failed to save file."
        }
      }
    }
  }

  fun handleDownloadAttachment(uriString: String, fileName: String?, mimeType: String?) {
    scope.launch {
      val res = MediaStorageHelper.saveToPublicDownloads(context, uriString, fileName, mimeType)
      if (res.isSuccess) {
        viewModel.feedbackMessage.value = "${s.downloadedToPrefix} ${res.getOrNull()}"
      } else if (res.exceptionOrNull()?.message == "USE_DOCUMENT_PICKER") {
        pendingSaveUri = uriString
        createDocLauncher.launch(fileName ?: "xchat_download.bin")
      } else {
        viewModel.feedbackMessage.value = res.exceptionOrNull()?.message ?: "Download failed."
      }
    }
  }

  fun handleOpenAttachment(uriString: String, fileName: String?, mimeType: String?) {
    scope.launch {
      val opened = MediaStorageHelper.openAttachmentExternally(context, uriString, mimeType, fileName)
      if (!opened) {
        viewModel.feedbackMessage.value = s.noAppToOpenFile
      }
    }
  }

  LaunchedEffect(pagedMessages.size, messages.lastOrNull()?.id, channel.id) {
    if (messages.isEmpty()) {
      unreadBelowCount = 0
      return@LaunchedEffect
    }
    val newest = messages.last()
    val targetIdx = (pagedMessages.lastIndex).coerceAtLeast(0)
    if (lastSeenMsgId == null) {
      if (pagedMessages.isNotEmpty()) listState.scrollToItem(targetIdx)
      lastSeenMsgId = newest.id
      unreadBelowCount = 0
      viewModel.markActiveChannelMessagesRead(messages)
    } else if (newest.id != lastSeenMsgId) {
      val prevIdx = messages.indexOfFirst { it.id == lastSeenMsgId }
      val newIncomingCount = if (prevIdx >= 0) {
        messages.drop(prevIdx + 1).count { it.senderId != currentUser?.id }
      } else {
        if (newest.senderId != currentUser?.id) 1 else 0
      }
      if (newest.senderId == currentUser?.id || scrollOnNextOwnSend || isAtBottom) {
        scrollOnNextOwnSend = false
        unreadBelowCount = 0
        if (pagedMessages.isNotEmpty()) listState.animateScrollToItem(targetIdx)
        viewModel.markActiveChannelMessagesRead(messages)
      } else if (newIncomingCount > 0) {
        unreadBelowCount += newIncomingCount
      }
      lastSeenMsgId = newest.id
    }
  }

  LaunchedEffect(isAtBottom, messages.size) {
    if (isAtBottom && messages.isNotEmpty()) {
      unreadBelowCount = 0
      viewModel.markActiveChannelMessagesRead(messages)
    }
  }

  Scaffold(
    contentWindowInsets = WindowInsets(0.dp),
    topBar = {
      TopAppBar(
        windowInsets = WindowInsets(0.dp),
        title = {
          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              val channelIcon = when (channel.type) {
                "announcements" -> Icons.Filled.Campaign
                "rules" -> Icons.Filled.Gavel
                "forums" -> Icons.Filled.Forum
                else -> Icons.Filled.Tag
              }
              Icon(channelIcon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = channel.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
              )
            }
            Text(
              text = serverName,
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              maxLines = 1
            )
          }
        },
        navigationIcon = {
          IconButton(onClick = onOpenServerMenu, modifier = Modifier.testTag("chat_server_menu_button")) {
            Icon(Icons.Filled.Menu, contentDescription = s.serverListHeader, tint = MaterialTheme.colorScheme.onSurface)
          }
        },
        actions = {
          IconButton(onClick = { showSearchDialog = true }) {
            Icon(Icons.Filled.Search, contentDescription = "Search", tint = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          IconButton(onClick = { showPinnedDialog = true }) {
            Icon(Icons.Filled.PushPin, contentDescription = s.pinnedMessages, tint = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f))
      )
    },
    bottomBar = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .navigationBarsPadding()
          .imePadding()
          .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.88f))
          .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
      ) {
        TypingIndicatorBar(typingUsers = typingUsers)
        if (isUploadingMedia) {
          LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }

        // @username / @everyone / #channel interactive autocomplete bar
        val activeToken = remember(messageText) {
          val lastWord = messageText.substringAfterLast(' ')
          if (lastWord.startsWith("@") || lastWord.startsWith("#")) lastWord else null
        }
        if (activeToken != null) {
          val suggestions = remember(activeToken, allUsers, currentChannels) {
            if (activeToken.startsWith("@")) {
              val q = activeToken.drop(1).lowercase()
              val base = if ("everyone".contains(q)) listOf("@everyone") else emptyList()
              base + allUsers
                .filter { it.username.lowercase().contains(q) || it.displayName.lowercase().contains(q) }
                .take(5)
                .map { "@${it.username}" }
            } else {
              val q = activeToken.drop(1).lowercase()
              currentChannels
                .filter { it.name.lowercase().contains(q) }
                .take(5)
                .map { "#${it.name}" }
            }
          }
          if (suggestions.isNotEmpty()) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 4.dp),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              suggestions.forEach { tag ->
                SuggestionChip(
                  onClick = {
                    val idx = messageText.lastIndexOf(activeToken)
                    if (idx >= 0) {
                      viewModel.messageText.value = messageText.substring(0, idx) + "$tag "
                    }
                  },
                  label = { Text(tag, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                )
              }
            }
          }
        }

        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
          if (replyingTo != null) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.primaryContainer)
                .padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.Reply, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "@${replyingTo?.senderName}: ${replyingTo?.content?.take(30)}",
                  style = MaterialTheme.typography.bodyMedium,
                  fontSize = 12.sp,
                  color = MaterialTheme.colorScheme.primary,
                  maxLines = 1
                )
              }
              IconButton(
                onClick = { viewModel.replyingToMessage.value = null },
                modifier = Modifier.size(20.dp)
              ) {
                Icon(Icons.Filled.Close, contentDescription = s.cancel, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
              }
            }
          }

          if (attachedFile != null) {
            val af = attachedFile!!
            val isImg = MediaStorageHelper.isImageAttachment(af.mimeType, af.fileName, af.uri)
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                .padding(8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              val previewModel = remember(af.uri) { CloudMediaHelper.resolveCoilModel(af.uri) }
              if (isImg && previewModel != null) {
                val previewReq = remember(previewModel) {
                  ImageRequest.Builder(context).data(previewModel).crossfade(false).build()
                }
                AsyncImage(
                  model = previewReq,
                  contentDescription = af.fileName,
                  modifier = Modifier.size(48.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF1E1F22)),
                  contentScale = ContentScale.Crop
                )
              } else {
                Box(
                  modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(Icons.Filled.AttachFile, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                }
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = af.fileName,
                  fontWeight = FontWeight.SemiBold,
                  fontSize = 12.sp,
                  color = MaterialTheme.colorScheme.onSurface,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
                Text(
                  text = MediaStorageHelper.formatFileSize(af.sizeBytes),
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              IconButton(
                onClick = { viewModel.attachedFile.value = null },
                modifier = Modifier.size(28.dp)
              ) {
                Icon(Icons.Filled.Close, contentDescription = "Remove", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
              }
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box {
              IconButton(
                onClick = { showAttachMenu = true },
                modifier = Modifier.size(40.dp).testTag("chat_attach_gallery_button")
              ) {
                Icon(Icons.Filled.AddCircle, contentDescription = "Attach File / Media", tint = MaterialTheme.colorScheme.primary)
              }
              DropdownMenu(
                expanded = showAttachMenu,
                onDismissRequest = { showAttachMenu = false }
              ) {
                DropdownMenuItem(
                  text = { Text(s.galleryMediaOption) },
                  leadingIcon = { Icon(Icons.Filled.PhotoLibrary, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                  onClick = {
                    showAttachMenu = false
                    mediaPickerLauncher.launch(
                      PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                    )
                  }
                )
                DropdownMenuItem(
                  text = { Text(s.allFilesOption) },
                  leadingIcon = { Icon(Icons.Filled.UploadFile, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                  onClick = {
                    showAttachMenu = false
                    anyFilePickerLauncher.launch(arrayOf("*/*"))
                  }
                )
                DropdownMenuItem(
                  text = { Text(s.createSticker) },
                  leadingIcon = { Icon(Icons.Filled.StickyNote2, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                  onClick = {
                    showAttachMenu = false
                    showStickerSheet = true
                  }
                )
                DropdownMenuItem(
                  text = { Text(s.searchGif) },
                  leadingIcon = { Icon(Icons.Filled.GifBox, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                  onClick = {
                    showAttachMenu = false
                    showGifSheet = true
                  }
                )
                DropdownMenuItem(
                  text = { Text(s.sendVideo7s) },
                  leadingIcon = { Icon(Icons.Filled.VideoLibrary, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                  onClick = {
                    showAttachMenu = false
                    showVideo7sSheet = true
                  }
                )
                DropdownMenuItem(
                  text = { Text(s.shareLocation) },
                  leadingIcon = { Icon(Icons.Filled.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                  onClick = {
                    showAttachMenu = false
                    showLocationSheet = true
                  }
                )
                DropdownMenuItem(
                  text = { Text(s.inviteMiniGame) },
                  leadingIcon = { Icon(Icons.Filled.SportsEsports, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                  onClick = {
                    showAttachMenu = false
                    showGameInviteDialog = true
                  }
                )
              }
            }

            Spacer(modifier = Modifier.width(4.dp))

            OutlinedTextField(
              value = messageText,
              onValueChange = { next ->
                viewModel.messageText.value = next
                if (next.isNotBlank()) {
                  viewModel.onUserTyping(channel.id)
                }
              },
              placeholder = {
                Text("${s.typeMessageHint} #${channel.name}...", style = MaterialTheme.typography.bodyMedium)
              },
              modifier = Modifier.weight(1f).testTag("chat_message_input"),
              shape = RoundedCornerShape(20.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f),
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f),
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline
              ),
              maxLines = 4
            )

            Spacer(modifier = Modifier.width(6.dp))

            FilledIconButton(
              onClick = {
                scrollOnNextOwnSend = true
                unreadBelowCount = 0
                viewModel.sendMessage()
                viewModel.clearTyping()
                if (pagedMessages.isNotEmpty()) {
                  scope.launch { listState.animateScrollToItem(pagedMessages.lastIndex) }
                }
              },
              enabled = (messageText.isNotBlank() || attachedFile != null) && !isUploadingMedia,
              colors = IconButtonDefaults.filledIconButtonColors(containerColor = MaterialTheme.colorScheme.primary),
              modifier = Modifier.size(48.dp).testTag("chat_send_button")
            ) {
              Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White, modifier = Modifier.size(18.dp))
            }
          }
        }
      }
    },
    containerColor = Color.Transparent
  ) { innerPadding ->
    if (messages.isEmpty()) {
      Box(
        modifier = Modifier.fillMaxSize().padding(innerPadding),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Box(
            modifier = Modifier
              .size(60.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Filled.Tag, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
          }
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = "#${channel.name}",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
          )
          Text(
            text = s.emptyChannelMsg,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp)
          )
        }
      }
    } else {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
      ) {
        LazyColumn(
          state = listState,
          modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 8.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          if (messages.size > visibleLimit) {
            item(key = "load_older_messages") {
              Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                OutlinedButton(
                  onClick = { visibleLimit += 40 },
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.height(40.dp)
                ) {
                  Text("${s.loadOlderMessages} (${messages.size - visibleLimit})", fontSize = 12.sp)
                }
              }
            }
          }
          items(pagedMessages, key = { it.id }) { msg ->
            val liveUser = allUsers.find { it.id == msg.senderId }
            val liveMember = serverMembers.find { it.userId == msg.senderId }
            val liveRole = serverRoles.find { it.name.equals(liveMember?.role, ignoreCase = true) }

            MessageItem(
              message = msg,
              isCurrentUser = msg.senderId == currentUser?.id,
              currentUser = currentUser,
              liveSender = liveUser,
              liveMember = liveMember,
              liveRole = liveRole,
              availableChannels = currentChannels,
              onSelectChannelMention = { viewModel.selectChannel(it) },
              onLongClick = { contextMenuMessage = msg },
              onReply = { viewModel.replyingToMessage.value = msg },
              onProfileClick = { viewModel.openUserProfile(msg.senderId) },
              onDownloadAttachment = { handleDownloadAttachment(msg.attachmentUri!!, msg.attachmentName, msg.attachmentMimeType) },
              onOpenAttachment = { handleOpenAttachment(msg.attachmentUri!!, msg.attachmentName, msg.attachmentMimeType) }
            )
          }
        }

        if (!isAtBottom || unreadBelowCount > 0) {
          Box(
            modifier = Modifier
              .align(Alignment.BottomEnd)
              .padding(end = 14.dp, bottom = 14.dp)
          ) {
            SmallFloatingActionButton(
              onClick = {
                unreadBelowCount = 0
                if (pagedMessages.isNotEmpty()) {
                  scope.launch {
                    listState.animateScrollToItem(pagedMessages.lastIndex)
                  }
                }
                viewModel.markActiveChannelMessagesRead(messages)
              },
              containerColor = MaterialTheme.colorScheme.surface,
              contentColor = MaterialTheme.colorScheme.primary,
              shape = CircleShape,
              modifier = Modifier
                .size(48.dp)
                .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                .testTag("chat_scroll_to_bottom_button")
            ) {
              Icon(
                Icons.Filled.KeyboardArrowDown,
                contentDescription = s.jumpToLatest,
                modifier = Modifier.size(24.dp)
              )
            }
            if (unreadBelowCount > 0) {
              Box(
                modifier = Modifier
                  .align(Alignment.TopEnd)
                  .offset(x = 2.dp, y = (-4).dp)
                  .defaultMinSize(minWidth = 22.dp, minHeight = 22.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFEF4444))
                  .padding(horizontal = 5.dp, vertical = 2.dp),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = if (unreadBelowCount > 99) "99+" else "$unreadBelowCount",
                  color = Color.White,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }
        }
      }
    }

    if (contextMenuMessage != null) {
      val targetMsg = contextMenuMessage!!
      AlertDialog(
        onDismissRequest = { contextMenuMessage = null },
        title = { Text(s.messageOptions, fontWeight = FontWeight.Bold) },
        text = {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
              horizontalArrangement = Arrangement.SpaceAround,
              modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            ) {
              ReactionButton(Icons.Filled.ThumbUp, "like", Color(0xFF3B82F6)) {
                viewModel.addReaction(targetMsg.id, "like"); contextMenuMessage = null
              }
              ReactionButton(Icons.Filled.Favorite, "heart", Color(0xFFEF4444)) {
                viewModel.addReaction(targetMsg.id, "heart"); contextMenuMessage = null
              }
              ReactionButton(Icons.Filled.Whatshot, "fire", Color(0xFFF97316)) {
                viewModel.addReaction(targetMsg.id, "fire"); contextMenuMessage = null
              }
              ReactionButton(Icons.Filled.Star, "star", Color(0xFFFBBF24)) {
                viewModel.addReaction(targetMsg.id, "star"); contextMenuMessage = null
              }
              ReactionButton(Icons.Filled.RocketLaunch, "rocket", MaterialTheme.colorScheme.primary) {
                viewModel.addReaction(targetMsg.id, "rocket"); contextMenuMessage = null
              }
              ReactionButton(Icons.Filled.Diamond, "diamond", Color(0xFF06B6D4)) {
                viewModel.addReaction(targetMsg.id, "diamond"); contextMenuMessage = null
              }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline)

            TextButton(
              onClick = { viewModel.replyingToMessage.value = targetMsg; contextMenuMessage = null },
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Reply, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(s.replyMessage, color = MaterialTheme.colorScheme.onSurface)
              }
            }

            TextButton(
              onClick = {
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("XChat Message", targetMsg.content))
                contextMenuMessage = null
              },
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.ContentCopy, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.width(8.dp))
                Text(s.copyText, color = MaterialTheme.colorScheme.onSurface)
              }
            }

            TextButton(
              onClick = { viewModel.togglePin(targetMsg.id); contextMenuMessage = null },
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.PushPin, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (targetMsg.isPinned) s.unpinMessage else s.pinMessage, color = MaterialTheme.colorScheme.onSurface)
              }
            }

            TextButton(
              onClick = { forwardTargetMessage = targetMsg; contextMenuMessage = null },
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Forward, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(s.forwardMessage, color = MaterialTheme.colorScheme.onSurface)
              }
            }

            if (targetMsg.senderId != currentUser?.id) {
              TextButton(
                onClick = { reportTargetMessage = targetMsg; contextMenuMessage = null },
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Filled.Flag, contentDescription = null, tint = RoseError)
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(s.reportMessage, color = RoseError)
                }
              }
            }

            if (targetMsg.senderId == currentUser?.id || currentUser?.isOwner == true) {
              TextButton(
                onClick = {
                  editMessageTarget = targetMsg
                  editContentText = targetMsg.content
                  contextMenuMessage = null
                },
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Filled.Edit, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(s.editMessage, color = MaterialTheme.colorScheme.primary)
                }
              }

              TextButton(
                onClick = { viewModel.deleteMessage(targetMsg.id); contextMenuMessage = null },
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Filled.Delete, contentDescription = null, tint = RoseError)
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(s.deleteMessage, color = RoseError)
                }
              }
            }
          }
        },
        confirmButton = {
          TextButton(onClick = { contextMenuMessage = null }) { Text(s.close) }
        }
      )
    }

    if (editMessageTarget != null) {
      AlertDialog(
        onDismissRequest = { editMessageTarget = null },
        title = { Text(s.editMessage, fontWeight = FontWeight.Bold) },
        text = {
          OutlinedTextField(
            value = editContentText,
            onValueChange = { editContentText = it },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp)
          )
        },
        confirmButton = {
          Button(onClick = { viewModel.editMessage(editMessageTarget!!.id, editContentText); editMessageTarget = null }) {
            Text(s.save)
          }
        },
        dismissButton = {
          TextButton(onClick = { editMessageTarget = null }) { Text(s.cancel) }
        }
      )
    }

    if (showSearchDialog) {
      val query by viewModel.searchQuery.collectAsState()
      val results by viewModel.searchResults.collectAsState()

      AlertDialog(
        onDismissRequest = { showSearchDialog = false; viewModel.performSearch("") },
        title = { Text("#${channel.name}", fontWeight = FontWeight.Bold) },
        text = {
          Column {
            OutlinedTextField(
              value = query,
              onValueChange = { viewModel.performSearch(it) },
              placeholder = { Text(s.searchHint) },
              leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
              modifier = Modifier.fillMaxWidth(),
              singleLine = true,
              shape = RoundedCornerShape(10.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            if (results.isEmpty() && query.isNotBlank()) {
              Text(s.noMatchingMessages, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
              LazyColumn(modifier = Modifier.heightIn(max = 240.dp)) {
                items(results) { resMsg ->
                  Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                  ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                      Text(resMsg.senderName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                      Text(resMsg.content, fontSize = 13.sp)
                    }
                  }
                }
              }
            }
          }
        },
        confirmButton = {
          TextButton(onClick = { showSearchDialog = false; viewModel.performSearch("") }) { Text(s.close) }
        }
      )
    }

    if (showPinnedDialog) {
      val pinned = messages.filter { it.isPinned }
      AlertDialog(
        onDismissRequest = { showPinnedDialog = false },
        title = { Text("${s.pinnedMessages} (#${channel.name})", fontWeight = FontWeight.Bold) },
        text = {
          if (pinned.isEmpty()) {
            Text(
              s.noPinnedMessagesDesc,
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          } else {
            LazyColumn(modifier = Modifier.heightIn(max = 280.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
              items(pinned, key = { it.id }) { pMsg ->
                Card(
                  modifier = Modifier.fillMaxWidth(),
                  colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                  shape = RoundedCornerShape(10.dp)
                ) {
                  Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Text(pMsg.senderName, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                      IconButton(onClick = { viewModel.togglePin(pMsg.id) }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Filled.Close, contentDescription = "Unpin", modifier = Modifier.size(14.dp))
                      }
                    }
                    Text(pMsg.content, fontSize = 13.sp)
                  }
                }
              }
            }
          }
        },
        confirmButton = {
          TextButton(onClick = { showPinnedDialog = false }) { Text(s.close) }
        }
      )
    }

    if (showStickerSheet) {
      StickerStudioSheet(
        viewModel = viewModel,
        onSendSticker = { sticker ->
          scrollOnNextOwnSend = true
          viewModel.sendStickerMessage(sticker)
          showStickerSheet = false
        },
        onDismiss = { showStickerSheet = false }
      )
    }

    if (showGifSheet) {
      GifSearchSheet(
        viewModel = viewModel,
        onSendGif = { gif ->
          scrollOnNextOwnSend = true
          viewModel.sendGifMessage(gif)
          showGifSheet = false
        },
        onDismiss = { showGifSheet = false }
      )
    }

    if (showVideo7sSheet) {
      Video7sTrimSheet(
        onSendTrimmedVideo = { file, durMs, caption ->
          scrollOnNextOwnSend = true
          viewModel.sendVideo7sMessage(file, durMs, caption)
          showVideo7sSheet = false
        },
        onDismiss = { showVideo7sSheet = false }
      )
    }

    if (showLocationSheet) {
      LocationShareSheet(
        onSendLocation = { lat, lng, label, liveMinutes ->
          scrollOnNextOwnSend = true
          viewModel.sendLocationMessage(lat, lng, label, liveMinutes)
          showLocationSheet = false
        },
        onDismiss = { showLocationSheet = false }
      )
    }

    if (showGameInviteDialog) {
      var selectedGame by remember { mutableStateOf("TIC_TAC_TOE") }
      var selectedMode by remember { mutableStateOf("CLASSIC") }
      var selectedOppId by remember { mutableStateOf(allUsers.firstOrNull { it.id != currentUser?.id }?.id ?: "BOT") }
      AlertDialog(
        onDismissRequest = { showGameInviteDialog = false },
        title = { Text("${s.inviteMiniGame} (#${channel.name})", fontWeight = FontWeight.Bold) },
        text = {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Select Game:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              listOf("TIC_TAC_TOE" to "TicTacToe", "CHESS" to "Chess", "CONNECT_FOUR" to "Connect 4", "REVERSI" to "Reversi").forEach { (g, lbl) ->
                FilterChip(selected = selectedGame == g, onClick = { selectedGame = g }, label = { Text(lbl, fontSize = 11.sp) })
              }
            }
            Text("Mode:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              listOf("CLASSIC", "RANKED").forEach { m ->
                FilterChip(selected = selectedMode == m, onClick = { selectedMode = m }, label = { Text(m, fontSize = 11.sp) })
              }
            }
            Text("Opponent:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            LazyColumn(modifier = Modifier.heightIn(max = 160.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              item {
                FilterChip(selected = selectedOppId == "BOT", onClick = { selectedOppId = "BOT" }, label = { Text("XChat Bot (Practice)", fontSize = 12.sp) })
              }
              items(allUsers.filter { it.id != currentUser?.id }, key = { it.id }) { u ->
                FilterChip(
                  selected = selectedOppId == u.id,
                  onClick = { selectedOppId = u.id },
                  label = { Text("${u.displayName} (@${u.username})", fontSize = 12.sp) }
                )
              }
            }
          }
        },
        confirmButton = {
          Button(onClick = {
            viewModel.createGameMatch(
              gameType = selectedGame,
              mode = selectedMode,
              opponentId = selectedOppId,
              channelOrConvId = channel.id,
              isDm = false
            )
            showGameInviteDialog = false
          }) {
            Text(tr("Start & Send", "Mulai & Kirim", "Mula & Hantar", "開始して送信"))
          }
        },
        dismissButton = {
          TextButton(onClick = { showGameInviteDialog = false }) { Text(s.cancel) }
        }
      )
    }

    if (forwardTargetMessage != null) {
      val fMsg = forwardTargetMessage!!
      val attachmentFallback = tr("Attachment", "Lampiran", "Lampiran", "添付")
      AlertDialog(
        onDismissRequest = { forwardTargetMessage = null },
        title = { Text(tr("Forward Message", "Teruskan Pesan", "Majukan Mesej", "メッセージを転送"), fontWeight = FontWeight.Bold) },
        text = {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("\"${fMsg.content.ifBlank { fMsg.attachmentName ?: attachmentFallback }.take(60)}\"", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(tr("To Server Channel:", "Ke Kanal Server:", "Ke Saluran Pelayan:", "サーバーチャンネルへ:"), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            LazyColumn(modifier = Modifier.heightIn(max = 150.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              items(currentChannels, key = { it.id }) { ch ->
                OutlinedButton(
                  onClick = {
                    viewModel.forwardMessageToChannel(fMsg, ch.id)
                    forwardTargetMessage = null
                  },
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Text("#${ch.name}", fontSize = 12.sp)
                }
              }
            }
            if (friends.isNotEmpty()) {
              Text(tr("To Friend (DM):", "Ke Teman (DM):", "Ke Rakan (DM):", "フレンド (DM) へ:"), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
              LazyColumn(modifier = Modifier.heightIn(max = 130.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(friends, key = { it.id }) { fr ->
                  OutlinedButton(
                    onClick = {
                      viewModel.forwardMessageToDm(
                        content = fMsg.content,
                        senderId = fMsg.senderId,
                        senderName = fMsg.senderName,
                        receiverId = fr.friendId,
                        attachmentUri = fMsg.attachmentUri,
                        attachmentName = fMsg.attachmentName,
                        attachmentMimeType = fMsg.attachmentMimeType
                      )
                      forwardTargetMessage = null
                    },
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Text("@${fr.friendUsername} (${fr.friendDisplayName})", fontSize = 12.sp)
                  }
                }
              }
            }
          }
        },
        confirmButton = {
          TextButton(onClick = { forwardTargetMessage = null }) { Text(s.close) }
        }
      )
    }

    if (reportTargetMessage != null) {
      val rMsg = reportTargetMessage!!
      var reason by remember { mutableStateOf("Spam / Harassment") }
      var details by remember { mutableStateOf("") }
      AlertDialog(
        onDismissRequest = { reportTargetMessage = null },
        title = { Text(s.reportMessage, fontWeight = FontWeight.Bold) },
        text = {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              listOf("Spam / Harassment", "Harmful Content", "Scam / Fraud").forEach { r ->
                FilterChip(selected = reason == r, onClick = { reason = r }, label = { Text(r, fontSize = 11.sp) })
              }
            }
            OutlinedTextField(
              value = details,
              onValueChange = { details = it },
              label = { Text("Additional details") },
              modifier = Modifier.fillMaxWidth(),
              minLines = 2
            )
          }
        },
        confirmButton = {
          Button(onClick = {
            viewModel.submitReport(rMsg.senderId, channel.serverId, rMsg.id, reason, details)
            reportTargetMessage = null
          }) { Text(s.sendBtn) }
        },
        dismissButton = {
          TextButton(onClick = { reportTargetMessage = null }) { Text(s.cancel) }
        }
      )
    }
  }
}

@Composable
private fun ReactionButton(icon: ImageVector, type: String, tint: Color, onClick: () -> Unit) {
  IconButton(
    onClick = onClick,
    modifier = Modifier.size(36.dp).clip(CircleShape).background(tint.copy(alpha = 0.18f))
  ) {
    Icon(icon, contentDescription = type, tint = tint, modifier = Modifier.size(18.dp))
  }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MessageItem(
  message: MessageEntity,
  isCurrentUser: Boolean,
  currentUser: UserEntity?,
  liveSender: UserEntity?,
  liveMember: ServerMemberEntity?,
  liveRole: ServerRoleEntity?,
  availableChannels: List<ChannelEntity>,
  onSelectChannelMention: (ChannelEntity) -> Unit,
  onLongClick: () -> Unit,
  onReply: () -> Unit,
  onProfileClick: () -> Unit,
  onDownloadAttachment: () -> Unit,
  onOpenAttachment: () -> Unit
) {
  val context = LocalContext.current
  val s = LocalStrings.current
  val scope = rememberCoroutineScope()
  val timeStr = remember(message.timestamp) {
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(message.timestamp))
  }

  // Resolve real-time synced sender style, PP, frame, presence & role icon
  val resolvedUser = if (isCurrentUser && currentUser != null) currentUser else liveSender
  val dispName = resolvedUser?.displayName ?: message.senderName
  val dispAvatar = resolvedUser?.avatarUri ?: message.senderAvatarUri
  val dispFrame = resolvedUser?.equippedFrame ?: message.senderFrameId
  val dispColor = resolvedUser?.profileColor ?: 0xFF8B5CF6L
  val dispFont = resolvedUser?.displayNameFont ?: message.senderDisplayFont
  val dispColors = resolvedUser?.displayNameColorsCsv ?: message.senderDisplayColorsCsv
  val dispEffect = resolvedUser?.displayNameEffect ?: message.senderDisplayEffect
  val dispPresence = resolvedUser?.presenceStatus ?: "ONLINE"
  val dispLastSeen = resolvedUser?.lastSeenAt ?: 0L
  val badgesCsv = resolvedUser?.equippedBadges ?: message.senderBadges

  val roleIconUri = liveRole?.iconUri ?: liveMember?.roleIconUri ?: message.senderRoleIconUri
  val roleChromaCsv = liveRole?.chromaKeyColorsCsv ?: liveMember?.roleChromaColorsCsv ?: message.senderRoleChromaCsv

  // Memoize own message bubble background (custom gradient or image/GIF from Settings) so sending never flickers
  val ownBubbleBgCsv = currentUser?.chatBubbleBgCsv
  val ownBubbleBrush = remember(ownBubbleBgCsv) {
    val cols = ColorHelper.parseColorsCsv(
      ownBubbleBgCsv,
      listOf(0xFF7C3AED, 0xFF9333EA)
    )
    if (cols.size >= 2) {
      Brush.linearGradient(cols)
    } else {
      Brush.linearGradient(listOf(cols.first(), cols.first()))
    }
  }
  val ownBubbleImage = if (isCurrentUser) currentUser?.chatBubbleImageUri else null
  val bubbleBgModel = remember(ownBubbleImage) { CloudMediaHelper.resolveCoilModel(ownBubbleImage) }
  val bubbleImgRequest = remember(bubbleBgModel) {
    bubbleBgModel?.let { ImageRequest.Builder(context).data(it).crossfade(false).build() }
  }

  val readCount = remember(message.readByCsv, currentUser?.id) {
    message.readByCsv.split(",")
      .map { it.trim() }
      .filter { it.isNotBlank() && it != currentUser?.id && it != message.senderId }
      .distinct()
      .size
  }

  val swipeOffset = remember(message.id) { Animatable(0f) }
  val swipeThresholdPx = 110f

  Box(
    modifier = Modifier
      .fillMaxWidth()
      .pointerInput(message.id) {
        detectHorizontalDragGestures(
          onDragEnd = {
            if (abs(swipeOffset.value) >= swipeThresholdPx) {
              onReply()
            }
            scope.launch {
              swipeOffset.animateTo(0f, animationSpec = tween(180))
            }
          },
          onDragCancel = {
            scope.launch {
              swipeOffset.animateTo(0f, animationSpec = tween(180))
            }
          },
          onHorizontalDrag = { _, dragAmount ->
            val next = (swipeOffset.value + dragAmount).coerceIn(-160f, 160f)
            scope.launch { swipeOffset.snapTo(next) }
          }
        )
      }
  ) {
    val progress = (abs(swipeOffset.value) / swipeThresholdPx).coerceIn(0f, 1f)
    if (progress > 0.05f) {
      Box(
        modifier = Modifier
          .align(if (swipeOffset.value >= 0f) Alignment.CenterStart else Alignment.CenterEnd)
          .padding(horizontal = 12.dp)
          .size(34.dp)
          .alpha(progress)
          .clip(CircleShape)
          .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Filled.Reply, contentDescription = "Reply", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
      }
    }

    Column(
      modifier = Modifier
        .fillMaxWidth()
        .offset { IntOffset(swipeOffset.value.roundToInt(), 0) }
        .combinedClickable(onClick = {}, onLongClick = onLongClick)
        .padding(vertical = 3.dp),
      horizontalAlignment = if (isCurrentUser) Alignment.End else Alignment.Start
    ) {
      // Mirrored Tappable Header Bar:
      // Others (left): [Profil] | Nama | Role Icon | Jam
      // Self (right):  Jam | Role Icon | Nama | [Profil]
      Surface(
        onClick = onProfileClick,
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
        modifier = Modifier.testTag("chat_sender_profile_${message.id}")
      ) {
        Row(
          modifier = Modifier
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .horizontalScroll(rememberScrollState()),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
          if (!isCurrentUser) {
            UserAvatar(
              avatarUri = dispAvatar,
              displayName = dispName,
              size = 26.dp,
              frameId = dispFrame,
              showStatus = true,
              presenceStatus = dispPresence,
              lastSeenAt = dispLastSeen,
              userId = message.senderId,
              backgroundColor = dispColor
            )
            HeaderBarDivider()
            StyledDisplayName(
              name = dispName,
              fontKey = dispFont,
              colorsCsv = dispColors,
              effectKey = dispEffect,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              maxLines = 1
            )
            if (!roleIconUri.isNullOrBlank()) {
              HeaderBarDivider()
              RoleIconImage(
                iconUri = roleIconUri,
                chromaKeyColorsCsv = roleChromaCsv,
                size = 18.dp
              )
            }
            if (badgesCsv.isNotBlank()) {
              BadgesRow(
                badgeIdsCsv = badgesCsv,
                badgeSize = 14.dp,
                spacing = 2.dp,
                maxCount = 3
              )
            }
            HeaderBarDivider()
            Text(
              text = timeStr,
              fontSize = 10.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              maxLines = 1,
              softWrap = false
            )
          } else {
            Text(
              text = timeStr,
              fontSize = 10.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              maxLines = 1,
              softWrap = false
            )
            if (badgesCsv.isNotBlank()) {
              BadgesRow(
                badgeIdsCsv = badgesCsv,
                badgeSize = 14.dp,
                spacing = 2.dp,
                maxCount = 3
              )
            }
            if (!roleIconUri.isNullOrBlank()) {
              HeaderBarDivider()
              RoleIconImage(
                iconUri = roleIconUri,
                chromaKeyColorsCsv = roleChromaCsv,
                size = 18.dp
              )
            }
            HeaderBarDivider()
            StyledDisplayName(
              name = dispName,
              fontKey = dispFont,
              colorsCsv = dispColors,
              effectKey = dispEffect,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              maxLines = 1
            )
            HeaderBarDivider()
            UserAvatar(
              avatarUri = dispAvatar,
              displayName = dispName,
              size = 26.dp,
              frameId = dispFrame,
              showStatus = true,
              presenceStatus = dispPresence,
              lastSeenAt = dispLastSeen,
              userId = message.senderId,
              backgroundColor = dispColor
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(4.dp))

      Column(
        modifier = Modifier.widthIn(max = 310.dp),
        horizontalAlignment = if (isCurrentUser) Alignment.End else Alignment.Start
      ) {
        if (!message.replyToSnippet.isNullOrBlank()) {
          Row(
            modifier = Modifier
              .padding(bottom = 4.dp)
              .clip(RoundedCornerShape(6.dp))
              .background(MaterialTheme.colorScheme.surfaceVariant)
              .padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Filled.Reply, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(12.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = message.replyToSnippet, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
          }
        }

        val bubbleShape = RoundedCornerShape(
          topStart = 14.dp,
          topEnd = 14.dp,
          bottomStart = if (isCurrentUser) 14.dp else 4.dp,
          bottomEnd = if (isCurrentUser) 4.dp else 14.dp
        )

        Box(
          modifier = Modifier
            .clip(bubbleShape)
            .then(
              if (isCurrentUser) {
                if (bubbleImgRequest != null) {
                  Modifier.background(Color(0xFF141518))
                } else {
                  Modifier.background(ownBubbleBrush)
                }
              } else {
                Modifier
                  .background(MaterialTheme.colorScheme.surface)
                  .border(1.dp, MaterialTheme.colorScheme.outline, bubbleShape)
              }
            )
        ) {
          if (bubbleImgRequest != null) {
            AsyncImage(
              model = bubbleImgRequest,
              contentDescription = null,
              contentScale = ContentScale.Crop,
              modifier = Modifier.matchParentSize()
            )
            Box(modifier = Modifier.matchParentSize().background(Color.Black.copy(alpha = 0.42f)))
          }

          Column(modifier = Modifier.padding(10.dp)) {
            if (!message.forwardedFromName.isNullOrBlank()) {
              Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 4.dp)) {
                Icon(Icons.Filled.Forward, contentDescription = null, tint = if (isCurrentUser) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.primary, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "${s.forwardedFrom} ${message.forwardedFromName}",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Medium,
                  color = if (isCurrentUser) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.primary
                )
              }
            }

            if (!message.attachmentUri.isNullOrBlank()) {
              MessageAttachmentView(
                uri = message.attachmentUri,
                fileName = message.attachmentName,
                mimeType = message.attachmentMimeType,
                sizeBytes = message.attachmentSizeBytes,
                attachmentDurationMs = message.attachmentDurationMs,
                stickerId = message.stickerId,
                locationLat = message.locationLat,
                locationLng = message.locationLng,
                locationLabel = message.locationLabel,
                locationLiveUntil = message.locationLiveUntil,
                onDownload = onDownloadAttachment,
                onOpen = onOpenAttachment
              )
              if (message.content.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
              }
            }

            if (message.content.isNotBlank()) {
              Text(
                text = message.content,
                style = MaterialTheme.typography.bodyLarge,
                fontSize = 14.sp,
                color = if (isCurrentUser) Color.White else MaterialTheme.colorScheme.onSurface,
                lineHeight = 20.sp
              )
              val matchedChannels = remember(message.content, availableChannels) {
                availableChannels.filter { ch ->
                  message.content.contains("#${ch.name}", ignoreCase = true)
                }.take(3)
              }
              if (matchedChannels.isNotEmpty()) {
                Row(
                  modifier = Modifier.padding(top = 4.dp).horizontalScroll(rememberScrollState()),
                  horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                  matchedChannels.forEach { ch ->
                    SuggestionChip(
                      onClick = { onSelectChannelMention(ch) },
                      label = { Text("#${ch.name}", fontSize = 11.sp) }
                    )
                  }
                }
              }
            }

            Row(
              modifier = Modifier.padding(top = if (message.isEdited || isCurrentUser) 3.dp else 0.dp),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              if (message.isEdited) {
                Text(
                  text = s.editedTag,
                  fontSize = 10.sp,
                  color = if (isCurrentUser) Color.White.copy(alpha = 0.7f) else MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              if (isCurrentUser) {
                val readText = if (readCount > 0) "✓✓ ${s.readStatus} ($readCount)" else "✓ ${s.sentStatus}"
                Text(
                  text = readText,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Medium,
                  color = if (readCount > 0) Color(0xFF67E8F9) else Color.White.copy(alpha = 0.72f)
                )
              }
            }
          }
        }

        if (message.reactions.isNotBlank()) {
          Row(
            modifier = Modifier.padding(top = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            message.reactions.split(",").filter { it.isNotBlank() }.forEach { rx ->
              val parts = rx.split(":")
              if (parts.size == 2) {
                val rType = parts[0]
                val count = parts[1]
                val icon = when (rType) {
                  "like" -> Icons.Filled.ThumbUp
                  "heart" -> Icons.Filled.Favorite
                  "fire" -> Icons.Filled.Whatshot
                  "star" -> Icons.Filled.Star
                  "rocket" -> Icons.Filled.RocketLaunch
                  else -> Icons.Filled.Diamond
                }
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                  contentAlignment = Alignment.Center
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(count, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun HeaderBarDivider() {
  Text(
    text = "|",
    fontSize = 11.sp,
    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.85f),
    fontWeight = FontWeight.Normal
  )
}
