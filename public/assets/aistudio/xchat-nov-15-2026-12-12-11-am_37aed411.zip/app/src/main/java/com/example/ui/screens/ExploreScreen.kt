package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.ui.MainTab
import com.example.ui.XChatViewModel
import com.example.ui.components.GameCatalog
import com.example.ui.components.GameLogo
import com.example.ui.components.MultiGameBadgesRow
import com.example.ui.components.ServerTagPill
import com.example.ui.theme.*
import com.example.utils.CloudMediaHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExploreScreen(viewModel: XChatViewModel) {
  val context = LocalContext.current
  val s = LocalStrings.current
  val servers by viewModel.servers.collectAsState()
  val selectedServerId by viewModel.selectedServerId.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()
  val isVerifiedAdmin by viewModel.isVerifiedAdmin.collectAsState()
  val visibleServers = remember(servers, isVerifiedAdmin) {
    if (isVerifiedAdmin) servers else servers.filter { !it.isVanished }
  }

  val isAstral = currentUser?.subscriptionTier?.equals("ASTRAL", ignoreCase = true) == true || currentUser?.isOwner == true

  var showCreateDialog by remember { mutableStateOf(false) }
  var showJoinDialog by remember { mutableStateOf(false) }
  var inviteCodeInput by remember { mutableStateOf("") }

  Scaffold(
    contentWindowInsets = WindowInsets(0.dp),
    topBar = {
      TopAppBar(
        windowInsets = WindowInsets(0.dp),
        title = {
          Text(s.tabExplore, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        },
        actions = {
          IconButton(
            onClick = { showJoinDialog = true },
            modifier = Modifier.testTag("join_by_code_button")
          ) {
            Icon(Icons.Filled.Key, contentDescription = s.joinCode, tint = MaterialTheme.colorScheme.primary)
          }
          IconButton(
            onClick = { showCreateDialog = true },
            modifier = Modifier.testTag("create_server_button")
          ) {
            Icon(Icons.Filled.Add, contentDescription = s.createServer, tint = MaterialTheme.colorScheme.primary)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f))
      )
    },
    containerColor = Color.Transparent
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 16.dp, vertical = 10.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)),
          border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.secondary))
          )
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = s.exploreHeroTitle,
              fontWeight = FontWeight.Bold,
              fontSize = 16.sp,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = s.exploreHeroDesc,
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
              Button(
                onClick = { showJoinDialog = true },
                modifier = Modifier.weight(1f).height(44.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(8.dp)
              ) {
                Icon(Icons.Filled.Key, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(s.joinCode, fontSize = 12.sp)
              }

              OutlinedButton(
                onClick = { showCreateDialog = true },
                modifier = Modifier.weight(1f).height(44.dp),
                shape = RoundedCornerShape(8.dp)
              ) {
                Icon(Icons.Filled.Add, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(s.createServer, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
              }
            }
          }
        }
      }

      item {
        Text(
          text = s.communityServersHeader,
          fontWeight = FontWeight.Bold,
          fontSize = 11.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          letterSpacing = 1.sp,
          modifier = Modifier.padding(top = 4.dp)
        )
      }

      items(visibleServers, key = { it.id }) { server ->
        val isCurrent = server.id == selectedServerId
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)),
          border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.outline, MaterialTheme.colorScheme.outline))
          )
        ) {
          Column {
            val bannerModel = remember(server.bannerUri) { CloudMediaHelper.resolveCoilModel(server.bannerUri) }
            val bannerReq = remember(bannerModel) {
              bannerModel?.let { ImageRequest.Builder(context).data(it).crossfade(false).build() }
            }
            if (bannerReq != null) {
              AsyncImage(
                model = bannerReq,
                contentDescription = "Banner ${server.name}",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().height(76.dp).background(Color(0xFF141518))
              )
            }

            Column(modifier = Modifier.padding(14.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                val iconModel = remember(server.iconUri) { CloudMediaHelper.resolveCoilModel(server.iconUri) }
                val iconReq = remember(iconModel) {
                  iconModel?.let { ImageRequest.Builder(context).data(it).crossfade(false).build() }
                }
                Box(
                  modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .then(
                      if (iconReq != null) Modifier.background(Color(0xFF1E1F22))
                      else Modifier.background(AppThemeAccentBrush())
                    ),
                  contentAlignment = Alignment.Center
                ) {
                  if (iconReq != null) {
                    AsyncImage(
                      model = iconReq,
                      contentDescription = server.name,
                      contentScale = ContentScale.Crop,
                      modifier = Modifier.fillMaxSize()
                    )
                  } else {
                    Text(
                      text = server.name.take(2).uppercase(),
                      color = Color.White,
                      fontWeight = FontWeight.Bold,
                      fontSize = 16.sp
                    )
                  }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = server.name,
                      fontWeight = FontWeight.Bold,
                      fontSize = 15.sp,
                      color = MaterialTheme.colorScheme.onSurface,
                      maxLines = 1,
                      modifier = Modifier.weight(1f, fill = false)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(AstralViolet.copy(alpha = 0.2f))
                        .padding(horizontal = 5.dp, vertical = 1.dp)
                    ) {
                      Text(
                        text = "Lvl ${server.boostLevel} • ${server.boostCount} Boost",
                        fontSize = 9.sp,
                        color = AstralViolet,
                        fontWeight = FontWeight.SemiBold
                      )
                    }
                  }

                  Text(
                    text = server.description,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    modifier = Modifier.padding(top = 2.dp)
                  )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                  onClick = {
                    viewModel.selectServer(server.id)
                    viewModel.setActiveTab(MainTab.CHANNELS)
                  },
                  shape = RoundedCornerShape(8.dp),
                  colors = ButtonDefaults.buttonColors(
                    containerColor = if (isCurrent) EmeraldSuccess else MaterialTheme.colorScheme.primary
                  ),
                  contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                ) {
                  Text(text = if (isCurrent) s.activeBadge else s.enterBadge, fontSize = 12.sp)
                }
              }

              // Server Type, Tag + Icon, Genre Pills
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(top = 10.dp)
                  .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                MetaPill(server.serverType, MaterialTheme.colorScheme.primary)
                ServerTagPill(tagText = server.serverTag, tagIconKeyOrUri = server.serverTagIcon)
                MetaPill(server.serverGenre, CyanInfo)
              }

              if (!server.supportedGame.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                MultiGameBadgesRow(supportedGamesCsv = server.supportedGame)
              }

              Row(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "${s.joinCode}: ${server.inviteCode}",
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FilledTonalButton(
                  onClick = { viewModel.boostServer(server.id) },
                  contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                  modifier = Modifier.height(28.dp),
                  shape = RoundedCornerShape(8.dp)
                ) {
                  Icon(Icons.Filled.RocketLaunch, contentDescription = null, tint = AstralViolet, modifier = Modifier.size(13.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Boost", fontSize = 11.sp, color = AstralViolet, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }
      }
    }

    // Join Server Dialog
    if (showJoinDialog) {
      AlertDialog(
        onDismissRequest = { showJoinDialog = false },
        title = { Text("${s.join} Server", fontWeight = FontWeight.Bold) },
        text = {
          Column {
            Text(
              "Enter the server's unique invite code (e.g. XCHAT-MAIN, DEV-HQ88):",
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
              value = inviteCodeInput,
              onValueChange = { inviteCodeInput = it },
              label = { Text(s.joinCode) },
              modifier = Modifier.fillMaxWidth(),
              singleLine = true
            )
          }
        },
        confirmButton = {
          Button(
            onClick = {
              if (inviteCodeInput.isNotBlank()) {
                viewModel.joinServer(inviteCodeInput) {
                  showJoinDialog = false
                  inviteCodeInput = ""
                  viewModel.setActiveTab(MainTab.CHANNELS)
                }
              }
            }
          ) {
            Text(s.join)
          }
        },
        dismissButton = {
          TextButton(onClick = { showJoinDialog = false }) { Text(s.cancel) }
        }
      )
    }

    // Enhanced Create Server Dialog with Multi-Select Supported Games (22 Popular Games)
    if (showCreateDialog) {
      var serverName by remember { mutableStateOf("") }
      var serverDesc by remember { mutableStateOf("") }
      var selectedType by remember { mutableStateOf("Community") }
      var selectedTag by remember { mutableStateOf("#Chill") }
      var selectedGenre by remember { mutableStateOf("General") }
      var selectedGameIds by remember { mutableStateOf<Set<String>>(emptySet()) }
      var customInviteCode by remember { mutableStateOf("") }

      val typeOptions = listOf("Community", "Gaming", "Technology", "Creative", "Esports", "Education")
      val tagOptions = listOf("#Chill", "#SquadUp", "#Competitive", "#Coding", "#Roleplay", "#Anime")
      val genreOptions = listOf("General", "Sandbox", "MOBA", "FPS / Shooter", "RPG", "Software & AI", "Music & Chill")

      AlertDialog(
        onDismissRequest = { showCreateDialog = false },
        title = { Text(s.createServer, fontWeight = FontWeight.Bold) },
        text = {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .heightIn(max = 470.dp)
              .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            OutlinedTextField(
              value = serverName,
              onValueChange = { serverName = it },
              label = { Text("Server Name") },
              modifier = Modifier.fillMaxWidth(),
              singleLine = true
            )
            OutlinedTextField(
              value = serverDesc,
              onValueChange = { serverDesc = it },
              label = { Text("Server Description") },
              modifier = Modifier.fillMaxWidth(),
              maxLines = 2
            )

            Text("Server Type:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Row(
              modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              typeOptions.forEach { t ->
                FilterChip(selected = selectedType == t, onClick = { selectedType = t }, label = { Text(t, fontSize = 11.sp) })
              }
            }

            Text("Server Tag:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Row(
              modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              tagOptions.forEach { tg ->
                FilterChip(selected = selectedTag == tg, onClick = { selectedTag = tg }, label = { Text(tg, fontSize = 11.sp) })
              }
            }
            OutlinedTextField(
              value = selectedTag,
              onValueChange = { selectedTag = it },
              label = { Text("Or Type Custom Tag") },
              modifier = Modifier.fillMaxWidth(),
              singleLine = true
            )

            Text("Server Genre:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Row(
              modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              genreOptions.forEach { gn ->
                FilterChip(selected = selectedGenre == gn, onClick = { selectedGenre = gn }, label = { Text(gn, fontSize = 11.sp) })
              }
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text("Supported Games (Multi-select):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
              if (selectedGameIds.isNotEmpty()) {
                Text("${selectedGameIds.size} selected", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
              }
            }
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
              FilterChip(
                selected = selectedGameIds.isEmpty(),
                onClick = { selectedGameIds = emptySet() },
                label = { Text("No Specific Game", fontSize = 11.sp) }
              )
              GameCatalog.games.chunked(2).forEach { pair ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                  pair.forEach { gm ->
                    val isSel = selectedGameIds.contains(gm.id)
                    Surface(
                      onClick = {
                        selectedGameIds = if (isSel) selectedGameIds - gm.id else selectedGameIds + gm.id
                      },
                      shape = RoundedCornerShape(8.dp),
                      color = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                      border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                      ),
                      modifier = Modifier.weight(1f)
                    ) {
                      Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                      ) {
                        GameLogo(gameIdOrName = gm.id, size = 20.dp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                          text = gm.name,
                          fontSize = 11.sp,
                          fontWeight = FontWeight.SemiBold,
                          maxLines = 1,
                          overflow = TextOverflow.Ellipsis,
                          modifier = Modifier.weight(1f)
                        )
                        if (isSel) {
                          Icon(
                            Icons.Filled.CheckCircle,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(14.dp)
                          )
                        }
                      }
                    }
                  }
                  if (pair.size == 1) Spacer(modifier = Modifier.weight(1f))
                }
              }
            }

            // Custom Invite Code (Astral Only)
            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
              Text("Custom Invite Code", fontSize = 12.sp, fontWeight = FontWeight.Bold)
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(4.dp))
                  .background(AstralViolet)
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text("ASTRAL ONLY", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
              }
            }
            OutlinedTextField(
              value = customInviteCode,
              onValueChange = { if (isAstral) customInviteCode = it.uppercase() },
              enabled = isAstral,
              placeholder = {
                Text(
                  if (isAstral) "e.g. MINECRAFT-HUB (optional)" else "Upgrade to Astral for custom code",
                  fontSize = 12.sp
                )
              },
              modifier = Modifier.fillMaxWidth(),
              singleLine = true
            )
          }
        },
        confirmButton = {
          Button(
            onClick = {
              if (serverName.isNotBlank()) {
                viewModel.createServer(
                  name = serverName,
                  desc = serverDesc,
                  serverType = selectedType,
                  serverTag = selectedTag,
                  serverGenre = selectedGenre,
                  supportedGame = selectedGameIds.joinToString(",").takeIf { it.isNotBlank() },
                  customInviteCode = customInviteCode.takeIf { it.isNotBlank() }
                ) {
                  showCreateDialog = false
                  viewModel.setActiveTab(MainTab.CHANNELS)
                }
              }
            }
          ) {
            Text(s.createServer)
          }
        },
        dismissButton = {
          TextButton(onClick = { showCreateDialog = false }) { Text(s.cancel) }
        }
      )
    }
  }
}

@Composable
private fun MetaPill(label: String, tint: Color) {
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(6.dp))
      .background(tint.copy(alpha = 0.16f))
      .border(1.dp, tint.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
      .padding(horizontal = 7.dp, vertical = 3.dp)
  ) {
    Text(text = label, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = tint)
  }
}
