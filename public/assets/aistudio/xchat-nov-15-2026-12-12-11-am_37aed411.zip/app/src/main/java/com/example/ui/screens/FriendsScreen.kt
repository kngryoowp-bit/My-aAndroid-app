package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.DirectMessageEntity
import com.example.data.model.UserEntity
import com.example.ui.XChatViewModel
import com.example.ui.components.BadgesRow
import com.example.ui.components.GifSearchSheet
import com.example.ui.components.LocationShareSheet
import com.example.ui.components.MessageAttachmentView
import com.example.ui.components.StickerStudioSheet
import com.example.ui.components.StyledDisplayName
import com.example.ui.components.TypingIndicatorBar
import com.example.ui.components.UserAvatar
import com.example.ui.components.Video7sTrimSheet
import com.example.ui.components.isUserOnlineNow
import com.example.ui.components.presenceLabelFor
import com.example.ui.theme.*
import com.example.utils.CloudMediaHelper
import com.example.utils.MediaStorageHelper
import com.example.utils.PickedFileInfo
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun FriendsScreen(viewModel: XChatViewModel) {
  val context = LocalContext.current
  val s = LocalStrings.current
  val friends by viewModel.friends.collectAsState()
  val allUsers by viewModel.allUsers.collectAsState()
  val activeDmUserId by viewModel.activeDmUserId.collectAsState()
  val dmMessages by viewModel.activeDmMessages.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()
  val currentChannels by viewModel.currentChannels.collectAsState()
  val isPeerTyping by viewModel.isActiveDmPeerTyping.collectAsState()
  val isUploadingMedia by viewModel.isUploadingMedia.collectAsState()

  val scope = rememberCoroutineScope()
  var showAddFriendDialog by remember { mutableStateOf(false) }
  var dmInputText by remember { mutableStateOf("") }
  var dmAttachedFile by remember { mutableStateOf<PickedFileInfo?>(null) }
  var showDmAttachMenu by remember { mutableStateOf(false) }
  var showDmStickerSheet by remember { mutableStateOf(false) }
  var showDmGifSheet by remember { mutableStateOf(false) }
  var showDmVideo7sSheet by remember { mutableStateOf(false) }
  var showDmLocationSheet by remember { mutableStateOf(false) }
  var showDmGameDialog by remember { mutableStateOf(false) }
  var replyToDm by remember { mutableStateOf<DirectMessageEntity?>(null) }
  var contextMenuDm by remember { mutableStateOf<DirectMessageEntity?>(null) }
  var editTargetDm by remember { mutableStateOf<DirectMessageEntity?>(null) }
  var editDmText by remember { mutableStateOf("") }
  var forwardTargetDm by remember { mutableStateOf<DirectMessageEntity?>(null) }
  var pendingCallIsVideo by remember { mutableStateOf(false) }
  var pendingCallPeer by remember { mutableStateOf<UserEntity?>(null) }
  var isViewingDm by remember { mutableStateOf(false) }
  var pendingSaveUri by remember { mutableStateOf<String?>(null) }
  val openDmSignal by viewModel.openDmThreadSignal.collectAsState()

  val callPermLauncher = rememberLauncherForActivityResult(
    ActivityResultContracts.RequestMultiplePermissions()
  ) { grants ->
    val peer = pendingCallPeer
    pendingCallPeer = null
    val micOk = grants[Manifest.permission.RECORD_AUDIO] == true ||
      ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    val camOk = !pendingCallIsVideo || grants[Manifest.permission.CAMERA] == true ||
      ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    if (micOk && camOk && peer != null) {
      viewModel.startDmCall(peer, pendingCallIsVideo)
    } else if (!micOk || !camOk) {
      viewModel.feedbackMessage.value = "Microphone/camera permission is required for calls."
    }
  }

  fun initiateDmCall(peer: UserEntity, isVideo: Boolean) {
    val needMic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
    val needCam = isVideo && ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
    if (!needMic && !needCam) {
      viewModel.startDmCall(peer, isVideo)
    } else {
      pendingCallPeer = peer
      pendingCallIsVideo = isVideo
      val perms = buildList {
        if (needMic) add(Manifest.permission.RECORD_AUDIO)
        if (needCam) add(Manifest.permission.CAMERA)
      }.toTypedArray()
      callPermLauncher.launch(perms)
    }
  }

  LaunchedEffect(openDmSignal) {
    if (openDmSignal > 0L) {
      isViewingDm = true
      viewModel.consumeOpenDmThreadSignal()
    }
  }

  val dmMediaLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      viewModel.prepareAndPickAttachment(uri) { info ->
        dmAttachedFile = info
      }
    }
  }

  val dmFileLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenDocument()
  ) { uri: Uri? ->
    if (uri != null) {
      viewModel.prepareAndPickAttachment(uri) { info ->
        dmAttachedFile = info
      }
    }
  }

  val dmCreateDocLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.CreateDocument("*/*")
  ) { destUri: Uri? ->
    val src = pendingSaveUri
    pendingSaveUri = null
    if (destUri != null && src != null) {
      scope.launch {
        val res = MediaStorageHelper.copyToDestinationUri(context, src, destUri)
        viewModel.feedbackMessage.value = if (res.isSuccess) s.fileSavedMsg else res.exceptionOrNull()?.message
      }
    }
  }

  fun downloadDmFile(uri: String, fileName: String?, mimeType: String?) {
    scope.launch {
      val res = MediaStorageHelper.saveToPublicDownloads(context, uri, fileName, mimeType)
      if (res.isSuccess) {
        viewModel.feedbackMessage.value = "${s.downloadedToPrefix} ${res.getOrNull()}"
      } else if (res.exceptionOrNull()?.message == "USE_DOCUMENT_PICKER") {
        pendingSaveUri = uri
        dmCreateDocLauncher.launch(fileName ?: "xchat_download.bin")
      } else {
        viewModel.feedbackMessage.value = res.exceptionOrNull()?.message ?: "Download failed."
      }
    }
  }

  val activeFriend = friends.find { it.friendId == activeDmUserId }
  val livePeer = allUsers.find { it.id == activeDmUserId }

  LaunchedEffect(isViewingDm, activeFriend?.friendId) {
    viewModel.setIsViewingDm(isViewingDm && activeFriend != null)
  }
  DisposableEffect(Unit) {
    onDispose { viewModel.setIsViewingDm(false) }
  }

  BackHandler(enabled = isViewingDm) {
    isViewingDm = false
  }

  if (isViewingDm && activeFriend != null) {
    val peerName = livePeer?.displayName ?: activeFriend.friendDisplayName
    val peerAvatar = livePeer?.avatarUri ?: activeFriend.friendAvatarUri
    val peerFrame = livePeer?.equippedFrame
    val peerColor = livePeer?.profileColor ?: 0xFF8B5CF6L
    val peerOnlineRecent = if (livePeer != null) isUserOnlineNow(livePeer) else activeFriend.isOnline
    val peerPresence = livePeer?.presenceStatus ?: if (activeFriend.isOnline) "ONLINE" else "OFFLINE"
    val peerLastSeen = livePeer?.lastSeenAt ?: 0L
    val peerStatusLabel = if (!livePeer?.statusTag.isNullOrBlank()) {
      "${presenceLabelFor(peerPresence, peerOnlineRecent)} • ${livePeer!!.statusTag}"
    } else {
      presenceLabelFor(peerPresence, peerOnlineRecent)
    }

    val ownBubbleBgCsv = currentUser?.chatBubbleBgCsv
    val ownBubbleBrush = remember(ownBubbleBgCsv) {
      val cols = ColorHelper.parseColorsCsv(
        ownBubbleBgCsv,
        listOf(0xFF7C3AED, 0xFF9333EA)
      )
      if (cols.size >= 2) {
        Brush.linearGradient(cols)
      } else {
        Brush.linearGradient(listOf(cols.first(), cols.first()))
      }
    }
    val ownBubbleImage = currentUser?.chatBubbleImageUri
    val ownBubbleImgModel = remember(ownBubbleImage) { CloudMediaHelper.resolveCoilModel(ownBubbleImage) }
    val ownBubbleImgRequest = remember(ownBubbleImgModel) {
      ownBubbleImgModel?.let { ImageRequest.Builder(context).data(it).crossfade(false).build() }
    }

    var dmVisibleLimit by remember(activeFriend.friendId) { mutableIntStateOf(40) }
    val pagedDms = remember(dmMessages, dmVisibleLimit) {
      if (dmMessages.size > dmVisibleLimit) dmMessages.takeLast(dmVisibleLimit) else dmMessages
    }
    val dmListState = rememberLazyListState()
    var lastSeenDmId by remember(activeFriend.friendId) { mutableStateOf<String?>(null) }
    var unreadDmCount by remember(activeFriend.friendId) { mutableIntStateOf(0) }
    var scrollOnNextOwnDm by remember(activeFriend.friendId) { mutableStateOf(false) }

    val isAtBottom by remember {
      derivedStateOf {
        val info = dmListState.layoutInfo
        val total = info.totalItemsCount
        if (total == 0) true else (info.visibleItemsInfo.lastOrNull()?.index ?: 0) >= total - 2
      }
    }

    LaunchedEffect(pagedDms.size, dmMessages.lastOrNull()?.id, activeFriend.friendId) {
      if (dmMessages.isEmpty()) {
        unreadDmCount = 0
        return@LaunchedEffect
      }
      val newest = dmMessages.last()
      val targetIdx = pagedDms.lastIndex.coerceAtLeast(0)
      if (lastSeenDmId == null) {
        if (pagedDms.isNotEmpty()) dmListState.scrollToItem(targetIdx)
        lastSeenDmId = newest.id
        unreadDmCount = 0
        viewModel.markActiveDmConversationAsRead(activeFriend.friendId)
      } else if (newest.id != lastSeenDmId) {
        val prevIdx = dmMessages.indexOfFirst { it.id == lastSeenDmId }
        val newIncoming = if (prevIdx >= 0) {
          dmMessages.drop(prevIdx + 1).count { it.senderId != currentUser?.id }
        } else {
          if (newest.senderId != currentUser?.id) 1 else 0
        }
        if (newest.senderId == currentUser?.id || scrollOnNextOwnDm || isAtBottom) {
          scrollOnNextOwnDm = false
          unreadDmCount = 0
          if (pagedDms.isNotEmpty()) dmListState.animateScrollToItem(targetIdx)
          viewModel.markActiveDmConversationAsRead(activeFriend.friendId)
        } else if (newIncoming > 0) {
          unreadDmCount += newIncoming
        }
        lastSeenDmId = newest.id
      }
    }

    LaunchedEffect(isAtBottom, dmMessages.size) {
      if (isAtBottom && dmMessages.isNotEmpty()) {
        unreadDmCount = 0
        viewModel.markActiveDmConversationAsRead(activeFriend.friendId)
      }
    }

    Scaffold(
      contentWindowInsets = WindowInsets(0.dp),
      topBar = {
        TopAppBar(
          windowInsets = WindowInsets(0.dp),
          title = {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.clickable { viewModel.openUserProfile(activeFriend.friendId) }
            ) {
              UserAvatar(
                avatarUri = peerAvatar,
                displayName = peerName,
                size = 36.dp,
                frameId = peerFrame,
                isOnline = peerOnlineRecent,
                showStatus = true,
                presenceStatus = peerPresence,
                lastSeenAt = peerLastSeen,
                userId = activeFriend.friendId,
                backgroundColor = peerColor
              )
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                StyledDisplayName(
                  name = peerName,
                  fontKey = livePeer?.displayNameFont ?: "SERIF",
                  colorsCsv = livePeer?.displayNameColorsCsv ?: "",
                  effectKey = livePeer?.displayNameEffect ?: "GRADIENT",
                  fontSize = 15.sp,
                  fontWeight = FontWeight.Bold
                )
                Text(peerStatusLabel, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
              }
            }
          },
          navigationIcon = {
            IconButton(onClick = { isViewingDm = false }) {
              Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = s.backLabel, tint = MaterialTheme.colorScheme.onSurface)
            }
          },
          actions = {
            val targetPeer = livePeer ?: UserEntity(
              id = activeFriend.friendId,
              username = activeFriend.friendUsername,
              displayName = peerName,
              email = "",
              passwordHash = "",
              avatarUri = peerAvatar
            )
            IconButton(
              onClick = { initiateDmCall(targetPeer, isVideo = false) },
              modifier = Modifier.size(48.dp).testTag("dm_voice_call_button")
            ) {
              Icon(Icons.Filled.Call, contentDescription = s.callVoiceBtn, tint = MaterialTheme.colorScheme.primary)
            }
            IconButton(
              onClick = { initiateDmCall(targetPeer, isVideo = true) },
              modifier = Modifier.size(48.dp).testTag("dm_video_call_button")
            ) {
              Icon(Icons.Filled.Videocam, contentDescription = s.callVideoBtn, tint = MaterialTheme.colorScheme.primary)
            }
          },
          colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f))
        )
      },
      bottomBar = {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .imePadding()
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.88f))
            .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
          if (isPeerTyping && livePeer != null) {
            TypingIndicatorBar(typingUsers = listOf(livePeer), modifier = Modifier.padding(bottom = 4.dp))
          }
          if (replyToDm != null) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.primaryContainer)
                .padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.Reply, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "${replyToDm?.senderName}: ${replyToDm?.content?.take(36)}",
                  fontSize = 12.sp,
                  color = MaterialTheme.colorScheme.primary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
              }
              IconButton(onClick = { replyToDm = null }, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Filled.Close, contentDescription = s.cancel, modifier = Modifier.size(14.dp))
              }
            }
          }
          if (isUploadingMedia) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp))
          }
          if (dmAttachedFile != null) {
            val af = dmAttachedFile!!
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Filled.AttachFile, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "${af.fileName} (${MediaStorageHelper.formatFileSize(af.sizeBytes)})",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
              )
              IconButton(onClick = { dmAttachedFile = null }, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Filled.Close, contentDescription = "Remove", modifier = Modifier.size(16.dp))
              }
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box {
              IconButton(onClick = { showDmAttachMenu = true }, modifier = Modifier.size(40.dp)) {
                Icon(Icons.Filled.AddCircle, contentDescription = "Attach", tint = MaterialTheme.colorScheme.primary)
              }
              DropdownMenu(expanded = showDmAttachMenu, onDismissRequest = { showDmAttachMenu = false }) {
                DropdownMenuItem(
                  text = { Text(s.galleryMediaOption) },
                  leadingIcon = { Icon(Icons.Filled.PhotoLibrary, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                  onClick = {
                    showDmAttachMenu = false
                    dmMediaLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                  }
                )
                DropdownMenuItem(
                  text = { Text(s.allFilesOption) },
                  leadingIcon = { Icon(Icons.Filled.UploadFile, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                  onClick = {
                    showDmAttachMenu = false
                    dmFileLauncher.launch(arrayOf("*/*"))
                  }
                )
                DropdownMenuItem(
                  text = { Text(s.createSticker) },
                  leadingIcon = { Icon(Icons.Filled.StickyNote2, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                  onClick = {
                    showDmAttachMenu = false
                    showDmStickerSheet = true
                  }
                )
                DropdownMenuItem(
                  text = { Text(s.searchGif) },
                  leadingIcon = { Icon(Icons.Filled.GifBox, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                  onClick = {
                    showDmAttachMenu = false
                    showDmGifSheet = true
                  }
                )
                DropdownMenuItem(
                  text = { Text(s.sendVideo7s) },
                  leadingIcon = { Icon(Icons.Filled.VideoLibrary, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                  onClick = {
                    showDmAttachMenu = false
                    showDmVideo7sSheet = true
                  }
                )
                DropdownMenuItem(
                  text = { Text(s.shareLocation) },
                  leadingIcon = { Icon(Icons.Filled.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                  onClick = {
                    showDmAttachMenu = false
                    showDmLocationSheet = true
                  }
                )
                DropdownMenuItem(
                  text = { Text(s.inviteMiniGame) },
                  leadingIcon = { Icon(Icons.Filled.SportsEsports, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                  onClick = {
                    showDmAttachMenu = false
                    showDmGameDialog = true
                  }
                )
              }
            }
            Spacer(modifier = Modifier.width(4.dp))
            OutlinedTextField(
              value = dmInputText,
              onValueChange = { next ->
                dmInputText = next
                val meId = currentUser?.id
                if (meId != null && next.isNotBlank()) {
                  val convId = if (meId < activeFriend.friendId) "dm_${meId}_${activeFriend.friendId}" else "dm_${activeFriend.friendId}_$meId"
                  viewModel.onUserTyping(convId)
                }
              },
              placeholder = { Text("${s.dmHintPrefix} @${activeFriend.friendUsername}...", fontSize = 13.sp) },
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(20.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f),
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f)
              )
            )
            Spacer(modifier = Modifier.width(6.dp))
            FilledIconButton(
              onClick = {
                if (dmInputText.isNotBlank() || dmAttachedFile != null) {
                  scrollOnNextOwnDm = true
                  unreadDmCount = 0
                  val r = replyToDm
                  viewModel.sendDm(
                    content = dmInputText.trim(),
                    attachment = dmAttachedFile,
                    replyToId = r?.id,
                    replyToSnippet = r?.let { "${it.senderName}: ${it.content.take(40)}" }
                  )
                  viewModel.clearTyping()
                  dmInputText = ""
                  dmAttachedFile = null
                  replyToDm = null
                  if (pagedDms.isNotEmpty()) {
                    scope.launch { dmListState.animateScrollToItem(pagedDms.lastIndex) }
                  }
                }
              },
              colors = IconButtonDefaults.filledIconButtonColors(containerColor = MaterialTheme.colorScheme.primary),
              modifier = Modifier.size(48.dp)
            ) {
              Icon(Icons.AutoMirrored.Filled.Send, contentDescription = s.sendBtn, tint = Color.White, modifier = Modifier.size(18.dp))
            }
          }
        }
      },
      containerColor = Color.Transparent
    ) { innerPadding ->
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
      ) {
        LazyColumn(
          state = dmListState,
          modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 8.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          if (dmMessages.size > dmVisibleLimit) {
            item(key = "dm_load_older") {
              Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                OutlinedButton(onClick = { dmVisibleLimit += 40 }, shape = RoundedCornerShape(12.dp)) {
                  Text("${s.loadOlderMessages} (${dmMessages.size - dmVisibleLimit})", fontSize = 12.sp)
                }
              }
            }
          }
          items(pagedDms, key = { it.id }) { dm ->
            val isMe = dm.senderId == currentUser?.id
            val senderUser = if (isMe) currentUser else livePeer
            val shape = RoundedCornerShape(
              topStart = 12.dp,
              topEnd = 12.dp,
              bottomStart = if (isMe) 12.dp else 4.dp,
              bottomEnd = if (isMe) 4.dp else 12.dp
            )
            val timeStr = remember(dm.timestamp) {
              SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(dm.timestamp))
            }

            Column(
              modifier = Modifier
                .fillMaxWidth()
                .combinedClickable(onClick = {}, onLongClick = { contextMenuDm = dm }),
              horizontalAlignment = if (isMe) Alignment.End else Alignment.Start
            ) {
              Surface(
                onClick = { viewModel.openUserProfile(dm.senderId) },
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
              ) {
                Row(
                  modifier = Modifier
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .horizontalScroll(rememberScrollState()),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                  if (!isMe) {
                    UserAvatar(
                      avatarUri = senderUser?.avatarUri ?: peerAvatar,
                      displayName = senderUser?.displayName ?: dm.senderName,
                      size = 24.dp,
                      frameId = senderUser?.equippedFrame,
                      showStatus = true,
                      presenceStatus = senderUser?.presenceStatus ?: if (peerOnlineRecent) "ONLINE" else "OFFLINE",
                      lastSeenAt = senderUser?.lastSeenAt ?: 0L,
                      userId = dm.senderId,
                      backgroundColor = senderUser?.profileColor ?: 0xFF8B5CF6L
                    )
                    Text("|", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                    StyledDisplayName(
                      name = senderUser?.displayName ?: dm.senderName,
                      fontKey = senderUser?.displayNameFont ?: "SERIF",
                      colorsCsv = senderUser?.displayNameColorsCsv ?: "",
                      effectKey = senderUser?.displayNameEffect ?: "GRADIENT",
                      fontSize = 12.sp,
                      fontWeight = FontWeight.Bold
                    )
                    if (!senderUser?.equippedBadges.isNullOrBlank()) {
                      BadgesRow(badgeIdsCsv = senderUser!!.equippedBadges, badgeSize = 14.dp, spacing = 2.dp, maxCount = 3)
                    }
                    Text("|", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                    Text(timeStr, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, softWrap = false)
                  } else {
                    Text(timeStr, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, softWrap = false)
                    if (!senderUser?.equippedBadges.isNullOrBlank()) {
                      BadgesRow(badgeIdsCsv = senderUser!!.equippedBadges, badgeSize = 14.dp, spacing = 2.dp, maxCount = 3)
                    }
                    Text("|", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                    StyledDisplayName(
                      name = senderUser?.displayName ?: dm.senderName,
                      fontKey = senderUser?.displayNameFont ?: "SERIF",
                      colorsCsv = senderUser?.displayNameColorsCsv ?: "",
                      effectKey = senderUser?.displayNameEffect ?: "GRADIENT",
                      fontSize = 12.sp,
                      fontWeight = FontWeight.Bold
                    )
                    Text("|", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                    UserAvatar(
                      avatarUri = senderUser?.avatarUri ?: currentUser?.avatarUri,
                      displayName = senderUser?.displayName ?: dm.senderName,
                      size = 24.dp,
                      frameId = senderUser?.equippedFrame,
                      showStatus = true,
                      presenceStatus = senderUser?.presenceStatus ?: "ONLINE",
                      lastSeenAt = senderUser?.lastSeenAt ?: 0L,
                      userId = dm.senderId,
                      backgroundColor = senderUser?.profileColor ?: 0xFF8B5CF6L
                    )
                  }
                }
              }

              Spacer(modifier = Modifier.height(4.dp))

              if (!dm.replyToSnippet.isNullOrBlank()) {
                Row(
                  modifier = Modifier
                    .padding(bottom = 3.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f))
                    .padding(horizontal = 8.dp, vertical = 3.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(Icons.Filled.Reply, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(12.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(dm.replyToSnippet, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
              }

              Box(
                modifier = Modifier
                  .widthIn(max = 290.dp)
                  .clip(shape)
                  .then(
                    if (isMe) {
                      if (ownBubbleImgRequest != null) Modifier.background(Color(0xFF141518))
                      else Modifier.background(ownBubbleBrush)
                    } else Modifier.background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
                  )
              ) {
                if (isMe && ownBubbleImgRequest != null) {
                  AsyncImage(
                    model = ownBubbleImgRequest,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.matchParentSize()
                  )
                  Box(modifier = Modifier.matchParentSize().background(Color.Black.copy(alpha = 0.42f)))
                }
                Column(modifier = Modifier.padding(10.dp)) {
                  if (!dm.forwardedFromName.isNullOrBlank()) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 4.dp)) {
                      Icon(Icons.Filled.Forward, contentDescription = null, tint = if (isMe) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.primary, modifier = Modifier.size(12.dp))
                      Spacer(modifier = Modifier.width(4.dp))
                      Text("${s.forwardedFrom} ${dm.forwardedFromName}", fontSize = 10.sp, color = if (isMe) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.primary)
                    }
                  }
                  if (!dm.attachmentUri.isNullOrBlank()) {
                    MessageAttachmentView(
                      uri = dm.attachmentUri,
                      fileName = dm.attachmentName,
                      mimeType = dm.attachmentMimeType,
                      sizeBytes = dm.attachmentSizeBytes,
                      attachmentDurationMs = dm.attachmentDurationMs,
                      stickerId = dm.stickerId,
                      locationLat = dm.locationLat,
                      locationLng = dm.locationLng,
                      locationLabel = dm.locationLabel,
                      locationLiveUntil = dm.locationLiveUntil,
                      onDownload = { downloadDmFile(dm.attachmentUri, dm.attachmentName, dm.attachmentMimeType) },
                      onOpen = {
                        scope.launch {
                          if (!MediaStorageHelper.openAttachmentExternally(context, dm.attachmentUri, dm.attachmentMimeType, dm.attachmentName)) {
                            viewModel.feedbackMessage.value = s.noAppToOpenFile
                          }
                        }
                      }
                    )
                    if (dm.content.isNotBlank()) Spacer(modifier = Modifier.height(6.dp))
                  }
                  if (dm.content.isNotBlank()) {
                    Text(
                      text = dm.content,
                      fontSize = 14.sp,
                      color = if (isMe) Color.White else MaterialTheme.colorScheme.onSurface
                    )
                  }
                  Row(
                    modifier = Modifier.padding(top = 3.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    if (dm.isEdited) {
                      Text(s.editedTag, fontSize = 10.sp, color = if (isMe) Color.White.copy(alpha = 0.7f) else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (isMe) {
                      Text(
                        text = if (dm.isRead) "✓✓ ${s.readStatus}" else "✓ ${s.sentStatus}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (dm.isRead) Color(0xFF67E8F9) else Color.White.copy(alpha = 0.72f)
                      )
                    }
                  }
                }
              }
              if (dm.reactions.isNotBlank()) {
                Row(modifier = Modifier.padding(top = 3.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                  dm.reactions.split(",").filter { it.isNotBlank() }.forEach { rx ->
                    val parts = rx.split(":")
                    if (parts.size == 2) {
                      Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                      ) {
                        Text("${parts[0]} ${parts[1]}", fontSize = 10.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                      }
                    }
                  }
                }
              }
            }
          }
        }

        if (!isAtBottom || unreadDmCount > 0) {
          Box(
            modifier = Modifier
              .align(Alignment.BottomEnd)
              .padding(end = 14.dp, bottom = 14.dp)
          ) {
            SmallFloatingActionButton(
              onClick = {
                unreadDmCount = 0
                if (pagedDms.isNotEmpty()) {
                  scope.launch {
                    dmListState.animateScrollToItem(pagedDms.lastIndex)
                  }
                }
                viewModel.markActiveDmConversationAsRead(activeFriend.friendId)
              },
              containerColor = MaterialTheme.colorScheme.surface,
              contentColor = MaterialTheme.colorScheme.primary,
              shape = CircleShape,
              modifier = Modifier
                .size(48.dp)
                .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                .testTag("dm_scroll_to_bottom_button")
            ) {
              Icon(
                Icons.Filled.KeyboardArrowDown,
                contentDescription = s.jumpToLatest,
                modifier = Modifier.size(24.dp)
              )
            }
            if (unreadDmCount > 0) {
              Box(
                modifier = Modifier
                  .align(Alignment.TopEnd)
                  .offset(x = 2.dp, y = (-4).dp)
                  .defaultMinSize(minWidth = 22.dp, minHeight = 22.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFEF4444))
                  .padding(horizontal = 5.dp, vertical = 2.dp),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = if (unreadDmCount > 99) "99+" else "$unreadDmCount",
                  color = Color.White,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }
        }
      }

      if (contextMenuDm != null) {
        val target = contextMenuDm!!
        AlertDialog(
          onDismissRequest = { contextMenuDm = null },
          title = { Text(s.messageOptions, fontWeight = FontWeight.Bold) },
          text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Row(horizontalArrangement = Arrangement.SpaceAround, modifier = Modifier.fillMaxWidth()) {
                listOf("❤️", "🔥", "👍", "😂", "⭐").forEach { emoji ->
                  FilledTonalIconButton(onClick = { viewModel.reactDm(target.id, emoji); contextMenuDm = null }) {
                    Text(emoji, fontSize = 15.sp)
                  }
                }
              }
              TextButton(onClick = { replyToDm = target; contextMenuDm = null }, modifier = Modifier.fillMaxWidth()) {
                Text(s.replyMessage)
              }
              TextButton(onClick = { forwardTargetDm = target; contextMenuDm = null }, modifier = Modifier.fillMaxWidth()) {
                Text(s.forwardMessage)
              }
              if (target.senderId == currentUser?.id) {
                TextButton(
                  onClick = { editTargetDm = target; editDmText = target.content; contextMenuDm = null },
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Text(s.editMessage, color = MaterialTheme.colorScheme.primary)
                }
                TextButton(
                  onClick = { viewModel.deleteDm(target.id); contextMenuDm = null },
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Text(s.deleteMessage, color = RoseError)
                }
              }
            }
          },
          confirmButton = { TextButton(onClick = { contextMenuDm = null }) { Text(s.close) } }
        )
      }

      if (editTargetDm != null) {
        AlertDialog(
          onDismissRequest = { editTargetDm = null },
          title = { Text(s.editMessage, fontWeight = FontWeight.Bold) },
          text = {
            OutlinedTextField(value = editDmText, onValueChange = { editDmText = it }, modifier = Modifier.fillMaxWidth())
          },
          confirmButton = {
            Button(onClick = { viewModel.editDm(editTargetDm!!.id, editDmText); editTargetDm = null }) { Text(s.save) }
          },
          dismissButton = { TextButton(onClick = { editTargetDm = null }) { Text(s.cancel) } }
        )
      }

      if (forwardTargetDm != null) {
        val fDm = forwardTargetDm!!
        AlertDialog(
          onDismissRequest = { forwardTargetDm = null },
          title = { Text(s.forwardMessage, fontWeight = FontWeight.Bold) },
          text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              LazyColumn(modifier = Modifier.heightIn(max = 220.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(friends, key = { it.id }) { fr ->
                  OutlinedButton(
                    onClick = {
                      viewModel.forwardMessageToDm(
                        content = fDm.content,
                        senderId = fDm.senderId,
                        senderName = fDm.senderName,
                        receiverId = fr.friendId,
                        attachmentUri = fDm.attachmentUri,
                        attachmentName = fDm.attachmentName,
                        attachmentMimeType = fDm.attachmentMimeType
                      )
                      forwardTargetDm = null
                    },
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Text("@${fr.friendUsername} (${fr.friendDisplayName})", fontSize = 12.sp)
                  }
                }
              }
            }
          },
          confirmButton = { TextButton(onClick = { forwardTargetDm = null }) { Text(s.close) } }
        )
      }

      if (showDmStickerSheet) {
        StickerStudioSheet(
          viewModel = viewModel,
          onSendSticker = { sticker ->
            scrollOnNextOwnDm = true
            viewModel.sendStickerDm(sticker)
            showDmStickerSheet = false
          },
          onDismiss = { showDmStickerSheet = false }
        )
      }

      if (showDmGifSheet) {
        GifSearchSheet(
          viewModel = viewModel,
          onSendGif = { gif ->
            scrollOnNextOwnDm = true
            viewModel.sendGifDm(gif)
            showDmGifSheet = false
          },
          onDismiss = { showDmGifSheet = false }
        )
      }

      if (showDmVideo7sSheet) {
        Video7sTrimSheet(
          onSendTrimmedVideo = { file, durMs, caption ->
            scrollOnNextOwnDm = true
            viewModel.sendVideo7sDm(file, durMs, caption)
            showDmVideo7sSheet = false
          },
          onDismiss = { showDmVideo7sSheet = false }
        )
      }

      if (showDmLocationSheet) {
        LocationShareSheet(
          onSendLocation = { lat, lng, label, liveMinutes ->
            scrollOnNextOwnDm = true
            viewModel.sendLocationDm(lat, lng, label, liveMinutes)
            showDmLocationSheet = false
          },
          onDismiss = { showDmLocationSheet = false }
        )
      }

      if (showDmGameDialog) {
        var selectedGame by remember { mutableStateOf("TIC_TAC_TOE") }
        var selectedMode by remember { mutableStateOf("CLASSIC") }
        val meId = currentUser?.id ?: ""
        val convId = if (meId < activeFriend.friendId) "dm_${meId}_${activeFriend.friendId}" else "dm_${activeFriend.friendId}_$meId"
        AlertDialog(
          onDismissRequest = { showDmGameDialog = false },
          title = { Text("Challenge @${activeFriend.friendUsername}", fontWeight = FontWeight.Bold) },
          text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("TIC_TAC_TOE" to "TicTacToe", "CHESS" to "Chess", "CONNECT_FOUR" to "Connect 4", "REVERSI" to "Reversi").forEach { (g, lbl) ->
                  FilterChip(selected = selectedGame == g, onClick = { selectedGame = g }, label = { Text(lbl, fontSize = 11.sp) })
                }
              }
              Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("CLASSIC", "RANKED").forEach { m ->
                  FilterChip(selected = selectedMode == m, onClick = { selectedMode = m }, label = { Text(m, fontSize = 11.sp) })
                }
              }
            }
          },
          confirmButton = {
            Button(onClick = {
              viewModel.createGameMatch(selectedGame, selectedMode, activeFriend.friendId, convId, isDm = true)
              showDmGameDialog = false
            }) { Text(s.sendBtn) }
          },
          dismissButton = { TextButton(onClick = { showDmGameDialog = false }) { Text(s.cancel) } }
        )
      }
    }
    return
  }

  Scaffold(
    contentWindowInsets = WindowInsets(0.dp),
    topBar = {
      TopAppBar(
        windowInsets = WindowInsets(0.dp),
        title = {
          Text(s.tabFriends, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        },
        actions = {
          IconButton(
            onClick = { showAddFriendDialog = true },
            modifier = Modifier.testTag("add_friend_button")
          ) {
            Icon(Icons.Filled.PersonAdd, contentDescription = s.addFriendBtn, tint = MaterialTheme.colorScheme.primary)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f))
      )
    },
    containerColor = Color.Transparent
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
      Text(
        text = "${s.allFriendsHeader} (${friends.size})",
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(vertical = 8.dp)
      )

      if (friends.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.Group, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(48.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(s.noFriendsYet, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          items(friends, key = { it.id }) { friend ->
            val liveUser = allUsers.find { it.id == friend.friendId }
            val dispName = liveUser?.displayName ?: friend.friendDisplayName
            val avatar = liveUser?.avatarUri ?: friend.friendAvatarUri
            val isOnline = if (liveUser != null) isUserOnlineNow(liveUser) else friend.isOnline
            val presence = liveUser?.presenceStatus ?: if (friend.isOnline) "ONLINE" else "OFFLINE"
            val subtitle = buildString {
              append("@${liveUser?.username ?: friend.friendUsername} • ${presenceLabelFor(presence, isOnline)}")
              if (!liveUser?.statusTag.isNullOrBlank()) append(" • ${liveUser!!.statusTag}")
            }

            Card(
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  viewModel.selectDmUser(friend.friendId)
                  isViewingDm = true
                },
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                UserAvatar(
                  avatarUri = avatar,
                  displayName = dispName,
                  size = 44.dp,
                  frameId = liveUser?.equippedFrame,
                  isOnline = isOnline,
                  showStatus = true,
                  presenceStatus = presence,
                  lastSeenAt = liveUser?.lastSeenAt ?: 0L,
                  userId = friend.friendId,
                  backgroundColor = liveUser?.profileColor ?: 0xFF8B5CF6L
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                  StyledDisplayName(
                    name = dispName,
                    fontKey = liveUser?.displayNameFont ?: "SERIF",
                    colorsCsv = liveUser?.displayNameColorsCsv ?: "",
                    effectKey = liveUser?.displayNameEffect ?: "GRADIENT",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                  )
                  Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                }
                IconButton(onClick = {
                  viewModel.selectDmUser(friend.friendId)
                  isViewingDm = true
                }) {
                  Icon(Icons.Filled.ChatBubbleOutline, contentDescription = s.sendBtn, tint = MaterialTheme.colorScheme.primary)
                }
              }
            }
          }
        }
      }
    }

    if (showAddFriendDialog) {
      var addUsernameText by remember { mutableStateOf("") }
      AlertDialog(
        onDismissRequest = { showAddFriendDialog = false },
        title = { Text(s.addFriendTitle, fontWeight = FontWeight.Bold) },
        text = {
          Column {
            Text("Username (@):", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
              value = addUsernameText,
              onValueChange = { addUsernameText = it },
              label = { Text("Username (@)") },
              modifier = Modifier.fillMaxWidth(),
              singleLine = true
            )
          }
        },
        confirmButton = {
          Button(
            onClick = {
              if (addUsernameText.isNotBlank()) {
                viewModel.addFriend(addUsernameText) { showAddFriendDialog = false }
              }
            }
          ) {
            Text(s.addFriendBtn)
          }
        },
        dismissButton = {
          TextButton(onClick = { showAddFriendDialog = false }) { Text(s.cancel) }
        }
      )
    }
  }
}
