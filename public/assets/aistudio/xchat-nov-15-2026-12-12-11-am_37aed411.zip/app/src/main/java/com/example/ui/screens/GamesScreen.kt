package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GameMatchEntity
import com.example.ui.XChatViewModel
import com.example.ui.components.GlassCard
import com.example.ui.components.UserAvatar
import com.example.ui.theme.*
import com.example.utils.MiniGameEngines

@Composable
fun GamesScreen(
  viewModel: XChatViewModel,
  modifier: Modifier = Modifier
) {
  val strings = LocalStrings.current
  val currentUser by viewModel.currentUser.collectAsState()
  val allUsers by viewModel.allUsers.collectAsState()
  val matches by viewModel.allMatches.collectAsState()
  val ratings by viewModel.gameRatings.collectAsState()
  val tournaments by viewModel.tournaments.collectAsState()
  val activeMatchId by viewModel.activeMatchId.collectAsState()
  val selectedChannelId by viewModel.selectedChannelId.collectAsState()

  var subTab by remember { mutableIntStateOf(0) } // 0=Pertandingan, 1=Turnamen, 2=Leaderboard ELO
  var showChallengeDialog by remember { mutableStateOf(false) }
  var showNewTournamentDialog by remember { mutableStateOf(false) }

  val activeMatch = remember(activeMatchId, matches) {
    matches.firstOrNull { it.id == activeMatchId }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp, vertical = 10.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    if (activeMatch != null) {
      ActiveGameMatchView(
        match = activeMatch,
        myId = currentUser?.id.orEmpty(),
        onBack = { viewModel.openMatch(null) },
        onMove = { idxOrCol, toIdx, promo ->
          viewModel.submitGameMove(activeMatch.id, idxOrCol, toIdx, promo)
        },
        onResign = { viewModel.resignGameMatch(activeMatch.id) },
        onOfferDraw = { viewModel.offerOrAcceptDraw(activeMatch.id) }
      )
      return
    }

    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
      Column(modifier = Modifier.weight(1f)) {
        Text("ARCADE MULTIPLAYER", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, letterSpacing = 1.4.sp)
        Text(strings.tabGames, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = PureWhiteText)
      }
      Button(
        onClick = { showChallengeDialog = true },
        modifier = Modifier.height(48.dp).testTag("create_game_match_btn")
      ) {
        Icon(Icons.Filled.SportsEsports, contentDescription = null)
        Spacer(modifier = Modifier.width(6.dp))
        Text("Challenge")
      }
    }

    TabRow(
      selectedTabIndex = subTab,
      containerColor = CharcoalSurface.copy(alpha = 0.85f),
      contentColor = PureWhiteText,
      modifier = Modifier.clip(RoundedCornerShape(12.dp))
    ) {
      Tab(selected = subTab == 0, onClick = { subTab = 0 }, text = { Text("Duels (${matches.size})") })
      Tab(selected = subTab == 1, onClick = { subTab = 1 }, text = { Text("Tournaments") })
      Tab(selected = subTab == 2, onClick = { subTab = 2 }, text = { Text("ELO Rankings") })
    }

    when (subTab) {
      0 -> {
        val myId = currentUser?.id.orEmpty()
        LazyColumn(
          modifier = Modifier.weight(1f).fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(8.dp),
          contentPadding = PaddingValues(bottom = 16.dp)
        ) {
          if (matches.isEmpty()) {
            item {
              GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                  modifier = Modifier.padding(24.dp),
                  horizontalAlignment = Alignment.CenterHorizontally,
                  verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  Icon(Icons.Filled.Casino, contentDescription = null, tint = SilverAccent, modifier = Modifier.size(40.dp))
                  Text("No matches yet. Challenge a friend to Chess, Tic Tac Toe, Connect 4, or Reversi!", color = SilverAccent, textAlign = TextAlign.Center, fontSize = 13.sp)
                  Button(onClick = { showChallengeDialog = true }) { Text("Start First Match") }
                }
              }
            }
          } else {
            items(matches, key = { it.id }) { m ->
              val isInvitedToMe = m.status == "INVITED" && m.opponentId == myId
              GlassCard(
                onClick = { if (m.status == "ACTIVE" || m.status == "FINISHED") viewModel.openMatch(m.id) },
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${m.gameType.replace('_', ' ')} (${m.mode})", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = PureWhiteText, modifier = Modifier.weight(1f))
                    Surface(
                      color = when (m.status) {
                        "ACTIVE" -> EmeraldSuccess.copy(alpha = 0.2f)
                        "INVITED" -> AmberWarning.copy(alpha = 0.2f)
                        else -> SilverMuted.copy(alpha = 0.2f)
                      },
                      shape = RoundedCornerShape(8.dp)
                    ) {
                      Text(m.status, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = PureWhiteText, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
                    }
                  }
                  Text("${m.challengerName} vs ${m.opponentName}", fontSize = 12.sp, color = SilverAccent)
                  if (isInvitedToMe) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                      Button(
                        onClick = { viewModel.acceptGameMatch(m.id) },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        modifier = Modifier.weight(1f).height(40.dp)
                      ) { Text("Accept Duel", fontSize = 12.sp) }
                      OutlinedButton(
                        onClick = { viewModel.declineGameMatch(m.id) },
                        modifier = Modifier.weight(1f).height(40.dp)
                      ) { Text(strings.rejectBtn, fontSize = 12.sp, color = RoseError) }
                    }
                  } else if (m.status == "ACTIVE") {
                    Text(
                      text = if (m.turnUserId == myId) "YOUR turn to move!" else "Waiting for opponent...",
                      fontSize = 12.sp,
                      fontWeight = FontWeight.Bold,
                      color = if (m.turnUserId == myId) EmeraldSuccess else AmberWarning
                    )
                  } else if (m.status == "FINISHED") {
                    val winText = when (m.winnerId) {
                      "DRAW" -> "Draw"
                      myId -> "You Won!"
                      else -> "Finished"
                    }
                    Text(winText, fontSize = 12.sp, color = CyanInfo, fontWeight = FontWeight.SemiBold)
                  }
                }
              }
            }
          }
        }
      }
      1 -> {
        Column(modifier = Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedButton(
            onClick = { showNewTournamentDialog = true },
            modifier = Modifier.fillMaxWidth().height(46.dp)
          ) {
            Icon(Icons.Filled.EmojiEvents, contentDescription = null, tint = AmberWarning)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Create New Tournament")
          }
          LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tournaments, key = { it.id }) { t ->
              val participants = t.participantsCsv.split(",").filter { it.isNotBlank() }
              val joined = participants.contains(currentUser?.id)
              GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(t.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = PureWhiteText, modifier = Modifier.weight(1f))
                    Text(t.status, fontSize = 11.sp, color = AmberWarning, fontWeight = FontWeight.Bold)
                  }
                  Text("Game: ${t.gameType} • Players: ${participants.size}", fontSize = 12.sp, color = SilverAccent)
                  Button(
                    onClick = { viewModel.joinTournament(t.id) },
                    enabled = !joined && t.status == "OPEN",
                    modifier = Modifier.fillMaxWidth().height(42.dp)
                  ) {
                    Text(if (joined) "Already Joined" else "Join Tournament")
                  }
                }
              }
            }
          }
        }
      }
      2 -> {
        LazyColumn(
          modifier = Modifier.weight(1f).fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          if (ratings.isEmpty()) {
            item {
              Text("No Ranked scores yet. Play RANKED matches to climb the ELO leaderboard!", color = SilverAccent, fontSize = 13.sp, modifier = Modifier.padding(16.dp))
            }
          } else {
            items(ratings.sortedByDescending { it.elo }, key = { it.id }) { r ->
              GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Filled.MilitaryTech, contentDescription = null, tint = AmberWarning)
                  Spacer(modifier = Modifier.width(10.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text("${r.displayName} (@${r.username})", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PureWhiteText)
                    Text("${r.gameType} • W:${r.wins} L:${r.losses} D:${r.draws}", fontSize = 11.sp, color = SilverAccent)
                  }
                  Text("${r.elo} ELO", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = EmeraldSuccess)
                }
              }
            }
          }
        }
      }
    }
  }

  if (showChallengeDialog) {
    val myId = currentUser?.id.orEmpty()
    val candidates = remember(allUsers, myId) { allUsers.filter { it.id != myId && !it.isBanned } }
    var selectedGame by remember { mutableStateOf("CHESS") }
    var selectedMode by remember { mutableStateOf("CLASSIC") }
    var selectedOpponent by remember(candidates) { mutableStateOf(candidates.firstOrNull()) }

    AlertDialog(
      onDismissRequest = { showChallengeDialog = false },
      containerColor = CharcoalSurface,
      titleContentColor = PureWhiteText,
      textContentColor = PureWhiteText,
      title = { Text("Challenge to Mini-Game", fontWeight = FontWeight.Bold) },
      text = {
        Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("Select Game:", fontSize = 12.sp, color = SilverAccent)
          listOf("CHESS" to "Chess", "TIC_TAC_TOE" to "Tic Tac Toe", "CONNECT_FOUR" to "Connect Four", "REVERSI" to "Reversi / Othello").forEach { (key, label) ->
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable { selectedGame = key }) {
              RadioButton(selected = selectedGame == key, onClick = { selectedGame = key })
              Text(label, fontSize = 13.sp)
            }
          }
          Text("Mode:", fontSize = 12.sp, color = SilverAccent)
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("CLASSIC", "RANKED", "TOURNAMENT").forEach { md ->
              FilterChip(selected = selectedMode == md, onClick = { selectedMode = md }, label = { Text(md, fontSize = 10.sp) })
            }
          }
          Text("Select Opponent:", fontSize = 12.sp, color = SilverAccent)
          candidates.take(6).forEach { opp ->
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable { selectedOpponent = opp }) {
              RadioButton(selected = selectedOpponent?.id == opp.id, onClick = { selectedOpponent = opp })
              UserAvatar(opp.avatarUri, opp.displayName, size = 28.dp)
              Spacer(modifier = Modifier.width(8.dp))
              Text("${opp.displayName} (@${opp.username})", fontSize = 12.sp)
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val opp = selectedOpponent ?: return@Button
            viewModel.createGameMatch(
              gameType = selectedGame,
              mode = selectedMode,
              opponentId = opp.id,
              channelOrConvId = selectedChannelId,
              isDm = false
            ) { showChallengeDialog = false }
          },
          enabled = selectedOpponent != null
        ) { Text(strings.sendBtn) }
      },
      dismissButton = { TextButton(onClick = { showChallengeDialog = false }) { Text(strings.cancel) } }
    )
  }

  if (showNewTournamentDialog) {
    var tName by remember { mutableStateOf("") }
    var tGame by remember { mutableStateOf("CHESS") }
    AlertDialog(
      onDismissRequest = { showNewTournamentDialog = false },
      title = { Text("Create Community Tournament") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(value = tName, onValueChange = { tName = it }, label = { Text("Tournament Name") }, singleLine = true)
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("CHESS", "TIC_TAC_TOE", "CONNECT_FOUR", "REVERSI").forEach { g ->
              FilterChip(selected = tGame == g, onClick = { tGame = g }, label = { Text(g.take(7), fontSize = 10.sp) })
            }
          }
        }
      },
      confirmButton = {
        Button(onClick = {
          if (tName.isNotBlank()) viewModel.createTournament(tName.trim(), tGame) { showNewTournamentDialog = false }
        }) { Text(strings.createBtn) }
      },
      dismissButton = { TextButton(onClick = { showNewTournamentDialog = false }) { Text(strings.cancel) } }
    )
  }
}

@Composable
private fun ActiveGameMatchView(
  match: GameMatchEntity,
  myId: String,
  onBack: () -> Unit,
  onMove: (Int, Int, Char) -> Unit,
  onResign: () -> Unit,
  onOfferDraw: () -> Unit
) {
  val isMyTurn = match.status == "ACTIVE" && match.turnUserId == myId
  val isWhite = myId == match.challengerId

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState()),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
      IconButton(onClick = onBack) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PureWhiteText)
      }
      Column(modifier = Modifier.weight(1f)) {
        Text("${match.gameType.replace('_', ' ')} (${match.mode})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = PureWhiteText)
        Text("${match.challengerName} vs ${match.opponentName}", fontSize = 12.sp, color = SilverAccent)
      }
      if (match.status == "ACTIVE") {
        TextButton(onClick = onOfferDraw) { Text(if (match.drawOfferedBy != null && match.drawOfferedBy != myId) "Accept Draw" else "Offer Draw", fontSize = 11.sp) }
        TextButton(onClick = onResign) { Text("Resign", color = RoseError, fontSize = 11.sp) }
      }
    }

    Surface(
      color = if (match.status == "FINISHED") CyanInfo.copy(alpha = 0.16f) else if (isMyTurn) EmeraldSuccess.copy(alpha = 0.18f) else CharcoalElevated,
      shape = RoundedCornerShape(12.dp),
      border = BorderStroke(1.dp, GlassBorderLight),
      modifier = Modifier.fillMaxWidth()
    ) {
      Text(
        text = when {
          match.status == "FINISHED" -> when (match.winnerId) {
            "DRAW" -> "Match ended in a Draw!"
            myId -> "CONGRATULATIONS! You Won!"
            else -> "Match Finished • Opponent Won"
          }
          isMyTurn -> "Your Turn (${if (isWhite) "Player 1 / White" else "Player 2 / Black"})"
          else -> "Waiting for opponent move..."
        },
        color = PureWhiteText,
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(10.dp)
      )
    }

    when (match.gameType) {
      "TIC_TAC_TOE" -> {
        val state = remember(match.boardStateJson) { MiniGameEngines.TicTacToeState.fromJson(match.boardStateJson) }
        Column(
          modifier = Modifier.fillMaxWidth().padding(12.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          for (r in 0..2) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              for (c in 0..2) {
                val idx = r * 3 + c
                val sym = state.cells[idx]
                val isWinCell = state.winningLine.contains(idx)
                Surface(
                  onClick = { if (isMyTurn && sym.isEmpty()) onMove(idx, -1, 'Q') },
                  shape = RoundedCornerShape(14.dp),
                  color = if (isWinCell) EmeraldSuccess.copy(alpha = 0.35f) else CharcoalElevated,
                  border = BorderStroke(1.5.dp, if (isWinCell) EmeraldSuccess else GlassBorderLight),
                  modifier = Modifier.size(92.dp)
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Text(
                      text = sym,
                      fontSize = 36.sp,
                      fontWeight = FontWeight.ExtraBold,
                      color = if (sym == "X") CyanInfo else AmberWarning
                    )
                  }
                }
              }
            }
          }
        }
      }
      "CONNECT_FOUR" -> {
        val state = remember(match.boardStateJson) { MiniGameEngines.ConnectFourState.fromJson(match.boardStateJson) }
        GlassCard(modifier = Modifier.fillMaxWidth()) {
          Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
              for (col in 0..6) {
                FilledTonalButton(
                  onClick = { if (isMyTurn) onMove(col, -1, 'Q') },
                  enabled = isMyTurn && state.board[col] == 0,
                  contentPadding = PaddingValues(0.dp),
                  modifier = Modifier.size(40.dp)
                ) { Text("▼", fontSize = 14.sp) }
              }
            }
            for (r in 0 until 6) {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                for (c in 0 until 7) {
                  val idx = r * 7 + c
                  val v = state.board[idx]
                  val isWin = state.winningCells.contains(idx)
                  Box(
                    modifier = Modifier
                      .size(38.dp)
                      .clip(CircleShape)
                      .background(
                        when (v) {
                          1 -> RoseError
                          2 -> AmberWarning
                          else -> ObsidianBlack
                        }
                      )
                      .border(if (isWin) 2.5.dp else 1.dp, if (isWin) Color.White else GlassBorderSubtle, CircleShape)
                  )
                }
              }
            }
          }
        }
      }
      "REVERSI" -> {
        val state = remember(match.boardStateJson) { MiniGameEngines.ReversiState.fromJson(match.boardStateJson) }
        val validMoves = remember(state) { MiniGameEngines.getReversiValidMoves(state.board, state.nextPlayer) }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Text("⚫ Black: ${state.blackCount}", fontWeight = FontWeight.Bold, color = PureWhiteText)
            Text("⚪ White: ${state.whiteCount}", fontWeight = FontWeight.Bold, color = PureWhiteText)
          }
          GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
              for (r in 0 until 8) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                  for (c in 0 until 8) {
                    val idx = r * 8 + c
                    val v = state.board[idx]
                    val isValid = isMyTurn && validMoves.contains(idx)
                    Box(
                      modifier = Modifier
                        .weight(1f)
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isValid) EmeraldSuccess.copy(alpha = 0.25f) else Color(0xFF143A2A))
                        .clickable(enabled = isValid) { onMove(idx, -1, 'Q') },
                      contentAlignment = Alignment.Center
                    ) {
                      if (v != 0) {
                        Box(
                          modifier = Modifier
                            .fillMaxSize(0.75f)
                            .clip(CircleShape)
                            .background(if (v == 1) ObsidianBlack else PureWhiteText)
                            .border(1.dp, GlassBorderLight, CircleShape)
                        )
                      } else if (isValid) {
                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(EmeraldSuccess))
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      "CHESS" -> {
        val state = remember(match.boardStateJson) { MiniGameEngines.ChessState.fromJson(match.boardStateJson) }
        var selectedSquare by remember(match.boardStateJson) { mutableIntStateOf(-1) }
        var pendingPromoFromTo by remember { mutableStateOf<Pair<Int, Int>?>(null) }
        val legalTargets = remember(state, selectedSquare) {
          if (selectedSquare >= 0) MiniGameEngines.getChessLegalMovesFrom(state, selectedSquare) else emptyList()
        }

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("⏱ White: ${match.whiteTimeMs / 1000}s", fontSize = 12.sp, color = PureWhiteText)
            Text("Status: ${state.status}", fontSize = 12.sp, color = if (state.status == "CHECK") RoseError else SilverAccent, fontWeight = FontWeight.Bold)
            Text("⏱ Black: ${match.blackTimeMs / 1000}s", fontSize = 12.sp, color = PureWhiteText)
          }

          GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(4.dp)) {
              for (r in 0 until 8) {
                Row(modifier = Modifier.fillMaxWidth()) {
                  for (c in 0 until 8) {
                    val idx = r * 8 + c
                    val piece = state.board[idx]
                    val isLightSq = (r + c) % 2 == 0
                    val isSel = selectedSquare == idx
                    val isLegal = legalTargets.contains(idx)
                    val isLast = state.lastFrom == idx || state.lastTo == idx

                    val bg = when {
                      isSel -> MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)
                      isLast -> AmberWarning.copy(alpha = 0.28f)
                      isLightSq -> Color(0xFF3B4252)
                      else -> Color(0xFF1A1E28)
                    }

                    Box(
                      modifier = Modifier
                        .weight(1f)
                        .aspectRatio(1f)
                        .background(bg)
                        .clickable(enabled = isMyTurn) {
                          if (selectedSquare >= 0 && legalTargets.contains(idx)) {
                            val moving = state.board[selectedSquare]
                            val toRow = idx / 8
                            if ((moving == 'P' && toRow == 0) || (moving == 'p' && toRow == 7)) {
                              pendingPromoFromTo = selectedSquare to idx
                            } else {
                              onMove(selectedSquare, idx, 'Q')
                            }
                            selectedSquare = -1
                          } else {
                            val expectedTurn = if (isWhite) 'W' else 'B'
                            val belongsToMe = if (expectedTurn == 'W') piece in 'A'..'Z' else piece in 'a'..'z'
                            selectedSquare = if (belongsToMe && state.turn == expectedTurn.toString()) idx else -1
                          }
                        },
                      contentAlignment = Alignment.Center
                    ) {
                      if (piece != '.') {
                        Text(
                          text = MiniGameEngines.pieceSymbolUnicode(piece),
                          fontSize = 24.sp,
                          color = if (piece in 'A'..'Z') Color.White else Color(0xFFCBD5E1)
                        )
                      }
                      if (isLegal) {
                        Box(
                          modifier = Modifier
                            .size(if (piece != '.') 34.dp else 12.dp)
                            .clip(CircleShape)
                            .border(if (piece != '.') 2.dp else 0.dp, EmeraldSuccess, CircleShape)
                            .background(if (piece == '.') EmeraldSuccess.copy(alpha = 0.75f) else Color.Transparent)
                        )
                      }
                    }
                  }
                }
              }
            }
          }
        }

        pendingPromoFromTo?.let { (fromIdx, toIdx) ->
          AlertDialog(
            onDismissRequest = { pendingPromoFromTo = null },
            title = { Text("Pawn Promotion") },
            text = {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                listOf('Q' to "♕", 'R' to "♖", 'B' to "♗", 'N' to "♘").forEach { (promo, sym) ->
                  FilledTonalButton(onClick = {
                    onMove(fromIdx, toIdx, promo)
                    pendingPromoFromTo = null
                  }) { Text(sym, fontSize = 22.sp) }
                }
              }
            },
            confirmButton = {}
          )
        }
      }
    }
  }
}
