package com.example.ui.screens

import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.model.AudioTrackEntity
import com.example.ui.MainTab
import com.example.ui.XChatViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.utils.AudioRepeatMode
import com.example.utils.CloudMediaHelper
import com.example.utils.MediaStorageHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeShowcaseScreen(
  viewModel: XChatViewModel,
  onOpenGlobalSearch: () -> Unit,
  onOpenNotifications: () -> Unit,
  modifier: Modifier = Modifier
) {
  val strings = LocalStrings.current
  val user by viewModel.currentUser.collectAsState()
  val friends by viewModel.friends.collectAsState()
  val servers by viewModel.servers.collectAsState()
  val notifications by viewModel.notifications.collectAsState()
  val myGamesApps by viewModel.myGamesApps.collectAsState()
  val audioState by viewModel.audioState.collectAsState()

  var showFullMusicPlayer by remember { mutableStateOf(false) }

  val unreadNotifCount = remember(notifications) { notifications.count { !it.isRead } }
  val joinedDateText = remember(user?.createdAt) {
    val ts = user?.createdAt ?: System.currentTimeMillis()
    SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(ts))
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp)
  ) {
    // Top Header Bar
    Row(
      modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = "XCHAT V2.0",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.primary,
          letterSpacing = 1.6.sp
        )
        Text(
          text = strings.tabHome,
          fontSize = 22.sp,
          fontWeight = FontWeight.ExtraBold,
          color = PureWhiteText
        )
      }
      IconButton(
        onClick = { showFullMusicPlayer = true },
        modifier = Modifier.size(48.dp).testTag("home_music_player_btn")
      ) {
        Icon(Icons.Filled.LibraryMusic, contentDescription = strings.tabMusic, tint = PureWhiteText)
      }
      IconButton(
        onClick = onOpenGlobalSearch,
        modifier = Modifier.size(48.dp).testTag("home_global_search_btn")
      ) {
        Icon(Icons.Filled.Search, contentDescription = strings.globalSearchTitle, tint = PureWhiteText)
      }
      IconButton(
        onClick = onOpenNotifications,
        modifier = Modifier.size(48.dp).testTag("home_notifications_btn")
      ) {
        BadgedBox(
          badge = {
            if (unreadNotifCount > 0) {
              Badge(containerColor = RoseError) { Text("$unreadNotifCount", fontSize = 9.sp) }
            }
          }
        ) {
          Icon(Icons.Filled.Notifications, contentDescription = strings.notificationCenterTitle, tint = PureWhiteText)
        }
      }
    }

    LazyColumn(
      modifier = Modifier.weight(1f).fillMaxWidth(),
      verticalArrangement = Arrangement.spacedBy(14.dp),
      contentPadding = PaddingValues(bottom = 20.dp)
    ) {
      // Hero Profile Showcase Card
      item {
        val u = user
        if (u != null) {
          GlassCard(
            onClick = { viewModel.setActiveTab(MainTab.PROFILE) },
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                UserAvatar(
                  avatarUri = u.avatarUri,
                  displayName = u.displayName,
                  size = 64.dp,
                  frameId = u.equippedFrame,
                  showStatus = true,
                  presenceStatus = u.presenceStatus,
                  lastSeenAt = u.lastSeenAt,
                  userId = u.id,
                  backgroundColor = u.profileColor,
                  lowPerfMode = u.lowPerfMode
                )
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                  StyledDisplayName(
                    name = u.displayName,
                    fontKey = u.displayNameFont,
                    colorsCsv = u.displayNameColorsCsv,
                    effectKey = u.displayNameEffect,
                    fontSize = 18.sp,
                    lowPerfMode = u.lowPerfMode
                  )
                  Text(
                    "@${u.username} • ${tr("Joined", "Bergabung", "Menyertai", "参加日")} $joinedDateText",
                    color = SilverAccent,
                    fontSize = 11.sp
                  )
                  BadgesRow(badgeIdsCsv = u.equippedBadges, badgeSize = 16.dp, maxCount = 6)
                }
              }

              val nextLevelXp = (u.level.coerceAtLeast(1) * 150L)
              val progress = (u.xp % nextLevelXp).toFloat() / nextLevelXp.toFloat()
              Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("Level ${u.level} • ${u.xp} XP", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PureWhiteText)
                  Text("${u.followersCount} ${strings.followersLabel} • ${u.followingCount} ${strings.followingLabel}", fontSize = 11.sp, color = SilverAccent)
                }
                LinearProgressIndicator(
                  progress = { progress.coerceIn(0f, 1f) },
                  modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(4.dp)),
                  color = MaterialTheme.colorScheme.primary,
                  trackColor = GlassBorderSubtle
                )
              }

              if (!u.listeningTitle.isNullOrBlank() || !u.activeAppName.isNullOrBlank()) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  if (!u.listeningTitle.isNullOrBlank()) {
                    Surface(
                      color = CharcoalElevated.copy(alpha = 0.85f),
                      shape = RoundedCornerShape(10.dp),
                      modifier = Modifier.weight(1f).clickable { showFullMusicPlayer = true }
                    ) {
                      Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.MusicNote, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                          "${u.listeningTitle} — ${u.listeningArtist.orEmpty()}",
                          color = PureWhiteText,
                          fontSize = 11.sp,
                          maxLines = 1,
                          overflow = TextOverflow.Ellipsis
                        )
                      }
                    }
                  }
                  if (!u.activeAppName.isNullOrBlank()) {
                    Surface(
                      color = CharcoalElevated.copy(alpha = 0.85f),
                      shape = RoundedCornerShape(10.dp),
                      modifier = Modifier.weight(1f)
                    ) {
                      Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.SportsEsports, contentDescription = null, tint = CyanInfo, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(u.activeAppName!!, color = PureWhiteText, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }

      // Music Player Quick Card
      item {
        GlassCard(
          onClick = { showFullMusicPlayer = true },
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Box(
              modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Brush.linearGradient(listOf(CharcoalElevated, SilverAccent.copy(alpha = 0.25f)))),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Filled.LibraryMusic, contentDescription = null, tint = PureWhiteText)
            }
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = audioState.currentTrack?.title ?: strings.musicPlayerTitle,
                color = PureWhiteText,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
              Text(
                text = audioState.currentTrack?.artist ?: tr(
                  "Tap to manage playlists, play local audio, or stream URLs",
                  "Ketuk untuk kelola playlist, putar audio lokal, atau URL",
                  "Ketik untuk urus senarai main, audio tempatan, atau URL",
                  "タップしてプレイリスト管理・ローカル音声・URLを再生"
                ),
                color = SilverAccent,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }
            IconButton(
              onClick = { viewModel.toggleMusicPlayPause() },
              modifier = Modifier.size(48.dp)
            ) {
              Icon(
                if (audioState.isPlaying) Icons.Filled.PauseCircle else Icons.Filled.PlayCircle,
                contentDescription = tr("Play / Pause", "Putar / Jeda", "Main / Jeda", "再生 / 一時停止"),
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(34.dp)
              )
            }
          }
        }
      }

      // Quick Mini-Games Arcade Strip
      item {
        Text(
          tr("MULTIPLAYER MINI GAMES ARENA", "ARENA MINI GAMES MULTIPLAYER", "ARENA PERMAINAN MINI BERBILANG PEMAIN", "マルチプレイミニゲーム"),
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = SilverMuted,
          letterSpacing = 1.2.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        val games = listOf(
          Triple(tr("Chess", "Catur (Chess)", "Catur (Chess)", "チェス"), tr("Full Rules + ELO", "Aturan Penuh + ELO", "Peraturan Penuh + ELO", "完全ルール + ELO"), Icons.Filled.Extension),
          Triple("Tic Tac Toe", tr("Quick 3x3 Duel", "Duel Cepat 3x3", "Pertarungan Pantas 3x3", "3x3 クイック対戦"), Icons.Filled.GridOn),
          Triple("Connect Four", tr("4-in-a-Row Strategy", "Strategi 4 Sejajar", "Strategi 4 Sebaris", "4目並べ戦略"), Icons.Filled.ViewWeek),
          Triple("Reversi / Othello", tr("8x8 Disc Flip", "Balik Keping 8x8", "Balik Keping 8x8", "8x8 リバーシ"), Icons.Filled.Contrast)
        )
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          items(games) { (title, sub, icon) ->
            GlassCard(
              onClick = { viewModel.setActiveTab(MainTab.GAMES) },
              modifier = Modifier.width(164.dp)
            ) {
              Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(icon, contentDescription = title, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
                Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PureWhiteText, maxLines = 1)
                Text(sub, fontSize = 11.sp, color = SilverAccent, maxLines = 1)
              }
            }
          }
        }
      }

      // Showcase Friends Strip
      item {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
          Text(tr("FRIENDS & QUICK CONTACTS", "TEMAN & KONTAK CEPAT", "RAKAN & KENALAN PANTAS", "フレンド＆クイック連絡"), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SilverMuted, letterSpacing = 1.2.sp)
          TextButton(onClick = { viewModel.setActiveTab(MainTab.DMS) }) { Text(tr("View All", "Lihat Semua", "Lihat Semua", "すべて表示")) }
        }
        if (friends.isEmpty()) {
          GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text(
              strings.noFriendsYet,
              color = SilverAccent,
              fontSize = 12.sp,
              modifier = Modifier.padding(14.dp)
            )
          }
        } else {
          LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(friends.take(10), key = { it.id }) { f ->
              GlassCard(
                onClick = { viewModel.startDmWithUser(f.friendId) },
                modifier = Modifier.width(120.dp)
              ) {
                Column(
                  modifier = Modifier.padding(10.dp),
                  horizontalAlignment = Alignment.CenterHorizontally,
                  verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                  UserAvatar(
                    avatarUri = f.friendAvatarUri,
                    displayName = f.friendDisplayName,
                    size = 46.dp,
                    showStatus = true,
                    isOnline = f.isOnline
                  )
                  Text(f.friendDisplayName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PureWhiteText, maxLines = 1, overflow = TextOverflow.Ellipsis)
                  Text(f.statusText, fontSize = 10.sp, color = SilverAccent, maxLines = 1)
                }
              }
            }
          }
        }
      }

      // Showcase Servers Strip
      item {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
          Text(strings.communityServersHeader, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SilverMuted, letterSpacing = 1.2.sp)
          TextButton(onClick = { viewModel.setActiveTab(MainTab.EXPLORE) }) { Text(strings.tabExplore) }
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          items(servers.filter { !it.isVanished || user?.isOwner == true }.take(10), key = { it.id }) { srv ->
            GlassCard(
              onClick = {
                viewModel.selectServer(srv.id)
                viewModel.setActiveTab(MainTab.CHANNELS)
              },
              modifier = Modifier.width(196.dp)
            ) {
              Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  UserAvatar(srv.iconUri, srv.name, size = 36.dp)
                  Column(modifier = Modifier.weight(1f)) {
                    Text(srv.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PureWhiteText, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("Lv.${srv.boostLevel} • ${srv.serverTag}", fontSize = 10.sp, color = SilverAccent)
                  }
                }
                Text(srv.description, fontSize = 11.sp, color = SilverAccent, maxLines = 2, overflow = TextOverflow.Ellipsis)
              }
            }
          }
        }
      }

      // My Games & Apps preview
      if (myGamesApps.isNotEmpty()) {
        item {
          Text(strings.myGamesAppsHeader, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SilverMuted, letterSpacing = 1.2.sp)
          Spacer(modifier = Modifier.height(6.dp))
          LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(myGamesApps, key = { it.id }) { item ->
              GlassCard(
                onClick = { viewModel.setActiveTab(MainTab.PROFILE) },
                modifier = Modifier.width(160.dp)
              ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                  Text(item.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PureWhiteText, maxLines = 1)
                  Text(item.category, fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                  if (item.activityStatus.isNotBlank()) {
                    Text(item.activityStatus, fontSize = 11.sp, color = SilverAccent, maxLines = 1, overflow = TextOverflow.Ellipsis)
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  if (showFullMusicPlayer) {
    FullMusicPlayerDialog(
      viewModel = viewModel,
      onDismiss = { showFullMusicPlayer = false }
    )
  }
}

@Composable
fun MiniMusicPlayerBar(
  viewModel: XChatViewModel,
  onOpenFullPlayer: () -> Unit,
  modifier: Modifier = Modifier
) {
  val audioState by viewModel.audioState.collectAsState()
  val track = audioState.currentTrack ?: return

  Surface(
    color = GlassFillElevated,
    shape = RoundedCornerShape(14.dp),
    border = BorderStroke(1.dp, GlassBorderLight),
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 10.dp, vertical = 4.dp)
      .clickable(onClick = onOpenFullPlayer)
      .testTag("mini_music_player_bar")
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Icon(Icons.Filled.MusicNote, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(18.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(track.title, color = PureWhiteText, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(track.artist, color = SilverAccent, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
      }
      IconButton(onClick = { viewModel.prevMusicTrack() }, modifier = Modifier.size(36.dp)) {
        Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", tint = PureWhiteText)
      }
      IconButton(onClick = { viewModel.toggleMusicPlayPause() }, modifier = Modifier.size(36.dp)) {
        Icon(if (audioState.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, contentDescription = "Play/Pause", tint = PureWhiteText)
      }
      IconButton(onClick = { viewModel.nextMusicTrack() }, modifier = Modifier.size(36.dp)) {
        Icon(Icons.Filled.SkipNext, contentDescription = "Next", tint = PureWhiteText)
      }
    }
  }
}

@Composable
fun FullMusicPlayerDialog(
  viewModel: XChatViewModel,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val strings = LocalStrings.current
  val scope = rememberCoroutineScope()
  val audioState by viewModel.audioState.collectAsState()
  val playlists by viewModel.playlists.collectAsState()
  val selectedPlaylistId by viewModel.selectedPlaylistId.collectAsState()
  val tracks by viewModel.tracksForActivePlaylist.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()

  var showNewPlaylistDialog by remember { mutableStateOf(false) }
  var showAddTrackDialog by remember { mutableStateOf(false) }

  val audioFilePicker = rememberLauncherForActivityResult(
    ActivityResultContracts.OpenDocument()
  ) { uri: Uri? ->
    if (uri != null) {
      val activePl = selectedPlaylistId ?: playlists.firstOrNull()?.id ?: ""
      scope.launch {
        val result = withContext(Dispatchers.IO) {
          runCatching {
            val picked = MediaStorageHelper.persistPickedFile(context, uri)
            val mmr = MediaMetadataRetriever()
            var titleMeta: String? = null
            var artistMeta: String? = null
            var durMs = 0L
            runCatching {
              mmr.setDataSource(picked.uri)
              titleMeta = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
              artistMeta = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
              durMs = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            }
            runCatching { mmr.release() }
            val fallbackName = picked.fileName.substringBeforeLast('.').ifBlank { "Local Audio" }
            Triple(
              titleMeta?.takeIf { it.isNotBlank() } ?: fallbackName,
              artistMeta?.takeIf { it.isNotBlank() } ?: strings.localAudioArtist,
              picked.uri to durMs
            )
          }
        }
        result.onSuccess { (resolvedTitle, resolvedArtist, pair) ->
          viewModel.addTrackToPlaylist(
            playlistId = activePl,
            title = resolvedTitle,
            artist = resolvedArtist,
            sourceUri = pair.first,
            sourceType = "LOCAL",
            durationMs = pair.second,
            autoPlay = true
          )
        }.onFailure { err ->
          viewModel.feedbackMessage.value = err.message ?: "Failed to import local audio."
        }
      }
    }
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    GlassCard(
      containerColor = ObsidianBlack.copy(alpha = 0.96f),
      modifier = Modifier.fillMaxWidth(0.95f).fillMaxHeight(0.88f)
    ) {
      Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
          Icon(Icons.Filled.LibraryMusic, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(8.dp))
          Text(strings.musicPlayerTitle, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = PureWhiteText, modifier = Modifier.weight(1f))
          IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, contentDescription = strings.close, tint = PureWhiteText) }
        }

        // Now Playing Card
        GlassSurface(modifier = Modifier.fillMaxWidth()) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val cur = audioState.currentTrack
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
              Box(
                modifier = Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)).background(CharcoalElevated),
                contentAlignment = Alignment.Center
              ) {
                if (!cur?.coverUri.isNullOrBlank()) {
                  AsyncImage(
                    model = CloudMediaHelper.resolveCoilModel(cur?.coverUri, context),
                    contentDescription = cur?.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                  )
                } else {
                  Icon(Icons.Filled.MusicNote, contentDescription = null, tint = SilverAccent, modifier = Modifier.size(28.dp))
                }
              }
              Column(modifier = Modifier.weight(1f)) {
                Text(cur?.title ?: strings.pickTrackToPlay, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = PureWhiteText, maxLines = 1)
                Text(cur?.artist ?: strings.musicReadyHint, fontSize = 12.sp, color = SilverAccent, maxLines = 1)
                audioState.statusMessage?.let { msg ->
                  Text(msg, fontSize = 11.sp, color = AmberWarning)
                }
              }
              if (cur != null && (cur.sourceType == "SPOTIFY" || cur.sourceType == "YOUTUBE")) {
                FilledTonalButton(onClick = { viewModel.openExternalMusicService(cur) }) {
                  Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(strings.openBtn, fontSize = 11.sp)
                }
              }
            }

            if (audioState.durationMs > 0L) {
              Slider(
                value = audioState.positionMs.toFloat().coerceIn(0f, audioState.durationMs.toFloat()),
                onValueChange = { viewModel.seekMusicTo(it.toLong()) },
                valueRange = 0f..audioState.durationMs.toFloat()
              )
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceEvenly,
              verticalAlignment = Alignment.CenterVertically
            ) {
              IconButton(onClick = { viewModel.toggleMusicShuffle() }) {
                Icon(Icons.Filled.Shuffle, contentDescription = "Shuffle", tint = if (audioState.shuffleEnabled) EmeraldSuccess else SilverMuted)
              }
              IconButton(onClick = { viewModel.prevMusicTrack() }) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", tint = PureWhiteText)
              }
              FilledIconButton(
                onClick = { viewModel.toggleMusicPlayPause() },
                modifier = Modifier.size(52.dp)
              ) {
                Icon(if (audioState.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, contentDescription = "Play/Pause")
              }
              IconButton(onClick = { viewModel.nextMusicTrack() }) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next", tint = PureWhiteText)
              }
              IconButton(onClick = { viewModel.cycleMusicRepeat() }) {
                Icon(
                  imageVector = if (audioState.repeatMode == AudioRepeatMode.ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                  contentDescription = "Repeat",
                  tint = if (audioState.repeatMode != AudioRepeatMode.OFF) EmeraldSuccess else SilverMuted
                )
              }
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Icon(Icons.Filled.VolumeUp, contentDescription = null, tint = SilverAccent, modifier = Modifier.size(18.dp))
              Slider(
                value = audioState.volume,
                onValueChange = { viewModel.setMusicVolume(it) },
                modifier = Modifier.weight(1f)
              )
            }

            // Listening privacy
            Row(
              modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(strings.listeningStatusLabel, fontSize = 11.sp, color = SilverAccent)
              val curPrivacy = currentUser?.listeningPrivacy ?: "PUBLIC"
              listOf("PUBLIC" to strings.publicLabel, "FRIENDS" to strings.friendsLabel, "PRIVATE" to strings.privateLabel).forEach { (key, label) ->
                FilterChip(
                  selected = curPrivacy == key,
                  onClick = { viewModel.setListeningPrivacy(key) },
                  label = { Text(label, fontSize = 10.sp) }
                )
              }
            }
          }
        }

        // Playlists bar
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Row(
            modifier = Modifier.weight(1f).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            val activeId = selectedPlaylistId ?: playlists.firstOrNull()?.id
            playlists.forEach { pl ->
              FilterChip(
                selected = pl.id == activeId,
                onClick = { viewModel.selectPlaylist(pl.id) },
                label = { Text(pl.name, fontSize = 12.sp) }
              )
            }
          }
          IconButton(onClick = { showNewPlaylistDialog = true }) {
            Icon(Icons.Filled.PlaylistAdd, contentDescription = strings.createPlaylistTitle, tint = MaterialTheme.colorScheme.primary)
          }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
          OutlinedButton(
            onClick = { audioFilePicker.launch(arrayOf("audio/*")) },
            modifier = Modifier.weight(1f).height(44.dp).testTag("pick_local_audio_btn")
          ) {
            Icon(Icons.Filled.AudioFile, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(strings.addLocalAudioBtn, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
          }
          Button(
            onClick = { showAddTrackDialog = true },
            modifier = Modifier.weight(1f).height(44.dp).testTag("add_track_url_btn")
          ) {
            Icon(Icons.Filled.AddLink, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(strings.addTrackUrlBtn, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
          }
        }

        // Queue / Tracks List
        LazyColumn(
          modifier = Modifier.weight(1f).fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          itemsIndexed(tracks, key = { _, t -> t.id }) { idx, track ->
            val isCurrent = audioState.currentTrack?.id == track.id
            Surface(
              color = if (isCurrent) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f) else CharcoalElevated,
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.fillMaxWidth().clickable { viewModel.playPlaylist(tracks, idx) }
            ) {
              Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  if (isCurrent && audioState.isPlaying) Icons.Filled.GraphicEq else Icons.Filled.PlayArrow,
                  contentDescription = null,
                  tint = if (isCurrent) EmeraldSuccess else SilverAccent
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(track.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PureWhiteText, maxLines = 1, overflow = TextOverflow.Ellipsis)
                  Text("${track.artist} • ${track.sourceType}", fontSize = 11.sp, color = SilverAccent, maxLines = 1)
                }
                if (idx > 0) {
                  IconButton(onClick = { viewModel.swapTrackOrder(tracks[idx], tracks[idx - 1]) }, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Filled.ArrowUpward, contentDescription = "Move Up", tint = SilverAccent, modifier = Modifier.size(16.dp))
                  }
                }
                IconButton(onClick = { viewModel.deleteTrack(track) }, modifier = Modifier.size(32.dp)) {
                  Icon(Icons.Filled.Delete, contentDescription = strings.deleteMessage, tint = RoseError, modifier = Modifier.size(16.dp))
                }
              }
            }
          }
        }
      }
    }
  }

  if (showNewPlaylistDialog) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
      onDismissRequest = { showNewPlaylistDialog = false },
      title = { Text(strings.createPlaylistTitle) },
      text = {
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(strings.playlistNameLabel) }, singleLine = true)
      },
      confirmButton = {
        Button(onClick = {
          if (name.isNotBlank()) viewModel.createPlaylist(name.trim()) { showNewPlaylistDialog = false }
        }) { Text(strings.createBtn) }
      },
      dismissButton = { TextButton(onClick = { showNewPlaylistDialog = false }) { Text(strings.cancel) } }
    )
  }

  if (showAddTrackDialog) {
    var title by remember { mutableStateOf("") }
    var artist by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var sourceType by remember { mutableStateOf("URL") }
    val activePl = selectedPlaylistId ?: playlists.firstOrNull()?.id ?: ""

    AlertDialog(
      onDismissRequest = { showAddTrackDialog = false },
      title = { Text(strings.addTrackTitle) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("URL" to "Audio HTTP", "SPOTIFY" to "Spotify", "YOUTUBE" to "YouTube").forEach { (key, lbl) ->
              FilterChip(selected = sourceType == key, onClick = { sourceType = key }, label = { Text(lbl, fontSize = 11.sp) })
            }
          }
          OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text(strings.trackTitleLabel) }, singleLine = true)
          OutlinedTextField(value = artist, onValueChange = { artist = it }, label = { Text(strings.artistLabel) }, singleLine = true)
          OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text(strings.streamUrlLabel) }, singleLine = true)
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (title.isNotBlank() && url.isNotBlank()) {
              viewModel.addTrackToPlaylist(
                playlistId = activePl,
                title = title.trim(),
                artist = artist.trim().ifBlank { strings.localAudioArtist },
                sourceUri = url.trim(),
                sourceType = sourceType,
                autoPlay = sourceType == "URL"
              ) { showAddTrackDialog = false }
            }
          },
          enabled = title.isNotBlank() && url.isNotBlank(),
          modifier = Modifier.testTag("save_audio_track_btn")
        ) { Text(strings.save) }
      },
      dismissButton = { TextButton(onClick = { showAddTrackDialog = false }) { Text(strings.cancel) } }
    )
  }
}
