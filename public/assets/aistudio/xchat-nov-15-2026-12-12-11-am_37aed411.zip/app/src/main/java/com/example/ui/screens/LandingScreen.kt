package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import com.example.R
import com.example.ui.theme.*
import com.example.utils.GoogleSignInHelper
import com.example.utils.IpDetectionResult

@Composable
fun LandingScreen(
  activeLang: String,
  ipInfo: IpDetectionResult?,
  onSelectLanguage: (String) -> Unit,
  onNavigateToLogin: () -> Unit,
  onNavigateToRegister: () -> Unit,
  onGoogleSignInSuccess: () -> Unit
) {
  val context = LocalContext.current
  val credentialManager = remember { CredentialManager.create(context) }
  val scope = rememberCoroutineScope()
  val scrollState = rememberScrollState()
  val s = LocalStrings.current

  var isSigningIn by remember { mutableStateOf(false) }
  var authError by remember { mutableStateOf<String?>(null) }

  Scaffold(
    containerColor = Color.Transparent
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .verticalScroll(scrollState)
        .padding(horizontal = 24.dp, vertical = 20.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      // Auto IP Detection Pill + Quick Language Switcher
      Row(
        modifier = Modifier
          .clip(RoundedCornerShape(20.dp))
          .background(MaterialTheme.colorScheme.surface)
          .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp))
          .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(Icons.Filled.Public, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = if (ipInfo != null) "${s.detectedIpPrefix}: ${ipInfo.countryCode} • ${activeLang.uppercase()}" else s.detectingIp,
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        AppLanguage.entries.forEach { lang ->
          FilterChip(
            selected = activeLang.equals(lang.code, ignoreCase = true),
            onClick = { onSelectLanguage(lang.code) },
            label = { Text(lang.code.uppercase(), fontSize = 11.sp) }
          )
        }
      }

      Spacer(modifier = Modifier.height(18.dp))

      // Logo and Branding
      Box(
        modifier = Modifier
          .size(88.dp)
          .clip(CircleShape)
          .background(AppThemeAccentBrush())
          .border(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Image(
          painter = painterResource(id = R.drawable.ic_xchat_icon),
          contentDescription = "XChat Logo",
          modifier = Modifier.size(68.dp).clip(CircleShape)
        )
      }

      Spacer(modifier = Modifier.height(18.dp))

      Text(
        text = s.appName,
        style = MaterialTheme.typography.displayLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground,
        letterSpacing = 1.sp
      )

      Text(
        text = s.tagline,
        style = MaterialTheme.typography.bodyLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(top = 6.dp)
      )

      Spacer(modifier = Modifier.height(22.dp))

      val featureItems = when (activeLang.lowercase()) {
        "id" -> listOf(
          "Real-Time Cloud Sync & Forum Komunitas" to "Chat, DM, profil, avatar GIF, banner, dan forum diskusi tersinkron otomatis lintas perangkat.",
          "Server Boost, Custom Tag & Role Icon" to "Buka tag & ikon server di 3 Boost serta role icon kustom chroma-key di 5 Boost.",
          "Gradasi Nama Tampilan & Efek Profil" to "Ekspresikan gaya Anda dengan 5 gradasi warna nama, efek profil animasi, dan status online live.",
          "22+ Supported Game & Kode Undangan" to "Pilih multi-game populer seperti Minecraft, Valorant, Fortnite, Marvel Rivals, & Mobile Legends."
        )
        "ms" -> listOf(
          "Segerak Awan Masa Nyata & Forum Komuniti" to "Sembang, DM, profil, avatar GIF dan forum disegerakkan secara automatik merentas peranti.",
          "Boost Pelayan, Tag & Ikon Role Tersuai" to "Buka tag & ikon pelayan pada 3 Boost serta ikon role chroma-key pada 5 Boost.",
          "Gradasi Nama Paparan & Kesan Profil" to "Serlahkan identiti anda dengan 5 gradasi nama, kesan profil animasi & status aktif.",
          "22+ Permainan Disokong & Kod Jemputan" to "Pilih pelbagai permainan popular seperti Minecraft, Valorant, Fortnite, & Mobile Legends."
        )
        "ja" -> listOf(
          "リアルタイムクラウド同期＆フォーラム" to "チャット・DM・プロフィール・GIF・フォーラムが端末間でリアルタイム同期。",
          "サーバーブースト＆カスタムタグ／ロールアイコン" to "ブースト3でカスタムタグ、ブースト5でクロマキー対応ロールアイコンを解放。",
          "表示名グラデーション＆プロフィールエフェクト" to "5色グラデーションと動くプロフィールエフェクト、リアルタイム入力中表示に対応。",
          "22種以上のゲーム対応＆カスタム招待" to "Minecraft・Valorant・Fortnite・Marvel Rivalsなど複数ゲームの選択が可能。"
        )
        else -> listOf(
          "Real-Time Cloud Sync & Community Forums" to "Chats, DMs, GIF avatars, banners, and Discord-style forums sync live across devices.",
          "Server Boosts, Custom Tags & Role Icons" to "Unlock custom server tags at 3 Boosts and chroma-key gallery role icons at 5 Boosts.",
          "Display Name Gradients & Profile Effects" to "Stand out with 5-stop name gradients, animated profile effects, and live typing status.",
          "22+ Supported Games & Custom Invites" to "Pick multiple supported games like Minecraft, Valorant, Fortnite, and Marvel Rivals."
        )
      }

      FeatureCard(icon = Icons.Filled.Forum, title = featureItems[0].first, desc = featureItems[0].second)
      Spacer(modifier = Modifier.height(10.dp))
      FeatureCard(icon = Icons.Filled.RocketLaunch, title = featureItems[1].first, desc = featureItems[1].second)
      Spacer(modifier = Modifier.height(10.dp))
      FeatureCard(icon = Icons.Filled.AutoAwesome, title = featureItems[2].first, desc = featureItems[2].second)
      Spacer(modifier = Modifier.height(10.dp))
      FeatureCard(icon = Icons.Filled.SportsEsports, title = featureItems[3].first, desc = featureItems[3].second)

      Spacer(modifier = Modifier.height(22.dp))

      if (authError != null) {
        Card(
          modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
          colors = CardDefaults.cardColors(containerColor = RoseError.copy(alpha = 0.16f)),
          shape = RoundedCornerShape(10.dp)
        ) {
          Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = RoseError, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(authError ?: "", color = RoseError, fontSize = 12.sp)
          }
        }
      }

      Button(
        onClick = {
          authError = null
          isSigningIn = true
          GoogleSignInHelper.onGoogleSignInClicked(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = {
              isSigningIn = false
              onGoogleSignInSuccess()
            },
            onAuthError = { err ->
              isSigningIn = false
              authError = err
            },
            onAuthCancelled = {
              isSigningIn = false
            },
            scope = scope
          )
        },
        enabled = !isSigningIn,
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .testTag("landing_google_signin_button"),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
      ) {
        if (isSigningIn) {
          CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
        } else {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.AccountCircle, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = when (activeLang.lowercase()) {
                "id" -> "Masuk dengan Google"
                "ms" -> "Teruskan dengan Google"
                "ja" -> "Googleで続行"
                else -> "Continue with Google"
              },
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.Bold,
              fontSize = 15.sp
            )
            Spacer(modifier = Modifier.width(6.dp))
            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedButton(
          onClick = onNavigateToLogin,
          modifier = Modifier
            .weight(1f)
            .height(48.dp)
            .testTag("landing_login_button"),
          shape = RoundedCornerShape(12.dp),
          border = ButtonDefaults.outlinedButtonBorder(enabled = true)
        ) {
          Text(s.loginBtn, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
        }

        OutlinedButton(
          onClick = onNavigateToRegister,
          modifier = Modifier
            .weight(1f)
            .height(48.dp)
            .testTag("landing_register_button"),
          shape = RoundedCornerShape(12.dp),
          border = ButtonDefaults.outlinedButtonBorder(enabled = true)
        ) {
          Text(s.registerBtn, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
        }
      }

      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}

@Composable
private fun FeatureCard(
  icon: ImageVector,
  title: String,
  desc: String
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.outline, MaterialTheme.colorScheme.surfaceVariant)))
  ) {
    Row(
      modifier = Modifier.padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(42.dp)
          .clip(RoundedCornerShape(10.dp))
          .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center
      ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
      }
      Spacer(modifier = Modifier.width(14.dp))
      Column {
        Text(
          text = title,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          fontSize = 14.sp,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = desc,
          style = MaterialTheme.typography.bodyMedium,
          fontSize = 12.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          lineHeight = 16.sp
        )
      }
    }
  }
}
