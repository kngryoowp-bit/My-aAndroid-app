package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.ChannelEntity
import com.example.ui.MainTab
import com.example.ui.XChatViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.utils.CloudMediaHelper
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun MainScreen(
  viewModel: XChatViewModel,
  onGoogleSignOut: () -> Unit = { viewModel.logout() }
) {
  val context = LocalContext.current
  val s = LocalStrings.current
  val activeTab by viewModel.activeTab.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()
  val servers by viewModel.servers.collectAsState()
  val selectedServerId by viewModel.selectedServerId.collectAsState()
  val currentCategories by viewModel.currentCategories.collectAsState()
  val currentChannels by viewModel.currentChannels.collectAsState()
  val selectedChannelId by viewModel.selectedChannelId.collectAsState()
  val serverRoles by viewModel.currentServerRoles.collectAsState()
  val serverMembers by viewModel.currentServerMembers.collectAsState()
  val allUsers by viewModel.allUsers.collectAsState()
  val inspectedProfile by viewModel.inspectedProfileUser.collectAsState()
  val inspectedFollowers by viewModel.inspectedUserFollowers.collectAsState()
  val inspectedFollowing by viewModel.inspectedUserFollowing.collectAsState()
  val inspectedGamesApps by viewModel.inspectedUserGamesApps.collectAsState()
  val myFollowing by viewModel.myFollowing.collectAsState()
  val voiceState by viewModel.voiceState.collectAsState()
  val feedback by viewModel.feedbackMessage.collectAsState()
  val mutedUserIds by viewModel.mutedUserIds.collectAsState()
  val mutedServerIds by viewModel.mutedServerIds.collectAsState()
  val inAppNotification by viewModel.inAppNotification.collectAsState()
  val isAppLocked by viewModel.isAppLocked.collectAsState()
  val activeRestriction by viewModel.activeRestriction.collectAsState()
  val isVerifiedAdmin by viewModel.isVerifiedAdmin.collectAsState()
  val audioState by viewModel.audioState.collectAsState()

  val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
  val scope = rememberCoroutineScope()
  val snackbarHostState = remember { SnackbarHostState() }

  var showAddChannelDialog by remember { mutableStateOf(false) }
  var addChannelInitialCategoryId by remember { mutableStateOf("") }
  var showCreateCategoryDialog by remember { mutableStateOf(false) }
  var showServerManageDialog by remember { mutableStateOf(false) }
  var serverManageInitialTab by remember { mutableIntStateOf(0) }
  var showGlobalSearch by remember { mutableStateOf(false) }
  var showNotificationsSheet by remember { mutableStateOf(false) }
  var showFullMusicPlayer by remember { mutableStateOf(false) }
  var reportTargetUserId by remember { mutableStateOf<String?>(null) }
  var reportReasonText by remember { mutableStateOf("Spam / Harassment") }
  var reportDetailsText by remember { mutableStateOf("") }
  val isViewingDm by viewModel.isViewingDm.collectAsState()
  val imeVisible = WindowInsets.isImeVisible

  LaunchedEffect(feedback) {
    feedback?.let {
      snackbarHostState.showSnackbar(it)
      viewModel.feedbackMessage.value = null
    }
  }

  BackHandler(
    enabled = drawerState.isOpen ||
      activeTab == MainTab.SETTINGS ||
      activeTab == MainTab.OWNER_DASHBOARD ||
      activeTab == MainTab.EXPLORE ||
      activeTab == MainTab.GAMES
  ) {
    when {
      drawerState.isOpen -> scope.launch { drawerState.close() }
      activeTab == MainTab.SETTINGS || activeTab == MainTab.OWNER_DASHBOARD -> viewModel.setActiveTab(MainTab.PROFILE)
      activeTab == MainTab.EXPLORE || activeTab == MainTab.GAMES -> viewModel.setActiveTab(MainTab.HOME)
    }
  }

  val visibleServers = remember(servers, isVerifiedAdmin) {
    if (isVerifiedAdmin) servers else servers.filter { !it.isVanished }
  }
  val activeServer = visibleServers.find { it.id == selectedServerId } ?: visibleServers.firstOrNull()
  val activeChannel = currentChannels.find { it.id == selectedChannelId } ?: currentChannels.firstOrNull()
  val isActiveServerMuted = activeServer != null && mutedServerIds.contains(activeServer.id)

  val isRestrictedNow = activeRestriction?.let {
    it.isActive && System.currentTimeMillis() < it.expiresAt
  } == true

  Box(modifier = Modifier.fillMaxSize()) {
    // Persistent Cinematic Moving Marble / User Custom Wallpaper Background Layer
    XChatCinematicBackground(
      wallpaperMode = currentUser?.wallpaperMode ?: "MARBLE",
      customWallpaperUri = currentUser?.customWallpaperUri,
      wallpaperGradientCsv = currentUser?.wallpaperGradientCsv ?: "0xFF07080B,0xFF111318,0xFF1E222A",
      blurRadius = currentUser?.wallpaperBlur ?: 0f,
      opacity = currentUser?.wallpaperOpacity ?: 0.85f,
      brightness = currentUser?.wallpaperBrightness ?: 0.9f,
      tintHex = currentUser?.wallpaperTintHex ?: 0xFF07080BL,
      lowPerfMode = currentUser?.lowPerfMode ?: false
    )

    ModalNavigationDrawer(
      drawerState = drawerState,
      gesturesEnabled = activeTab == MainTab.CHANNELS && !voiceState.isInVoice && !isRestrictedNow,
      drawerContent = {
        ModalDrawerSheet(
          drawerContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.93f),
          modifier = Modifier.width(310.dp)
        ) {
          Column(
            modifier = Modifier.fillMaxSize().padding(16.dp)
          ) {
            val activeBannerModel = remember(activeServer?.bannerUri) { CloudMediaHelper.resolveCoilModel(activeServer?.bannerUri) }
            val activeBannerReq = remember(activeBannerModel) {
              activeBannerModel?.let { ImageRequest.Builder(context).data(it).crossfade(false).build() }
            }
            val activeIconModel = remember(activeServer?.iconUri) { CloudMediaHelper.resolveCoilModel(activeServer?.iconUri) }
            val activeIconReq = remember(activeIconModel) {
              activeIconModel?.let { ImageRequest.Builder(context).data(it).crossfade(false).build() }
            }
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(if (activeBannerReq != null) Color(0xFF141518) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
                .border(1.dp, GlassBorderSubtle, RoundedCornerShape(14.dp))
            ) {
              if (activeBannerReq != null) {
                AsyncImage(
                  model = activeBannerReq,
                  contentDescription = "Server Banner",
                  contentScale = ContentScale.Crop,
                  modifier = Modifier.matchParentSize()
                )
                Box(modifier = Modifier.matchParentSize().background(Color.Black.copy(alpha = 0.55f)))
              }
              Row(
                modifier = Modifier.fillMaxWidth().padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .then(
                      if (activeIconReq != null) Modifier.background(Color(0xFF1E1F22))
                      else Modifier.background(AppThemeAccentBrush())
                    )
                    .border(1.5.dp, Color.White.copy(alpha = 0.5f), CircleShape),
                  contentAlignment = Alignment.Center
                ) {
                  if (activeIconReq != null) {
                    AsyncImage(
                      model = activeIconReq,
                      contentDescription = activeServer?.name,
                      contentScale = ContentScale.Crop,
                      modifier = Modifier.fillMaxSize()
                    )
                  } else {
                    Text(
                      text = activeServer?.name?.take(2)?.uppercase() ?: "XC",
                      color = Color.White,
                      fontWeight = FontWeight.Bold,
                      fontSize = 16.sp
                    )
                  }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = activeServer?.name ?: s.selectServer,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = if (activeBannerModel != null) Color.White else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1
                  )
                  Text(
                    text = "${s.joinCode}: ${activeServer?.inviteCode ?: "-"} • Lvl ${activeServer?.boostLevel ?: 0} (${activeServer?.boostCount ?: 0})",
                    fontSize = 10.sp,
                    color = if (activeBannerModel != null) Color.White.copy(alpha = 0.85f) else MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (activeServer != null) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(bottom = 8.dp)
                  .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                FilledTonalButton(
                  onClick = {
                    serverManageInitialTab = 0
                    showServerManageDialog = true
                  },
                  contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                  modifier = Modifier.height(32.dp),
                  shape = RoundedCornerShape(8.dp)
                ) {
                  Icon(Icons.Filled.RocketLaunch, contentDescription = null, modifier = Modifier.size(13.dp), tint = AstralViolet)
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Edit & Boost", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                FilledTonalButton(
                  onClick = {
                    serverManageInitialTab = 1
                    showServerManageDialog = true
                  },
                  contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                  modifier = Modifier.height(32.dp),
                  shape = RoundedCornerShape(8.dp)
                ) {
                  Icon(Icons.Filled.Shield, contentDescription = null, modifier = Modifier.size(13.dp), tint = MaterialTheme.colorScheme.primary)
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Roles (${serverRoles.size})", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                FilledTonalButton(
                  onClick = { viewModel.toggleMuteServer(activeServer.id) },
                  contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                  modifier = Modifier.height(32.dp).testTag("drawer_mute_server_button"),
                  shape = RoundedCornerShape(8.dp)
                ) {
                  Icon(
                    if (isActiveServerMuted) Icons.Filled.NotificationsOff else Icons.Filled.NotificationsActive,
                    contentDescription = null,
                    modifier = Modifier.size(13.dp),
                    tint = if (isActiveServerMuted) AmberWarning else MaterialTheme.colorScheme.primary
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = if (isActiveServerMuted) s.unmuteServerNotif else s.muteServerNotif,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                  )
                }
                if (isVerifiedAdmin) {
                  FilledTonalButton(
                    onClick = { viewModel.toggleServerVanish(activeServer.id, !activeServer.isVanished) },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp).testTag("drawer_vanish_server_button"),
                    shape = RoundedCornerShape(8.dp)
                  ) {
                    Icon(
                      if (activeServer.isVanished) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                      contentDescription = null,
                      modifier = Modifier.size(13.dp),
                      tint = if (activeServer.isVanished) RoseError else EmeraldSuccess
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (activeServer.isVanished) "Vanished" else s.publicLabel, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                  }
                }
                ServerTagPill(
                  tagText = activeServer.serverTag,
                  tagIconKeyOrUri = activeServer.serverTagIcon
                )
              }

              if (!activeServer.supportedGame.isNullOrBlank()) {
                MultiGameBadgesRow(
                  supportedGamesCsv = activeServer.supportedGame,
                  modifier = Modifier.padding(bottom = 8.dp)
                )
              }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline)

            Row(
              modifier = Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 6.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = s.serverListHeader,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 1.sp
              )
              TextButton(
                onClick = {
                  viewModel.setActiveTab(MainTab.EXPLORE)
                  scope.launch { drawerState.close() }
                },
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                modifier = Modifier.height(26.dp).testTag("drawer_explore_button")
              ) {
                Icon(Icons.Filled.Explore, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(s.tabExplore, fontSize = 10.sp, fontWeight = FontWeight.Bold)
              }
            }

            Row(
              modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(bottom = 12.dp),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              visibleServers.forEach { srv ->
                val isSelected = srv.id == selectedServerId
                val srvIconModel = remember(srv.iconUri) { CloudMediaHelper.resolveCoilModel(srv.iconUri) }
                val srvIconReq = remember(srvIconModel) {
                  srvIconModel?.let { ImageRequest.Builder(context).data(it).crossfade(false).build() }
                }
                Box(
                  modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(if (isSelected) 12.dp else 21.dp))
                    .background(
                      when {
                        srvIconReq != null -> Color(0xFF1E1F22)
                        isSelected -> MaterialTheme.colorScheme.primary
                        else -> MaterialTheme.colorScheme.surfaceVariant
                      }
                    )
                    .clickable { viewModel.selectServer(srv.id) },
                  contentAlignment = Alignment.Center
                ) {
                  if (srvIconReq != null) {
                    AsyncImage(
                      model = srvIconReq,
                      contentDescription = srv.name,
                      contentScale = ContentScale.Crop,
                      modifier = Modifier.fillMaxSize()
                    )
                  } else {
                    Text(
                      text = srv.name.take(2).uppercase(),
                      fontWeight = FontWeight.Bold,
                      fontSize = 12.sp,
                      color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                    )
                  }
                }
              }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline)

            Row(
              modifier = Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 6.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = s.channelsHeader,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 1.sp
              )
              if (activeServer != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                  IconButton(
                    onClick = { showCreateCategoryDialog = true },
                    modifier = Modifier.size(28.dp).testTag("drawer_add_category_button")
                  ) {
                    Icon(Icons.Filled.CreateNewFolder, contentDescription = "Add Category", tint = SilverAccent, modifier = Modifier.size(18.dp))
                  }
                  IconButton(
                    onClick = {
                      addChannelInitialCategoryId = currentCategories.firstOrNull()?.id ?: ""
                      showAddChannelDialog = true
                    },
                    modifier = Modifier.size(28.dp).testTag("drawer_add_channel_button")
                  ) {
                    Icon(Icons.Filled.AddCircleOutline, contentDescription = "Add Channel", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                  }
                }
              }
            }

            LazyColumn(
              modifier = Modifier.weight(1f),
              verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              if (currentCategories.isEmpty()) {
                items(currentChannels, key = { it.id }) { ch ->
                  DrawerChannelItemRow(
                    ch = ch,
                    isSelected = ch.id == selectedChannelId,
                    onClick = {
                      viewModel.selectChannel(ch)
                      scope.launch { drawerState.close() }
                    }
                  )
                }
              } else {
                val knownCatIds = currentCategories.map { it.id }.toSet()
                currentCategories.forEach { cat ->
                  val catChannels = currentChannels.filter { it.categoryId == cat.id }
                  item(key = "cat_${cat.id}") {
                    Row(
                      modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { viewModel.toggleCategoryCollapsed(cat) }
                        .padding(horizontal = 4.dp, vertical = 6.dp),
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Icon(
                        if (cat.isCollapsed) Icons.Filled.KeyboardArrowRight else Icons.Filled.KeyboardArrowDown,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                      )
                      Spacer(modifier = Modifier.width(4.dp))
                      Text(
                        text = cat.name.uppercase(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        letterSpacing = 0.8.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                      )
                      IconButton(
                        onClick = {
                          addChannelInitialCategoryId = cat.id
                          showAddChannelDialog = true
                        },
                        modifier = Modifier.size(22.dp)
                      ) {
                        Icon(Icons.Filled.Add, contentDescription = "Add to ${cat.name}", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                      }
                    }
                  }
                  if (!cat.isCollapsed) {
                    items(catChannels, key = { it.id }) { ch ->
                      DrawerChannelItemRow(
                        ch = ch,
                        isSelected = ch.id == selectedChannelId,
                        onClick = {
                          viewModel.selectChannel(ch)
                          scope.launch { drawerState.close() }
                        }
                      )
                    }
                  }
                }
                val uncategorized = currentChannels.filter { it.categoryId !in knownCatIds }
                if (uncategorized.isNotEmpty()) {
                  item(key = "cat_other") {
                    Text(
                      text = s.otherCategory,
                      fontWeight = FontWeight.Bold,
                      fontSize = 10.sp,
                      letterSpacing = 0.8.sp,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp)
                    )
                  }
                  items(uncategorized, key = { it.id }) { ch ->
                    DrawerChannelItemRow(
                      ch = ch,
                      isSelected = ch.id == selectedChannelId,
                      onClick = {
                        viewModel.selectChannel(ch)
                        scope.launch { drawerState.close() }
                      }
                    )
                  }
                }
              }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
            Row(
              modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              UserAvatar(
                avatarUri = currentUser?.avatarUri,
                displayName = currentUser?.displayName ?: "User",
                size = 38.dp,
                frameId = currentUser?.equippedFrame,
                isOnline = isUserOnlineNow(currentUser),
                showStatus = true,
                presenceStatus = currentUser?.presenceStatus ?: "ONLINE",
                lastSeenAt = currentUser?.lastSeenAt ?: 0L,
                userId = currentUser?.id ?: "",
                backgroundColor = currentUser?.profileColor ?: 0xFF8B5CF6L
              )
              Spacer(modifier = Modifier.width(10.dp))
              Column(modifier = Modifier.weight(1f)) {
                StyledDisplayName(
                  name = currentUser?.displayName ?: "User",
                  fontKey = currentUser?.displayNameFont ?: "SERIF",
                  colorsCsv = currentUser?.displayNameColorsCsv ?: "",
                  effectKey = currentUser?.displayNameEffect ?: "GRADIENT",
                  fontSize = 13.sp,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = "@${currentUser?.username ?: "-"}",
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              IconButton(
                onClick = {
                  viewModel.setActiveTab(MainTab.OWNER_DASHBOARD)
                  scope.launch { drawerState.close() }
                },
                modifier = Modifier.testTag("drawer_owner_button")
              ) {
                Icon(Icons.Filled.AdminPanelSettings, contentDescription = s.ownerDashboard, tint = MaterialTheme.colorScheme.primary)
              }
              IconButton(
                onClick = {
                  viewModel.setActiveTab(MainTab.SETTINGS)
                  scope.launch { drawerState.close() }
                }
              ) {
                Icon(Icons.Filled.Settings, contentDescription = s.settings, tint = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }
        }
      }
    ) {
      BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 600.dp

        Row(modifier = Modifier.fillMaxSize()) {
          if (isWideScreen) {
            NavigationRail(
              containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.82f),
              contentColor = MaterialTheme.colorScheme.primary,
              modifier = Modifier.fillMaxHeight()
            ) {
              Spacer(modifier = Modifier.height(8.dp))
              NavigationRailItem(
                selected = activeTab == MainTab.HOME,
                onClick = { viewModel.setActiveTab(MainTab.HOME) },
                icon = { Icon(Icons.Filled.Home, contentDescription = s.tabHome) },
                label = { Text(s.tabHome, fontSize = 10.sp) },
                modifier = Modifier.testTag("tab_home")
              )
              NavigationRailItem(
                selected = activeTab == MainTab.CHANNELS,
                onClick = { viewModel.setActiveTab(MainTab.CHANNELS) },
                icon = { Icon(Icons.Filled.Forum, contentDescription = s.tabChannels) },
                label = { Text(s.tabChannels, fontSize = 10.sp) },
                modifier = Modifier.testTag("tab_channels")
              )
              NavigationRailItem(
                selected = activeTab == MainTab.DMS,
                onClick = { viewModel.setActiveTab(MainTab.DMS) },
                icon = { Icon(Icons.Filled.People, contentDescription = s.tabFriends) },
                label = { Text(s.tabFriends, fontSize = 10.sp) },
                modifier = Modifier.testTag("tab_dms")
              )
              NavigationRailItem(
                selected = activeTab == MainTab.EXPLORE,
                onClick = { viewModel.setActiveTab(MainTab.EXPLORE) },
                icon = { Icon(Icons.Filled.Explore, contentDescription = s.tabExplore) },
                label = { Text(s.tabExplore, fontSize = 10.sp) },
                modifier = Modifier.testTag("tab_explore")
              )
              NavigationRailItem(
                selected = activeTab == MainTab.GAMES,
                onClick = { viewModel.setActiveTab(MainTab.GAMES) },
                icon = { Icon(Icons.Filled.SportsEsports, contentDescription = s.tabGames) },
                label = { Text(s.tabGames, fontSize = 10.sp) },
                modifier = Modifier.testTag("tab_games")
              )
              NavigationRailItem(
                selected = activeTab == MainTab.MARKET,
                onClick = { viewModel.setActiveTab(MainTab.MARKET) },
                icon = { Icon(Icons.Filled.Storefront, contentDescription = s.tabMarket) },
                label = { Text(s.tabMarket, fontSize = 10.sp) },
                modifier = Modifier.testTag("tab_market")
              )
              NavigationRailItem(
                selected = activeTab == MainTab.PROFILE || activeTab == MainTab.SETTINGS || activeTab == MainTab.OWNER_DASHBOARD,
                onClick = { viewModel.setActiveTab(MainTab.PROFILE) },
                icon = { Icon(Icons.Filled.AccountCircle, contentDescription = s.tabProfile) },
                label = { Text(s.tabProfile, fontSize = 10.sp) },
                modifier = Modifier.testTag("tab_profile")
              )
            }
          }

          Scaffold(
            modifier = Modifier.weight(1f).fillMaxHeight(),
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
              val hideBottomBar = imeVisible || (activeTab == MainTab.DMS && isViewingDm)
              Column(modifier = Modifier.fillMaxWidth()) {
                if (audioState.currentTrack != null && !imeVisible) {
                  MiniMusicPlayerBar(
                    viewModel = viewModel,
                    onOpenFullPlayer = { showFullMusicPlayer = true }
                  )
                }
                if (!isWideScreen && !hideBottomBar) {
                  NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                    contentColor = MaterialTheme.colorScheme.primary,
                    tonalElevation = 0.dp
                  ) {
                    val navItemColors = NavigationBarItemDefaults.colors(
                      selectedIconColor = MaterialTheme.colorScheme.primary,
                      selectedTextColor = MaterialTheme.colorScheme.primary,
                      indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                      unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                      unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    NavigationBarItem(
                      selected = activeTab == MainTab.HOME,
                      onClick = { viewModel.setActiveTab(MainTab.HOME) },
                      icon = { Icon(Icons.Filled.Home, contentDescription = s.tabHome) },
                      label = { Text(s.tabHome, fontSize = 9.sp, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis) },
                      colors = navItemColors,
                      modifier = Modifier.testTag("tab_home")
                    )
                    NavigationBarItem(
                      selected = activeTab == MainTab.CHANNELS,
                      onClick = { viewModel.setActiveTab(MainTab.CHANNELS) },
                      icon = { Icon(Icons.Filled.Forum, contentDescription = s.tabChannels) },
                      label = { Text(s.tabChannels, fontSize = 9.sp, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis) },
                      colors = navItemColors,
                      modifier = Modifier.testTag("tab_channels")
                    )
                    NavigationBarItem(
                      selected = activeTab == MainTab.DMS,
                      onClick = { viewModel.setActiveTab(MainTab.DMS) },
                      icon = { Icon(Icons.Filled.People, contentDescription = s.tabFriends) },
                      label = { Text(s.tabFriends, fontSize = 9.sp, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis) },
                      colors = navItemColors,
                      modifier = Modifier.testTag("tab_dms")
                    )
                    NavigationBarItem(
                      selected = activeTab == MainTab.GAMES,
                      onClick = { viewModel.setActiveTab(MainTab.GAMES) },
                      icon = { Icon(Icons.Filled.SportsEsports, contentDescription = s.tabGames) },
                      label = { Text(s.tabGames, fontSize = 9.sp, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis) },
                      colors = navItemColors,
                      modifier = Modifier.testTag("tab_games")
                    )
                    NavigationBarItem(
                      selected = activeTab == MainTab.MARKET,
                      onClick = { viewModel.setActiveTab(MainTab.MARKET) },
                      icon = { Icon(Icons.Filled.Storefront, contentDescription = s.tabMarket) },
                      label = { Text(s.tabMarket, fontSize = 9.sp, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis) },
                      colors = navItemColors,
                      modifier = Modifier.testTag("tab_market")
                    )
                    NavigationBarItem(
                      selected = activeTab == MainTab.PROFILE || activeTab == MainTab.SETTINGS || activeTab == MainTab.OWNER_DASHBOARD,
                      onClick = { viewModel.setActiveTab(MainTab.PROFILE) },
                      icon = { Icon(Icons.Filled.AccountCircle, contentDescription = s.tabProfile) },
                      label = { Text(s.tabProfile, fontSize = 9.sp, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis) },
                      colors = navItemColors,
                      modifier = Modifier.testTag("tab_profile")
                    )
                  }
                }
              }
            },
            containerColor = Color.Transparent
          ) { innerPadding ->
            Box(
              modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .consumeWindowInsets(innerPadding)
            ) {
              if (voiceState.isInVoice) {
                VoiceScreen(viewModel = viewModel)
              } else {
                when (activeTab) {
                  MainTab.HOME -> HomeShowcaseScreen(
                    viewModel = viewModel,
                    onOpenGlobalSearch = { showGlobalSearch = true },
                    onOpenNotifications = { showNotificationsSheet = true }
                  )
                  MainTab.CHANNELS -> {
                    if (activeChannel != null) {
                      ChatScreen(
                        viewModel = viewModel,
                        serverName = activeServer?.name ?: "XChat",
                        channel = activeChannel,
                        activeServer = activeServer,
                        serverRoles = serverRoles,
                        serverMembers = serverMembers,
                        allUsers = allUsers,
                        onOpenServerMenu = { scope.launch { drawerState.open() } }
                      )
                    } else {
                      Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(s.loadingChannel, color = MaterialTheme.colorScheme.onSurfaceVariant)
                      }
                    }
                  }
                  MainTab.DMS -> FriendsScreen(viewModel = viewModel)
                  MainTab.EXPLORE -> ExploreScreen(viewModel = viewModel)
                  MainTab.GAMES -> GamesScreen(viewModel = viewModel)
                  MainTab.MARKET -> MarketplaceScreen(viewModel = viewModel)
                  MainTab.PROFILE -> ProfileScreen(viewModel = viewModel)
                  MainTab.SETTINGS -> SettingsScreen(viewModel = viewModel, onLogoutClick = onGoogleSignOut)
                  MainTab.OWNER_DASHBOARD -> OwnerDashboardScreen(viewModel = viewModel)
                }
              }
            }
          }
        }
      }
    }

    if (showAddChannelDialog && activeServer != null) {
      AddChannelDialog(
        serverId = activeServer.id,
        viewModel = viewModel,
        categories = currentCategories,
        initialCategoryId = addChannelInitialCategoryId,
        onDismiss = { showAddChannelDialog = false }
      )
    }

    if (showCreateCategoryDialog && activeServer != null) {
      var catNameInput by remember { mutableStateOf("") }
      AlertDialog(
        onDismissRequest = { showCreateCategoryDialog = false },
        title = { Text("Create Channel Category", fontWeight = FontWeight.Bold) },
        text = {
          OutlinedTextField(
            value = catNameInput,
            onValueChange = { catNameInput = it },
            label = { Text("Category Name (e.g. COMMUNITY)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        },
        confirmButton = {
          Button(
            onClick = {
              if (catNameInput.isNotBlank()) {
                viewModel.createCategory(activeServer.id, catNameInput) {
                  showCreateCategoryDialog = false
                }
              }
            },
            enabled = catNameInput.isNotBlank()
          ) { Text(s.createBtn) }
        },
        dismissButton = {
          TextButton(onClick = { showCreateCategoryDialog = false }) { Text(s.cancel) }
        }
      )
    }

    if (showServerManageDialog && activeServer != null) {
      ServerManageDialog(
        server = activeServer,
        currentUser = currentUser,
        roles = serverRoles,
        members = serverMembers,
        allUsers = allUsers,
        initialTab = serverManageInitialTab,
        viewModel = viewModel,
        onDismiss = { showServerManageDialog = false }
      )
    }

    if (inspectedProfile != null) {
      val target = allUsers.find { it.id == inspectedProfile!!.id } ?: inspectedProfile!!
      val memberRole = serverMembers.find { it.userId == target.id }
      val amFollowingTarget = myFollowing.any { it.targetUserId == target.id }
      UserProfileFullDialog(
        user = target,
        isSelf = target.id == currentUser?.id,
        memberRole = memberRole,
        isUserMuted = mutedUserIds.contains(target.id),
        followersCount = inspectedFollowers.size,
        followingCount = inspectedFollowing.size,
        isFollowing = amFollowingTarget,
        gamesApps = inspectedGamesApps,
        onToggleFollow = { viewModel.toggleFollowUser(target.id) },
        onVoiceCall = {
          viewModel.closeUserProfile()
          viewModel.startDmCall(target, isVideo = false)
        },
        onVideoCall = {
          viewModel.closeUserProfile()
          viewModel.startDmCall(target, isVideo = true)
        },
        onReportUser = {
          reportTargetUserId = target.id
          viewModel.closeUserProfile()
        },
        onToggleMuteUser = { viewModel.toggleMuteUser(target.id) },
        onDismiss = { viewModel.closeUserProfile() },
        onSendDm = { viewModel.startDmWithUser(target.id) },
        onAddFriend = {
          viewModel.addFriend(target.username) {
            viewModel.closeUserProfile()
          }
        }
      )
    }

    if (reportTargetUserId != null) {
      AlertDialog(
        onDismissRequest = { reportTargetUserId = null },
        title = { Text(s.reportIssueBtn, fontWeight = FontWeight.Bold) },
        text = {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
              value = reportReasonText,
              onValueChange = { reportReasonText = it },
              label = { Text(s.lockReasonLabel) },
              singleLine = true,
              modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
              value = reportDetailsText,
              onValueChange = { reportDetailsText = it },
              label = { Text("Incident Details") },
              maxLines = 3,
              modifier = Modifier.fillMaxWidth()
            )
          }
        },
        confirmButton = {
          Button(
            onClick = {
              viewModel.submitReport(
                targetUserId = reportTargetUserId,
                targetServerId = null,
                targetMessageId = null,
                reason = reportReasonText,
                details = reportDetailsText
              ) {
                reportTargetUserId = null
                reportDetailsText = ""
              }
            }
          ) { Text(s.sendBtn) }
        },
        dismissButton = {
          TextButton(onClick = { reportTargetUserId = null }) { Text(s.cancel) }
        }
      )
    }

    if (showGlobalSearch) {
      GlobalSearchDialog(
        viewModel = viewModel,
        onDismiss = { showGlobalSearch = false }
      )
    }

    if (showNotificationsSheet) {
      NotificationCenterSheet(
        viewModel = viewModel,
        onDismiss = { showNotificationsSheet = false }
      )
    }

    if (showFullMusicPlayer) {
      FullMusicPlayerDialog(
        viewModel = viewModel,
        onDismiss = { showFullMusicPlayer = false }
      )
    }

    // Active Bilateral Call Overlay (DM Voice/Video)
    CallOverlayDialog(viewModel = viewModel)

    // Draggable & Minimizable Floating Admin Panel (strictly gated by isVerifiedAdmin)
    if (!isAppLocked && !isRestrictedNow) {
      FloatingAdminOverlay(viewModel = viewModel)
    }

    // Top Clickable In-App Notification Banner
    AnimatedVisibility(
      visible = inAppNotification != null && !isAppLocked && !isRestrictedNow,
      enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
      exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
      modifier = Modifier
        .align(Alignment.TopCenter)
        .statusBarsPadding()
        .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
      val notif = inAppNotification
      if (notif != null) {
        Surface(
          onClick = { viewModel.openNotificationTarget(notif) },
          shape = RoundedCornerShape(14.dp),
          color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
          tonalElevation = 8.dp,
          shadowElevation = 8.dp,
          border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)),
          modifier = Modifier.fillMaxWidth().testTag("in_app_notification_banner")
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                if (notif.isDm) Icons.Filled.MarkChatUnread else Icons.Filled.NotificationsActive,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(notif.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
              Text(notif.body, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            IconButton(
              onClick = { viewModel.dismissInAppNotification() },
              modifier = Modifier.size(32.dp)
            ) {
              Icon(Icons.Filled.Close, contentDescription = s.close, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
            }
          }
        }
      }
    }

    // App Lock PIN Security Overlay
    if (isAppLocked && !isRestrictedNow) {
      var pinInput by remember { mutableStateOf("") }
      var pinError by remember { mutableStateOf(false) }

      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(Color(0xF5111216))
          .padding(24.dp),
        contentAlignment = Alignment.Center
      ) {
        Card(
          modifier = Modifier.fillMaxWidth().widthIn(max = 380.dp),
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
        ) {
          Column(
            modifier = Modifier.padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Box(
              modifier = Modifier.size(56.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Filled.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
            }
            Text("XChat Security Lock", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurface)
            Text(
              "Enter your 4–6 digit PIN to unlock your account session.",
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedTextField(
              value = pinInput,
              onValueChange = { next ->
                if (next.length <= 6 && next.all { it.isDigit() }) {
                  pinInput = next
                  pinError = false
                }
              },
              label = { Text("Security PIN") },
              visualTransformation = PasswordVisualTransformation(),
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
              isError = pinError,
              singleLine = true,
              modifier = Modifier.fillMaxWidth().testTag("app_lock_pin_input"),
              shape = RoundedCornerShape(12.dp)
            )
            if (pinError) {
              Text("Incorrect PIN. Please try again.", color = RoseError, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
            Button(
              onClick = {
                if (!viewModel.unlockWithPin(pinInput)) {
                  pinError = true
                }
              },
              enabled = pinInput.length >= 4,
              modifier = Modifier.fillMaxWidth().height(48.dp).testTag("app_lock_unlock_btn"),
              shape = RoundedCornerShape(12.dp)
            ) {
              Icon(Icons.Filled.LockOpen, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("Unlock", fontWeight = FontWeight.Bold)
            }
            TextButton(onClick = onGoogleSignOut) {
              Text(s.logout, color = RoseError, fontSize = 12.sp)
            }
          }
        }
      }
    }

    // Highest Priority: XChat In-App Lock Screen Restriction Overlay (never locks Android OS)
    val rst = activeRestriction
    if (rst != null && rst.isActive && System.currentTimeMillis() < rst.expiresAt) {
      XChatLockScreenOverlay(
        restriction = rst,
        onSubmitAppeal = { appealMsg ->
          viewModel.submitRestrictionAppeal(rst, appealMsg)
        },
        onLogout = onGoogleSignOut
      )
    }
  }
}

@Composable
private fun DrawerChannelItemRow(
  ch: ChannelEntity,
  isSelected: Boolean,
  onClick: () -> Unit
) {
  val icon = when (ch.type) {
    "voice" -> Icons.Filled.VolumeUp
    "announcements" -> Icons.Filled.Campaign
    "rules" -> Icons.Filled.Gavel
    "forums" -> Icons.Filled.Forum
    "media" -> Icons.Filled.PermMedia
    else -> Icons.Filled.Tag
  }
  Surface(
    onClick = onClick,
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(8.dp),
    color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        icon,
        contentDescription = null,
        tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(18.dp)
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = ch.name,
        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
        fontSize = 14.sp,
        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
      )
      if (ch.type == "voice") {
        Spacer(modifier = Modifier.weight(1f))
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(EmeraldSuccess.copy(alpha = 0.18f))
            .padding(horizontal = 5.dp, vertical = 1.dp)
        ) {
          Text("VOICE", color = EmeraldSuccess, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}
