package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MarketplaceItemEntity
import com.example.ui.XChatViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarketplaceScreen(viewModel: XChatViewModel) {
  val s = LocalStrings.current
  val currentUser by viewModel.currentUser.collectAsState()
  val items by viewModel.marketplaceItems.collectAsState()
  val quests by viewModel.quests.collectAsState()
  val inventory by viewModel.userInventory.collectAsState()

  var selectedTab by remember { mutableIntStateOf(0) } // 0: Toko XIT, 1: Quest, 2: Langganan Astrix & Astral
  var showPaymentDialog by remember { mutableStateOf(false) }
  var showTransferDialog by remember { mutableStateOf(false) }
  var paymentTier by remember { mutableStateOf("ASTRAL") }
  var redeemCodeInput by remember { mutableStateOf("") }

  Scaffold(
    contentWindowInsets = WindowInsets(0.dp),
    topBar = {
      TopAppBar(
        windowInsets = WindowInsets(0.dp),
        title = {
          Text(s.tabMarket, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        },
        actions = {
          AssistChip(
            onClick = { selectedTab = 2 },
            label = {
              Text(
                if (currentUser?.isOwner == true) "∞ Boost" else "${currentUser?.boostBalance ?: 0} Boost",
                fontWeight = FontWeight.Bold,
                color = AstralViolet,
                fontSize = 11.sp
              )
            },
            leadingIcon = {
              Icon(Icons.Filled.RocketLaunch, contentDescription = null, tint = AstralViolet, modifier = Modifier.size(16.dp))
            },
            modifier = Modifier.padding(end = 6.dp)
          )
          AssistChip(
            onClick = { showTransferDialog = true },
            label = {
              Text(
                if (currentUser?.isOwner == true) "∞ XIT" else "${currentUser?.xitBalance ?: 0} XIT",
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                fontSize = 11.sp
              )
            },
            leadingIcon = {
              Icon(Icons.Filled.Paid, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
            },
            modifier = Modifier.padding(end = 10.dp)
          )
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f))
      )
    },
    containerColor = Color.Transparent
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      PrimaryTabRow(
        selectedTabIndex = selectedTab,
        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f),
        contentColor = MaterialTheme.colorScheme.primary
      ) {
        Tab(
          selected = selectedTab == 0,
          onClick = { selectedTab = 0 },
          text = { Text(s.shopTab, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
        )
        Tab(
          selected = selectedTab == 1,
          onClick = { selectedTab = 1 },
          text = { Text(s.questsTab, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
        )
        Tab(
          selected = selectedTab == 2,
          onClick = { selectedTab = 2 },
          text = { Text(s.tiersTab, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
        )
      }

      when (selectedTab) {
        0 -> {
          LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            item(key = "redeem_code_card") {
              Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f)),
                border = CardDefaults.outlinedCardBorder().copy(
                  brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), MaterialTheme.colorScheme.outline))
                )
              ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                  Text("Tukar Kode Hadiah (Redeem Code)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                  Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                      value = redeemCodeInput,
                      onValueChange = { redeemCodeInput = it.uppercase() },
                      label = { Text("Kode Redeem (cth: XCHAT2026)") },
                      singleLine = true,
                      modifier = Modifier.weight(1f),
                      shape = RoundedCornerShape(10.dp)
                    )
                    Button(
                      onClick = {
                        viewModel.redeemCode(redeemCodeInput) { redeemCodeInput = "" }
                      },
                      enabled = redeemCodeInput.isNotBlank(),
                      modifier = Modifier.height(50.dp),
                      shape = RoundedCornerShape(10.dp)
                    ) {
                      Text(s.redeemBtn, fontWeight = FontWeight.Bold)
                    }
                  }
                }
              }
            }
            items(items, key = { it.id }) { item ->
              val invItem = inventory.firstOrNull { it.itemId == item.id }
              val owned = invItem != null
              val isEquipped = when (item.category) {
                "FRAME" -> currentUser?.equippedFrame == item.id
                "NAMEPLATE" -> currentUser?.equippedNameplate == item.id
                "DECORATION", "EFFECT" -> currentUser?.equippedEffect == item.id
                "TEXT_EFFECT" -> currentUser?.displayNameEffect.equals(item.id.removePrefix("txt_"), ignoreCase = true)
                "CHAT_EFFECT" -> invItem?.isEquipped == true || currentUser?.chatBubbleBgCsv == "0xFF13161D,0xFF232938"
                "BACKGROUND_THEME" -> invItem?.isEquipped == true || currentUser?.wallpaperMode == "GRADIENT"
                else -> invItem?.isEquipped == true
              }

              MarketItemCard(
                item = item,
                isOwned = owned,
                isEquipped = isEquipped,
                onBuy = { viewModel.buyItem(item) },
                onToggleEquip = {
                  if (isEquipped) {
                    viewModel.unequipItem(item.id, item.category)
                  } else {
                    viewModel.equipItem(item.id, item.category)
                  }
                }
              )
            }
          }
        }
        1 -> {
          LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            items(quests, key = { it.id }) { quest ->
              Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)),
                border = CardDefaults.outlinedCardBorder().copy(
                  brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.outline, MaterialTheme.colorScheme.outline))
                )
              ) {
                Column(modifier = Modifier.padding(14.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(quest.title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                      Text("+${quest.rewardXit} XIT", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                    }
                  }

                  Text(
                    text = quest.description,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
                  )

                  LinearProgressIndicator(
                    progress = { (quest.currentCount.toFloat() / quest.targetCount.toFloat()).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                  )

                  Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text("${quest.currentCount}/${quest.targetCount} ${s.completedSuffix}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    Button(
                      onClick = { viewModel.claimQuestReward(quest.id) },
                      enabled = quest.currentCount >= quest.targetCount && !quest.isClaimed,
                      shape = RoundedCornerShape(8.dp),
                      contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                      Text(if (quest.isClaimed) s.claimedBtn else s.claimRewardBtn, fontSize = 12.sp)
                    }
                  }
                }
              }
            }
          }
        }
        2 -> {
          LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
          ) {
            item {
              Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                border = CardDefaults.outlinedCardBorder().copy(
                  brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.secondary))
                )
              ) {
                Column(modifier = Modifier.padding(14.dp)) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.AccountBalanceWallet, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                      text = s.paymentNoticeTitle,
                      fontWeight = FontWeight.Bold,
                      fontSize = 14.sp,
                      color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                  }
                  Text(
                    text = s.paymentTransferInstructions,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(top = 6.dp),
                    lineHeight = 18.sp
                  )
                }
              }
            }

            item {
              SubscriptionCard(
                tierName = "Astrix (Nitro Basic)",
                price = "Rp 35.000 / mo",
                badgeColor = AstrixGold,
                features = listOf(
                  "Exclusive Gold Astrix Badge",
                  "Expanded Media & Upload Limits",
                  "+500 Monthly XIT Bonus",
                  "Custom Chat Bubble Background Access"
                ),
                onSelect = {
                  paymentTier = "ASTRIX"
                  showPaymentDialog = true
                }
              )
            }

            item {
              SubscriptionCard(
                tierName = "Astral (Nitro Supreme)",
                price = "Rp 70.000 / mo",
                badgeColor = AstralViolet,
                features = listOf(
                  "Purple Diamond Astral Badge",
                  "Custom App Theme Gradients & Typography",
                  "Custom Server Invite Codes (Astral Only)",
                  "Full Animated GIF Avatars & Banners",
                  "Custom Soundboard & +1,500 Monthly XIT Bonus",
                  "Exclusive Frames & Astral Marketplace Items"
                ),
                onSelect = {
                  paymentTier = "ASTRAL"
                  showPaymentDialog = true
                }
              )
            }

            item {
              SubscriptionCard(
                tierName = "7 Server Boosts Pack",
                price = "Rp 120.000 / pack",
                badgeColor = Color(0xFFEC4899),
                features = listOf(
                  "Instant +7 Server Boosts",
                  "Unlocks Server Banners & HD Server Icons",
                  "Official 'Server Booster' Profile Badge",
                  "Upgrade Server Level up to Level 2 or Level 3",
                  "Owner receives Unlimited Free Boosts in Owner Page"
                ),
                onSelect = {
                  paymentTier = "BOOST_7"
                  showPaymentDialog = true
                }
              )
            }
          }
        }
      }
    }

    if (showPaymentDialog) {
      PaymentConfirmationDialog(
        tier = paymentTier,
        viewModel = viewModel,
        onDismiss = { showPaymentDialog = false },
        onSubmit = { senderName, senderAccount, slipUri ->
          viewModel.submitPayment(paymentTier, senderName, senderAccount, slipUri) {
            showPaymentDialog = false
          }
        }
      )
    }

    if (showTransferDialog) {
      var recipientName by remember { mutableStateOf("") }
      var transferAmountText by remember { mutableStateOf("") }

      AlertDialog(
        onDismissRequest = { showTransferDialog = false },
        title = { Text(s.transferXitTitle, fontWeight = FontWeight.Bold) },
        text = {
          Column {
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
              value = recipientName,
              onValueChange = { recipientName = it },
              label = { Text(s.recipientUsernameLabel) },
              modifier = Modifier.fillMaxWidth(),
              singleLine = true
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
              value = transferAmountText,
              onValueChange = { transferAmountText = it },
              label = { Text(s.xitAmountLabel) },
              modifier = Modifier.fillMaxWidth(),
              singleLine = true
            )
          }
        },
        confirmButton = {
          Button(
            onClick = {
              val amt = transferAmountText.toLongOrNull() ?: 0L
              if (amt > 0 && recipientName.isNotBlank()) {
                viewModel.transferXit(recipientName, amt) { showTransferDialog = false }
              }
            }
          ) {
            Text(s.sendXitBtn)
          }
        },
        dismissButton = {
          TextButton(onClick = { showTransferDialog = false }) { Text(s.cancel) }
        }
      )
    }
  }
}

@Composable
private fun MarketItemCard(
  item: MarketplaceItemEntity,
  isOwned: Boolean,
  isEquipped: Boolean,
  onBuy: () -> Unit,
  onToggleEquip: () -> Unit
) {
  val s = LocalStrings.current
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)),
    border = CardDefaults.outlinedCardBorder().copy(
      brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.outline, MaterialTheme.colorScheme.outline))
    )
  ) {
    Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
      Box(
        modifier = Modifier
          .size(48.dp)
          .clip(RoundedCornerShape(10.dp))
          .background(Color(item.previewColor).copy(alpha = 0.2f))
          .border(2.dp, Color(item.previewColor), RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = Color(item.previewColor), modifier = Modifier.size(24.dp))
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(item.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
          if (item.isAstralOnly) {
            Spacer(modifier = Modifier.width(5.dp))
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(AstralViolet)
                .padding(horizontal = 5.dp, vertical = 1.dp)
            ) {
              Text("ASTRAL", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
        Text(item.description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        Text("${item.priceXit} XIT", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
      }

      if (isOwned) {
        FilledTonalButton(
          onClick = onToggleEquip,
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.filledTonalButtonColors(
            containerColor = if (isEquipped) RoseError.copy(alpha = 0.16f) else MaterialTheme.colorScheme.primaryContainer
          )
        ) {
          Text(
            text = if (isEquipped) s.unequipBtn else s.equipBtn,
            fontSize = 11.sp,
            color = if (isEquipped) RoseError else MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold
          )
        }
      } else {
        Button(
          onClick = onBuy,
          shape = RoundedCornerShape(8.dp),
          contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
        ) {
          Text(s.buyBtn, fontSize = 12.sp)
        }
      }
    }
  }
}

@Composable
private fun SubscriptionCard(
  tierName: String,
  price: String,
  badgeColor: Color,
  features: List<String>,
  onSelect: () -> Unit
) {
  val s = LocalStrings.current
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)),
    border = CardDefaults.outlinedCardBorder().copy(
      brush = Brush.linearGradient(listOf(badgeColor.copy(alpha = 0.7f), MaterialTheme.colorScheme.outline))
    )
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(tierName, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = MaterialTheme.colorScheme.onSurface)
          Text(price, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = badgeColor)
        }
        Box(
          modifier = Modifier.size(36.dp).clip(CircleShape).background(badgeColor.copy(alpha = 0.18f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Filled.Diamond, contentDescription = null, tint = badgeColor, modifier = Modifier.size(20.dp))
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      features.forEach { feat ->
        Row(modifier = Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = badgeColor, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(feat, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      Button(
        onClick = onSelect,
        modifier = Modifier.fillMaxWidth().height(44.dp),
        shape = RoundedCornerShape(8.dp),
        colors = ButtonDefaults.buttonColors(containerColor = badgeColor)
      ) {
        Text(s.subscribeNowBtn, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
      }
    }
  }
}

@Composable
private fun PaymentConfirmationDialog(
  tier: String,
  viewModel: XChatViewModel,
  onDismiss: () -> Unit,
  onSubmit: (String, String, String?) -> Unit
) {
  val s = LocalStrings.current
  var senderName by remember { mutableStateOf("") }
  var senderAccount by remember { mutableStateOf("") }
  var slipUri by remember { mutableStateOf<String?>(null) }

  val slipPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      viewModel.prepareAndPickMedia(uri, maxDim = 960) { cloudUri ->
        slipUri = cloudUri
      }
    }
  }

  val displayTitle = if (tier == "BOOST_7") "7 Server Boosts" else tier
  val amountDisplay = when (tier) {
    "ASTRAL" -> "Rp 70.000"
    "BOOST_7" -> "Rp 120.000"
    else -> "Rp 35.000"
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("${s.payConfirmTitle} ($displayTitle)", fontWeight = FontWeight.Bold) },
    text = {
      Column {
        Text(
          text = "Destination: 088212365499\nRecipient: XChat Official\nAmount: $amountDisplay",
          fontSize = 12.sp,
          color = MaterialTheme.colorScheme.primary,
          lineHeight = 16.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = senderName,
          onValueChange = { senderName = it },
          label = { Text(s.senderNameLabel) },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = senderAccount,
          onValueChange = { senderAccount = it },
          label = { Text(s.senderBankLabel) },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )
        Spacer(modifier = Modifier.height(12.dp))

        Button(
          onClick = {
            slipPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
          },
          modifier = Modifier.fillMaxWidth(),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          shape = RoundedCornerShape(8.dp)
        ) {
          Icon(
            if (slipUri != null) Icons.Filled.CheckCircle else Icons.Filled.AttachFile,
            contentDescription = null,
            tint = if (slipUri != null) EmeraldSuccess else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            if (slipUri != null) s.proofSelectedBtn else s.pickProofBtn,
            fontSize = 12.sp,
            color = if (slipUri != null) EmeraldSuccess else MaterialTheme.colorScheme.onSurface
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (senderName.isNotBlank() && senderAccount.isNotBlank()) {
            onSubmit(senderName, senderAccount, slipUri)
          }
        }
      ) {
        Text(s.submitConfirmBtn)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text(s.cancel) }
    }
  )
}
