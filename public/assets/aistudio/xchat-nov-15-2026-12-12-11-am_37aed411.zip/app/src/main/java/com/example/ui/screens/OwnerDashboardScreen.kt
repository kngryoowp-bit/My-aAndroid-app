package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserEntity
import com.example.ui.MainTab
import com.example.ui.XChatViewModel
import com.example.ui.components.BadgeCatalog
import com.example.ui.components.BadgeLogo
import com.example.ui.components.BadgesRow
import com.example.ui.components.UserAvatar
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OwnerDashboardScreen(viewModel: XChatViewModel) {
  val allUsers by viewModel.allUsers.collectAsState()
  val paymentRequests by viewModel.paymentRequests.collectAsState()
  val auditLogs by viewModel.auditLogs.collectAsState()
  val allRestrictions by viewModel.allRestrictions.collectAsState()
  val reports by viewModel.reports.collectAsState()
  val redeemCodes by viewModel.redeemCodes.collectAsState()
  val isUnlocked by viewModel.isOwnerDashboardUnlocked.collectAsState()
  val activeLang by viewModel.activeLanguageCode.collectAsState()
  val s = LocalStrings.current

  var selectedTab by remember { mutableIntStateOf(0) }
  var showBroadcastDialog by remember { mutableStateOf(false) }
  var userActionTarget by remember { mutableStateOf<UserEntity?>(null) }
  var badgeManagerTarget by remember { mutableStateOf<UserEntity?>(null) }
  var targetUsernameForBadge by remember { mutableStateOf("") }
  var selectedGrantBadgeId by remember { mutableStateOf(BadgeCatalog.badges.first().id) }

  var keyInput by remember { mutableStateOf("") }
  var showKeyText by remember { mutableStateOf(false) }
  var keyError by remember { mutableStateOf<String?>(null) }

  Scaffold(
    contentWindowInsets = WindowInsets(0.dp),
    topBar = {
      TopAppBar(
        windowInsets = WindowInsets(0.dp),
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              if (isUnlocked) Icons.Filled.Shield else Icons.Filled.Lock,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("Owner Dashboard", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
          }
        },
        navigationIcon = {
          IconButton(onClick = { viewModel.setActiveTab(MainTab.PROFILE) }) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onSurface)
          }
        },
        actions = {
          if (isUnlocked) {
            IconButton(onClick = { showBroadcastDialog = true }) {
              Icon(Icons.Filled.Campaign, contentDescription = "Broadcast", tint = MaterialTheme.colorScheme.primary)
            }
            IconButton(onClick = {
              keyInput = ""
              keyError = null
              viewModel.lockOwnerDashboard()
            }) {
              Icon(Icons.Filled.Lock, contentDescription = "Lock Owner Dashboard", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f))
      )
    },
    containerColor = Color.Transparent
  ) { innerPadding ->
    if (!isUnlocked) {
      val (titleTxt, descTxt, fieldLabel, btnTxt, invalidErr) = when (activeLang.lowercase()) {
        "en" -> listOf(
          "Owner Access Verification",
          "This panel is visible to everyone, but restricted to authorized administrators. Enter the secret Owner Key to continue.",
          "Owner Access Key",
          "Unlock Owner Panel",
          "Invalid Owner Access Key."
        )
        "ms" -> listOf(
          "Pengesahan Akses Pemilik",
          "Panel ini kelihatan kepada semua pengguna, tetapi dilindungi kunci rahsia. Masukkan Kunci Akses Pemilik untuk meneruskan.",
          "Kunci Akses Pemilik",
          "Buka Panel Pemilik",
          "Kunci akses tidak sah."
        )
        "ja" -> listOf(
          "オーナーアクセス認証",
          "このページは全員に表示されますが、管理機能は秘密キーで保護されています。続行するにはオーナーキーを入力してください。",
          "オーナーアクセスキー",
          "パネルをロック解除",
          "アクセスキーが無効です。"
        )
        else -> listOf(
          "Verifikasi Kunci Owner",
          "Halaman ini terlihat oleh semua pengguna, namun terkunci rapat. Masukkan Owner Access Key rahasia untuk mengakses panel admin.",
          "Owner Access Key",
          "Buka Owner Dashboard",
          "Kunci akses Owner tidak valid."
        )
      }

      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
          .padding(24.dp),
        contentAlignment = Alignment.Center
      ) {
        Card(
          modifier = Modifier.fillMaxWidth().widthIn(max = 440.dp),
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.outline))
          )
        ) {
          Column(
            modifier = Modifier.padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Box(
              modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                Icons.Filled.Key,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(30.dp)
              )
            }

            Text(
              text = titleTxt,
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface,
              textAlign = TextAlign.Center
            )

            Text(
              text = descTxt,
              style = MaterialTheme.typography.bodyMedium,
              fontSize = 13.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              textAlign = TextAlign.Center,
              lineHeight = 19.sp
            )

            OutlinedTextField(
              value = keyInput,
              onValueChange = {
                keyInput = it
                keyError = null
              },
              label = { Text(fieldLabel) },
              leadingIcon = { Icon(Icons.Filled.Shield, contentDescription = null) },
              trailingIcon = {
                IconButton(onClick = { showKeyText = !showKeyText }) {
                  Icon(
                    if (showKeyText) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                    contentDescription = null
                  )
                }
              },
              visualTransformation = if (showKeyText) VisualTransformation.None else PasswordVisualTransformation(),
              singleLine = true,
              isError = keyError != null,
              modifier = Modifier.fillMaxWidth().testTag("owner_key_input"),
              shape = RoundedCornerShape(12.dp)
            )

            if (keyError != null) {
              Text(
                text = keyError!!,
                color = RoseError,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.align(Alignment.Start)
              )
            }

            Button(
              onClick = {
                if (viewModel.unlockOwnerDashboard(keyInput)) {
                  keyInput = ""
                  keyError = null
                } else {
                  keyError = invalidErr
                }
              },
              enabled = keyInput.isNotBlank(),
              modifier = Modifier.fillMaxWidth().height(48.dp).testTag("owner_key_unlock_button"),
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
              Icon(Icons.Filled.LockOpen, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(btnTxt, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
      return@Scaffold
    }

    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.86f))
          .horizontalScroll(rememberScrollState())
          .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        listOf(
          0 to tr("Payment Review", "Verifikasi Bayar", "Semak Bayaran", "支払い審査"),
          1 to tr("Users", "Pengguna", "Pengguna", "ユーザー"),
          2 to tr("XChat Lock & Appeals", "Kunci XChat & Banding", "Sekatan XChat & Rayuan", "ロック・異議申し立て"),
          3 to tr("Reports & Redeem", "Laporan & Redeem", "Laporan & Tebus", "通報・コード"),
          4 to tr("Audit Log", "Audit Log", "Log Audit", "監査ログ")
        ).forEach { (idx, lbl) ->
          FilterChip(
            selected = selectedTab == idx,
            onClick = { selectedTab = idx },
            label = { Text(lbl, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
          )
        }
      }

      when (selectedTab) {
        0 -> {
          LazyColumn(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            item {
              Text(
                text = tr("PAYMENT REQUESTS TO 088212365499", "PERMINTAAN PEMBAYARAN TUJUAN 088212365499", "PERMINTAAN PEMBAYARAN KE 088212365499", "088212365499 宛の支払い申請"),
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 1.sp
              )
            }

            if (paymentRequests.isEmpty()) {
              item {
                Text(tr("No pending payment requests.", "Tidak ada antrean pembayaran saat ini.", "Tiada permohonan bayaran buat masa ini.", "現在保留中の支払い申請はありません。"), color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }

            items(paymentRequests, key = { it.id }) { req ->
              Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder().copy(
                  brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.outline, MaterialTheme.colorScheme.outline))
                )
              ) {
                Column(modifier = Modifier.padding(14.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    val itemLabel = if (req.targetTier == "BOOST_7") "7 Server Boosts" else "Tier ${req.targetTier}"
                    Text("@${req.username} • $itemLabel", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(
                          when (req.status) {
                            "APPROVED" -> EmeraldSuccess.copy(alpha = 0.18f)
                            "REJECTED" -> RoseError.copy(alpha = 0.18f)
                            else -> AmberWarning.copy(alpha = 0.18f)
                          }
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                      Text(
                        text = req.status,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = when (req.status) {
                          "APPROVED" -> EmeraldSuccess
                          "REJECTED" -> RoseError
                          else -> AmberWarning
                        }
                      )
                    }
                  }

                  Text(
                    text = tr("Sender", "Pengirim", "Penghantar", "送金者") + ": ${req.senderName} (${req.senderAccount})\n" + tr("Amount", "Jumlah", "Jumlah", "金額") + ": ${req.amountIdr} -> 088212365499",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 6.dp)
                  )

                  if (req.status == "PENDING") {
                    Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.End) {
                      OutlinedButton(
                        onClick = { viewModel.rejectPayment(req) },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                      ) {
                        Text(s.rejectBtn, color = RoseError, fontSize = 12.sp)
                      }
                      Spacer(modifier = Modifier.width(8.dp))
                      Button(
                        onClick = { viewModel.approvePayment(req) },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                      ) {
                        Text(tr("Approve & Activate", "Setujui & Aktifkan", "Luluskan & Aktifkan", "承認して有効化"), fontSize = 12.sp)
                      }
                    }
                  }
                }
              }
            }
          }
        }
        1 -> {
          LazyColumn(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            item {
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = AstralViolet.copy(alpha = 0.16f),
                border = androidx.compose.foundation.BorderStroke(1.dp, AstralViolet.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier.padding(12.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.RocketLaunch, contentDescription = null, tint = AstralViolet, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                      Text(tr("Owner Privilege: Unlimited Server Boost", "Hak Istimewa Owner: Unlimited Server Boost", "Keistimewaan Pemilik: Server Boost Tanpa Had", "オーナー権限: サーバーブースト無制限"), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                      Text(tr("Owner access stays saved automatically with unlimited boosts.", "Akses Owner Page tersimpan otomatis & bisa boost server tanpa batas.", "Akses Halaman Pemilik disimpan automatik dengan boost tanpa had.", "オーナー権限は自動保存され、無制限にブーストできます。"), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                  }
                }
              }
            }

            item {
              Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder().copy(
                  brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.outline))
                )
              ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                  Text(
                    text = tr("GRANT BADGE / ALL BADGES TO @USERNAME", "BERI BADGE / ALL BADGE KE @USERNAME", "BERI LENCANA / SEMUA KE @USERNAME", "@USERNAME へバッジを付与"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 0.8.sp
                  )
                  OutlinedTextField(
                    value = targetUsernameForBadge,
                    onValueChange = { targetUsernameForBadge = it },
                    label = { Text(tr("Username (blank = self)", "Username (kosong = diri sendiri)", "Nama pengguna (kosong = sendiri)", "ユーザー名 (空欄=自分)")) },
                    leadingIcon = { Icon(Icons.Filled.AlternateEmail, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth().testTag("admin_badge_username_input"),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp)
                  )
                  Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                  ) {
                    BadgeCatalog.badges.forEach { b ->
                      val isSel = selectedGrantBadgeId == b.id
                      FilterChip(
                        selected = isSel,
                        onClick = { selectedGrantBadgeId = b.id },
                        leadingIcon = { BadgeLogo(badgeId = b.id, size = 18.dp, showBorder = false) },
                        label = { Text(b.name, fontSize = 11.sp) }
                      )
                    }
                  }
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                  ) {
                    Button(
                      onClick = {
                        if (targetUsernameForBadge.isNotBlank()) {
                          viewModel.grantBadgeByUsername(targetUsernameForBadge, selectedGrantBadgeId)
                        }
                      },
                      enabled = targetUsernameForBadge.isNotBlank(),
                      modifier = Modifier.weight(1f).height(44.dp).testTag("admin_grant_single_badge_btn"),
                      shape = RoundedCornerShape(10.dp)
                    ) {
                      Icon(Icons.Filled.Verified, contentDescription = null, modifier = Modifier.size(16.dp))
                      Spacer(modifier = Modifier.width(6.dp))
                      Text(tr("Give Badge", "Beri Badge", "Beri Lencana", "バッジ付与"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                      onClick = {
                        viewModel.grantAllBadgesByUsername(targetUsernameForBadge.ifBlank { "@self" })
                      },
                      modifier = Modifier.weight(1f).height(44.dp).testTag("admin_grant_all_badges_btn"),
                      colors = ButtonDefaults.buttonColors(containerColor = AstralViolet),
                      shape = RoundedCornerShape(10.dp)
                    ) {
                      Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                      Spacer(modifier = Modifier.width(6.dp))
                      Text(s.allBadgesBtn, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                  }
                  FilledTonalButton(
                    onClick = { viewModel.grantAllBadgesToSelf() },
                    modifier = Modifier.fillMaxWidth().height(40.dp),
                    shape = RoundedCornerShape(10.dp)
                  ) {
                    Icon(Icons.Filled.Verified, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(s.giveAllBadgesMeBtn, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                  }
                }
              }
            }

            items(allUsers, key = { it.id }) { user ->
              Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
              ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                  UserAvatar(avatarUri = user.avatarUri, displayName = user.displayName, size = 38.dp)
                  Spacer(modifier = Modifier.width(10.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Text(user.displayName, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                      if (user.isOwner) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("(Owner)", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                      }
                    }
                    Text(
                      "@${user.username} • ${user.subscriptionTier} • ${if (user.isOwner) "∞" else user.xitBalance} XIT • ${if (user.isOwner) "∞" else user.boostBalance} Boost",
                      fontSize = 11.sp,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (user.equippedBadges.isNotBlank()) {
                      Spacer(modifier = Modifier.height(4.dp))
                      BadgesRow(badgeIdsCsv = user.equippedBadges, badgeSize = 16.dp, spacing = 3.dp, maxCount = 6)
                    }
                  }
                  IconButton(onClick = { userActionTarget = user }) {
                    Icon(Icons.Filled.MoreVert, contentDescription = tr("Actions", "Tindakan", "Tindakan", "操作"), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                }
              }
            }
          }
        }
        2 -> {
          var lockTargetUserId by remember { mutableStateOf(allUsers.firstOrNull { !it.isOwner }?.id ?: "") }
          var lockReason by remember { mutableStateOf("Community rules violation") }
          var lockCustomMsg by remember { mutableStateOf("") }
          var lockMinutes by remember { mutableStateOf("60") }
          LazyColumn(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            item {
              Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f))
              ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                  Text(tr("APPLY XCHAT LOCK SCREEN (IN-APP)", "TERAPKAN KUNCI LAYAR XCHAT (IN-APP)", "KENAKAN SKRIN KUNCI XCHAT", "XCHAT ロック画面を適用"), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = RoseError)
                  Text(tr("Select user:", "Pilih pengguna:", "Pilih pengguna:", "ユーザーを選択:"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    allUsers.filter { !it.isOwner }.forEach { u ->
                      FilterChip(
                        selected = lockTargetUserId == u.id,
                        onClick = { lockTargetUserId = u.id },
                        label = { Text("@${u.username}", fontSize = 11.sp) }
                      )
                    }
                  }
                  OutlinedTextField(value = lockReason, onValueChange = { lockReason = it }, label = { Text(s.lockReasonLabel) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                  OutlinedTextField(value = lockCustomMsg, onValueChange = { lockCustomMsg = it }, label = { Text(s.lockMsgLabel) }, modifier = Modifier.fillMaxWidth())
                  OutlinedTextField(value = lockMinutes, onValueChange = { lockMinutes = it.filter { c -> c.isDigit() } }, label = { Text(s.durationMinutesLabel) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                  Button(
                    onClick = {
                      val mins = (lockMinutes.toLongOrNull() ?: 60L).coerceAtLeast(1L)
                      if (lockTargetUserId.isNotBlank()) {
                        viewModel.applyUserRestriction(lockTargetUserId, lockReason, lockCustomMsg, mins) {
                          lockCustomMsg = ""
                        }
                      }
                    },
                    enabled = lockTargetUserId.isNotBlank() && lockReason.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = RoseError),
                    modifier = Modifier.fillMaxWidth().height(46.dp)
                  ) {
                    Text(tr("Lock User XChat Access", "Kunci Akses XChat Pengguna", "Kunci Akses XChat Pengguna", "ユーザーのXChatアクセスをロック"), fontWeight = FontWeight.Bold)
                  }
                }
              }
            }
            item {
              Text(tr("RESTRICTIONS & APPEALS (${allRestrictions.size})", "RIWAYAT PEMBATASAN & BANDING (${allRestrictions.size})", "SEJARAH SEKATAN & RAYUAN (${allRestrictions.size})", "制限・異議申し立て履歴 (${allRestrictions.size})"), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(allRestrictions, key = { it.id }) { rst ->
              val u = allUsers.find { it.id == rst.userId }
              Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f))
              ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                  val stateTxt = if (rst.isActive) s.activeBadge else tr("ENDED", "SELESAI", "TAMAT", "終了")
                  Text("@${u?.username ?: rst.userId} • ${rst.appealStatus} • $stateTxt", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                  Text("${s.lockReasonLabel}: ${rst.reason}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  if (rst.appealMessage.isNotBlank()) {
                    Text(tr("User appeal", "Banding pengguna", "Rayuan pengguna", "異議内容") + ": \"${rst.appealMessage}\"", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                  }
                  if (rst.isActive) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                      Button(
                        onClick = { viewModel.liftRestriction(rst, approve = true) },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        modifier = Modifier.weight(1f)
                      ) { Text(s.liftOrApproveBtn, fontSize = 12.sp) }
                      OutlinedButton(
                        onClick = { viewModel.liftRestriction(rst, approve = false) },
                        modifier = Modifier.weight(1f)
                      ) { Text(s.rejectBtn, fontSize = 12.sp, color = RoseError) }
                    }
                  }
                }
              }
            }
          }
        }
        3 -> {
          var codeText by remember { mutableStateOf("") }
          var xitAmt by remember { mutableStateOf("500") }
          var boostAmt by remember { mutableStateOf("1") }
          var maxUsesTxt by remember { mutableStateOf("25") }
          LazyColumn(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            item {
              Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f))
              ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                  Text(tr("CREATE NEW REDEEM CODE", "BUAT KODE REDEEM BARU", "CIPTA KOD TEBUS BAHARU", "新しい引き換えコードを作成"), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                  OutlinedTextField(value = codeText, onValueChange = { codeText = it.uppercase() }, label = { Text(s.newRedeemCodeLabel) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                  Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = xitAmt, onValueChange = { xitAmt = it.filter { c -> c.isDigit() } }, label = { Text("XIT") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = boostAmt, onValueChange = { boostAmt = it.filter { c -> c.isDigit() } }, label = { Text("Boost") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = maxUsesTxt, onValueChange = { maxUsesTxt = it.filter { c -> c.isDigit() } }, label = { Text(tr("Max Uses", "Kuota", "Kuota", "上限")) }, singleLine = true, modifier = Modifier.weight(1f))
                  }
                  Button(
                    onClick = {
                      viewModel.createRedeemCode(
                        code = codeText,
                        rewardXit = xitAmt.toLongOrNull() ?: 500L,
                        rewardBoosts = boostAmt.toIntOrNull() ?: 0,
                        maxUses = maxUsesTxt.toIntOrNull() ?: 10
                      ) { codeText = "" }
                    },
                    enabled = codeText.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(44.dp)
                  ) { Text(s.createRedeemBtn, fontWeight = FontWeight.Bold) }
                }
              }
            }
            if (redeemCodes.isNotEmpty()) {
              item {
                Text(tr("REDEEM CODES (${redeemCodes.size})", "DAFTAR KODE REDEEM (${redeemCodes.size})", "SENARAI KOD TEBUS (${redeemCodes.size})", "コード一覧 (${redeemCodes.size})"), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              items(redeemCodes, key = { it.code }) { rc ->
                Card(
                  modifier = Modifier.fillMaxWidth(),
                  shape = RoundedCornerShape(10.dp),
                  colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f))
                ) {
                  Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                      Text(rc.code, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                      Text("+${rc.rewardXit} XIT • +${rc.rewardBoosts} Boost • ${rc.usedCount}/${rc.maxUses}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                  }
                }
              }
            }
            item {
              Text(tr("USER REPORTS QUEUE (${reports.size})", "ANTRIAN LAPORAN PENGGUNA (${reports.size})", "BARISAN LAPORAN PENGGUNA (${reports.size})", "ユーザー通報キュー (${reports.size})"), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(reports, key = { it.id }) { rpt ->
              Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f))
              ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                  Text("${rpt.reason} • [${rpt.status}]", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                  Text(tr("Reporter", "Pelapor", "Pelapor", "通報者") + ": ${rpt.reporterId} • " + tr("Target", "Target", "Sasaran", "対象") + ": ${rpt.targetUserId ?: rpt.targetServerId ?: tr("General", "Umum", "Umum", "一般")}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  if (rpt.details.isNotBlank()) {
                    Text(rpt.details, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                  }
                  if (rpt.status == "OPEN") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                      Button(
                        onClick = { viewModel.resolveReport(rpt, "RESOLVED", "Resolved by Admin") },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        modifier = Modifier.weight(1f)
                      ) { Text(s.resolveDoneBtn, fontSize = 12.sp) }
                      OutlinedButton(
                        onClick = { viewModel.resolveReport(rpt, "DISMISSED", "Dismissed by Admin") },
                        modifier = Modifier.weight(1f)
                      ) { Text(tr("Dismiss", "Abaikan", "Abaikan", "却下"), fontSize = 12.sp) }
                    }
                  }
                }
              }
            }
          }
        }
        4 -> {
          val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault())
          LazyColumn(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            items(auditLogs, key = { it.id }) { log ->
              Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f))
              ) {
                Column(modifier = Modifier.padding(10.dp)) {
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(log.action, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    Text(dateFormat.format(Date(log.timestamp)), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                  Text(log.details, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(top = 2.dp))
                  Text("${tr("Actor", "Aktor", "Pelaku", "実行者")}: @${log.actorUsername}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }
            }
          }
        }
      }
    }

    if (userActionTarget != null) {
      val target = userActionTarget!!
      AlertDialog(
        onDismissRequest = { userActionTarget = null },
        title = { Text("${tr("Actions for", "Tindakan untuk", "Tindakan untuk", "操作対象:")} @${target.username}", fontWeight = FontWeight.Bold) },
        text = {
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            TextButton(
              onClick = { viewModel.grantXit(target.id, 500L); userActionTarget = null },
              modifier = Modifier.fillMaxWidth()
            ) {
              Text("+500 XIT", color = MaterialTheme.colorScheme.primary)
            }

            TextButton(
              onClick = { viewModel.grantBoosts(target.id, 7); userActionTarget = null },
              modifier = Modifier.fillMaxWidth()
            ) {
              Text("+7 Server Boosts", color = Color(0xFFEC4899), fontWeight = FontWeight.Bold)
            }

            TextButton(
              onClick = { viewModel.grantSubscription(target.id, "ASTRAL"); userActionTarget = null },
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(s.giftAstralBtn, color = AstralViolet)
            }

            TextButton(
              onClick = { viewModel.grantSubscription(target.id, "ASTRIX"); userActionTarget = null },
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(s.giftAstrixBtn, color = AstrixGold)
            }

            TextButton(
              onClick = { viewModel.grantSubscription(target.id, "FREE"); userActionTarget = null },
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(s.giftFreeBtn, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline)

            TextButton(
              onClick = {
                badgeManagerTarget = target
                userActionTarget = null
              },
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(tr("Manage / Pick User Badges", "Kelola / Pilih Badge Pengguna", "Urus / Pilih Lencana Pengguna", "ユーザーバッジを管理"), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }

            TextButton(
              onClick = {
                viewModel.grantAllBadgesByUsername(target.username)
                userActionTarget = null
              },
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(s.allBadgesBtn, color = AstralViolet, fontWeight = FontWeight.Bold)
            }

            Text(tr("Assign Admin Role (RBAC Firestore):", "Tetapkan Peran Admin (RBAC Firestore):", "Tetapkan Peranan Admin:", "管理者ロールを設定:"), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              listOf("NONE", "SUPPORT", "MODERATOR", "ADMIN", "SUPER_ADMIN", "OWNER").forEach { roleName ->
                FilterChip(
                  selected = target.adminRole.equals(roleName, ignoreCase = true),
                  onClick = {
                    viewModel.assignAdminRole(target.id, roleName)
                    userActionTarget = null
                  },
                  label = { Text(roleName, fontSize = 10.sp) }
                )
              }
            }

            if (!target.isOwner) {
              TextButton(
                onClick = { viewModel.toggleBan(target.id, !target.isBanned); userActionTarget = null },
                modifier = Modifier.fillMaxWidth()
              ) {
                Text(if (target.isBanned) "Unban User" else "Ban User", color = RoseError)
              }
              TextButton(
                onClick = {
                  viewModel.deleteUserAccount(target.id)
                  userActionTarget = null
                },
                modifier = Modifier.fillMaxWidth()
              ) {
                Text(s.deleteAccountBtn, color = RoseError, fontWeight = FontWeight.Bold)
              }
            }
          }
        },
        confirmButton = {
          TextButton(onClick = { userActionTarget = null }) { Text(s.close) }
        }
      )
    }

    if (badgeManagerTarget != null) {
      val target = badgeManagerTarget!!
      var selectedBadges by remember(target.id) {
        mutableStateOf(
          target.equippedBadges.split(",").map { it.trim() }.filter { it.isNotBlank() }.toSet()
        )
      }
      AlertDialog(
        onDismissRequest = { badgeManagerTarget = null },
        title = { Text("${tr("Manage Badges", "Kelola Badge", "Urus Lencana", "バッジ管理")} @${target.username}", fontWeight = FontWeight.Bold) },
        text = {
          Column(
            modifier = Modifier.fillMaxWidth().heightIn(max = 380.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              FilledTonalButton(
                onClick = { selectedBadges = BadgeCatalog.badges.map { it.id }.toSet() },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(8.dp)
              ) {
                Text(tr("Select All", "Pilih Semua", "Pilih Semua", "すべて選択"), fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }
              OutlinedButton(
                onClick = { selectedBadges = emptySet() },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(8.dp)
              ) {
                Text(tr("Clear All", "Kosongkan", "Kosongkan", "クリア"), fontSize = 11.sp)
              }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline)

            BadgeCatalog.badges.forEach { badge ->
              val checked = selectedBadges.contains(badge.id)
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(8.dp))
                  .clickable {
                    selectedBadges = if (checked) selectedBadges - badge.id else selectedBadges + badge.id
                  }
                  .padding(vertical = 4.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Checkbox(
                  checked = checked,
                  onCheckedChange = { isChk ->
                    selectedBadges = if (isChk) selectedBadges + badge.id else selectedBadges - badge.id
                  }
                )
                BadgeLogo(badgeId = badge.id, size = 24.dp)
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(badge.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                  Text(badge.rarity, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }
            }
          }
        },
        confirmButton = {
          Button(
            onClick = {
              viewModel.updateUserBadges(target.id, selectedBadges.joinToString(","))
              badgeManagerTarget = null
            }
          ) {
            Text(s.save)
          }
        },
        dismissButton = {
          TextButton(onClick = { badgeManagerTarget = null }) { Text(s.cancel) }
        }
      )
    }

    if (showBroadcastDialog) {
      var annTitle by remember { mutableStateOf("") }
      var annBody by remember { mutableStateOf("") }

      AlertDialog(
        onDismissRequest = { showBroadcastDialog = false },
        title = { Text(tr("Broadcast Global Announcement", "Siarkan Pengumuman Global", "Siarkan Pengumuman Global", "全体お知らせを配信"), fontWeight = FontWeight.Bold) },
        text = {
          Column {
            OutlinedTextField(
              value = annTitle,
              onValueChange = { annTitle = it },
              label = { Text(tr("Announcement Title", "Judul Pengumuman", "Tajuk Pengumuman", "お知らせタイトル")) },
              modifier = Modifier.fillMaxWidth(),
              singleLine = true
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
              value = annBody,
              onValueChange = { annBody = it },
              label = { Text(tr("Announcement Message", "Isi Pesan Pengumuman", "Mesej Pengumuman", "お知らせ本文")) },
              modifier = Modifier.fillMaxWidth(),
              maxLines = 4
            )
          }
        },
        confirmButton = {
          Button(
            onClick = {
              if (annTitle.isNotBlank() && annBody.isNotBlank()) {
                viewModel.broadcastAnnouncement(annTitle, annBody) { showBroadcastDialog = false }
              }
            }
          ) {
            Text(tr("Broadcast Now", "Siarkan Sekarang", "Siarkan Sekarang", "今すぐ配信"))
          }
        },
        dismissButton = {
          TextButton(onClick = { showBroadcastDialog = false }) { Text(s.cancel) }
        }
      )
    }
  }
}
