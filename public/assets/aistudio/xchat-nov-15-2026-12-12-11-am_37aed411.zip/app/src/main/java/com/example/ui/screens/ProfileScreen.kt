package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.UserGameAppEntity
import com.example.ui.MainTab
import com.example.ui.XChatViewModel
import com.example.ui.components.AnimatedProfileEffectOverlay
import com.example.ui.components.BadgeCatalog
import com.example.ui.components.BadgeLogo
import com.example.ui.components.BadgesRow
import com.example.ui.components.DisplayNameEffect
import com.example.ui.components.DisplayNameStyleDialog
import com.example.ui.components.OnlineStatusDot
import com.example.ui.components.PickColorBottomSheet
import com.example.ui.components.ProfileEffectCatalog
import com.example.ui.components.StyledDisplayName
import com.example.ui.components.UserAvatar
import com.example.ui.components.isUserOnlineNow
import com.example.ui.components.presenceLabelFor
import com.example.ui.theme.*
import com.example.utils.AppActivityTracker
import com.example.utils.CloudMediaHelper
import kotlinx.coroutines.delay
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

private val PaletteSwatches = listOf(
  0xFFF2F3F5L, 0xFF8B5CF6L, 0xFFC084FCL, 0xFFEC4899L,
  0xFFF43F5EL, 0xFFF97316L, 0xFFFACC15L, 0xFF22C55EL,
  0xFF14B8A6L, 0xFF38BDF8L, 0xFF3B82F6L, 0xFF6366F1L,
  0xFF2B2D31L, 0xFF3B2E5AL, 0xFF1E1F22L, 0xFF0F172AL
)

private fun Color.toHexLongString(): String {
  val argb = this.toArgb().toLong() and 0xFFFFFFFFL
  return "0x" + argb.toString(16).uppercase().padStart(8, '0')
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(viewModel: XChatViewModel) {
  val context = LocalContext.current
  val s = LocalStrings.current
  val currentUser by viewModel.currentUser.collectAsState()
  val visitors by viewModel.profileVisitors.collectAsState()
  val savedThemes by viewModel.savedProfileThemes.collectAsState()
  val myGamesApps by viewModel.myGamesApps.collectAsState()
  val myFollowers by viewModel.myFollowers.collectAsState()
  val myFollowing by viewModel.myFollowing.collectAsState()
  val isUploadingMedia by viewModel.isUploadingMedia.collectAsState()
  val profileSyncError by viewModel.profileSyncError.collectAsState()

  val isAstral = currentUser?.subscriptionTier?.equals("ASTRAL", ignoreCase = true) == true || currentUser?.isOwner == true
  var isEditing by remember { mutableStateOf(false) }
  var saveThemeNameInput by remember { mutableStateOf("") }
  var showAddConnectionDialog by remember { mutableStateOf(false) }
  var showGameAppDialog by remember { mutableStateOf(false) }
  var editingGameApp by remember { mutableStateOf<UserGameAppEntity?>(null) }
  var showAllBadges by remember { mutableStateOf(false) }

  var editDisplayName by remember(currentUser?.id) { mutableStateOf(currentUser?.displayName ?: "") }
  var editBio by remember(currentUser?.id) { mutableStateOf(currentUser?.bio ?: "") }
  var editPronouns by remember(currentUser?.id) { mutableStateOf(currentUser?.pronouns ?: "") }
  var editPresenceStatus by remember(currentUser?.id) { mutableStateOf(currentUser?.presenceStatus ?: "ONLINE") }
  var editStatusTag by remember(currentUser?.id) { mutableStateOf(currentUser?.statusTag ?: "") }
  var editProfileEffect by remember(currentUser?.id) { mutableStateOf(currentUser?.equippedEffect ?: "") }
  var selectedAvatarUri by remember(currentUser?.id) { mutableStateOf(currentUser?.avatarUri) }
  var selectedBannerUri by remember(currentUser?.id) { mutableStateOf(currentUser?.bannerUri) }
  var selectedColor by remember(currentUser?.id) { mutableStateOf(currentUser?.profileColor ?: 0xFF8B5CF6L) }

  // Display Name style (Font + Effect + up to 5 gradient colors)
  var editDisplayFont by remember(currentUser?.id) { mutableStateOf(currentUser?.displayNameFont ?: "SERIF") }
  var editDisplayEffect by remember(currentUser?.id) { mutableStateOf(currentUser?.displayNameEffect ?: "GRADIENT") }
  var editNameColors by remember(currentUser?.id) {
    mutableStateOf(
      ColorHelper.parseColorsCsv(
        currentUser?.displayNameColorsCsv,
        listOf(0xFFF2F3F5L, 0xFFC084FCL)
      ).take(5)
    )
  }
  var activeNameStopIndex by remember { mutableIntStateOf(0) }

  // Profile Background (3 gradient colors)
  var editProfileBgColors by remember(currentUser?.id) {
    val parsed = ColorHelper.parseColorsCsv(
      currentUser?.profileBgColorsCsv,
      listOf(0xFF2B2D31L, 0xFF3B2E5AL, 0xFF1E1F22L)
    )
    val padded = when {
      parsed.size >= 3 -> parsed.take(3)
      parsed.size == 2 -> listOf(parsed[0], parsed[1], parsed[0])
      parsed.size == 1 -> listOf(parsed[0], parsed[0], parsed[0])
      else -> listOf(Color(0xFF2B2D31L), Color(0xFF3B2E5AL), Color(0xFF1E1F22L))
    }
    mutableStateOf(padded)
  }
  var activeBgStopIndex by remember { mutableIntStateOf(0) }

  // Keep local edit buffers immune to presence heartbeats while editing; sync when not editing
  LaunchedEffect(currentUser, isEditing) {
    val u = currentUser
    if (!isEditing && u != null) {
      editDisplayName = u.displayName
      editBio = u.bio
      editPronouns = u.pronouns
      editPresenceStatus = u.presenceStatus
      editStatusTag = u.statusTag
      editProfileEffect = u.equippedEffect ?: ""
      selectedAvatarUri = u.avatarUri
      selectedBannerUri = u.bannerUri
      selectedColor = u.profileColor
      editDisplayFont = u.displayNameFont
      editDisplayEffect = u.displayNameEffect
      editNameColors = ColorHelper.parseColorsCsv(
        u.displayNameColorsCsv,
        listOf(0xFFF2F3F5L, 0xFFC084FCL)
      ).take(5)
      val parsedBg = ColorHelper.parseColorsCsv(
        u.profileBgColorsCsv,
        listOf(0xFF2B2D31L, 0xFF3B2E5AL, 0xFF1E1F22L)
      )
      editProfileBgColors = when {
        parsedBg.size >= 3 -> parsedBg.take(3)
        parsedBg.size == 2 -> listOf(parsedBg[0], parsedBg[1], parsedBg[0])
        parsedBg.size == 1 -> listOf(parsedBg[0], parsedBg[0], parsedBg[0])
        else -> listOf(Color(0xFF2B2D31L), Color(0xFF3B2E5AL), Color(0xFF1E1F22L))
      }
    }
  }

  var showDisplayNameStudio by remember { mutableStateOf(false) }
  var pickerTarget by remember { mutableStateOf<String?>(null) } // "NAME_COLOR", "BG_COLOR", or "WALLPAPER_TINT"

  var wpMode by remember(currentUser?.id) { mutableStateOf(currentUser?.wallpaperMode ?: "MARBLE") }
  var wpUri by remember(currentUser?.id) { mutableStateOf(currentUser?.customWallpaperUri) }
  var wpBlur by remember(currentUser?.id) { mutableFloatStateOf(currentUser?.wallpaperBlur ?: 0f) }
  var wpOpacity by remember(currentUser?.id) { mutableFloatStateOf(currentUser?.wallpaperOpacity ?: 0.85f) }
  var wpBrightness by remember(currentUser?.id) { mutableFloatStateOf(currentUser?.wallpaperBrightness ?: 0.9f) }
  var wpTintHex by remember(currentUser?.id) { mutableLongStateOf(currentUser?.wallpaperTintHex ?: 0xFF07080BL) }

  val wallpaperMediaLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      val mime = context.contentResolver.getType(uri).orEmpty()
      if (mime.startsWith("video/")) {
        wpUri = uri.toString()
        wpMode = "VIDEO"
        viewModel.updateCustomWallpaper(
          mode = "VIDEO",
          uri = uri.toString(),
          gradientCsv = currentUser?.wallpaperGradientCsv ?: "",
          blur = wpBlur,
          opacity = wpOpacity,
          brightness = wpBrightness,
          tintHex = wpTintHex
        )
      } else {
        viewModel.prepareAndPickMedia(uri, maxDim = 1280, allowGifFree = true) { cloudUri ->
          val nextMode = if (mime.contains("gif", ignoreCase = true) || cloudUri.lowercase().contains(".gif")) "GIF" else "IMAGE"
          wpUri = cloudUri
          wpMode = nextMode
          viewModel.updateCustomWallpaper(
            mode = nextMode,
            uri = cloudUri,
            gradientCsv = currentUser?.wallpaperGradientCsv ?: "",
            blur = wpBlur,
            opacity = wpOpacity,
            brightness = wpBrightness,
            tintHex = wpTintHex
          )
        }
      }
    }
  }

  val avatarPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      viewModel.prepareAndPickMedia(uri, maxDim = 512) { cloudUri ->
        selectedAvatarUri = cloudUri
      }
    }
  }

  val bannerPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      if (!isAstral) {
        viewModel.feedbackMessage.value = s.astralRequiredBanner
        return@rememberLauncherForActivityResult
      }
      viewModel.prepareAndPickMedia(uri, maxDim = 960) { cloudUri ->
        selectedBannerUri = cloudUri
      }
    }
  }

  val scrollState = rememberScrollState()

  Scaffold(
    contentWindowInsets = WindowInsets(0.dp),
    topBar = {
      TopAppBar(
        windowInsets = WindowInsets(0.dp),
        title = {
          Text(
            if (isEditing) s.editProfile else s.tabProfile,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
        },
        actions = {
          if (!isEditing) {
            IconButton(
              onClick = { viewModel.setActiveTab(MainTab.SETTINGS) },
              modifier = Modifier.testTag("profile_settings_button")
            ) {
              Icon(Icons.Filled.Settings, contentDescription = s.settings, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            FilledTonalButton(
              onClick = { isEditing = true },
              shape = RoundedCornerShape(8.dp),
              colors = ButtonDefaults.filledTonalButtonColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
              ),
              modifier = Modifier.padding(end = 8.dp).testTag("profile_edit_toggle_button")
            ) {
              Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(s.editProfile, fontSize = 13.sp)
            }
          } else {
            TextButton(onClick = { isEditing = false }) {
              Text(s.cancel, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Button(
              onClick = {
                val nameCsv = editNameColors.take(5).joinToString(",") { it.toHexLongString() }
                val bgCsv = editProfileBgColors.take(3).joinToString(",") { it.toHexLongString() }
                viewModel.updateProfile(
                  displayName = editDisplayName,
                  bio = editBio,
                  pronouns = editPronouns,
                  avatarUri = selectedAvatarUri,
                  bannerUri = if (isAstral) selectedBannerUri else currentUser?.bannerUri,
                  profileColor = selectedColor,
                  bubbleStyle = currentUser?.messageBubbleStyle ?: "comfortable",
                  displayNameFont = editDisplayFont,
                  displayNameColorsCsv = nameCsv,
                  displayNameEffect = editDisplayEffect,
                  profileBgColorsCsv = bgCsv,
                  presenceStatus = editPresenceStatus,
                  statusTag = editStatusTag.trim(),
                  equippedEffect = editProfileEffect.ifBlank { null }
                )
                isEditing = false
              },
              enabled = !isUploadingMedia,
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.padding(end = 8.dp).testTag("profile_save_button")
            ) {
              Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(s.save, fontSize = 13.sp)
            }
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f))
      )
    },
    containerColor = Color.Transparent
  ) { innerPadding ->
    val user = currentUser
    if (user == null) {
      Box(modifier = Modifier.fillMaxSize().padding(innerPadding).padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
          if (profileSyncError == null) {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
          } else {
            Icon(
              Icons.Filled.ErrorOutline,
              contentDescription = null,
              tint = RoseError,
              modifier = Modifier.size(40.dp)
            )
          }
          Text(
            text = profileSyncError ?: tr("Loading account profile...", "Memuat profil akun...", "Memuatkan profil akaun...", "アカウントを読み込み中..."),
            style = MaterialTheme.typography.bodyMedium,
            color = if (profileSyncError != null) RoseError else MaterialTheme.colorScheme.onSurfaceVariant
          )
          FilledTonalButton(onClick = { viewModel.retryBindAuthenticatedUser() }) {
            Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(tr("Re-sync Profile", "Sinkronkan Ulang Profil", "Segerakkan Semula Profil", "プロフィール再同期"))
          }
        }
      }
      return@Scaffold
    }

    val activeBgStops = if (isEditing) editProfileBgColors else ColorHelper.parseColorsCsv(
      user.profileBgColorsCsv,
      listOf(0xFF07080BL, 0xFF111318L, 0xFF1A1D24L)
    )
    val profileBgBrush = if (activeBgStops.size >= 2) {
      Brush.verticalGradient(activeBgStops.take(3).map { it.copy(alpha = 0.42f) })
    } else {
      Brush.verticalGradient(listOf(activeBgStops.first().copy(alpha = 0.42f), activeBgStops.first().copy(alpha = 0.42f)))
    }

    val activeDisplayName = if (isEditing) editDisplayName.ifBlank { user.displayName } else user.displayName
    val activeFontKey = if (isEditing) editDisplayFont else user.displayNameFont
    val activeEffectKey = if (isEditing) editDisplayEffect else user.displayNameEffect
    val activeProfileEffect = if (isEditing) editProfileEffect else (user.equippedEffect ?: "")
    val activePresence = if (isEditing) editPresenceStatus else user.presenceStatus
    val activeStatusTag = if (isEditing) editStatusTag else user.statusTag
    val activeNameCsv = if (isEditing) {
      editNameColors.joinToString(",") { it.toHexLongString() }
    } else {
      user.displayNameColorsCsv
    }
    val activeAvatarUri = if (isEditing) selectedAvatarUri else user.avatarUri
    val activeBannerUri = if (isEditing) selectedBannerUri else user.bannerUri
    val tierDisplay = when (user.subscriptionTier.uppercase()) {
      "VIP", "ASTRAL" -> "ASTRAL"
      "PREM", "ASTRIX" -> "ASTRIX"
      else -> "FREE"
    }

    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .background(profileBgBrush)
        .verticalScroll(scrollState)
    ) {
      if (isUploadingMedia) {
        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
      }

      // Profile Banner + Animated Profile Effect Overlay
      var recoveredBannerFile by remember(activeBannerUri) { mutableStateOf<File?>(null) }
      var isBannerLoading by remember(activeBannerUri) { mutableStateOf(false) }
      var isBannerError by remember(activeBannerUri) { mutableStateOf(false) }
      var attemptedBannerRecovery by remember(activeBannerUri) { mutableStateOf(false) }

      val bannerModel = remember(isAstral, activeBannerUri, recoveredBannerFile) {
        if (isAstral) (recoveredBannerFile ?: CloudMediaHelper.resolveCoilModel(activeBannerUri, context)) else null
      }
      val bannerReq = remember(bannerModel) {
        bannerModel?.let {
          ImageRequest.Builder(context)
            .data(it)
            .allowHardware(false)
            .crossfade(false)
            .build()
        }
      }

      LaunchedEffect(isBannerError, activeBannerUri, isAstral) {
        if (isAstral && isBannerError && !attemptedBannerRecovery && !activeBannerUri.isNullOrBlank() &&
          (activeBannerUri.startsWith("http://") || activeBannerUri.startsWith("https://"))
        ) {
          attemptedBannerRecovery = true
          val res = CloudMediaHelper.ensureLocalCachedFile(context, activeBannerUri, "banner_${user.id.take(6)}.gif")
          val file = res.getOrNull()
          if (file != null && file.exists() && file.length() > 0L) {
            isBannerError = false
            recoveredBannerFile = file
          }
        }
      }

      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(172.dp)
          .background(
            Brush.linearGradient(
              listOf(Color(selectedColor), MaterialTheme.colorScheme.surfaceVariant)
            )
          )
      ) {
        if (bannerReq != null && !isBannerError) {
          AsyncImage(
            model = bannerReq,
            contentDescription = tr("Profile Banner", "Banner Profil", "Sepanduk Profil", "プロフィールバナー"),
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            onLoading = { isBannerLoading = true },
            onSuccess = {
              isBannerLoading = false
              isBannerError = false
            },
            onError = {
              isBannerLoading = false
              isBannerError = true
            }
          )
        }

        if (isBannerLoading || isUploadingMedia) {
          Box(
            modifier = Modifier
              .align(Alignment.Center)
              .clip(RoundedCornerShape(20.dp))
              .background(Color.Black.copy(alpha = 0.55f))
              .padding(horizontal = 14.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              CircularProgressIndicator(
                modifier = Modifier.size(16.dp),
                strokeWidth = 2.dp,
                color = Color.White
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = if (isUploadingMedia) tr("Uploading media...", "Mengunggah media...", "Memuat naik media...", "メディアをアップロード中...") else tr("Loading banner...", "Memuat banner...", "Memuatkan sepanduk...", "バナー読み込み中..."),
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
              )
            }
          }
        }

        AnimatedProfileEffectOverlay(
          effectId = activeProfileEffect,
          modifier = Modifier.matchParentSize()
        )

        if (isEditing) {
          Button(
            onClick = {
              if (!isAstral) {
                viewModel.feedbackMessage.value = s.astralRequiredBanner
              } else {
                bannerPickerLauncher.launch(
                  PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
              }
            },
            modifier = Modifier
              .align(Alignment.TopEnd)
              .padding(12.dp)
              .testTag("pick_banner_gallery_button"),
            colors = ButtonDefaults.buttonColors(
              containerColor = if (isAstral) Color.Black.copy(alpha = 0.72f) else AstralViolet.copy(alpha = 0.88f)
            ),
            shape = RoundedCornerShape(8.dp)
          ) {
            Icon(
              if (isAstral) Icons.Filled.AddPhotoAlternate else Icons.Filled.Lock,
              contentDescription = null,
              modifier = Modifier.size(16.dp),
              tint = Color.White
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(s.pickBannerGallery, fontSize = 12.sp, color = Color.White)
          }
        }
      }

      // Avatar & Styled Display Name Header
      Box(
        modifier = Modifier
          .padding(horizontal = 20.dp)
          .offset(y = (-44).dp)
      ) {
        Row(verticalAlignment = Alignment.Bottom) {
          Box {
            UserAvatar(
              avatarUri = activeAvatarUri,
              displayName = activeDisplayName,
              size = 90.dp,
              frameId = user.equippedFrame,
              showStatus = true,
              isOnline = isUserOnlineNow(user),
              presenceStatus = activePresence,
              lastSeenAt = user.lastSeenAt,
              userId = user.id,
              backgroundColor = selectedColor
            )
            if (isEditing) {
              FilledIconButton(
                onClick = {
                  avatarPickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                  )
                },
                modifier = Modifier
                  .align(Alignment.BottomEnd)
                  .size(36.dp)
                  .testTag("pick_avatar_gallery_button"),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = MaterialTheme.colorScheme.primary)
              ) {
                Icon(Icons.Filled.PhotoCamera, contentDescription = s.pickAvatarGallery, tint = Color.White, modifier = Modifier.size(18.dp))
              }
            }
          }

          Spacer(modifier = Modifier.width(14.dp))

          Column(modifier = Modifier.padding(bottom = 6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              StyledDisplayName(
                name = activeDisplayName,
                fontKey = activeFontKey,
                colorsCsv = activeNameCsv,
                effectKey = activeEffectKey,
                fontSize = 21.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f, fill = false)
              )
              if (tierDisplay != "FREE") {
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (tierDisplay == "ASTRAL") AstralViolet else AstrixGold)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                  Text(
                    text = tierDisplay,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                  )
                }
              }
            }
            Text(
              text = "@${user.username} • ${if (isEditing) editPronouns else user.pronouns}",
              fontSize = 13.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  OnlineStatusDot(
                    presenceStatus = activePresence,
                    lastSeenAt = user.lastSeenAt,
                    userId = user.id,
                    size = 8.dp
                  )
                  Spacer(modifier = Modifier.width(5.dp))
                  Text(
                    text = presenceLabelFor(activePresence, isOnlineRecent = true),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                  )
                }
              }
              if (activeStatusTag.isNotBlank()) {
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                  border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                ) {
                  Text(
                    text = activeStatusTag,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                  )
                }
              }
            }
          }
        }
      }

      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp)
          .offset(y = (-24).dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        if (isEditing) {
          // Live Preview Card (includes Profile Effect Overlay + Presence)
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent),
            border = CardDefaults.outlinedCardBorder().copy(
              brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.secondary))
            )
          ) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .background(profileBgBrush)
            ) {
              AnimatedProfileEffectOverlay(
                effectId = editProfileEffect,
                modifier = Modifier.matchParentSize()
              )
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(14.dp)
              ) {
                Text(
                  text = s.livePreviewHeader,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White.copy(alpha = 0.8f),
                  letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                  UserAvatar(
                    avatarUri = activeAvatarUri,
                    displayName = activeDisplayName,
                    size = 56.dp,
                    frameId = user.equippedFrame,
                    showStatus = true,
                    presenceStatus = editPresenceStatus,
                    lastSeenAt = System.currentTimeMillis(),
                    userId = user.id,
                    backgroundColor = selectedColor
                  )
                  Spacer(modifier = Modifier.width(12.dp))
                  Column {
                    StyledDisplayName(
                      name = activeDisplayName,
                      fontKey = editDisplayFont,
                      colorsCsv = activeNameCsv,
                      effectKey = editDisplayEffect,
                      fontSize = 18.sp,
                      fontWeight = FontWeight.Bold
                    )
                    Text(
                      text = "@${user.username} • ${editPronouns.ifBlank { user.pronouns }}",
                      fontSize = 12.sp,
                      color = Color.White.copy(alpha = 0.78f)
                    )
                    if (editStatusTag.isNotBlank()) {
                      Text(
                        text = editStatusTag,
                        fontSize = 11.sp,
                        color = PurpleLight,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 2.dp)
                      )
                    }
                  }
                }
              }
            }
          }

          // Gallery Pickers (Banner & GIF gated strictly to Astral / Owner)
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Text(
                text = if (isAstral) tr("Gallery Media (Photos & Animated GIFs Active)", "Media Galeri (Foto & GIF Animasi Aktif)", "Media Galeri (Foto & GIF Animasi Aktif)", "ギャラリーメディア (写真・GIFアニメ有効)") else tr("Gallery Media (Static Photos • GIF & Banner require Astral)", "Media Galeri (Foto Statis • GIF & Banner Khusus Astral)", "Media Galeri (Foto Statik • GIF & Sepanduk Khas Astral)", "ギャラリーメディア (静止画 • GIF/バナーはAstral限定)"),
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface
              )
              Spacer(modifier = Modifier.height(10.dp))
              Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                  onClick = {
                    avatarPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                  },
                  enabled = !isUploadingMedia,
                  modifier = Modifier.weight(1f).height(48.dp).testTag("gallery_avatar_btn"),
                  colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                  shape = RoundedCornerShape(10.dp)
                ) {
                  Icon(Icons.Filled.AccountCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(s.pickAvatarGallery, fontSize = 12.sp)
                }
                Button(
                  onClick = {
                    if (!isAstral) {
                      viewModel.feedbackMessage.value = s.astralRequiredBanner
                    } else {
                      bannerPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                  },
                  enabled = !isUploadingMedia,
                  modifier = Modifier.weight(1f).height(48.dp).testTag("gallery_banner_btn"),
                  colors = ButtonDefaults.buttonColors(
                    containerColor = if (isAstral) AstralViolet else MaterialTheme.colorScheme.surfaceVariant
                  ),
                  shape = RoundedCornerShape(10.dp)
                ) {
                  Icon(
                    if (isAstral) Icons.Filled.Image else Icons.Filled.Lock,
                    contentDescription = null,
                    tint = if (isAstral) Color.White else AstralViolet,
                    modifier = Modifier.size(16.dp)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    s.pickBannerGallery,
                    fontSize = 12.sp,
                    color = if (isAstral) Color.White else AstralViolet
                  )
                }
              }
              if (isUploadingMedia) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  CircularProgressIndicator(
                    modifier = Modifier.size(14.dp),
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.primary
                  )
                  Text(
                    text = tr("Uploading image / GIF to cloud...", "Mengunggah gambar / GIF ke cloud...", "Memuat naik imej / GIF ke awan...", "クラウドへアップロード中..."),
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Medium
                  )
                }
              }
            }
          }

          // Identity Card (Display Name, Pronouns, Bio)
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Badge, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(tr("Identity & Bio", "Identitas & Biodata", "Identiti & Biodata", "プロフィール情報"), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
              }

              OutlinedTextField(
                value = editDisplayName,
                onValueChange = { editDisplayName = it },
                label = { Text(s.displayNameLabel) },
                modifier = Modifier.fillMaxWidth().testTag("edit_display_name_input"),
                shape = RoundedCornerShape(10.dp),
                singleLine = true
              )

              OutlinedTextField(
                value = editPronouns,
                onValueChange = { editPronouns = it },
                label = { Text(s.pronounsLabel) },
                modifier = Modifier.fillMaxWidth().testTag("edit_pronouns_input"),
                shape = RoundedCornerShape(10.dp),
                singleLine = true
              )

              OutlinedTextField(
                value = editBio,
                onValueChange = { editBio = it },
                label = { Text(s.bioLabel) },
                modifier = Modifier.fillMaxWidth().testTag("edit_bio_input"),
                shape = RoundedCornerShape(10.dp),
                maxLines = 4
              )
            }
          }

          // Presence Status & Custom Status Tag Card
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Circle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(tr("Presence & Status Tag", "Status Kehadiran & Status Tag", "Status Kehadiran & Tag Status", "プレゼンス＆ステータスタグ"), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
              }

              val presenceChoices = listOf(
                "ONLINE" to "Online",
                "IDLE" to "Idle",
                "DND" to "Do Not Disturb",
                "OFFLINE" to "Offline / Invisible"
              )
              Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                presenceChoices.forEach { (code, label) ->
                  FilterChip(
                    selected = editPresenceStatus.equals(code, ignoreCase = true),
                    onClick = { editPresenceStatus = code },
                    leadingIcon = {
                      OnlineStatusDot(presenceStatus = code, size = 10.dp)
                    },
                    label = { Text(label, fontSize = 11.sp) }
                  )
                }
              }

              OutlinedTextField(
                value = editStatusTag,
                onValueChange = { editStatusTag = it.take(40) },
                label = { Text(tr("Custom Status Tag (e.g. Pushing rank)", "Status Tag Kustom (cth: Lagi push rank 🎮)", "Tag Status Tersuai (cth: Tengah main 🎮)", "カスタムステータス (例: ランク戦中)")) },
                leadingIcon = { Icon(Icons.Filled.Mood, contentDescription = null) },
                trailingIcon = {
                  if (editStatusTag.isNotEmpty()) {
                    IconButton(onClick = { editStatusTag = "" }) {
                      Icon(Icons.Filled.Clear, contentDescription = tr("Clear", "Bersihkan", "Kosongkan", "クリア"))
                    }
                  }
                },
                modifier = Modifier.fillMaxWidth().testTag("edit_status_tag_input"),
                singleLine = true,
                shape = RoundedCornerShape(10.dp)
              )
            }
          }

          // Profile Effects Card
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = AstralViolet, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(tr("Profile Effects", "Profile Effects (Efek Kartu Profil)", "Kesan Profil", "プロフィールエフェクト"), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
              }

              Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                ProfileEffectCatalog.options.forEach { opt ->
                  val isSel = editProfileEffect.equals(opt.id, ignoreCase = true)
                  FilterChip(
                    selected = isSel,
                    onClick = { editProfileEffect = opt.id },
                    leadingIcon = {
                      Icon(
                        if (opt.id.isBlank()) Icons.Filled.Block else Icons.Filled.AutoAwesome,
                        contentDescription = null,
                        modifier = Modifier.size(15.dp)
                      )
                    },
                    label = { Text(opt.label, fontSize = 11.sp) }
                  )
                }
              }
              val activeDesc = ProfileEffectCatalog.options.firstOrNull { it.id == editProfileEffect }?.desc ?: ""
              if (activeDesc.isNotBlank()) {
                Text(activeDesc, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }

          // Change Display Name Style Studio Card + Quick Editor
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = s.displayNameStyle,
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp,
                  color = MaterialTheme.colorScheme.onSurface
                )
              }

              Button(
                onClick = { showDisplayNameStudio = true },
                modifier = Modifier.fillMaxWidth().height(46.dp).testTag("open_display_name_studio_btn"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
              ) {
                Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(tr("Open Display Name Style Studio", "Buka Display Name Style Studio", "Buka Studio Gaya Nama", "表示名スタイルスタジオを開く"), fontWeight = FontWeight.Bold, fontSize = 13.sp)
              }

              Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                AppFontOption.entries.forEach { fontOpt ->
                  val isSel = editDisplayFont.equals(fontOpt.key, ignoreCase = true)
                  FilterChip(
                    selected = isSel,
                    onClick = { editDisplayFont = fontOpt.key },
                    label = { Text(fontOpt.label, fontFamily = fontOpt.fontFamily, fontSize = 12.sp) }
                  )
                }
              }

              Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                DisplayNameEffect.entries.forEach { eff ->
                  FilterChip(
                    selected = editDisplayEffect.equals(eff.key, ignoreCase = true),
                    onClick = { editDisplayEffect = eff.key },
                    label = { Text(eff.label, fontSize = 11.sp) }
                  )
                }
              }

              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                editNameColors.forEachIndexed { idx, col ->
                  Box(
                    modifier = Modifier
                      .size(34.dp)
                      .clip(CircleShape)
                      .background(col)
                      .border(
                        width = if (activeNameStopIndex == idx) 3.dp else 1.dp,
                        color = if (activeNameStopIndex == idx) Color.White else MaterialTheme.colorScheme.outline,
                        shape = CircleShape
                      )
                      .clickable {
                        activeNameStopIndex = idx
                        pickerTarget = "NAME_COLOR"
                      },
                    contentAlignment = Alignment.Center
                  ) {
                    Text("${idx + 1}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black.copy(alpha = 0.65f))
                  }
                }
                if (editNameColors.size < 5) {
                  FilledIconButton(
                    onClick = {
                      editNameColors = editNameColors + Color(0xFF38BDF8)
                      activeNameStopIndex = editNameColors.lastIndex
                      pickerTarget = "NAME_COLOR"
                    },
                    modifier = Modifier.size(34.dp)
                  ) {
                    Icon(Icons.Filled.Add, contentDescription = "Add", modifier = Modifier.size(16.dp))
                  }
                }
                if (editNameColors.size > 1) {
                  OutlinedIconButton(
                    onClick = {
                      val rmIdx = activeNameStopIndex.coerceIn(0, editNameColors.lastIndex)
                      editNameColors = editNameColors.toMutableList().apply { removeAt(rmIdx) }
                      activeNameStopIndex = activeNameStopIndex.coerceIn(0, editNameColors.lastIndex)
                    },
                    modifier = Modifier.size(34.dp)
                  ) {
                    Icon(Icons.Filled.Remove, contentDescription = "Remove", modifier = Modifier.size(16.dp))
                  }
                }
                Spacer(modifier = Modifier.weight(1f))
                FilledTonalButton(
                  onClick = { pickerTarget = "NAME_COLOR" },
                  contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                  modifier = Modifier.height(34.dp)
                ) {
                  Icon(Icons.Filled.Palette, contentDescription = null, modifier = Modifier.size(14.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(tr("All Colors", "Semua Warna", "Semua Warna", "すべての色"), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
              }

              ColorSwatchGrid(
                selectedColor = editNameColors.getOrElse(activeNameStopIndex) { Color.White },
                onSelectColor = { chosen ->
                  val idx = activeNameStopIndex.coerceIn(0, editNameColors.lastIndex)
                  editNameColors = editNameColors.toMutableList().apply { set(idx, chosen) }
                }
              )
            }
          }

          // Profile Background 3-Color Gradient Editor with Full Spectrum Color Picker
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = s.profileBgGradient,
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp,
                  color = MaterialTheme.colorScheme.onSurface
                )
                FilledTonalButton(
                  onClick = { pickerTarget = "BG_COLOR" },
                  contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                  modifier = Modifier.height(32.dp)
                ) {
                  Icon(Icons.Filled.ColorLens, contentDescription = null, modifier = Modifier.size(14.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Pick a Color", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
              }

              val bgPresets = listOf(
                "Obsidian Marble" to listOf(Color(0xFF07080B), Color(0xFF111318), Color(0xFF1A1D24)),
                "Silver Slate" to listOf(Color(0xFF101319), Color(0xFF1E2430), Color(0xFF0A0C10)),
                "Ocean Cyber" to listOf(Color(0xFF0C4A6E), Color(0xFF312E81), Color(0xFF0F172A)),
                "Emerald Night" to listOf(Color(0xFF064E3B), Color(0xFF134E4A), Color(0xFF111827))
              )
              Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                bgPresets.forEach { (label, cols) ->
                  AssistChip(
                    onClick = { editProfileBgColors = cols },
                    label = { Text(label, fontSize = 11.sp) }
                  )
                }
              }

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                editProfileBgColors.forEachIndexed { idx, col ->
                  val isSel = activeBgStopIndex == idx
                  Surface(
                    onClick = {
                      activeBgStopIndex = idx
                      pickerTarget = "BG_COLOR"
                    },
                    shape = RoundedCornerShape(10.dp),
                    color = col,
                    border = androidx.compose.foundation.BorderStroke(
                      if (isSel) 2.5.dp else 1.dp,
                      if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                    ),
                    modifier = Modifier.weight(1f).height(52.dp)
                  ) {
                    Column(
                      modifier = Modifier.fillMaxSize(),
                      verticalArrangement = Arrangement.Center,
                      horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                      Text(
                        "${tr("Color", "Warna", "Warna", "色")} ${idx + 1}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                      )
                      Text(
                        ColorHelper.toHex6(col),
                        fontSize = 9.sp,
                        color = Color.White.copy(alpha = 0.85f)
                      )
                    }
                  }
                }
              }

              ColorSwatchGrid(
                selectedColor = editProfileBgColors.getOrElse(activeBgStopIndex) { Color(0xFF2B2D31) },
                onSelectColor = { chosen ->
                  val idx = activeBgStopIndex.coerceIn(0, 2)
                  editProfileBgColors = editProfileBgColors.toMutableList().apply { set(idx, chosen) }
                }
              )
            }
          }
        } else {
          // Level / XP Progress, Joined Date & Followers/Following Card
          val xpPerLevel = 200L
          val xpFraction = ((user.xp % xpPerLevel).toFloat() / xpPerLevel.toFloat()).coerceIn(0f, 1f)
          val joinedDate = remember(user.createdAt) {
            SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(user.createdAt))
          }
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f)),
            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.outline, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))))
          ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Level ${user.level}", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.primary)
                Text("${user.xp % xpPerLevel} / $xpPerLevel XP", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              LinearProgressIndicator(
                progress = { xpFraction },
                modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(4.dp))
              )
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${s.followersLabel}: ${maxOf(user.followersCount, myFollowers.size)}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                Text("${s.followingLabel}: ${maxOf(user.followingCount, myFollowing.size)}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                Text("${tr("Joined", "Bergabung", "Menyertai", "参加日")} $joinedDate", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }

          // Display Profile Mode with Quick Presence Switcher
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f)),
            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.outline, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))))
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text(
                text = tr("QUICK PRESENCE STATUS", "STATUS KEHADIRAN CEPAT", "STATUS KEHADIRAN PANTAS", "クイックステータス"),
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 1.sp
              )
              Spacer(modifier = Modifier.height(6.dp))
              Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                listOf("ONLINE" to "Online", "IDLE" to "Idle", "DND" to "DND", "OFFLINE" to "Offline").forEach { (code, label) ->
                  FilterChip(
                    selected = user.presenceStatus.equals(code, ignoreCase = true),
                    onClick = { viewModel.updatePresence(code, user.statusTag) },
                    leadingIcon = { OnlineStatusDot(presenceStatus = code, size = 9.dp) },
                    label = { Text(label, fontSize = 11.sp) }
                  )
                }
              }

              Spacer(modifier = Modifier.height(12.dp))
              HorizontalDivider(color = MaterialTheme.colorScheme.outline)
              Spacer(modifier = Modifier.height(12.dp))

              Text(
                text = s.aboutMeHeader,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 1.sp
              )
              Text(
                text = user.bio,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface,
                lineHeight = 22.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
              )

              HorizontalDivider(color = MaterialTheme.colorScheme.outline)
              Spacer(modifier = Modifier.height(12.dp))

              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "${s.officialBadgesHeader} (${user.equippedBadges.split(",").count { it.isNotBlank() }}/${BadgeCatalog.badges.size})",
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  letterSpacing = 1.sp
                )
                TextButton(onClick = { showAllBadges = !showAllBadges }) {
                  Text(if (showAllBadges) s.closeCollection else s.viewAllBadges, fontSize = 11.sp)
                }
              }
              Spacer(modifier = Modifier.height(6.dp))
              BadgesRow(badgeIdsCsv = user.equippedBadges, badgeSize = 28.dp, spacing = 8.dp, wrap = true)

              if (showAllBadges) {
                Spacer(modifier = Modifier.height(10.dp))
                val unlockedIds = remember(user.equippedBadges) {
                  user.equippedBadges.split(",").map { it.trim() }.filter { it.isNotBlank() }.toSet()
                }
                val progressMap = remember(user.unlockedBadgesProgressJson) {
                  BadgeCatalog.parseProgressMap(user.unlockedBadgesProgressJson)
                }
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                  BadgeCatalog.badges.forEach { badge ->
                    val unlocked = badge.id in unlockedIds
                    val curProg = if (unlocked) badge.targetProgress else (progressMap[badge.progressKey] ?: 0)
                    Row(
                      modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = if (unlocked) 0.72f else 0.42f))
                        .padding(8.dp),
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      BadgeLogo(badgeId = badge.id, size = 30.dp)
                      Spacer(modifier = Modifier.width(10.dp))
                      Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                          Text(badge.name, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                          Text(badge.rarity, fontSize = 10.sp, color = if (unlocked) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(badge.unlockCondition, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (badge.targetProgress > 1) {
                          LinearProgressIndicator(
                            progress = { (curProg.toFloat() / badge.targetProgress.toFloat()).coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp).height(4.dp).clip(RoundedCornerShape(2.dp))
                          )
                        }
                      }
                      Icon(
                        if (unlocked) Icons.Filled.CheckCircle else Icons.Filled.Lock,
                        contentDescription = null,
                        tint = if (unlocked) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                      )
                    }
                  }
                }
              }

              Spacer(modifier = Modifier.height(16.dp))
              HorizontalDivider(color = MaterialTheme.colorScheme.outline)
              Spacer(modifier = Modifier.height(12.dp))

              Text(
                text = s.xitBalanceHeader,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 1.sp
              )
              Row(modifier = Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Paid, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = if (user.isOwner) "∞ XIT (Owner)" else "${user.xitBalance} XIT",
                  fontWeight = FontWeight.Bold,
                  fontSize = 18.sp,
                  color = MaterialTheme.colorScheme.primary
                )
              }
            }
          }

          // Wallpaper & Latar Kustom Studio (terpisah dari tema UI)
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f)),
            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.outline, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))))
          ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Text(s.customWallpaperTitle, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.sp)
              Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                  "MARBLE" to s.movingMarbleFree,
                  "GRADIENT" to tr("Gradient", "Gradasi", "Gradien", "グラデ"),
                  "IMAGE" to tr("Photo", "Foto", "Foto", "写真"),
                  "GIF" to "GIF",
                  "VIDEO" to "Video"
                ).forEach { (mode, lbl) ->
                  FilterChip(
                    selected = wpMode.equals(mode, ignoreCase = true),
                    onClick = {
                      wpMode = mode
                      if (mode == "MARBLE" || mode == "GRADIENT") {
                        viewModel.updateCustomWallpaper(
                          mode = mode,
                          uri = wpUri,
                          gradientCsv = user.wallpaperGradientCsv,
                          blur = wpBlur,
                          opacity = wpOpacity,
                          brightness = wpBrightness,
                          tintHex = wpTintHex
                        )
                      }
                    },
                    label = { Text(lbl, fontSize = 11.sp) }
                  )
                }
              }
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                  onClick = {
                    wallpaperMediaLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                  },
                  modifier = Modifier.weight(1f).height(44.dp)
                ) {
                  Icon(Icons.Filled.Wallpaper, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(tr("Pick Photo/GIF/Video", "Pilih Foto/GIF/Video", "Pilih Foto/GIF/Video", "写真/GIF/動画を選択"), fontSize = 12.sp)
                }
                OutlinedButton(
                  onClick = { pickerTarget = "WALLPAPER_TINT" },
                  modifier = Modifier.height(44.dp)
                ) {
                  Text(tr("Color Tint", "Tint Warna", "Warna Tint", "色合い"), fontSize = 12.sp)
                }
              }
              Text("Blur (${wpBlur.toInt()}dp) • Opacity (${(wpOpacity * 100).toInt()}%) • ${tr("Brightness", "Kecerahan", "Kecerahan", "明るさ")} (${(wpBrightness * 100).toInt()}%)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Slider(value = wpBlur, onValueChange = { wpBlur = it }, valueRange = 0f..24f)
              Slider(value = wpOpacity, onValueChange = { wpOpacity = it }, valueRange = 0.2f..1f)
              Slider(value = wpBrightness, onValueChange = { wpBrightness = it }, valueRange = 0.25f..1f)
              Button(
                onClick = {
                  viewModel.updateCustomWallpaper(
                    mode = wpMode,
                    uri = wpUri,
                    gradientCsv = user.wallpaperGradientCsv,
                    blur = wpBlur,
                    opacity = wpOpacity,
                    brightness = wpBrightness,
                    tintHex = wpTintHex
                  )
                },
                modifier = Modifier.fillMaxWidth().height(44.dp)
              ) {
                Text(tr("Apply Wallpaper Settings", "Terapkan Pengaturan Wallpaper", "Gunakan Tetapan Kertas Dinding", "壁紙設定を適用"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
              }
            }
          }

          // My Games & Apps CRUD + Reorder Card
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f)),
            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.outline, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))))
          ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("${s.myGamesAppsHeader} (${myGamesApps.size})", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.sp)
                FilledTonalButton(
                  onClick = { editingGameApp = null; showGameAppDialog = true },
                  contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                  modifier = Modifier.height(32.dp)
                ) {
                  Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(tr("Add", "Tambah", "Tambah", "追加"), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
              }
              if (myGamesApps.isEmpty()) {
                Text(tr("Add favorite games or apps to showcase on your Home & public profile.", "Tambahkan game atau aplikasi favorit untuk dipamerkan di halaman Home & Profil publik.", "Tambahkan permainan atau aplikasi kegemaran untuk dipamerkan di Laman Utama & Profil awam.", "お気に入りのゲームやアプリを追加してホームやプロフィールに表示します。"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              } else {
                myGamesApps.forEachIndexed { idx, app ->
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .clip(RoundedCornerShape(10.dp))
                      .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
                      .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Icon(Icons.Filled.SportsEsports, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                      Text("${app.name} (${app.category})", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                      if (app.activityStatus.isNotBlank() || app.description.isNotBlank()) {
                        Text(app.activityStatus.ifBlank { app.description }, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                      }
                    }
                    if (idx > 0) {
                      IconButton(onClick = { viewModel.swapGameAppOrder(app, myGamesApps[idx - 1]) }, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Filled.ArrowUpward, contentDescription = tr("Move Up", "Naik", "Naik", "上へ"), modifier = Modifier.size(15.dp))
                      }
                    }
                    IconButton(onClick = { editingGameApp = app; showGameAppDialog = true }, modifier = Modifier.size(28.dp)) {
                      Icon(Icons.Filled.Edit, contentDescription = "Edit", modifier = Modifier.size(15.dp))
                    }
                    IconButton(onClick = { viewModel.deleteGameApp(app) }, modifier = Modifier.size(28.dp)) {
                      Icon(Icons.Filled.DeleteOutline, contentDescription = tr("Delete", "Hapus", "Padam", "削除"), tint = RoseError, modifier = Modifier.size(15.dp))
                    }
                  }
                }
              }
            }
          }

          // Live Activity Card (Game / App Elapsed Timer)
          val hasUsagePermission = AppActivityTracker.hasUsageAccess(context)
          val activeApp = user.activeAppName
          val startedAt = user.activeAppStartedAt
          if (!activeApp.isNullOrBlank() && startedAt > 0L) {
            var nowMs by remember(startedAt) { mutableLongStateOf(System.currentTimeMillis()) }
            LaunchedEffect(startedAt) {
              while (true) {
                nowMs = System.currentTimeMillis()
                delay(1000L)
              }
            }
            val elapsedSec = ((nowMs - startedAt).coerceAtLeast(0L) / 1000L)
            val hrs = elapsedSec / 3600L
            val mins = (elapsedSec % 3600L) / 60L
            val secs = elapsedSec % 60L
            val elapsedLabel = if (hrs > 0) String.format(Locale.US, "%d:%02d:%02d", hrs, mins, secs)
            else String.format(Locale.US, "%02d:%02d", mins, secs)

            Card(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f)),
              border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.5f))
            ) {
              Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(EmeraldSuccess.copy(alpha = 0.18f)),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(Icons.Filled.SportsEsports, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(22.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(tr("ACTIVE SESSION", "AKTIVITAS BERJALAN", "AKTIVITI SEMASA", "プレイ中"), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess, letterSpacing = 0.8.sp)
                  Text("${tr("Playing", "Sedang Memainkan", "Sedang Memainkan", "プレイ中:")} $activeApp", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                  Text("${tr("Elapsed", "Waktu berjalan", "Masa berlalu", "経過時間")}: $elapsedLabel", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }
            }
          }

          // Connections Card
          val connections = remember(user.connectionsJson) {
            AppActivityTracker.parseConnections(user.connectionsJson)
          }
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f)),
            border = CardDefaults.outlinedCardBorder().copy(
              brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.outline, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)))
            )
          ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = s.connectionsTitle,
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  letterSpacing = 1.sp
                )
                FilledTonalButton(
                  onClick = { showAddConnectionDialog = true },
                  contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                  modifier = Modifier.height(30.dp).testTag("profile_add_connection_btn"),
                  shape = RoundedCornerShape(8.dp)
                ) {
                  Icon(Icons.Filled.AddLink, contentDescription = null, modifier = Modifier.size(14.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(tr("Add", "Tambah", "Tambah", "追加"), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
              }

              if (!hasUsagePermission) {
                Surface(
                  onClick = { AppActivityTracker.openUsageAccessSettings(context) },
                  shape = RoundedCornerShape(10.dp),
                  color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Visibility, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                      text = tr("Enable Usage Access to display live game/music activity on your profile.", "Aktifkan Akses Penggunaan agar aktivitas game/musik tampil otomatis & live di profil.", "Aktifkan Akses Penggunaan supaya aktiviti permainan/muzik dipaparkan secara langsung.", "使用状況へのアクセスを有効にするとゲーム・音楽の状態を自動表示できます。"),
                      fontSize = 11.sp,
                      color = MaterialTheme.colorScheme.onPrimaryContainer,
                      modifier = Modifier.weight(1f)
                    )
                    Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                  }
                }
              }

              if (connections.isEmpty()) {
                Text(
                  text = tr("No connected game or social accounts yet (GitHub, Roblox, Minecraft, Spotify, etc.).", "Belum ada akun game atau sosial yang terhubung (GitHub, Roblox, Minecraft, Spotify, dll).", "Belum ada akaun permainan atau sosial yang disambungkan (GitHub, Roblox, Minecraft, Spotify, dll).", "連携済みのゲーム・SNSアカウントはありません (GitHub, Roblox, Minecraft, Spotify等)。"),
                  fontSize = 12.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              } else {
                connections.forEach { conn ->
                  val meta = AppActivityTracker.connectionCatalog.find { it.id == conn.platformId }
                  val tint = Color(meta?.colorHex ?: 0xFF8B5CF6L)
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .clip(RoundedCornerShape(10.dp))
                      .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
                      .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Box(
                      modifier = Modifier.size(30.dp).clip(CircleShape).background(tint.copy(alpha = 0.22f)),
                      contentAlignment = Alignment.Center
                    ) {
                      Icon(Icons.Filled.Link, contentDescription = null, tint = tint, modifier = Modifier.size(16.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                      Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(conn.platformName, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                        if (conn.verified) {
                          Spacer(modifier = Modifier.width(4.dp))
                          Icon(Icons.Filled.Verified, contentDescription = "Verified", tint = EmeraldSuccess, modifier = Modifier.size(13.dp))
                        }
                      }
                      Text(
                        text = buildString {
                          append("@${conn.handle}")
                          if (conn.subtitle.isNotBlank()) append(" • ${conn.subtitle}")
                        },
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                      )
                    }
                    IconButton(
                      onClick = { viewModel.removeConnection(conn.platformId) },
                      modifier = Modifier.size(28.dp)
                    ) {
                      Icon(Icons.Filled.Close, contentDescription = tr("Remove Connection", "Hapus Koneksi", "Buang Sambungan", "連携解除"), tint = RoseError, modifier = Modifier.size(16.dp))
                    }
                  }
                }
              }
            }
          }

          // Saved Profile Themes Card (e.g. "Sasuke" — Save / Name / Equip / Unequip / Delete)
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f)),
            border = CardDefaults.outlinedCardBorder().copy(
              brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.outline, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)))
            )
          ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Text(
                text = s.savedThemesTitle,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 1.sp
              )
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                OutlinedTextField(
                  value = saveThemeNameInput,
                  onValueChange = { saveThemeNameInput = it.take(28) },
                  label = { Text(tr("Theme Name (e.g. Sasuke)", "Nama Tema (cth: Sasuke)", "Nama Tema (cth: Sasuke)", "テーマ名 (例: Sasuke)")) },
                  singleLine = true,
                  modifier = Modifier.weight(1f).testTag("save_profile_theme_name_input"),
                  shape = RoundedCornerShape(10.dp)
                )
                Button(
                  onClick = {
                    val trimmed = saveThemeNameInput.trim()
                    if (trimmed.isNotBlank()) {
                      viewModel.saveCurrentProfileTheme(trimmed) {
                        saveThemeNameInput = ""
                      }
                    }
                  },
                  enabled = saveThemeNameInput.isNotBlank(),
                  modifier = Modifier.height(50.dp).testTag("save_profile_theme_btn"),
                  shape = RoundedCornerShape(10.dp)
                ) {
                  Icon(Icons.Filled.BookmarkAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(s.save, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
              }

              if (savedThemes.isEmpty()) {
                Text(
                  text = tr("Save your current profile style, name font, and colors as a named theme you can equip or unequip anytime.", "Simpan gaya profil, font nama, dan warna saat ini menjadi tema bernama agar bisa dipasang/dilepas kapan saja.", "Simpan gaya profil, fon nama, dan warna semasa sebagai tema supaya boleh dipasang atau ditanggalkan bila-bila masa.", "現在のプロフィールスタイル・フォント・色を保存して、いつでも着脱できます。"),
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              } else {
                savedThemes.forEach { theme ->
                  val previewCols = remember(theme.profileBgColorsCsv) {
                    ColorHelper.parseColorsCsv(theme.profileBgColorsCsv, listOf(0xFF2B2D31L, 0xFF8B5CF6L))
                  }
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .clip(RoundedCornerShape(10.dp))
                      .background(
                        if (theme.isEquipped) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                      )
                      .border(
                        1.dp,
                        if (theme.isEquipped) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                        RoundedCornerShape(10.dp)
                      )
                      .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Box(
                      modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(
                          if (previewCols.size >= 2) Brush.linearGradient(previewCols)
                          else Brush.linearGradient(listOf(previewCols.first(), previewCols.first()))
                        )
                        .border(1.dp, Color.White.copy(alpha = 0.6f), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                      Text(theme.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                      Text(
                        text = if (theme.isEquipped) "${theme.displayNameFont} • ${s.equippedBtn}" else theme.displayNameFont,
                        fontSize = 10.sp,
                        color = if (theme.isEquipped) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                      )
                    }
                    if (theme.isEquipped) {
                      OutlinedButton(
                        onClick = { viewModel.unequipSavedProfileTheme() },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier.height(32.dp)
                      ) {
                        Text(s.unequipBtn, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                      }
                    } else {
                      Button(
                        onClick = { viewModel.equipSavedProfileTheme(theme.id) },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier.height(32.dp)
                      ) {
                        Text(s.equipBtn, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                      }
                    }
                    IconButton(
                      onClick = { viewModel.deleteSavedProfileTheme(theme) },
                      modifier = Modifier.size(30.dp)
                    ) {
                      Icon(Icons.Filled.DeleteOutline, contentDescription = tr("Delete Theme", "Hapus Tema", "Padam Tema", "テーマを削除"), tint = RoseError, modifier = Modifier.size(16.dp))
                    }
                  }
                }
              }
            }
          }

          Button(
            onClick = { viewModel.setActiveTab(MainTab.OWNER_DASHBOARD) },
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("profile_owner_dashboard_btn"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
          ) {
            Icon(Icons.Filled.AdminPanelSettings, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(s.ownerDashboard, fontWeight = FontWeight.Bold, fontSize = 14.sp)
          }

          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f))
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = s.profileVisitorsHeader,
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  letterSpacing = 1.sp
                )
                Icon(Icons.Filled.Visibility, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
              }

              if (visitors.isEmpty()) {
                Text(
                  text = s.noVisitorsYet,
                  fontSize = 12.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.padding(vertical = 12.dp)
                )
              } else {
                val dateFormat = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())
                Column(modifier = Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                  visitors.take(5).forEach { vis ->
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                      Row(verticalAlignment = Alignment.CenterVertically) {
                        UserAvatar(avatarUri = vis.visitorAvatarUri, displayName = vis.visitorUsername, size = 30.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("@${vis.visitorUsername}", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                      }
                      Text(dateFormat.format(Date(vis.visitedAt)), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                  }
                }
              }
            }
          }
        }
        Spacer(modifier = Modifier.height(16.dp))
      }
    }

    if (showDisplayNameStudio) {
      DisplayNameStyleDialog(
        user = user,
        displayNamePreview = editDisplayName.ifBlank { user.displayName },
        initialFontKey = editDisplayFont,
        initialEffectKey = editDisplayEffect,
        initialColors = editNameColors,
        profileBgColors = editProfileBgColors,
        avatarUri = activeAvatarUri,
        bannerUri = activeBannerUri,
        profileColor = selectedColor,
        onDismiss = { showDisplayNameStudio = false },
        onSaveStyle = { chosenFont, chosenEffect, chosenColors ->
          editDisplayFont = chosenFont
          editDisplayEffect = chosenEffect
          editNameColors = chosenColors
          showDisplayNameStudio = false
        }
      )
    }

    if (pickerTarget != null) {
      val initialCol = when (pickerTarget) {
        "NAME_COLOR" -> editNameColors.getOrElse(activeNameStopIndex) { Color(0xFFC32AFF) }
        "WALLPAPER_TINT" -> Color(wpTintHex)
        else -> editProfileBgColors.getOrElse(activeBgStopIndex) { Color(0xFF3B2E5A) }
      }
      PickColorBottomSheet(
        initialColor = initialCol,
        title = "Pick a Color",
        onDismiss = { pickerTarget = null },
        onSelect = { chosen ->
          when (pickerTarget) {
            "NAME_COLOR" -> {
              val idx = activeNameStopIndex.coerceIn(0, editNameColors.lastIndex)
              editNameColors = editNameColors.toMutableList().apply { set(idx, chosen) }
            }
            "WALLPAPER_TINT" -> {
              wpTintHex = chosen.toArgb().toLong() and 0xFFFFFFFFL
              viewModel.updateCustomWallpaper(wpMode, wpUri, user.wallpaperGradientCsv, wpBlur, wpOpacity, wpBrightness, wpTintHex)
            }
            else -> {
              val idx = activeBgStopIndex.coerceIn(0, 2)
              editProfileBgColors = editProfileBgColors.toMutableList().apply { set(idx, chosen) }
            }
          }
          pickerTarget = null
        }
      )
    }

    if (showGameAppDialog) {
      var gName by remember(editingGameApp) { mutableStateOf(editingGameApp?.name ?: "") }
      var gCat by remember(editingGameApp) { mutableStateOf(editingGameApp?.category ?: "Game") }
      var gStatus by remember(editingGameApp) { mutableStateOf(editingGameApp?.activityStatus ?: "") }
      var gDesc by remember(editingGameApp) { mutableStateOf(editingGameApp?.description ?: "") }
      var gLink by remember(editingGameApp) { mutableStateOf(editingGameApp?.appLink ?: "") }
      AlertDialog(
        onDismissRequest = { showGameAppDialog = false },
        title = { Text(if (editingGameApp == null) tr("Add Game / App", "Tambah Game / Aplikasi", "Tambah Permainan / Aplikasi", "ゲーム・アプリを追加") else tr("Edit Game / App", "Edit Game / Aplikasi", "Edit Permainan / Aplikasi", "ゲーム・アプリを編集"), fontWeight = FontWeight.Bold) },
        text = {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = gName, onValueChange = { gName = it }, label = { Text(tr("Game / App Name", "Nama Game / App", "Nama Permainan / App", "ゲーム・アプリ名")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              listOf("Game", "App", "Music", "Coding").forEach { cat ->
                FilterChip(selected = gCat == cat, onClick = { gCat = cat }, label = { Text(cat, fontSize = 11.sp) })
              }
            }
            OutlinedTextField(value = gStatus, onValueChange = { gStatus = it }, label = { Text(tr("Activity Status (e.g. Rank Mythic)", "Status Aktivitas (cth: Rank Mythic)", "Status Aktiviti (cth: Rank Mythic)", "アクティビティ (例: ランク戦)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = gDesc, onValueChange = { gDesc = it }, label = { Text(tr("Short Description", "Deskripsi singkat", "Huraian ringkas", "短い説明")) }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = gLink, onValueChange = { gLink = it }, label = { Text(tr("Link / Package (optional)", "Tautan / Package (opsional)", "Pautan / Pakej (pilihan)", "リンク / パッケージ(任意)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
          }
        },
        confirmButton = {
          Button(
            onClick = {
              val item = UserGameAppEntity(
                id = editingGameApp?.id ?: "ga_${UUID.randomUUID().toString().take(8)}",
                userId = user.id,
                name = gName.trim(),
                category = gCat,
                activityStatus = gStatus.trim(),
                description = gDesc.trim(),
                appLink = gLink.trim(),
                orderIndex = editingGameApp?.orderIndex ?: myGamesApps.size
              )
              viewModel.saveGameApp(item) { showGameAppDialog = false }
            },
            enabled = gName.isNotBlank()
          ) { Text(s.save) }
        },
        dismissButton = { TextButton(onClick = { showGameAppDialog = false }) { Text(s.cancel) } }
      )
    }

    if (showAddConnectionDialog) {
      var selectedPlatform by remember { mutableStateOf(AppActivityTracker.connectionCatalog.first().id) }
      var handleInput by remember { mutableStateOf("") }

      AlertDialog(
        onDismissRequest = { showAddConnectionDialog = false },
        title = { Text(tr("Connect Account / Game", "Hubungkan Akun / Game", "Sambung Akaun / Permainan", "アカウント・ゲームを連携"), fontWeight = FontWeight.Bold) },
        text = {
          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
              tr("Select platform or game (GitHub & Roblox verified via official API):", "Pilih platform atau game (GitHub & Roblox diverifikasi via API resmi):", "Pilih platform atau permainan (GitHub & Roblox disahkan melalui API rasmi):", "プラットフォームを選択 (GitHub・Robloxは公式APIで認証):"),
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(
              modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              AppActivityTracker.connectionCatalog.forEach { app ->
                FilterChip(
                  selected = selectedPlatform == app.id,
                  onClick = { selectedPlatform = app.id },
                  label = { Text(app.displayName, fontSize = 11.sp) }
                )
              }
            }
            OutlinedTextField(
              value = handleInput,
              onValueChange = { handleInput = it },
              label = { Text(tr("Username / Account ID", "Username / ID Akun", "Nama Pengguna / ID Akaun", "ユーザー名 / アカウントID")) },
              singleLine = true,
              modifier = Modifier.fillMaxWidth().testTag("connection_handle_input"),
              shape = RoundedCornerShape(10.dp)
            )
          }
        },
        confirmButton = {
          Button(
            onClick = {
              viewModel.addOrVerifyConnection(selectedPlatform, handleInput) {
                showAddConnectionDialog = false
              }
            },
            enabled = handleInput.isNotBlank()
          ) {
            Text(tr("Connect", "Hubungkan", "Sambungkan", "連携する"))
          }
        },
        dismissButton = {
          TextButton(onClick = { showAddConnectionDialog = false }) { Text(s.cancel) }
        }
      )
    }
  }
}

@Composable
private fun ColorSwatchGrid(
  selectedColor: Color,
  onSelectColor: (Color) -> Unit
) {
  Row(
    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    PaletteSwatches.forEach { hexLong ->
      val c = Color(hexLong)
      val isSel = c == selectedColor
      Box(
        modifier = Modifier
          .size(32.dp)
          .clip(CircleShape)
          .background(c)
          .border(
            width = if (isSel) 2.5.dp else 1.dp,
            color = if (isSel) Color.White else MaterialTheme.colorScheme.outline,
            shape = CircleShape
          )
          .clickable { onSelectColor(c) }
      )
    }
  }
}
