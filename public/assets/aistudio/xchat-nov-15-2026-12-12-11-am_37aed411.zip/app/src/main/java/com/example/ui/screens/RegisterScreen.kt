package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import com.example.ui.theme.*
import com.example.utils.GoogleSignInHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterScreen(
  onBack: () -> Unit,
  onNavigateToLogin: () -> Unit,
  onBeforeGoogleSignUp: (preferredUsername: String, preferredDisplayName: String) -> Unit = { _, _ -> },
  onGoogleSignUpSuccess: (preferredUsername: String, preferredDisplayName: String) -> Unit
) {
  val context = LocalContext.current
  val credentialManager = remember { CredentialManager.create(context) }
  val scope = rememberCoroutineScope()

  var displayName by remember { mutableStateOf("") }
  var username by remember { mutableStateOf("") }
  var agreedTerms by remember { mutableStateOf(true) }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  var isLoading by remember { mutableStateOf(false) }

  val s = LocalStrings.current
  val scrollState = rememberScrollState()

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text(s.registerBtn, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) },
        navigationIcon = {
          IconButton(
            onClick = onBack,
            modifier = Modifier.testTag("register_back_button")
          ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
      )
    },
    containerColor = Color.Transparent
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .verticalScroll(scrollState)
        .padding(horizontal = 24.dp, vertical = 12.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Text(
        text = s.registerTitle,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground,
        modifier = Modifier.fillMaxWidth()
      )

      Text(
        text = s.registerSubtitle,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 20.dp)
      )

      if (errorMessage != null) {
        Card(
          modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
          colors = CardDefaults.cardColors(containerColor = RoseError.copy(alpha = 0.15f)),
          shape = RoundedCornerShape(8.dp)
        ) {
          Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = RoseError)
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = errorMessage ?: "", color = RoseError, style = MaterialTheme.typography.bodyMedium)
          }
        }
      }

      OutlinedTextField(
        value = displayName,
        onValueChange = { displayName = it; errorMessage = null },
        label = { Text(s.displayNameLabel) },
        leadingIcon = { Icon(Icons.Filled.Badge, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
        placeholder = { Text("e.g. Alex / PlayerOne") },
        modifier = Modifier.fillMaxWidth().testTag("reg_displayname_input"),
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = MaterialTheme.colorScheme.surface,
          unfocusedContainerColor = MaterialTheme.colorScheme.surface
        )
      )

      Spacer(modifier = Modifier.height(12.dp))

      OutlinedTextField(
        value = username,
        onValueChange = { username = it.lowercase().replace(" ", "_"); errorMessage = null },
        label = { Text("Username (@)") },
        leadingIcon = { Icon(Icons.Filled.AlternateEmail, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
        placeholder = { Text("e.g. alex_xchat") },
        modifier = Modifier.fillMaxWidth().testTag("reg_username_input"),
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = MaterialTheme.colorScheme.surface,
          unfocusedContainerColor = MaterialTheme.colorScheme.surface
        )
      )

      Spacer(modifier = Modifier.height(14.dp))

      Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(
          checked = agreedTerms,
          onCheckedChange = { agreedTerms = it },
          colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
        )
        Text(
          text = s.agreeTerms,
          style = MaterialTheme.typography.bodyMedium,
          fontSize = 12.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      Spacer(modifier = Modifier.height(20.dp))

      Button(
        onClick = {
          if (!agreedTerms) {
            errorMessage = "Please agree to the terms of service."
            return@Button
          }
          val cleanUser = username.trim().removePrefix("@")
          if (cleanUser.isNotBlank() && cleanUser.length < 2) {
            errorMessage = "Username must be at least 2 characters."
            return@Button
          }
          errorMessage = null
          isLoading = true
          onBeforeGoogleSignUp(cleanUser, displayName.trim())
          GoogleSignInHelper.onGoogleSignInClicked(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = {
              isLoading = false
              onGoogleSignUpSuccess(cleanUser, displayName.trim())
            },
            onAuthError = { err ->
              isLoading = false
              onBeforeGoogleSignUp("", "")
              errorMessage = err
            },
            onAuthCancelled = {
              isLoading = false
              onBeforeGoogleSignUp("", "")
            },
            scope = scope
          )
        },
        enabled = !isLoading,
        modifier = Modifier.fillMaxWidth().height(52.dp).testTag("reg_submit_button"),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
      ) {
        if (isLoading) {
          CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
        } else {
          Icon(Icons.Filled.AccountCircle, contentDescription = null, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(s.registerBtn, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      Row(verticalAlignment = Alignment.CenterVertically) {
        Text("${s.haveAccountPrompt} ", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        TextButton(onClick = onNavigateToLogin) {
          Text(s.loginBtn, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
      }
      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}
