package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.ui.MainTab
import com.example.ui.XChatViewModel
import com.example.ui.components.PickColorBottomSheet
import com.example.ui.theme.*
import com.example.utils.AppActivityTracker
import com.example.utils.CloudMediaHelper
import com.example.utils.SoundEffectType
import com.example.utils.SoundEffectsEngine

private val SettingsColorSwatches = listOf(
  0xFF7C3AEDL, 0xFF9333EAL, 0xFF8B5CF6L, 0xFFEC4899L,
  0xFFF43F5EL, 0xFFF97316L, 0xFF10B981L, 0xFF0EA5E9L,
  0xFF3B82F6L, 0xFF6366F1L, 0xFF2B2D31L, 0xFF1E1F22L
)

private fun Color.toHexArg(): String {
  val argb = this.toArgb().toLong() and 0xFFFFFFFFL
  return "0x" + argb.toString(16).uppercase().padStart(8, '0')
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
  viewModel: XChatViewModel,
  onLogoutClick: () -> Unit = { viewModel.logout() }
) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current
  val s = LocalStrings.current
  val currentUser by viewModel.currentUser.collectAsState()
  val activeLanguage by viewModel.activeLanguageCode.collectAsState()
  val detectedIpInfo by viewModel.detectedIpInfo.collectAsState()
  val hasAppPin by viewModel.hasAppPin.collectAsState()

  val scrollState = rememberScrollState()
  val soundState by viewModel.soundState.collectAsState()
  var visitorTrackingEnabled by remember { mutableStateOf(true) }
  var showLogoutConfirm by remember { mutableStateOf(false) }
  var showReportBugDialog by remember { mutableStateOf(false) }

  var newPasswordText by remember { mutableStateOf("") }
  var confirmNewPasswordText by remember { mutableStateOf("") }
  var pinInputText by remember { mutableStateOf("") }

  var permissionRefreshTick by remember { mutableIntStateOf(0) }
  DisposableEffect(lifecycleOwner) {
    val obs = LifecycleEventObserver { _, event ->
      if (event == Lifecycle.Event.ON_RESUME) permissionRefreshTick++
    }
    lifecycleOwner.lifecycle.addObserver(obs)
    onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
  }

  val notifPermissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { permissionRefreshTick++ }
  val cameraPermissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { permissionRefreshTick++ }
  val micPermissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { permissionRefreshTick++ }

  val isAstral = currentUser?.subscriptionTier?.equals("ASTRAL", ignoreCase = true) == true || currentUser?.isOwner == true

  // Custom theme gradient builder state (Astral only)
  var themeStop1 by remember(currentUser) {
    val parsed = ColorHelper.parseColorsCsv(currentUser?.appThemeGradientCsv, listOf(0xFF7C3AEDL, 0xFFA855F7L))
    mutableStateOf(parsed.firstOrNull() ?: Color(0xFF7C3AED))
  }
  var themeStop2 by remember(currentUser) {
    val parsed = ColorHelper.parseColorsCsv(currentUser?.appThemeGradientCsv, listOf(0xFF7C3AEDL, 0xFFA855F7L))
    mutableStateOf(parsed.lastOrNull() ?: Color(0xFFA855F7))
  }

  // Own message bubble background builder state
  val bubbleColors = ColorHelper.parseColorsCsv(currentUser?.chatBubbleBgCsv, listOf(0xFF7C3AEDL, 0xFF9333EAL))
  var bubbleStop1 by remember(currentUser) { mutableStateOf(bubbleColors.firstOrNull() ?: Color(0xFF7C3AED)) }
  var bubbleStop2 by remember(currentUser) { mutableStateOf(bubbleColors.lastOrNull() ?: Color(0xFF9333EA)) }

  var accentColor by remember(currentUser?.accentColorHex) {
    mutableStateOf(Color(currentUser?.accentColorHex ?: 0xFFC4C9D4L))
  }
  var activeSettingsPicker by remember { mutableStateOf<String?>(null) } // "THEME_1", "THEME_2", "BUBBLE_1", "BUBBLE_2", "ACCENT"

  val bubbleImagePicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      viewModel.prepareAndPickMedia(uri, maxDim = 800) { cloudUri ->
        viewModel.updateChatBubbleBackground(
          bgCsv = currentUser?.chatBubbleBgCsv ?: "0xFF1C2029,0xFF2B303D",
          imageUri = cloudUri,
          clearImage = false
        )
      }
    }
  }

  Scaffold(
    contentWindowInsets = WindowInsets(0.dp),
    topBar = {
      TopAppBar(
        windowInsets = WindowInsets(0.dp),
        title = {
          Text(s.settings, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        },
        navigationIcon = {
          IconButton(onClick = { viewModel.setActiveTab(MainTab.PROFILE) }) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = s.backLabel, tint = MaterialTheme.colorScheme.onSurface)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f))
      )
    },
    containerColor = Color.Transparent
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .verticalScroll(scrollState)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // 1. Language & IP Detection Section
      SettingsSection(title = s.languageSection) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(MaterialTheme.colorScheme.surfaceVariant)
              .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Filled.Public, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = "${s.detectedIpPrefix}: ${detectedIpInfo?.ipAddress ?: "..."} (${detectedIpInfo?.countryCode ?: "-"})",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "${s.activeLangLabel}: ${activeLanguage.uppercase()}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          val currentSettingLang = currentUser?.languageCode ?: "AUTO"
          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            FilterChip(
              selected = currentSettingLang.equals("AUTO", ignoreCase = true),
              onClick = { viewModel.setLanguage("AUTO") },
              label = { Text(s.autoIpLabel, fontSize = 12.sp) }
            )
            AppLanguage.entries.forEach { lang ->
              FilterChip(
                selected = activeLanguage.equals(lang.code, ignoreCase = true) && !currentSettingLang.equals("AUTO", ignoreCase = true),
                onClick = { viewModel.setLanguage(lang.code) },
                label = { Text(lang.displayName, fontSize = 12.sp) }
              )
            }
          }
        }
      }

      // 2. App Theme & Typography (Astral Only)
      SettingsSection(title = s.themeSection) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          if (!isAstral) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(AstralViolet.copy(alpha = 0.16f))
                .border(1.dp, AstralViolet.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                .padding(10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(s.astralOnlyTag, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = AstralViolet)
                Text(s.astralRequiredTheme, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              TextButton(onClick = { viewModel.setActiveTab(MainTab.MARKET) }) {
                Text(s.upgradeBtn, fontWeight = FontWeight.Bold, color = AstralViolet)
              }
            }
          }

          Text(s.themePresetsLabel, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            AppThemePresets.all.forEach { preset ->
              val isSel = currentUser?.appThemeId == preset.id
              val locked = preset.isAstralOnly && !isAstral
              Surface(
                onClick = {
                  viewModel.updateAppThemeAndFont(
                    themeId = preset.id,
                    gradientCsv = "",
                    fontKey = currentUser?.appFontKey ?: "SERIF"
                  )
                },
                shape = RoundedCornerShape(10.dp),
                color = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                border = androidx.compose.foundation.BorderStroke(
                  1.dp,
                  if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                ),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier.padding(10.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Box(
                    modifier = Modifier
                      .size(28.dp)
                      .clip(CircleShape)
                      .background(Brush.linearGradient(preset.gradientColors))
                      .border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape)
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(preset.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                    Text(if (preset.isAstralOnly) "Astral Only" else tr("Free (Default)", "Gratis (Default)", "Percuma (Lalai)", "無料 (デフォルト)"), fontSize = 10.sp, color = if (preset.isAstralOnly) AstralViolet else EmeraldSuccess)
                  }
                  if (locked) {
                    Icon(Icons.Filled.Lock, contentDescription = "Locked", tint = AstralViolet, modifier = Modifier.size(18.dp))
                  } else if (isSel) {
                    Icon(Icons.Filled.CheckCircle, contentDescription = "Selected", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                  }
                }
              }
            }
          }

          HorizontalDivider(color = MaterialTheme.colorScheme.outline)

          Text(tr("Custom Accent Gradient (Astral Only):", "Gradasi Warna Aksen Kustom (Astral Only):", "Gradien Warna Aksen Tersuai (Astral Only):", "カスタムアクセントグラデーション (Astral専用):"), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .height(34.dp)
              .clip(RoundedCornerShape(8.dp))
              .background(Brush.linearGradient(listOf(themeStop1, themeStop2))),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            Text(tr("Theme Gradient Preview", "Pratinjau Gradasi Tema", "Pratonton Gradien Tema", "テーマグラデーションプレビュー"), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
          }

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(tr("Gradient Start Color:", "Warna Awal Gradasi:", "Warna Mula Gradien:", "開始色:"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            TextButton(onClick = { activeSettingsPicker = "THEME_1" }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)) {
              Text("${tr("Pick Color", "Pilih Warna", "Pilih Warna", "色を選択")} (${ColorHelper.toHex6(themeStop1)})", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
          SwatchRow(selected = themeStop1) { themeStop1 = it }
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(tr("Gradient End Color:", "Warna Akhir Gradasi:", "Warna Akhir Gradien:", "終了色:"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            TextButton(onClick = { activeSettingsPicker = "THEME_2" }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)) {
              Text("${tr("Pick Color", "Pilih Warna", "Pilih Warna", "色を選択")} (${ColorHelper.toHex6(themeStop2)})", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
          SwatchRow(selected = themeStop2) { themeStop2 = it }

          Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
              onClick = {
                viewModel.updateAppThemeAndFont(
                  themeId = currentUser?.appThemeId ?: "obsidian_marble",
                  gradientCsv = "${themeStop1.toHexArg()},${themeStop2.toHexArg()}",
                  fontKey = currentUser?.appFontKey ?: "SERIF",
                  accentColorHex = accentColor.toArgb().toLong() and 0xFFFFFFFFL
                )
              },
              modifier = Modifier.weight(1f).height(44.dp),
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(tr("Apply Custom Gradient", "Terapkan Gradasi Kustom", "Gunakan Gradien Tersuai", "カスタムグラデを適用"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            OutlinedButton(
              onClick = { activeSettingsPicker = "ACCENT" },
              modifier = Modifier.height(44.dp),
              shape = RoundedCornerShape(8.dp)
            ) {
              Box(modifier = Modifier.size(14.dp).clip(CircleShape).background(accentColor))
              Spacer(modifier = Modifier.width(6.dp))
              Text(tr("Accent", "Aksen", "Aksen", "アクセント"), fontSize = 12.sp)
            }
          }

          HorizontalDivider(color = MaterialTheme.colorScheme.outline)

          Text(tr("App Typography Font:", "Font Tipografi Aplikasi:", "Fon Tipografi Aplikasi:", "アプリフォント:"), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            AppFontOption.entries.forEach { fOpt ->
              val isSel = (currentUser?.appFontKey ?: "SERIF").equals(fOpt.key, ignoreCase = true)
              FilterChip(
                selected = isSel,
                onClick = {
                  viewModel.updateAppThemeAndFont(
                    themeId = currentUser?.appThemeId ?: "obsidian_marble",
                    gradientCsv = currentUser?.appThemeGradientCsv ?: "",
                    fontKey = fOpt.key
                  )
                },
                label = { Text(fOpt.label, fontFamily = fOpt.fontFamily, fontSize = 12.sp) }
              )
            }
          }
        }
      }

      // 3. My Message Bubble Background
      SettingsSection(title = s.chatBubbleSection) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            text = s.bubbleHelpText,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          // Live Bubble Preview
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .background(MaterialTheme.colorScheme.surfaceVariant)
              .padding(12.dp),
            contentAlignment = Alignment.CenterEnd
          ) {
            val previewBrush = Brush.linearGradient(listOf(bubbleStop1, bubbleStop2))
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp, bottomStart = 14.dp, bottomEnd = 2.dp))
                .background(previewBrush)
            ) {
              val bubbleImg = currentUser?.chatBubbleImageUri
              val bubblePreviewModel = remember(bubbleImg) { CloudMediaHelper.resolveCoilModel(bubbleImg) }
              val bubblePreviewReq = remember(bubblePreviewModel) {
                bubblePreviewModel?.let { ImageRequest.Builder(context).data(it).crossfade(false).build() }
              }
              if (bubblePreviewReq != null) {
                AsyncImage(
                  model = bubblePreviewReq,
                  contentDescription = null,
                  contentScale = ContentScale.Crop,
                  modifier = Modifier.matchParentSize()
                )
                Box(modifier = Modifier.matchParentSize().background(Color.Black.copy(alpha = 0.42f)))
              }
              Text(
                text = s.bubblePreviewText,
                color = Color.White,
                fontSize = 13.sp,
                modifier = Modifier.padding(10.dp)
              )
            }
          }

          val bubblePresets = listOf(
            "XChat Purple" to (Color(0xFF7C3AED) to Color(0xFF9333EA)),
            "Cyber Pink" to (Color(0xFFEC4899) to Color(0xFF8B5CF6)),
            "Emerald Ocean" to (Color(0xFF059669) to Color(0xFF0EA5E9)),
            "Sunset Fire" to (Color(0xFFF43F5E) to Color(0xFFF97316)),
            "Obsidian Dark" to (Color(0xFF2B2D31) to Color(0xFF1E1F22))
          )
          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            bubblePresets.forEach { (label, pair) ->
              AssistChip(
                onClick = {
                  bubbleStop1 = pair.first
                  bubbleStop2 = pair.second
                  viewModel.updateChatBubbleBackground(
                    bgCsv = "${pair.first.toHexArg()},${pair.second.toHexArg()}",
                    imageUri = null,
                    clearImage = true
                  )
                },
                label = { Text(label, fontSize = 11.sp) }
              )
            }
          }

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Gradient 1:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            TextButton(onClick = { activeSettingsPicker = "BUBBLE_1" }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)) {
              Text("Pick Color (${ColorHelper.toHex6(bubbleStop1)})", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
          SwatchRow(selected = bubbleStop1) { bubbleStop1 = it }
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Gradient 2:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            TextButton(onClick = { activeSettingsPicker = "BUBBLE_2" }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)) {
              Text("Pick Color (${ColorHelper.toHex6(bubbleStop2)})", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
          SwatchRow(selected = bubbleStop2) { bubbleStop2 = it }

          Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
              onClick = {
                viewModel.updateChatBubbleBackground(
                  bgCsv = "${bubbleStop1.toHexArg()},${bubbleStop2.toHexArg()}",
                  imageUri = currentUser?.chatBubbleImageUri,
                  clearImage = false
                )
              },
              modifier = Modifier.weight(1f).height(44.dp),
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(s.saveColorsBtn, fontSize = 12.sp)
            }

            OutlinedButton(
              onClick = {
                bubbleImagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
              },
              modifier = Modifier.weight(1f).height(44.dp),
              shape = RoundedCornerShape(8.dp)
            ) {
              Icon(Icons.Filled.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(s.galleryMediaBtn, fontSize = 12.sp)
            }
          }

          if (!currentUser?.chatBubbleImageUri.isNullOrBlank()) {
            TextButton(
              onClick = {
                viewModel.updateChatBubbleBackground(
                  bgCsv = "${bubbleStop1.toHexArg()},${bubbleStop2.toHexArg()}",
                  imageUri = null,
                  clearImage = true
                )
              }
            ) {
              Icon(Icons.Filled.DeleteOutline, contentDescription = null, tint = RoseError, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(s.removeBubbleBgBtn, color = RoseError, fontSize = 12.sp)
            }
          }
        }
      }

      // 4. Account Section
      SettingsSection(title = s.accountSection) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          val fbAuthUser = remember { com.google.firebase.auth.FirebaseAuth.getInstance().currentUser }
          val fallbackHandle = fbAuthUser?.email?.substringBefore("@")?.takeIf { it.isNotBlank() }
          val displayHandle = currentUser?.username?.takeIf { it.isNotBlank() } ?: fallbackHandle ?: "-"
          val displayEmail = currentUser?.email?.takeIf { it.isNotBlank() } ?: fbAuthUser?.email?.takeIf { it.isNotBlank() } ?: "-"
          Text("Username", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text("@$displayHandle", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)

          Text(s.emailLabel, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(displayEmail, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)

          val tierLabel = when (currentUser?.subscriptionTier?.uppercase()) {
            "VIP", "ASTRAL" -> "ASTRAL"
            "PREM", "ASTRIX" -> "ASTRIX"
            else -> "FREE"
          }
          Text("Tier", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            if (currentUser?.isOwner == true) "Owner ($tierLabel)"
            else "Tier: $tierLabel",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.primary
          )
        }
      }

      // 5. 9 Sound Effects, Low Performance Mode & Privacy
      SettingsSection(title = "${s.soundPrivacySection} • ${s.soundEffectsTitle}") {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(s.uiSoundsTitle, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
              Text(s.uiSoundsDesc, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(
              checked = soundState.masterEnabled,
              onCheckedChange = {
                viewModel.setSoundMasterEnabled(it)
                if (it) SoundEffectsEngine.play(SoundEffectType.BUTTON)
              }
            )
          }

          if (soundState.masterEnabled) {
            Text("${s.uiSoundsTitle}: ${(soundState.volume * 100).toInt()}%", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Slider(
              value = soundState.volume,
              onValueChange = { viewModel.setSoundVolume(it) },
              valueRange = 0f..1f
            )
            Row(
              modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              SoundEffectType.entries.forEach { type ->
                val isMuted = type in soundState.mutedTypes
                FilterChip(
                  selected = !isMuted,
                  onClick = {
                    viewModel.toggleSoundTypeMuted(type)
                    if (isMuted) SoundEffectsEngine.play(type)
                  },
                  label = { Text(type.labelFor(activeLanguage), fontSize = 11.sp) }
                )
              }
            }
          }

          HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(s.lowPerfModeTitle, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
              Text(s.lowPerfDesc, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(
              checked = currentUser?.lowPerfMode == true,
              onCheckedChange = { viewModel.setLowPerfMode(it) }
            )
          }

          HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(s.profileHistoryTitle, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
              Text(s.profileHistoryDesc, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = visitorTrackingEnabled, onCheckedChange = { visitorTrackingEnabled = it })
          }
        }
      }

      // 5B. Security: Password Change, Email Reset & App Lock PIN
      SettingsSection(title = s.securitySection) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(s.changePasswordHeader, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
          OutlinedTextField(
            value = newPasswordText,
            onValueChange = { newPasswordText = it },
            label = { Text(s.newPasswordLabel) },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("settings_new_password_input"),
            shape = RoundedCornerShape(10.dp)
          )
          OutlinedTextField(
            value = confirmNewPasswordText,
            onValueChange = { confirmNewPasswordText = it },
            label = { Text(s.confirmNewPasswordLabel) },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("settings_confirm_password_input"),
            shape = RoundedCornerShape(10.dp)
          )
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
              onClick = {
                if (newPasswordText != confirmNewPasswordText) {
                  viewModel.feedbackMessage.value = "Password confirmation does not match."
                } else {
                  viewModel.updateAccountPassword(newPasswordText) {
                    newPasswordText = ""
                    confirmNewPasswordText = ""
                  }
                }
              },
              enabled = newPasswordText.length >= 8 && confirmNewPasswordText.isNotEmpty(),
              modifier = Modifier.weight(1f).height(44.dp).testTag("settings_update_password_btn"),
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(s.updatePasswordBtn, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            OutlinedButton(
              onClick = { viewModel.sendPasswordResetEmail() },
              modifier = Modifier.weight(1f).height(44.dp).testTag("settings_reset_password_email_btn"),
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(s.resetViaEmailBtn, fontSize = 12.sp)
            }
          }

          HorizontalDivider(color = MaterialTheme.colorScheme.outline)

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(s.appLockPinHeader, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(if (hasAppPin) EmeraldSuccess.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant)
                .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
              Text(
                text = if (hasAppPin) s.pinActiveBadge else s.pinInactiveBadge,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = if (hasAppPin) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
          OutlinedTextField(
            value = pinInputText,
            onValueChange = { next ->
              if (next.length <= 6 && next.all { it.isDigit() }) pinInputText = next
            },
            label = { Text(if (hasAppPin) s.newPinLabel else s.setPinLabel) },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("settings_pin_input"),
            shape = RoundedCornerShape(10.dp)
          )
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
              onClick = {
                if (viewModel.setAppPin(pinInputText)) {
                  pinInputText = ""
                }
              },
              enabled = pinInputText.length in 4..6,
              modifier = Modifier.weight(1f).height(44.dp).testTag("settings_save_pin_btn"),
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(if (hasAppPin) s.changePinBtn else s.enablePinBtn, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            if (hasAppPin) {
              OutlinedButton(
                onClick = { viewModel.clearAppPin() },
                modifier = Modifier.weight(1f).height(44.dp).testTag("settings_disable_pin_btn"),
                shape = RoundedCornerShape(8.dp)
              ) {
                Text(s.disablePinBtn, fontSize = 12.sp, color = RoseError)
              }
            }
          }
        }
      }

      // 5C. System Permissions Center (Notifications, Camera, Microphone, Screen Share, Usage Access)
      val notifGranted = remember(permissionRefreshTick) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
          ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else {
          NotificationManagerCompat.from(context).areNotificationsEnabled()
        }
      }
      val camGranted = remember(permissionRefreshTick) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
      }
      val micGranted = remember(permissionRefreshTick) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
      }
      val usageGranted = remember(permissionRefreshTick) {
        AppActivityTracker.hasUsageAccess(context)
      }

      SettingsSection(title = s.permissionsSection) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          PermissionRow(
            icon = Icons.Filled.Notifications,
            title = "Message Notifications",
            subtitle = "DM & channel alerts in-app and in the background.",
            granted = notifGranted,
            actionLabel = if (notifGranted) s.activeStatus else s.allowBtn,
            onAction = {
              if (!notifGranted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
              } else {
                val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                  putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                  addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                runCatching { context.startActivity(intent) }
              }
            }
          )
          HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
          PermissionRow(
            icon = Icons.Filled.Videocam,
            title = "Camera Access (Video & Voice)",
            subtitle = "Enable live camera video during Voice & DM calls.",
            granted = camGranted,
            actionLabel = if (camGranted) s.activeStatus else s.allowBtn,
            onAction = {
              if (!camGranted) {
                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
              } else {
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                  data = Uri.fromParts("package", context.packageName, null)
                  addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                runCatching { context.startActivity(intent) }
              }
            }
          )
          HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
          PermissionRow(
            icon = Icons.Filled.Mic,
            title = "Microphone Access (Voice & RMS)",
            subtitle = "Real-time voice detection and audio calls.",
            granted = micGranted,
            actionLabel = if (micGranted) s.activeStatus else s.allowBtn,
            onAction = {
              if (!micGranted) {
                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
              } else {
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                  data = Uri.fromParts("package", context.packageName, null)
                  addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                runCatching { context.startActivity(intent) }
              }
            }
          )
          HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
          PermissionRow(
            icon = Icons.Filled.ScreenShare,
            title = "Screen Share (MediaProjection)",
            subtitle = "Prompted automatically when tapping Screen Share inside a voice room.",
            granted = true,
            actionLabel = s.readyBtn,
            onAction = {
              viewModel.feedbackMessage.value = "Join a Voice Channel and tap Screen Share to authorize."
            }
          )
          HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
          PermissionRow(
            icon = Icons.Filled.SportsEsports,
            title = "Running Game & App Activity",
            subtitle = "Displays 'Now Playing' + live session timer on your profile.",
            granted = usageGranted,
            actionLabel = if (usageGranted) s.activeStatus else s.openPermBtn,
            onAction = { AppActivityTracker.openUsageAccessSettings(context) }
          )
        }
      }

      // 6. Report Bug / Abuse & Owner Dashboard (Key Protected)
      OutlinedButton(
        onClick = { showReportBugDialog = true },
        modifier = Modifier.fillMaxWidth().height(48.dp),
        shape = RoundedCornerShape(10.dp)
      ) {
        Icon(Icons.Filled.Flag, contentDescription = null, tint = AmberWarning)
        Spacer(modifier = Modifier.width(8.dp))
        Text(s.reportIssueBtn, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
      }

      OutlinedButton(
        onClick = { viewModel.setActiveTab(MainTab.OWNER_DASHBOARD) },
        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("settings_owner_dashboard_button"),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
      ) {
        Icon(Icons.Filled.AdminPanelSettings, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(8.dp))
        Text(s.ownerDashboard, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
      }

      // 7. Logout
      Button(
        onClick = { showLogoutConfirm = true },
        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("settings_logout_button"),
        colors = ButtonDefaults.buttonColors(containerColor = RoseError.copy(alpha = 0.16f)),
        shape = RoundedCornerShape(10.dp)
      ) {
        Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null, tint = RoseError)
        Spacer(modifier = Modifier.width(8.dp))
        Text(s.logout, fontWeight = FontWeight.Bold, color = RoseError)
      }

      Spacer(modifier = Modifier.height(20.dp))
    }

    if (showLogoutConfirm) {
      AlertDialog(
        onDismissRequest = { showLogoutConfirm = false },
        title = { Text(s.logoutConfirmTitle, fontWeight = FontWeight.Bold) },
        text = { Text(s.logoutConfirmDesc) },
        confirmButton = {
          Button(
            onClick = { showLogoutConfirm = false; onLogoutClick() },
            colors = ButtonDefaults.buttonColors(containerColor = RoseError)
          ) {
            Text(s.yesLogout)
          }
        },
        dismissButton = {
          TextButton(onClick = { showLogoutConfirm = false }) { Text(s.cancel) }
        }
      )
    }

    if (showReportBugDialog) {
      var rReason by remember { mutableStateOf("Bug Report") }
      var rDetails by remember { mutableStateOf("") }
      AlertDialog(
        onDismissRequest = { showReportBugDialog = false },
        title = { Text(s.reportIssueBtn, fontWeight = FontWeight.Bold) },
        text = {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              listOf("Bug Report", "Abuse / Harassment", "Account Issue").forEach { r ->
                FilterChip(selected = rReason == r, onClick = { rReason = r }, label = { Text(r, fontSize = 11.sp) })
              }
            }
            OutlinedTextField(value = rDetails, onValueChange = { rDetails = it }, label = { Text("Details") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
          }
        },
        confirmButton = {
          Button(
            onClick = {
              viewModel.submitReport(null, null, null, rReason, rDetails) { showReportBugDialog = false }
            },
            enabled = rDetails.isNotBlank()
          ) { Text(s.sendBtn) }
        },
        dismissButton = { TextButton(onClick = { showReportBugDialog = false }) { Text(s.cancel) } }
      )
    }

    if (activeSettingsPicker != null) {
      val initCol = when (activeSettingsPicker) {
        "THEME_1" -> themeStop1
        "THEME_2" -> themeStop2
        "BUBBLE_1" -> bubbleStop1
        "ACCENT" -> accentColor
        else -> bubbleStop2
      }
      PickColorBottomSheet(
        initialColor = initCol,
        title = "Pick a Color",
        onDismiss = { activeSettingsPicker = null },
        onSelect = { chosen ->
          when (activeSettingsPicker) {
            "THEME_1" -> themeStop1 = chosen
            "THEME_2" -> themeStop2 = chosen
            "BUBBLE_1" -> bubbleStop1 = chosen
            "BUBBLE_2" -> bubbleStop2 = chosen
            "ACCENT" -> {
              accentColor = chosen
              viewModel.updateAppThemeAndFont(
                themeId = currentUser?.appThemeId ?: "obsidian_marble",
                gradientCsv = currentUser?.appThemeGradientCsv ?: "",
                fontKey = currentUser?.appFontKey ?: "SERIF",
                accentColorHex = chosen.toArgb().toLong() and 0xFFFFFFFFL
              )
            }
          }
          activeSettingsPicker = null
        }
      )
    }
  }
}

@Composable
private fun SettingsSection(
  title: String,
  content: @Composable () -> Unit
) {
  Column {
    Text(
      text = title,
      fontWeight = FontWeight.Bold,
      fontSize = 11.sp,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
      letterSpacing = 1.sp,
      modifier = Modifier.padding(bottom = 6.dp)
    )
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f))
    ) {
      content()
    }
  }
}

@Composable
private fun SwatchRow(
  selected: Color,
  onSelect: (Color) -> Unit
) {
  Row(
    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    SettingsColorSwatches.forEach { hex ->
      val col = Color(hex)
      val isSel = col == selected
      Box(
        modifier = Modifier
          .size(30.dp)
          .clip(CircleShape)
          .background(col)
          .border(
            width = if (isSel) 2.5.dp else 1.dp,
            color = if (isSel) Color.White else MaterialTheme.colorScheme.outline,
            shape = CircleShape
          )
          .clickable { onSelect(col) }
      )
    }
  }
}

@Composable
private fun PermissionRow(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  title: String,
  subtitle: String,
  granted: Boolean,
  actionLabel: String,
  onAction: () -> Unit
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    Box(
      modifier = Modifier
        .size(36.dp)
        .clip(RoundedCornerShape(8.dp))
        .background(if (granted) EmeraldSuccess.copy(alpha = 0.16f) else MaterialTheme.colorScheme.primaryContainer),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        icon,
        contentDescription = null,
        tint = if (granted) EmeraldSuccess else MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(18.dp)
      )
    }
    Column(modifier = Modifier.weight(1f)) {
      Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
      Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 14.sp)
    }
    FilledTonalButton(
      onClick = onAction,
      contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
      modifier = Modifier.height(34.dp),
      shape = RoundedCornerShape(8.dp),
      colors = ButtonDefaults.filledTonalButtonColors(
        containerColor = if (granted) EmeraldSuccess.copy(alpha = 0.2f) else MaterialTheme.colorScheme.primaryContainer,
        contentColor = if (granted) EmeraldSuccess else MaterialTheme.colorScheme.primary
      )
    ) {
      Text(actionLabel, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
  }
}
