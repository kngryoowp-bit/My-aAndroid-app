package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.model.VoiceParticipantModel
import com.example.ui.XChatViewModel
import com.example.ui.components.UserAvatar
import com.example.ui.components.VoiceDiagnosticsDialog
import com.example.ui.components.WebRtcVideoRendererView
import com.example.ui.theme.*
import com.example.utils.ScreenShareBus
import com.example.utils.VoiceMediaForegroundService

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceScreen(viewModel: XChatViewModel) {
  val context = LocalContext.current
  val strings = LocalStrings.current
  val voiceState by viewModel.voiceState.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()
  val participants by viewModel.voiceParticipants.collectAsState()
  val rtcCallState by viewModel.rtcCallState.collectAsState()
  val localVideoTrack by viewModel.localVideoTrack.collectAsState()
  val remoteVideoTracks by viewModel.remoteVideoTracks.collectAsState()
  val micLevel by ScreenShareBus.micLevel.collectAsState()
  val latestScreenFrame by ScreenShareBus.latestFrame.collectAsState()
  val busSharing by ScreenShareBus.isScreenSharing.collectAsState()
  var showDiagnostics by remember { mutableStateOf(false) }

  val micPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
    if (granted) {
      ScreenShareBus.startMicLevelMonitor(context) { viewModel.voiceState.value.isMuted || viewModel.voiceState.value.isDeafened }
    } else {
      viewModel.feedbackMessage.value = "Microphone permission denied. Enable microphone access to speak."
    }
  }

  val cameraPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
    if (granted) {
      viewModel.setCameraActive(true)
    } else {
      viewModel.feedbackMessage.value = "Camera permission denied. Enable camera in System Permissions."
    }
  }

  val screenShareLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
    if (result.resultCode == Activity.RESULT_OK && result.data != null) {
      VoiceMediaForegroundService.startScreenShare(context, result.resultCode, result.data!!)
      viewModel.setScreenSharingActive(true)
    } else {
      viewModel.setScreenSharingActive(false)
      viewModel.feedbackMessage.value = "Screen sharing canceled."
    }
  }

  LaunchedEffect(voiceState.isInVoice) {
    if (voiceState.isInVoice) {
      val hasMic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
      if (!hasMic) {
        micPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
      }
    }
  }

  // Merge current self state cleanly into live Firestore participants (NO hardcoded fake users!)
  val displayParticipants = remember(participants, currentUser, voiceState, micLevel, busSharing) {
    val meId = currentUser?.id
    val others = participants.filter { it.userId != meId }
    val selfEntry = currentUser?.let { me ->
      VoiceParticipantModel(
        userId = me.id,
        channelId = voiceState.channelId,
        serverId = voiceState.serverId,
        displayName = me.displayName,
        avatarUri = me.avatarUri,
        isMuted = voiceState.isMuted,
        isDeafened = voiceState.isDeafened,
        isCameraOn = voiceState.isCameraOn,
        isScreenSharing = voiceState.isScreenSharing || busSharing,
        isSpeaking = !voiceState.isMuted && !voiceState.isDeafened && micLevel > 0.14f,
        updatedAt = System.currentTimeMillis()
      )
    }
    listOfNotNull(selfEntry) + others
  }

  Scaffold(
    contentWindowInsets = WindowInsets(0.dp),
    topBar = {
      TopAppBar(
        windowInsets = WindowInsets(0.dp),
        title = {
          Column {
            Text(
              voiceState.channelName.ifEmpty { strings.voiceRoomFallback },
              fontWeight = FontWeight.Bold,
              fontSize = 16.sp,
              color = MaterialTheme.colorScheme.onSurface
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(EmeraldSuccess))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                "WebRTC • ${rtcCallState.qualityLabel} • ${displayParticipants.size} ${strings.activeStatus}",
                fontSize = 11.sp,
                color = EmeraldSuccess
              )
            }
          }
        },
        actions = {
          IconButton(
            onClick = { showDiagnostics = true },
            modifier = Modifier.size(48.dp).testTag("voice_diagnostics_button")
          ) {
            Icon(Icons.Filled.GraphicEq, contentDescription = strings.voiceDiagnostics, tint = MaterialTheme.colorScheme.primary)
          }
          IconButton(onClick = { viewModel.leaveVoice() }, modifier = Modifier.size(48.dp)) {
            Icon(Icons.Filled.CallEnd, contentDescription = "Leave Voice", tint = RoseError)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f))
      )
    },
    bottomBar = {
      Card(
        modifier = Modifier.fillMaxWidth().navigationBarsPadding(),
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f)),
        elevation = CardDefaults.cardElevation(8.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
          horizontalArrangement = Arrangement.SpaceAround,
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(
            onClick = {
              val hasMic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
              if (!hasMic) {
                micPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
              } else {
                viewModel.toggleMute()
              }
            },
            modifier = Modifier
              .size(50.dp)
              .clip(CircleShape)
              .background(if (voiceState.isMuted) RoseError else MaterialTheme.colorScheme.surfaceVariant)
              .testTag("voice_mute_button")
          ) {
            Icon(
              if (voiceState.isMuted) Icons.Filled.MicOff else Icons.Filled.Mic,
              contentDescription = "Microphone",
              tint = if (voiceState.isMuted) Color.White else MaterialTheme.colorScheme.onSurface
            )
          }

          IconButton(
            onClick = { viewModel.toggleDeafen() },
            modifier = Modifier
              .size(50.dp)
              .clip(CircleShape)
              .background(if (voiceState.isDeafened) RoseError else MaterialTheme.colorScheme.surfaceVariant)
              .testTag("voice_deafen_button")
          ) {
            Icon(
              if (voiceState.isDeafened) Icons.Filled.HeadsetOff else Icons.Filled.Headset,
              contentDescription = "Headset",
              tint = if (voiceState.isDeafened) Color.White else MaterialTheme.colorScheme.onSurface
            )
          }

          IconButton(
            onClick = {
              if (voiceState.isCameraOn) {
                viewModel.setCameraActive(false)
              } else {
                val hasCam = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                if (hasCam) {
                  viewModel.setCameraActive(true)
                } else {
                  cameraPermLauncher.launch(Manifest.permission.CAMERA)
                }
              }
            },
            modifier = Modifier
              .size(50.dp)
              .clip(CircleShape)
              .background(if (voiceState.isCameraOn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
              .testTag("voice_camera_button")
          ) {
            Icon(
              if (voiceState.isCameraOn) Icons.Filled.Videocam else Icons.Filled.VideocamOff,
              contentDescription = "Camera",
              tint = if (voiceState.isCameraOn) Color.White else MaterialTheme.colorScheme.onSurface
            )
          }

          IconButton(
            onClick = {
              if (voiceState.isScreenSharing || busSharing) {
                viewModel.setScreenSharingActive(false)
              } else {
                val mgr = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                screenShareLauncher.launch(mgr.createScreenCaptureIntent())
              }
            },
            modifier = Modifier
              .size(50.dp)
              .clip(CircleShape)
              .background(if (voiceState.isScreenSharing || busSharing) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
              .testTag("voice_screenshare_button")
          ) {
            Icon(
              if (voiceState.isScreenSharing || busSharing) Icons.Filled.StopScreenShare else Icons.Filled.ScreenShare,
              contentDescription = "Share Screen",
              tint = if (voiceState.isScreenSharing || busSharing) Color.White else MaterialTheme.colorScheme.onSurface
            )
          }

          IconButton(
            onClick = { viewModel.leaveVoice() },
            modifier = Modifier
              .size(50.dp)
              .clip(CircleShape)
              .background(RoseError)
              .testTag("voice_leave_button")
          ) {
            Icon(Icons.Filled.CallEnd, contentDescription = "Leave", tint = Color.White)
          }
        }
      }
    },
    containerColor = Color.Transparent
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(16.dp)
    ) {
      rtcCallState.errorMessage?.let { err ->
        Surface(
          modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
          shape = RoundedCornerShape(10.dp),
          color = RoseError.copy(alpha = 0.2f),
          border = androidx.compose.foundation.BorderStroke(1.dp, RoseError)
        ) {
          Text(err, color = RoseError, fontSize = 12.sp, modifier = Modifier.padding(10.dp))
        }
      }
      if ((voiceState.isScreenSharing || busSharing) && latestScreenFrame != null) {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .height(175.dp)
            .padding(bottom = 12.dp),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = Color.Black),
          border = androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
        ) {
          Box(modifier = Modifier.fillMaxSize()) {
            Image(
              bitmap = latestScreenFrame!!.asImageBitmap(),
              contentDescription = "Live Screen Share",
              contentScale = ContentScale.Fit,
              modifier = Modifier.fillMaxSize()
            )
            Surface(
              modifier = Modifier.align(Alignment.TopStart).padding(8.dp),
              shape = RoundedCornerShape(6.dp),
              color = RoseError.copy(alpha = 0.9f)
            ) {
              Text("LIVE SCREEN", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
            }
          }
        }
      }

      Text(
        text = "${strings.activeParticipantsHeader} (${displayParticipants.size})",
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(bottom = 10.dp)
      )

      if (displayParticipants.isEmpty()) {
        Surface(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          color = MaterialTheme.colorScheme.surface
        ) {
          Text(
            text = strings.voiceEmptyTitle,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 12.sp,
            modifier = Modifier.padding(16.dp)
          )
        }
      } else {
        LazyVerticalGrid(
          columns = GridCells.Fixed(2),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.heightIn(max = 260.dp)
        ) {
          items(displayParticipants, key = { it.userId }) { p ->
            val isSelf = p.userId == currentUser?.id
            val scaleAmt by animateFloatAsState(
              targetValue = if (p.isSpeaking) 1.04f + (if (isSelf) micLevel * 0.06f else 0.03f) else 1f,
              animationSpec = tween(120),
              label = "speaking_scale"
            )
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .height(145.dp)
                .then(
                  if (p.isSpeaking) Modifier.border(2.dp, EmeraldSuccess, RoundedCornerShape(14.dp))
                  else Modifier.border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                ),
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
              Box(modifier = Modifier.fillMaxSize()) {
                val remoteTrack = remoteVideoTracks[p.userId]
                if (isSelf && localVideoTrack != null) {
                  WebRtcVideoRendererView(
                    videoTrack = localVideoTrack!!,
                    mirror = true,
                    modifier = Modifier.fillMaxSize()
                  )
                } else if (!isSelf && remoteTrack != null) {
                  WebRtcVideoRendererView(
                    videoTrack = remoteTrack,
                    mirror = false,
                    modifier = Modifier.fillMaxSize()
                  )
                  Box(
                    modifier = Modifier
                      .align(Alignment.BottomStart)
                      .fillMaxWidth()
                      .background(Color.Black.copy(alpha = 0.55f))
                      .padding(horizontal = 8.dp, vertical = 4.dp)
                  ) {
                    Text(
                      text = "${p.displayName} (Video)",
                      color = Color.White,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis
                    )
                  }
                } else if (isSelf && voiceState.isCameraOn) {
                  CameraXLivePreview(modifier = Modifier.fillMaxSize())
                  Box(
                    modifier = Modifier
                      .align(Alignment.BottomStart)
                      .fillMaxWidth()
                      .background(Color.Black.copy(alpha = 0.55f))
                      .padding(horizontal = 8.dp, vertical = 4.dp)
                  ) {
                    Text(
                      text = "${p.displayName} (OnCam)",
                      color = Color.White,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis
                    )
                  }
                } else {
                  Column(
                    modifier = Modifier.fillMaxSize().padding(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                  ) {
                    Box(modifier = Modifier.scale(scaleAmt)) {
                      UserAvatar(
                        avatarUri = p.avatarUri,
                        displayName = p.displayName,
                        size = 54.dp,
                        frameId = if (isSelf) currentUser?.equippedFrame else null
                      )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                      text = if (isSelf) "${p.displayName} (You)" else p.displayName,
                      fontWeight = FontWeight.Bold,
                      fontSize = 12.sp,
                      color = MaterialTheme.colorScheme.onSurface,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis
                    )
                    Text(
                      text = when {
                        p.isDeafened -> strings.deafenedStatus
                        p.isMuted -> strings.mutedStatus
                        p.isSpeaking -> strings.speakingStatus
                        p.isCameraOn -> strings.cameraOnStatus
                        p.isScreenSharing -> strings.screenShareStatus
                        else -> strings.readyToSpeakStatus
                      },
                      fontSize = 10.sp,
                      color = if (p.isMuted || p.isDeafened) RoseError else if (p.isSpeaking) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                }
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(18.dp))

      Text(
        text = strings.soundboardHeader,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        letterSpacing = 1.sp
      )
      Text(
        text = strings.soundboardDesc,
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 2.dp, bottom = 10.dp)
      )

      val soundList = listOf(
        Triple("Airhorn", "horn", Icons.Filled.Campaign),
        Triple("Applause", "applause", Icons.Filled.ThumbUp),
        Triple("Good Game", "gg", Icons.Filled.EmojiEvents),
        Triple("Victory Chime", "victory", Icons.Filled.MusicNote),
        Triple("Bruh / Error", "bruh", Icons.Filled.GpsFixed),
        Triple("Drumroll", "drumroll", Icons.Filled.GraphicEq)
      )

      LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.weight(1f)
      ) {
        items(soundList) { sound ->
          Card(
            modifier = Modifier.fillMaxWidth().clickable { viewModel.playSoundboard(sound.second, sound.first) },
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = CardDefaults.outlinedCardBorder().copy(
              brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.outline, MaterialTheme.colorScheme.outline))
            )
          ) {
            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
              Icon(sound.third, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(sound.first, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
            }
          }
        }
      }
    }

    if (showDiagnostics) {
      VoiceDiagnosticsDialog(viewModel = viewModel) { showDiagnostics = false }
    }
  }
}

@Composable
private fun CameraXLivePreview(modifier: Modifier = Modifier) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current
  AndroidView(
    modifier = modifier,
    factory = { ctx ->
      val previewView = PreviewView(ctx).apply {
        scaleType = PreviewView.ScaleType.FILL_CENTER
      }
      val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
      cameraProviderFuture.addListener({
        try {
          val cameraProvider = cameraProviderFuture.get()
          val preview = Preview.Builder().build().also {
            it.surfaceProvider = previewView.surfaceProvider
          }
          val selector = if (cameraProvider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)) {
            CameraSelector.DEFAULT_FRONT_CAMERA
          } else {
            CameraSelector.DEFAULT_BACK_CAMERA
          }
          cameraProvider.unbindAll()
          cameraProvider.bindToLifecycle(lifecycleOwner, selector, preview)
        } catch (_: Exception) {
        }
      }, ContextCompat.getMainExecutor(ctx))
      previewView
    }
  )
}
