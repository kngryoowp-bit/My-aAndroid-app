package com.example.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

// XChat V2.0 — Cinematic Monochrome Obsidian Glass Tokens
val ObsidianBlack = Color(0xFF07080B)
val CharcoalDeep = Color(0xFF0D0F14)
val CharcoalSurface = Color(0xFF13161D)
val CharcoalElevated = Color(0xFF1B1F29)
val GlassBorderLight = Color(0x2EFFFFFF) // ~18% translucent white border
val GlassBorderSubtle = Color(0x1AFFFFFF) // ~10% subtle divider
val GlassFillDark = Color(0xB812151C) // ~72% frosted obsidian glass
val GlassFillElevated = Color(0xCC1A1E28) // ~80% elevated glass
val SilverAccent = Color(0xFFC4C9D4)
val SilverMuted = Color(0xFF8C93A3)
val PureWhiteText = Color(0xFFF5F7FA)

// Legacy compatibility aliases mapped seamlessly to Obsidian / Glass palette
val DiscordBg = CharcoalDeep
val DiscordSurface = CharcoalSurface
val DiscordDeep = ObsidianBlack
val DiscordElevated = CharcoalElevated
val DiscordDivider = Color(0xFF272C38)
val DiscordTextPrimary = PureWhiteText
val DiscordTextSecondary = SilverAccent
val DiscordTextMuted = SilverMuted

// Signature Accent Palette
val PurplePrimary = Color(0xFF8B5CF6)
val PurpleDeep = Color(0xFF6D28D9)
val PurpleLight = Color(0xFFA78BFA)
val PurpleContainer = Color(0xFF28203E)

// Semantic Status & Tier Colors
val EmeraldSuccess = Color(0xFF22C55E)
val AmberWarning = Color(0xFFF59E0B)
val RoseError = Color(0xFFEF4444)
val CyanInfo = Color(0xFF38BDF8)

// Tiers: Astrix & Astral
val AstrixGold = Color(0xFFF59E0B)
val AstralViolet = Color(0xFFC4C9D4)

// Light Theme tokens
val Slate50 = Color(0xFFF8FAFC)
val Slate100 = Color(0xFFF1F5F9)
val Slate200 = Color(0xFFE2E8F0)
val Slate300 = Color(0xFFCBD5E1)
val Slate400 = Color(0xFF94A3B8)
val Slate500 = Color(0xFF64748B)
val Slate600 = Color(0xFF475569)
val Slate700 = Color(0xFF334155)
val Slate800 = Color(0xFF1E293B)
val Slate900 = Color(0xFF0F172A)
val IndigoPrimary = SilverAccent
val IndigoSecondary = PureWhiteText
val IndigoLight = CharcoalElevated
val VioletAccent = SilverAccent

object ColorHelper {
  fun parseColorsCsv(csv: String?, fallback: List<Long>): List<Color> {
    if (csv.isNullOrBlank()) return fallback.map { Color(it) }
    val parsed = csv.split(",").mapNotNull { hex ->
      val clean = hex.trim()
      clean.toLongOrNull() ?: clean.removePrefix("0x").removePrefix("#").toLongOrNull(16)?.let {
        if (clean.removePrefix("#").length == 6) it or 0xFF000000L else it
      }
    }
    return if (parsed.isEmpty()) fallback.map { Color(it) } else parsed.map { Color(it) }
  }

  fun toHex6(color: Color): String {
    val rgb = color.toArgb() and 0xFFFFFF
    return "#" + rgb.toString(16).lowercase().padStart(6, '0')
  }

  fun toHexArgLong(color: Color): String {
    val argb = color.toArgb().toLong() and 0xFFFFFFFFL
    return "0x" + argb.toString(16).uppercase().padStart(8, '0')
  }

  fun parseHex6OrNull(hexInput: String): Color? {
    val clean = hexInput.trim().removePrefix("#").removePrefix("0x").removePrefix("0X")
    if (clean.length != 6) return null
    val rgb = clean.toLongOrNull(16) ?: return null
    return Color(rgb or 0xFF000000L)
  }

  fun colorToHsv(color: Color): FloatArray {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(color.toArgb(), hsv)
    return hsv
  }

  fun hsvToColor(hue: Float, saturation: Float, value: Float): Color {
    val argb = android.graphics.Color.HSVToColor(
      floatArrayOf(
        hue.coerceIn(0f, 360f),
        saturation.coerceIn(0f, 1f),
        value.coerceIn(0f, 1f)
      )
    )
    return Color(argb)
  }
}
