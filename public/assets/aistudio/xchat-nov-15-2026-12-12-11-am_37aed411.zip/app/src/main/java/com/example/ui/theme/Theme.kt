package com.example.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

data class AppThemeConfig(
  val id: String,
  val name: String,
  val isDark: Boolean,
  val primary: Color,
  val secondary: Color,
  val background: Color,
  val surface: Color,
  val surfaceVariant: Color,
  val gradientColors: List<Color>,
  val isAstralOnly: Boolean
)

object AppThemePresets {
  val OBSIDIAN_MARBLE = AppThemeConfig(
    id = "obsidian_marble",
    name = "Obsidian Moving Marble (Gratis)",
    isDark = true,
    primary = SilverAccent,
    secondary = PureWhiteText,
    background = ObsidianBlack,
    surface = CharcoalSurface,
    surfaceVariant = CharcoalElevated,
    gradientColors = listOf(Color(0xFFF5F7FA), Color(0xFFC4C9D4), Color(0xFF646C7C)),
    isAstralOnly = false
  )

  val SILVER_SLATE = AppThemeConfig(
    id = "silver_slate",
    name = "Silver Monochrome Glass (Gratis)",
    isDark = true,
    primary = Color(0xFFE2E8F0),
    secondary = Color(0xFF94A3B8),
    background = Color(0xFF0A0C10),
    surface = Color(0xFF141820),
    surfaceVariant = Color(0xFF1E2430),
    gradientColors = listOf(Color(0xFFFFFFFF), Color(0xFF94A3B8)),
    isAstralOnly = false
  )

  val DISCORD_PURPLE = AppThemeConfig(
    id = "discord_purple",
    name = "Midnight Violet",
    isDark = true,
    primary = PurplePrimary,
    secondary = PurpleLight,
    background = Color(0xFF14151B),
    surface = Color(0xFF1C1E26),
    surfaceVariant = Color(0xFF252834),
    gradientColors = listOf(Color(0xFF7C3AED), Color(0xFFA855F7)),
    isAstralOnly = false
  )

  val ASTRAL_NEBULA = AppThemeConfig(
    id = "astral_nebula",
    name = "Astral Nebula",
    isDark = true,
    primary = Color(0xFFC084FC),
    secondary = Color(0xFFF472B6),
    background = Color(0xFF150E22),
    surface = Color(0xFF1D152E),
    surfaceVariant = Color(0xFF261C3B),
    gradientColors = listOf(Color(0xFF7C3AED), Color(0xFFEC4899), Color(0xFF8B5CF6)),
    isAstralOnly = false
  )

  val MIDNIGHT_AURORA = AppThemeConfig(
    id = "midnight_aurora",
    name = "Midnight Aurora",
    isDark = true,
    primary = Color(0xFF38BDF8),
    secondary = Color(0xFFA855F7),
    background = Color(0xFF0B1220),
    surface = Color(0xFF111B2E),
    surfaceVariant = Color(0xFF1A2740),
    gradientColors = listOf(Color(0xFF0EA5E9), Color(0xFF6366F1), Color(0xFFA855F7)),
    isAstralOnly = false
  )

  val CRIMSON_VELVET = AppThemeConfig(
    id = "crimson_velvet",
    name = "Crimson Velvet",
    isDark = true,
    primary = Color(0xFFF43F5E),
    secondary = Color(0xFFFBBF24),
    background = Color(0xFF190E13),
    surface = Color(0xFF23141B),
    surfaceVariant = Color(0xFF2E1B24),
    gradientColors = listOf(Color(0xFFE11D48), Color(0xFFF97316), Color(0xFFEAB308)),
    isAstralOnly = false
  )

  val EMERALD_MATRIX = AppThemeConfig(
    id = "emerald_matrix",
    name = "Emerald Cyber",
    isDark = true,
    primary = Color(0xFF10B981),
    secondary = Color(0xFF2DD4BF),
    background = Color(0xFF091614),
    surface = Color(0xFF0F211E),
    surfaceVariant = Color(0xFF172F2B),
    gradientColors = listOf(Color(0xFF059669), Color(0xFF14B8A6), Color(0xFF38BDF8)),
    isAstralOnly = false
  )

  val PORCELAIN_LIGHT = AppThemeConfig(
    id = "porcelain_light",
    name = "Porcelain Light Glass",
    isDark = false,
    primary = Color(0xFF1E293B),
    secondary = Color(0xFF475569),
    background = Slate50,
    surface = Color.White,
    surfaceVariant = Slate100,
    gradientColors = listOf(Color(0xFF0F172A), Color(0xFF475569)),
    isAstralOnly = false
  )

  val all = listOf(
    OBSIDIAN_MARBLE,
    SILVER_SLATE,
    ASTRAL_NEBULA,
    MIDNIGHT_AURORA,
    CRIMSON_VELVET,
    EMERALD_MATRIX,
    PORCELAIN_LIGHT,
    DISCORD_PURPLE
  )

  fun find(id: String?): AppThemeConfig =
    all.find { it.id == id } ?: OBSIDIAN_MARBLE
}

val LocalAppThemeConfig = compositionLocalOf { AppThemePresets.OBSIDIAN_MARBLE }

@Composable
fun AppThemeAccentBrush(): Brush {
  val cfg = LocalAppThemeConfig.current
  return Brush.linearGradient(cfg.gradientColors)
}

@Composable
fun MyApplicationTheme(
  themeId: String = "obsidian_marble",
  customGradientCsv: String? = null,
  customAccentHex: Long? = null,
  fontKey: String = "SERIF",
  content: @Composable () -> Unit,
) {
  val basePreset = AppThemePresets.find(themeId)
  val customColors = if (!customGradientCsv.isNullOrBlank()) {
    ColorHelper.parseColorsCsv(customGradientCsv, emptyList())
  } else emptyList()

  val activeConfig = when {
    customColors.size >= 2 -> basePreset.copy(
      primary = customColors.first(),
      secondary = customColors.last(),
      gradientColors = customColors
    )
    customAccentHex != null && customAccentHex != 0L && customAccentHex != 0xFFC4C9D4L -> {
      val c = Color(customAccentHex)
      basePreset.copy(
        primary = c,
        secondary = c.copy(alpha = 0.78f),
        gradientColors = listOf(c, basePreset.secondary)
      )
    }
    else -> basePreset
  }

  val onPrimaryColor = if (activeConfig.isDark && activeConfig.primary.red > 0.68f && activeConfig.primary.green > 0.68f && activeConfig.primary.blue > 0.68f) {
    ObsidianBlack
  } else {
    Color.White
  }

  val colorScheme: ColorScheme = if (activeConfig.isDark) {
    darkColorScheme(
      primary = activeConfig.primary,
      onPrimary = onPrimaryColor,
      primaryContainer = activeConfig.primary.copy(alpha = 0.20f),
      onPrimaryContainer = PureWhiteText,
      secondary = activeConfig.secondary,
      onSecondary = ObsidianBlack,
      secondaryContainer = activeConfig.surfaceVariant,
      onSecondaryContainer = PureWhiteText,
      tertiary = activeConfig.secondary,
      onTertiary = ObsidianBlack,
      background = activeConfig.background,
      onBackground = PureWhiteText,
      surface = activeConfig.surface,
      onSurface = PureWhiteText,
      surfaceVariant = activeConfig.surfaceVariant,
      onSurfaceVariant = SilverAccent,
      outline = GlassBorderLight,
      error = RoseError,
      onError = Color.White
    )
  } else {
    lightColorScheme(
      primary = activeConfig.primary,
      onPrimary = Color.White,
      primaryContainer = activeConfig.primary.copy(alpha = 0.14f),
      onPrimaryContainer = activeConfig.primary,
      secondary = activeConfig.secondary,
      onSecondary = Color.White,
      secondaryContainer = Slate100,
      onSecondaryContainer = Slate900,
      tertiary = activeConfig.secondary,
      onTertiary = Color.White,
      background = activeConfig.background,
      onBackground = Slate900,
      surface = activeConfig.surface,
      onSurface = Slate900,
      surfaceVariant = activeConfig.surfaceVariant,
      onSurfaceVariant = Slate600,
      outline = Slate300,
      error = RoseError,
      onError = Color.White
    )
  }

  val fontFamily = AppFontOption.fromKey(fontKey).fontFamily

  CompositionLocalProvider(LocalAppThemeConfig provides activeConfig) {
    MaterialTheme(
      colorScheme = colorScheme,
      typography = buildTypography(fontFamily),
      content = content
    )
  }
}
