package com.example.utils

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ConnectedAccount(
  val platformId: String,
  val platformName: String,
  val handle: String,
  val verified: Boolean = false,
  val subtitle: String = ""
)

data class TrackedAppInfo(
  val id: String,
  val displayName: String,
  val packageName: String,
  val category: String,
  val colorHex: Long
)

data class DetectedAppActivity(
  val appName: String,
  val packageName: String,
  val startedAt: Long
)

object AppActivityTracker {
  private val httpClient = OkHttpClient.Builder()
    .connectTimeout(12, TimeUnit.SECONDS)
    .readTimeout(15, TimeUnit.SECONDS)
    .build()

  val connectionCatalog: List<TrackedAppInfo> = listOf(
    TrackedAppInfo("github", "GitHub", "com.github.android", "Dev", 0xFF6E5494),
    TrackedAppInfo("roblox", "Roblox", "com.roblox.client", "Game", 0xFFEF4444),
    TrackedAppInfo("mlbb", "Mobile Legends", "com.mobile.legends", "Game", 0xFF3B82F6),
    TrackedAppInfo("minecraft", "Minecraft", "com.mojang.minecraftpe", "Game", 0xFF22C55E),
    TrackedAppInfo("valorant", "Valorant", "com.riotgames.valorant", "Game", 0xFFF43F5E),
    TrackedAppInfo("freefire", "Free Fire", "com.dts.freefireth", "Game", 0xFFF97316),
    TrackedAppInfo("pubg", "PUBG Mobile", "com.tencent.ig", "Game", 0xFFEAB308),
    TrackedAppInfo("genshin", "Genshin Impact", "com.miHoYo.GenshinImpact", "Game", 0xFFA855F7),
    TrackedAppInfo("spotify", "Spotify", "com.spotify.music", "Music", 0xFF1DB954),
    TrackedAppInfo("youtube", "YouTube", "com.google.android.youtube", "Media", 0xFFFF0000),
    TrackedAppInfo("discord", "Discord", "com.discord", "Social", 0xFF5865F2),
    TrackedAppInfo("steam", "Steam", "com.valvesoftware.android.steam.community", "Game", 0xFF1B2838)
  )

  fun hasUsageAccess(context: Context): Boolean {
    return try {
      val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
      val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
      } else {
        @Suppress("DEPRECATION")
        appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
      }
      mode == AppOpsManager.MODE_ALLOWED
    } catch (_: Exception) {
      false
    }
  }

  fun openUsageAccessSettings(context: Context) {
    try {
      val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      context.startActivity(intent)
    } catch (_: Exception) {
    }
  }

  fun parseConnections(rawJson: String?): List<ConnectedAccount> {
    if (rawJson.isNullOrBlank()) return emptyList()
    return try {
      val arr = JSONArray(rawJson)
      buildList {
        for (i in 0 until arr.length()) {
          val obj = arr.optJSONObject(i) ?: continue
          val pid = obj.optString("platformId")
          val pname = obj.optString("platformName")
          val handle = obj.optString("handle")
          if (pid.isNotBlank() && handle.isNotBlank()) {
            add(
              ConnectedAccount(
                platformId = pid,
                platformName = pname.ifBlank { pid },
                handle = handle,
                verified = obj.optBoolean("verified", false),
                subtitle = obj.optString("subtitle", "")
              )
            )
          }
        }
      }
    } catch (_: Exception) {
      emptyList()
    }
  }

  fun serializeConnections(list: List<ConnectedAccount>): String {
    val arr = JSONArray()
    list.forEach { acc ->
      arr.put(
        JSONObject().apply {
          put("platformId", acc.platformId)
          put("platformName", acc.platformName)
          put("handle", acc.handle)
          put("verified", acc.verified)
          put("subtitle", acc.subtitle)
        }
      )
    }
    return arr.toString()
  }

  /**
   * Queries real public APIs for GitHub and Roblox to verify connected handles.
   */
  suspend fun verifyAndBuildConnection(platformId: String, rawHandle: String): ConnectedAccount = withContext(Dispatchers.IO) {
    val cleanHandle = rawHandle.trim().removePrefix("@")
    val meta = connectionCatalog.find { it.id == platformId }
    val platformName = meta?.displayName ?: platformId.replaceFirstChar { it.uppercase() }

    when (platformId) {
      "github" -> {
        try {
          val req = Request.Builder()
            .url("https://api.github.com/users/$cleanHandle")
            .header("User-Agent", "XChatAndroid/1.0")
            .get()
            .build()
          httpClient.newCall(req).execute().use { resp ->
            if (resp.isSuccessful) {
              val body = JSONObject(resp.body?.string() ?: "{}")
              val repos = body.optInt("public_repos", 0)
              val login = body.optString("login", cleanHandle)
              return@withContext ConnectedAccount("github", "GitHub", login, verified = true, subtitle = "$repos public repos")
            }
          }
        } catch (_: Exception) {
        }
        ConnectedAccount("github", "GitHub", cleanHandle, verified = false, subtitle = "Connected")
      }
      "roblox" -> {
        try {
          val payload = JSONObject().apply {
            put("usernames", JSONArray().put(cleanHandle))
            put("excludeBannedUsers", true)
          }.toString()
          val req = Request.Builder()
            .url("https://users.roblox.com/v1/usernames/users")
            .header("User-Agent", "XChatAndroid/1.0")
            .post(payload.toRequestBody("application/json".toMediaType()))
            .build()
          httpClient.newCall(req).execute().use { resp ->
            if (resp.isSuccessful) {
              val json = JSONObject(resp.body?.string() ?: "{}")
              val arr = json.optJSONArray("data")
              if (arr != null && arr.length() > 0) {
                val u = arr.getJSONObject(0)
                val name = u.optString("name", cleanHandle)
                val uid = u.optLong("id", 0L)
                return@withContext ConnectedAccount("roblox", "Roblox", name, verified = true, subtitle = "ID: $uid")
              }
            }
          }
        } catch (_: Exception) {
        }
        ConnectedAccount("roblox", "Roblox", cleanHandle, verified = false, subtitle = "Connected")
      }
      else -> ConnectedAccount(platformId, platformName, cleanHandle, verified = true, subtitle = meta?.category ?: "App")
    }
  }

  /**
   * Detects the currently active tracked game/app on device using Android UsageStatsManager.
   */
  fun detectForegroundConnectedApp(
    context: Context,
    connections: List<ConnectedAccount>,
    previousPkg: String?,
    previousStartedAt: Long
  ): DetectedAppActivity? {
    if (!hasUsageAccess(context)) return null
    val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return null
    val now = System.currentTimeMillis()
    val trackedByPkg = connectionCatalog.associateBy { it.packageName }
    val connectedPlatformIds = connections.map { it.platformId }.toSet()

    // Check UsageEvents in the last 3 minutes for the most recent foreground app
    var latestForegroundPkg: String? = null
    var latestForegroundTime = 0L
    try {
      val events = usm.queryEvents(now - 180_000L, now)
      val event = UsageEvents.Event()
      while (events.hasNextEvent()) {
        events.getNextEvent(event)
        val isResume = event.eventType == UsageEvents.Event.ACTIVITY_RESUMED ||
          @Suppress("DEPRECATION") (event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND)
        if (isResume && event.timeStamp >= latestForegroundTime && event.packageName != context.packageName) {
          latestForegroundTime = event.timeStamp
          latestForegroundPkg = event.packageName
        }
      }
    } catch (_: Exception) {
    }

    if (latestForegroundPkg == null) {
      val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 120_000L, now)
      val top = stats?.filter { it.packageName != context.packageName }?.maxByOrNull { it.lastTimeUsed }
      if (top != null && now - top.lastTimeUsed < 45_000L) {
        latestForegroundPkg = top.packageName
        latestForegroundTime = top.lastTimeUsed
      }
    }

    val activePkg = latestForegroundPkg ?: return null
    val matchedApp = trackedByPkg[activePkg] ?: return null
    // Match either connected apps OR any supported game/music/dev app in catalog
    if (connectedPlatformIds.isNotEmpty() && matchedApp.id !in connectedPlatformIds && matchedApp.category != "Game") {
      return null
    }
    val startedAt = if (previousPkg == activePkg && previousStartedAt > 0L) {
      previousStartedAt
    } else {
      latestForegroundTime.takeIf { it > 0L } ?: now
    }
    return DetectedAppActivity(
      appName = matchedApp.displayName,
      packageName = activePkg,
      startedAt = startedAt
    )
  }
}
