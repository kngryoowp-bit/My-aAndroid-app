package com.example.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.example.data.model.AudioTrackEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

enum class AudioRepeatMode {
  OFF, ALL, ONE
}

data class AudioPlayerUiState(
  val currentTrack: AudioTrackEntity? = null,
  val queue: List<AudioTrackEntity> = emptyList(),
  val currentIndex: Int = -1,
  val isPlaying: Boolean = false,
  val positionMs: Long = 0L,
  val durationMs: Long = 0L,
  val volume: Float = 0.85f,
  val shuffleEnabled: Boolean = false,
  val repeatMode: AudioRepeatMode = AudioRepeatMode.OFF,
  val statusMessage: String? = null
)

object AudioPlayerManager {
  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
  private val mainHandler = Handler(Looper.getMainLooper())

  private val _state = MutableStateFlow(AudioPlayerUiState())
  val state = _state.asStateFlow()

  var onTrackChangedListener: ((AudioTrackEntity?, Boolean, Long, Long) -> Unit)? = null

  private var exoPlayer: ExoPlayer? = null
  private var tickerJob: Job? = null

  private fun ensurePlayer(context: Context): ExoPlayer {
    exoPlayer?.let { return it }
    val player = ExoPlayer.Builder(context.applicationContext).build().apply {
      volume = _state.value.volume
      addListener(object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
          val cur = _state.value
          _state.value = cur.copy(
            isPlaying = isPlaying,
            statusMessage = if (isPlaying) null else cur.statusMessage
          )
          onTrackChangedListener?.invoke(cur.currentTrack, isPlaying, currentPosition.coerceAtLeast(0L), duration.coerceAtLeast(0L))
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
          val p = exoPlayer ?: return
          val dur = p.duration.takeIf { it > 0L } ?: _state.value.currentTrack?.durationMs ?: 0L
          _state.value = _state.value.copy(durationMs = dur)
          if (playbackState == Player.STATE_ENDED) {
            handleTrackEnded(context.applicationContext)
          }
        }

        override fun onPlayerError(error: PlaybackException) {
          val tr = _state.value.currentTrack
          val hint = if (tr != null && isExternalWebLink(tr.sourceUri)) {
            "Web link cannot be streamed directly; tap External Open for official app."
          } else {
            error.localizedMessage ?: "Audio playback error"
          }
          _state.value = _state.value.copy(isPlaying = false, statusMessage = hint)
        }
      })
    }
    exoPlayer = player
    startTicker()
    return player
  }

  private fun startTicker() {
    tickerJob?.cancel()
    tickerJob = scope.launch {
      while (isActive) {
        val p = exoPlayer
        if (p != null && _state.value.currentTrack != null) {
          val pos = p.currentPosition.coerceAtLeast(0L)
          val dur = p.duration.takeIf { it > 0L } ?: _state.value.durationMs
          if (pos != _state.value.positionMs || dur != _state.value.durationMs) {
            _state.value = _state.value.copy(positionMs = pos, durationMs = dur)
          }
        }
        delay(500L)
      }
    }
  }

  fun playPlaylist(context: Context, tracks: List<AudioTrackEntity>, startIndex: Int = 0) {
    if (tracks.isEmpty()) return
    val idx = startIndex.coerceIn(0, tracks.lastIndex)
    mainHandler.post {
      _state.value = _state.value.copy(queue = tracks, currentIndex = idx)
      loadAndPlay(context.applicationContext, tracks[idx])
    }
  }

  fun playSingleTrack(context: Context, track: AudioTrackEntity) {
    mainHandler.post {
      val curQ = _state.value.queue.toMutableList()
      val existingIdx = curQ.indexOfFirst { it.id == track.id }
      val idx = if (existingIdx >= 0) existingIdx else {
        curQ.add(track)
        curQ.lastIndex
      }
      _state.value = _state.value.copy(queue = curQ, currentIndex = idx)
      loadAndPlay(context.applicationContext, track)
    }
  }

  private fun loadAndPlay(context: Context, track: AudioTrackEntity) {
    val src = track.sourceUri.trim()
    if (isExternalWebLink(src)) {
      exoPlayer?.pause()
      _state.value = _state.value.copy(
        currentTrack = track,
        isPlaying = false,
        positionMs = 0L,
        durationMs = track.durationMs,
        statusMessage = "External link (${track.sourceType}) — tap external player button to launch official app."
      )
      onTrackChangedListener?.invoke(track, false, 0L, track.durationMs)
      return
    }
    val uri = when {
      src.startsWith("/") -> Uri.fromFile(File(src))
      else -> Uri.parse(src)
    }
    val player = ensurePlayer(context)
    player.setMediaItem(MediaItem.fromUri(uri))
    player.prepare()
    player.playWhenReady = true
    _state.value = _state.value.copy(
      currentTrack = track,
      isPlaying = true,
      positionMs = 0L,
      durationMs = track.durationMs,
      statusMessage = null
    )
    onTrackChangedListener?.invoke(track, true, 0L, track.durationMs)
  }

  fun togglePlayPause(context: Context) {
    mainHandler.post {
      val cur = _state.value
      val track = cur.currentTrack
      if (track != null && isExternalWebLink(track.sourceUri)) {
        openExternalOfficialService(context, track)
        return@post
      }
      val player = ensurePlayer(context)
      if (player.isPlaying) {
        player.pause()
      } else {
        if (player.mediaItemCount == 0 && track != null) {
          loadAndPlay(context.applicationContext, track)
        } else {
          player.play()
        }
      }
    }
  }

  fun nextTrack(context: Context) {
    mainHandler.post {
      val cur = _state.value
      if (cur.queue.isEmpty()) return@post
      val nextIdx = if (cur.shuffleEnabled && cur.queue.size > 1) {
        ((cur.queue.indices) - cur.currentIndex).random()
      } else {
        (cur.currentIndex + 1) % cur.queue.size
      }
      _state.value = cur.copy(currentIndex = nextIdx)
      loadAndPlay(context.applicationContext, cur.queue[nextIdx])
    }
  }

  fun previousTrack(context: Context) {
    mainHandler.post {
      val cur = _state.value
      if (cur.queue.isEmpty()) return@post
      val prevIdx = if (cur.currentIndex - 1 < 0) cur.queue.lastIndex else cur.currentIndex - 1
      _state.value = cur.copy(currentIndex = prevIdx)
      loadAndPlay(context.applicationContext, cur.queue[prevIdx])
    }
  }

  private fun handleTrackEnded(context: Context) {
    val cur = _state.value
    if (cur.queue.isEmpty()) {
      _state.value = cur.copy(isPlaying = false, positionMs = 0L)
      return
    }
    when (cur.repeatMode) {
      AudioRepeatMode.ONE -> cur.currentTrack?.let { loadAndPlay(context, it) }
      AudioRepeatMode.ALL -> nextTrack(context)
      AudioRepeatMode.OFF -> {
        if (cur.currentIndex < cur.queue.lastIndex) {
          nextTrack(context)
        } else {
          _state.value = cur.copy(isPlaying = false, positionMs = 0L)
        }
      }
    }
  }

  fun seekTo(posMs: Long) {
    mainHandler.post {
      exoPlayer?.seekTo(posMs.coerceAtLeast(0L))
      _state.value = _state.value.copy(positionMs = posMs.coerceAtLeast(0L))
    }
  }

  fun setVolume(vol: Float) {
    val clamped = vol.coerceIn(0f, 1f)
    mainHandler.post {
      exoPlayer?.volume = clamped
      _state.value = _state.value.copy(volume = clamped)
    }
  }

  fun toggleShuffle() {
    _state.value = _state.value.copy(shuffleEnabled = !_state.value.shuffleEnabled)
  }

  fun cycleRepeatMode() {
    val next = when (_state.value.repeatMode) {
      AudioRepeatMode.OFF -> AudioRepeatMode.ALL
      AudioRepeatMode.ALL -> AudioRepeatMode.ONE
      AudioRepeatMode.ONE -> AudioRepeatMode.OFF
    }
    _state.value = _state.value.copy(repeatMode = next)
  }

  fun openExternalOfficialService(context: Context, track: AudioTrackEntity) {
    val url = track.sourceUri.trim()
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    runCatching { context.startActivity(intent) }
  }

  private fun isExternalWebLink(source: String): Boolean {
    val lower = source.lowercase()
    return lower.contains("open.spotify.com") || lower.contains("spotify:") ||
      lower.contains("youtube.com/") || lower.contains("youtu.be/") ||
      lower.contains("music.youtube.com")
  }
}
