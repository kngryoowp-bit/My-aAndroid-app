package com.example.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

object CloudMediaHelper {
  @Volatile
  private var appContext: Context? = null

  private val decodedDataFileCache = object : LruCache<String, File>(128) {}
  private val remoteUrlFileCache = object : LruCache<String, File>(128) {}

  private val client = OkHttpClient.Builder()
    .followRedirects(true)
    .followSslRedirects(true)
    .connectTimeout(25, TimeUnit.SECONDS)
    .readTimeout(60, TimeUnit.SECONDS)
    .writeTimeout(60, TimeUnit.SECONDS)
    .build()

  fun init(context: Context) {
    appContext = context.applicationContext
  }

  /**
   * Normalizes tmpfiles.org URLs (both http:// and https://) to direct `/dl/` download URLs.
   */
  fun normalizeCloudUrl(url: String): String {
    val trimmed = url.trim()
    return when {
      trimmed.startsWith("http://tmpfiles.org/") ->
        if (trimmed.contains("/dl/")) trimmed.replaceFirst("http://", "https://")
        else trimmed.replaceFirst("http://tmpfiles.org/", "https://tmpfiles.org/dl/")
      trimmed.startsWith("https://tmpfiles.org/") ->
        if (trimmed.contains("/dl/")) trimmed
        else trimmed.replaceFirst("https://tmpfiles.org/", "https://tmpfiles.org/dl/")
      trimmed.startsWith("http://www.tmpfiles.org/") ->
        if (trimmed.contains("/dl/")) trimmed.replaceFirst("http://www.", "https://")
        else trimmed.replaceFirst("http://www.tmpfiles.org/", "https://tmpfiles.org/dl/")
      trimmed.startsWith("https://www.tmpfiles.org/") ->
        if (trimmed.contains("/dl/")) trimmed.replaceFirst("https://www.", "https://")
        else trimmed.replaceFirst("https://www.tmpfiles.org/", "https://tmpfiles.org/dl/")
      else -> trimmed
    }
  }

  /**
   * Resolves any media reference (`data:...;base64,...`, `file://`, `https://`, `content://`)
   * into a STABLE Coil-compatible model (`File`, `String`, or `Uri`) so recompositions never
   * re-decode Base64 byte arrays and never trigger flicker.
   */
  fun resolveCoilModel(uriOrData: String?, context: Context? = null): Any? {
    if (uriOrData.isNullOrBlank()) return null
    val resolvedCtx = context?.applicationContext ?: appContext
    return when {
      uriOrData.startsWith("data:") -> {
        resolveDataUriToStableFile(uriOrData, resolvedCtx) ?: decodeDataUriBytes(uriOrData)
      }
      uriOrData.startsWith("file://") -> {
        val path = Uri.parse(uriOrData).path
        val f = if (!path.isNullOrBlank()) File(path) else null
        if (f != null && f.exists() && f.length() > 0L) f else null
      }
      uriOrData.startsWith("http://") || uriOrData.startsWith("https://") -> {
        val normalized = normalizeCloudUrl(uriOrData)
        val cachedMem = remoteUrlFileCache.get(normalized)
        if (cachedMem != null && cachedMem.exists() && cachedMem.length() > 0L) {
          return cachedMem
        }
        if (resolvedCtx != null) {
          val cachedDisk = findDiskCachedRemoteFile(resolvedCtx, normalized)
          if (cachedDisk != null) {
            remoteUrlFileCache.put(normalized, cachedDisk)
            return cachedDisk
          }
        }
        normalized
      }
      else -> Uri.parse(uriOrData)
    }
  }

  private fun findDiskCachedRemoteFile(context: Context, normalizedUrl: String): File? {
    val cacheDir = File(context.cacheDir, "xchat_downloads")
    if (!cacheDir.exists()) return null
    val prefix = "${sha256Short(normalizedUrl).take(10)}_"
    val found = cacheDir.listFiles()?.firstOrNull { it.name.startsWith(prefix) && it.length() > 0L }
    return found
  }

  private fun cacheUploadedBytesLocally(context: Context, url: String, bytes: ByteArray, ext: String) {
    try {
      val normalized = normalizeCloudUrl(url)
      val cacheDir = File(context.cacheDir, "xchat_downloads").apply { if (!exists()) mkdirs() }
      val target = File(cacheDir, "${sha256Short(normalized).take(10)}_media.$ext")
      FileOutputStream(target).use { it.write(bytes) }
      if (target.exists() && target.length() > 0L) {
        remoteUrlFileCache.put(normalized, target)
      }
    } catch (_: Exception) {
    }
  }

  fun decodeDataUriBytes(dataUri: String): ByteArray? {
    val commaIdx = dataUri.indexOf(',')
    if (commaIdx <= 0) return null
    return try {
      Base64.decode(dataUri.substring(commaIdx + 1), Base64.DEFAULT)
    } catch (_: Exception) {
      null
    }
  }

  private fun mimeFromDataUri(dataUri: String): String {
    val semi = dataUri.indexOf(';')
    val colon = dataUri.indexOf(':')
    return if (colon in 0 until semi) {
      dataUri.substring(colon + 1, semi).lowercase()
    } else {
      "application/octet-stream"
    }
  }

  private fun extensionForMime(mime: String): String = when {
    mime.contains("gif") -> "gif"
    mime.contains("png") -> "png"
    mime.contains("webp") -> "webp"
    mime.contains("jpeg") || mime.contains("jpg") -> "jpg"
    mime.contains("mp4") -> "mp4"
    mime.contains("webm") -> "webm"
    mime.contains("pdf") -> "pdf"
    else -> "bin"
  }

  private fun sha256Short(input: String): String {
    val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
    return digest.take(16).joinToString("") { "%02x".format(it) }
  }

  private fun resolveDataUriToStableFile(dataUri: String, context: Context?): File? {
    val key = sha256Short(dataUri)
    decodedDataFileCache.get(key)?.let { cached ->
      if (cached.exists() && cached.length() > 0L) return cached
    }
    val cacheRoot = context?.cacheDir ?: return null
    val dir = File(cacheRoot, "data_media").apply { if (!exists()) mkdirs() }
    val ext = extensionForMime(mimeFromDataUri(dataUri))
    val target = File(dir, "$key.$ext")
    if (target.exists() && target.length() > 0L) {
      decodedDataFileCache.put(key, target)
      return target
    }
    val bytes = decodeDataUriBytes(dataUri) ?: return null
    return try {
      FileOutputStream(target).use { it.write(bytes) }
      decodedDataFileCache.put(key, target)
      target
    } catch (_: Exception) {
      null
    }
  }

  /**
   * Converts picked image/GIF/file into a cross-device shareable URI:
   * - Small GIFs (<= 420 KB) -> persistent base64 data URI (fast, zero expiry, < 600KB Firestore limit).
   * - Large GIFs -> uploads to permanent direct hosts (pomf2.lain.la -> uguu.se -> catbox.moe -> tmpfiles.org)
   *   and caches the bytes locally so it displays immediately without waiting for download.
   * - Static images -> memory-safe sampled decode + downscale (NEVER hangs/OOMs on 4K photos!).
   */
  suspend fun prepareCloudMediaUri(
    context: Context,
    sourceUriString: String,
    maxDimensionPx: Int = 512,
    preserveTransparency: Boolean = false
  ): String = withContext(Dispatchers.IO) {
    init(context)
    if (sourceUriString.startsWith("http://") || sourceUriString.startsWith("https://")) {
      return@withContext normalizeCloudUrl(sourceUriString)
    }
    if (sourceUriString.startsWith("data:")) {
      return@withContext sourceUriString
    }

    val bytes = readBytes(context, sourceUriString) ?: return@withContext sourceUriString
    val lower = sourceUriString.lowercase()
    val isGif = (bytes.size >= 3 && bytes[0] == 'G'.code.toByte() && bytes[1] == 'I'.code.toByte() && bytes[2] == 'F'.code.toByte()) ||
      lower.endsWith(".gif")

    if (isGif) {
      if (bytes.size <= 420_000) {
        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        val dataUri = "data:image/gif;base64,$b64"
        resolveDataUriToStableFile(dataUri, context)
        return@withContext dataUri
      } else {
        val uploaded = uploadFileBytes(bytes, "anim_${System.currentTimeMillis()}.gif", "image/gif")
        if (!uploaded.isNullOrBlank()) {
          cacheUploadedBytesLocally(context, uploaded, bytes, "gif")
          return@withContext uploaded
        }
        return@withContext sourceUriString
      }
    }

    // Bounds-first sampled decode to avoid OOM/hang on huge photos
    val bmp = decodeSampledBitmap(bytes, maxDimensionPx)
    if (bmp != null) {
      val scaled = scaleBitmap(bmp, maxDimensionPx)
      val out = ByteArrayOutputStream()
      val mime: String
      if (preserveTransparency) {
        scaled.compress(Bitmap.CompressFormat.PNG, 92, out)
        mime = "image/png"
      } else {
        scaled.compress(Bitmap.CompressFormat.JPEG, 84, out)
        mime = "image/jpeg"
      }
      val compressed = out.toByteArray()
      if (scaled !== bmp) scaled.recycle()
      bmp.recycle()
      if (compressed.size <= 420_000) {
        val b64 = Base64.encodeToString(compressed, Base64.NO_WRAP)
        val dataUri = "data:$mime;base64,$b64"
        resolveDataUriToStableFile(dataUri, context)
        return@withContext dataUri
      } else {
        val ext = if (preserveTransparency) "png" else "jpg"
        val uploaded = uploadFileBytes(compressed, "img_${System.currentTimeMillis()}.$ext", mime)
        if (!uploaded.isNullOrBlank()) {
          cacheUploadedBytesLocally(context, uploaded, compressed, ext)
          return@withContext uploaded
        }
        return@withContext sourceUriString
      }
    }

    val fileName = Uri.parse(sourceUriString).lastPathSegment ?: "file_${System.currentTimeMillis()}.bin"
    val uploaded = uploadFileBytes(bytes, fileName, "application/octet-stream")
    if (!uploaded.isNullOrBlank()) {
      val ext = fileName.substringAfterLast('.', "bin").take(8)
      cacheUploadedBytesLocally(context, uploaded, bytes, ext)
      uploaded
    } else {
      sourceUriString
    }
  }

  suspend fun uploadPickedFile(context: Context, picked: PickedFileInfo): PickedFileInfo = withContext(Dispatchers.IO) {
    init(context)
    if (picked.uri.startsWith("http://") || picked.uri.startsWith("https://")) {
      return@withContext picked.copy(uri = normalizeCloudUrl(picked.uri))
    }
    val bytes = readBytes(context, picked.uri) ?: return@withContext picked
    val mime = picked.mimeType.ifBlank { "application/octet-stream" }
    val isGif = (bytes.size >= 3 && bytes[0] == 'G'.code.toByte() && bytes[1] == 'I'.code.toByte() && bytes[2] == 'F'.code.toByte()) ||
      mime.equals("image/gif", ignoreCase = true) ||
      picked.fileName.lowercase().endsWith(".gif")
    if (isGif && bytes.size <= 400_000) {
      val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
      return@withContext picked.copy(uri = "data:image/gif;base64,$b64", mimeType = "image/gif")
    }
    if (mime.startsWith("image/") && !isGif && bytes.size <= 350_000) {
      val cloudUri = prepareCloudMediaUri(context, picked.uri, maxDimensionPx = 1024)
      return@withContext picked.copy(uri = cloudUri)
    }
    val uploaded = uploadFileBytes(bytes, picked.fileName, mime)
    if (!uploaded.isNullOrBlank()) {
      val ext = picked.fileName.substringAfterLast('.', extensionForMime(mime)).take(8)
      cacheUploadedBytesLocally(context, uploaded, bytes, ext)
      picked.copy(uri = uploaded)
    } else if (bytes.size <= 420_000) {
      // Safe fallback to inline base64 data URI if upload host unreachable and file fits Firestore limit
      val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
      picked.copy(uri = "data:$mime;base64,$b64")
    } else {
      picked
    }
  }

  suspend fun ensureLocalCachedFile(
    context: Context,
    uriOrData: String,
    fileNameHint: String? = null
  ): Result<File> = withContext(Dispatchers.IO) {
    init(context)
    try {
      val cacheDir = File(context.cacheDir, "xchat_downloads").apply { if (!exists()) mkdirs() }
      val safeHint = (fileNameHint?.takeIf { it.isNotBlank() } ?: "attachment_${sha256Short(uriOrData).take(8)}.bin")
        .replace(Regex("[^a-zA-Z0-9._-]"), "_")

      when {
        uriOrData.startsWith("data:") -> {
          val bytes = decodeDataUriBytes(uriOrData)
            ?: return@withContext Result.failure(Exception("Invalid file data."))
          val outFile = File(cacheDir, "${sha256Short(uriOrData).take(8)}_$safeHint")
          FileOutputStream(outFile).use { it.write(bytes) }
          Result.success(outFile)
        }
        uriOrData.startsWith("file://") -> {
          val path = Uri.parse(uriOrData).path
            ?: return@withContext Result.failure(Exception("Invalid local file path."))
          val file = File(path)
          if (file.exists() && file.length() > 0L) Result.success(file)
          else Result.failure(Exception("Local file not found."))
        }
        uriOrData.startsWith("http://") || uriOrData.startsWith("https://") -> {
          val normalized = normalizeCloudUrl(uriOrData)
          val memCached = remoteUrlFileCache.get(normalized)
          if (memCached != null && memCached.exists() && memCached.length() > 0L) {
            return@withContext Result.success(memCached)
          }
          val existingDisk = findDiskCachedRemoteFile(context, normalized)
          if (existingDisk != null) {
            remoteUrlFileCache.put(normalized, existingDisk)
            return@withContext Result.success(existingDisk)
          }
          val outFile = File(cacheDir, "${sha256Short(normalized).take(10)}_$safeHint")
          val downloaded = downloadUrlToFile(normalized, outFile)
          if (downloaded) {
            remoteUrlFileCache.put(normalized, outFile)
            Result.success(outFile)
          } else {
            runCatching { outFile.delete() }
            Result.failure(Exception("Failed to download file from media server."))
          }
        }
        else -> {
          val outFile = File(cacheDir, "${sha256Short(uriOrData).take(8)}_$safeHint")
          val input = context.contentResolver.openInputStream(Uri.parse(uriOrData))
            ?: return@withContext Result.failure(Exception("File source is inaccessible."))
          input.use { ins -> FileOutputStream(outFile).use { outs -> ins.copyTo(outs) } }
          Result.success(outFile)
        }
      }
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  private fun downloadUrlToFile(url: String, outFile: File, depth: Int = 0): Boolean {
    if (depth > 2) return false
    return try {
      val req = Request.Builder()
        .url(url)
        .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) XChat/2.0")
        .get()
        .build()
      client.newCall(req).execute().use { resp ->
        if (!resp.isSuccessful) return false
        val body = resp.body ?: return false
        val contentType = resp.header("Content-Type")?.lowercase() ?: ""
        if (contentType.contains("text/html")) {
          // If tmpfiles.org returns an HTML wrapper page, scrape its signed `/dl/<token>/...` URL
          val html = body.string()
          if (url.contains("tmpfiles.org")) {
            val match = Regex("""https?://(?:www\.)?tmpfiles\.org/dl/[^"'\s<>]+""").find(html)
            if (match != null && match.value != url) {
              return downloadUrlToFile(match.value, outFile, depth + 1)
            }
          }
          return false
        }
        body.byteStream().use { ins ->
          FileOutputStream(outFile).use { outs ->
            ins.copyTo(outs)
          }
        }
        outFile.exists() && outFile.length() > 0L
      }
    } catch (_: Exception) {
      false
    }
  }

  private fun readBytes(context: Context, uriStr: String): ByteArray? {
    return try {
      if (uriStr.startsWith("file://")) {
        val path = Uri.parse(uriStr).path ?: return null
        File(path).readBytes()
      } else {
        context.contentResolver.openInputStream(Uri.parse(uriStr))?.use { it.readBytes() }
      }
    } catch (_: Exception) {
      null
    }
  }

  private fun decodeSampledBitmap(bytes: ByteArray, targetMaxDim: Int): Bitmap? {
    return try {
      val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
      BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
      val maxSource = maxOf(bounds.outWidth, bounds.outHeight)
      var sampleSize = 1
      if (maxSource > targetMaxDim * 2) {
        val half = maxSource / 2
        while (half / sampleSize >= targetMaxDim * 2) {
          sampleSize *= 2
        }
      }
      val opts = BitmapFactory.Options().apply {
        inSampleSize = sampleSize
        inPreferredConfig = Bitmap.Config.ARGB_8888
      }
      BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    } catch (_: Exception) {
      null
    }
  }

  private fun scaleBitmap(src: Bitmap, maxDim: Int): Bitmap {
    val w = src.width
    val h = src.height
    if (w <= maxDim && h <= maxDim) return src
    val ratio = minOf(maxDim.toFloat() / w, maxDim.toFloat() / h)
    val nw = (w * ratio).toInt().coerceAtLeast(1)
    val nh = (h * ratio).toInt().coerceAtLeast(1)
    return Bitmap.createScaledBitmap(src, nw, nh, true)
  }

  private fun uploadFileBytes(bytes: ByteArray, fileName: String, mimeType: String): String? {
    return uploadToPomf2(bytes, fileName, mimeType)
      ?: uploadToUguu(bytes, fileName, mimeType)
      ?: uploadToCatbox(bytes, fileName, mimeType)
      ?: uploadToTmpFiles(bytes, fileName, mimeType)
  }

  private fun uploadToPomf2(bytes: ByteArray, fileName: String, mimeType: String): String? {
    return uploadPomfCompatible(
      endpoint = "https://pomf2.lain.la/upload.php",
      bytes = bytes,
      fileName = fileName,
      mimeType = mimeType
    )
  }

  private fun uploadToUguu(bytes: ByteArray, fileName: String, mimeType: String): String? {
    return uploadPomfCompatible(
      endpoint = "https://uguu.se/upload",
      bytes = bytes,
      fileName = fileName,
      mimeType = mimeType
    )
  }

  private fun uploadPomfCompatible(
    endpoint: String,
    bytes: ByteArray,
    fileName: String,
    mimeType: String
  ): String? {
    return try {
      val safeName = fileName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
      val body = MultipartBody.Builder()
        .setType(MultipartBody.FORM)
        .addFormDataPart(
          "files[]",
          safeName,
          bytes.toRequestBody(mimeType.toMediaTypeOrNull())
        )
        .build()
      val request = Request.Builder()
        .url(endpoint)
        .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) XChat/2.0")
        .post(body)
        .build()
      client.newCall(request).execute().use { resp ->
        if (!resp.isSuccessful) return null
        val jsonStr = resp.body?.string() ?: return null
        val json = JSONObject(jsonStr)
        if (!json.optBoolean("success", false)) return null
        val filesArr = json.optJSONArray("files") ?: return null
        if (filesArr.length() == 0) return null
        val rawUrl = filesArr.getJSONObject(0).optString("url", "").trim()
        if (rawUrl.startsWith("https://") || rawUrl.startsWith("http://")) rawUrl else null
      }
    } catch (_: Exception) {
      null
    }
  }

  private fun uploadToTmpFiles(bytes: ByteArray, fileName: String, mimeType: String): String? {
    return try {
      val safeName = fileName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
      val body = MultipartBody.Builder()
        .setType(MultipartBody.FORM)
        .addFormDataPart(
          "file",
          safeName,
          bytes.toRequestBody(mimeType.toMediaTypeOrNull())
        )
        .build()
      val request = Request.Builder()
        .url("https://tmpfiles.org/api/v1/upload")
        .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) XChat/2.0")
        .post(body)
        .build()
      client.newCall(request).execute().use { resp ->
        if (!resp.isSuccessful) return null
        val jsonStr = resp.body?.string() ?: return null
        val json = JSONObject(jsonStr)
        if (json.optString("status") == "success") {
          val rawUrl = json.getJSONObject("data").getString("url")
          val normalized = normalizeCloudUrl(rawUrl)
          // Verify if tmpfiles returns a direct binary or HTML token page
          val probeReq = Request.Builder()
            .url(normalized)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) XChat/2.0")
            .get()
            .build()
          client.newCall(probeReq).execute().use { probeResp ->
            val ct = probeResp.header("Content-Type")?.lowercase() ?: ""
            if (ct.contains("text/html")) {
              val html = probeResp.body?.string() ?: ""
              val signed = Regex("""https?://(?:www\.)?tmpfiles\.org/dl/[^"'\s<>]+""").find(html)?.value
              signed ?: normalized
            } else {
              normalized
            }
          }
        } else null
      }
    } catch (_: Exception) {
      null
    }
  }

  private fun uploadToCatbox(bytes: ByteArray, fileName: String, mimeType: String): String? {
    return try {
      val safeName = fileName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
      val body = MultipartBody.Builder()
        .setType(MultipartBody.FORM)
        .addFormDataPart("reqtype", "fileupload")
        .addFormDataPart(
          "fileToUpload",
          safeName,
          bytes.toRequestBody(mimeType.toMediaTypeOrNull())
        )
        .build()
      val request = Request.Builder()
        .url("https://catbox.moe/user/api.php")
        .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) XChat/2.0")
        .post(body)
        .build()
      client.newCall(request).execute().use { resp ->
        if (!resp.isSuccessful) return null
        val link = resp.body?.string()?.trim() ?: return null
        if (link.startsWith("https://")) link else null
      }
    } catch (_: Exception) {
      null
    }
  }
}
