package com.example.utils

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class GifResultItem(
  val id: String,
  val title: String,
  val previewUrl: String,
  val gifUrl: String,
  val category: String
)

/**
 * GIF search provider for XChat V2.0:
 * Uses Tenor/Klipy public endpoint when available and provides instant offline-safe curated animated GIFs
 * grouped by category so thumbnails never block chat performance.
 */
object GifSearchClient {
  private val http = OkHttpClient.Builder()
    .connectTimeout(8, TimeUnit.SECONDS)
    .readTimeout(10, TimeUnit.SECONDS)
    .build()

  val categories = listOf("Trending", "Reaksi", "Gaming", "Anime", "Monokrom", "Lucu")

  val curatedGifs = listOf(
    GifResultItem("gif_1", "Applause Clapping", "https://media.giphy.com/media/l3q2XhfQ8oCkm1Ts4/200w.gif", "https://media.giphy.com/media/l3q2XhfQ8oCkm1Ts4/giphy.gif", "Reaksi"),
    GifResultItem("gif_2", "Mind Blown Galaxy", "https://media.giphy.com/media/xT0xeJpnrWC4XWblEk/200w.gif", "https://media.giphy.com/media/xT0xeJpnrWC4XWblEk/giphy.gif", "Trending"),
    GifResultItem("gif_3", "Cool Sunglasses Deal", "https://media.giphy.com/media/62PP2yEIAZF6g/200w.gif", "https://media.giphy.com/media/62PP2yEIAZF6g/giphy.gif", "Monokrom"),
    GifResultItem("gif_4", "GG Gaming Victory", "https://media.giphy.com/media/3o7abB06u9bNzA8lu8/200w.gif", "https://media.giphy.com/media/3o7abB06u9bNzA8lu8/giphy.gif", "Gaming"),
    GifResultItem("gif_5", "Anime Hype Sparkle", "https://media.giphy.com/media/o75ajIFH0QnQC3nCeD/200w.gif", "https://media.giphy.com/media/o75ajIFH0QnQC3nCeD/giphy.gif", "Anime"),
    GifResultItem("gif_6", "Cat Vibing Rhythm", "https://media.giphy.com/media/GeimqsH0TLDt4tScGw/200w.gif", "https://media.giphy.com/media/GeimqsH0TLDt4tScGw/giphy.gif", "Lucu"),
    GifResultItem("gif_7", "Chess Checkmate Think", "https://media.giphy.com/media/3o6Zt6ML6BklcajjsA/200w.gif", "https://media.giphy.com/media/3o6Zt6ML6BklcajjsA/giphy.gif", "Gaming"),
    GifResultItem("gif_8", "Obsidian Smoke Wave", "https://media.giphy.com/media/l0HlBO7eyXzSZkJri/200w.gif", "https://media.giphy.com/media/l0HlBO7eyXzSZkJri/giphy.gif", "Monokrom"),
    GifResultItem("gif_9", "Thumbs Up Legend", "https://media.giphy.com/media/111ebonMs90YLu/200w.gif", "https://media.giphy.com/media/111ebonMs90YLu/giphy.gif", "Reaksi"),
    GifResultItem("gif_10", "LOL Laughing Hard", "https://media.giphy.com/media/10JhviFuU2gWD6/200w.gif", "https://media.giphy.com/media/10JhviFuU2gWD6/giphy.gif", "Lucu"),
    GifResultItem("gif_11", "Rocket Launch Hype", "https://media.giphy.com/media/mi6DsSSNKDbUY/200w.gif", "https://media.giphy.com/media/mi6DsSSNKDbUY/giphy.gif", "Trending"),
    GifResultItem("gif_12", "Neon Samurai Vibe", "https://media.giphy.com/media/26Ff2bTANl3s1KI6I/200w.gif", "https://media.giphy.com/media/26Ff2bTANl3s1KI6I/giphy.gif", "Anime")
  )

  suspend fun search(query: String, category: String = "Trending"): List<GifResultItem> = withContext(Dispatchers.IO) {
    val cleanQuery = query.trim()
    if (cleanQuery.isNotBlank()) {
      // Attempt public Tenor v1 demo search endpoint; fall back gracefully to filtered catalog
      val remote = runCatching {
        val url = "https://g.tenor.com/v1/search?q=${URLEncoder.encode(cleanQuery, "UTF-8")}&key=LIVDSRZULELA&limit=16"
        val req = Request.Builder().url(url).build()
        http.newCall(req).execute().use { resp ->
          if (!resp.isSuccessful) return@use emptyList()
          val body = resp.body?.string() ?: return@use emptyList()
          val results = JSONObject(body).optJSONArray("results") ?: return@use emptyList()
          buildList {
            for (i in 0 until results.length()) {
              val item = results.optJSONObject(i) ?: continue
              val media = item.optJSONArray("media")?.optJSONObject(0) ?: continue
              val tiny = media.optJSONObject("tinygif")?.optString("url")
              val full = media.optJSONObject("gif")?.optString("url") ?: tiny
              if (!full.isNullOrBlank()) {
                add(
                  GifResultItem(
                    id = item.optString("id", "tenor_$i"),
                    title = item.optString("content_description", cleanQuery).ifBlank { cleanQuery },
                    previewUrl = tiny ?: full,
                    gifUrl = full,
                    category = "Search"
                  )
                )
              }
            }
          }
        }
      }.getOrNull().orEmpty()
      if (remote.isNotEmpty()) return@withContext remote
      val localFiltered = curatedGifs.filter {
        it.title.contains(cleanQuery, ignoreCase = true) || it.category.contains(cleanQuery, ignoreCase = true)
      }
      return@withContext if (localFiltered.isNotEmpty()) localFiltered else curatedGifs
    }

    if (category == "Trending") curatedGifs else curatedGifs.filter { it.category.equals(category, ignoreCase = true) }
  }
}
