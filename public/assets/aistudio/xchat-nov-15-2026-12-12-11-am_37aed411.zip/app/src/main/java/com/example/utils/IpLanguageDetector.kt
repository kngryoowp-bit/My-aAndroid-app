package com.example.utils

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit

data class IpDetectionResult(
  val ipAddress: String,
  val countryCode: String,
  val countryName: String,
  val recommendedLang: String
)

object IpLanguageDetector {
  private val client = OkHttpClient.Builder()
    .connectTimeout(3, TimeUnit.SECONDS)
    .readTimeout(3, TimeUnit.SECONDS)
    .build()

  suspend fun detectIpAndLanguage(): IpDetectionResult = withContext(Dispatchers.IO) {
    // Primary lookup: ipapi.co
    try {
      val req = Request.Builder()
        .url("https://ipapi.co/json/")
        .header("User-Agent", "XChat-Android/2.0")
        .build()
      client.newCall(req).execute().use { resp ->
        if (resp.isSuccessful) {
          val body = resp.body?.string()
          if (!body.isNullOrBlank()) {
            val json = JSONObject(body)
            val ip = json.optString("ip", "Unknown")
            val cc = json.optString("country_code", "").uppercase()
            val cname = json.optString("country_name", cc)
            if (cc.isNotBlank()) {
              return@withContext IpDetectionResult(
                ipAddress = ip,
                countryCode = cc,
                countryName = cname,
                recommendedLang = mapCountryToLanguage(cc)
              )
            }
          }
        }
      }
    } catch (_: Exception) { }

    // Fallback lookup: api.country.is
    try {
      val req = Request.Builder().url("https://api.country.is/").build()
      client.newCall(req).execute().use { resp ->
        if (resp.isSuccessful) {
          val body = resp.body?.string()
          if (!body.isNullOrBlank()) {
            val json = JSONObject(body)
            val ip = json.optString("ip", "Unknown")
            val cc = json.optString("country", "").uppercase()
            if (cc.isNotBlank()) {
              return@withContext IpDetectionResult(
                ipAddress = ip,
                countryCode = cc,
                countryName = cc,
                recommendedLang = mapCountryToLanguage(cc)
              )
            }
          }
        }
      }
    } catch (_: Exception) { }

    // Offline / local fallback
    val sysLang = Locale.getDefault().language.lowercase()
    val fallbackLang = when {
      sysLang.startsWith("in") || sysLang == "id" -> "id"
      sysLang == "ms" -> "ms"
      sysLang == "ja" -> "ja"
      else -> "en"
    }
    IpDetectionResult(
      ipAddress = "Local / Offline",
      countryCode = Locale.getDefault().country.ifBlank { "ID" },
      countryName = "System Locale",
      recommendedLang = fallbackLang
    )
  }

  private fun mapCountryToLanguage(countryCode: String): String {
    return when (countryCode.uppercase()) {
      "ID" -> "id"
      "MY", "BN" -> "ms"
      "JP" -> "ja"
      else -> "en"
    }
  }
}
