package com.example.utils

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.Locale

data class LocationCandidate(
  val latitude: Double,
  val longitude: Double,
  val label: String
)

/**
 * Play-Policy compliant explicit Location Sharing helper:
 * - Never fetches location silently or in background
 * - Only runs when explicitly requested after granting permission
 */
object LocationHelper {
  fun hasLocationPermission(context: Context): Boolean {
    val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    return fine || coarse
  }

  @SuppressLint("MissingPermission")
  suspend fun fetchCurrentLocationWithPreview(context: Context): Result<LocationCandidate> = withContext(Dispatchers.IO) {
    if (!hasLocationPermission(context)) {
      return@withContext Result.failure(SecurityException("Location permission not granted."))
    }
    return@withContext try {
      val client = LocationServices.getFusedLocationProviderClient(context)
      val cts = CancellationTokenSource()
      val loc = client.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, cts.token).await()
        ?: client.lastLocation.await()
        ?: return@withContext Result.failure(Exception("Unable to acquire device GPS location. Use manual coordinates or retry."))

      val label = reverseGeocodeLabel(context, loc.latitude, loc.longitude)
      Result.success(LocationCandidate(loc.latitude, loc.longitude, label))
    } catch (t: Throwable) {
      Result.failure(t)
    }
  }

  @Suppress("DEPRECATION")
  private fun reverseGeocodeLabel(context: Context, lat: Double, lng: Double): String {
    return try {
      val geocoder = Geocoder(context, Locale.getDefault())
      val list = geocoder.getFromLocation(lat, lng, 1)
      val addr = list?.firstOrNull()
      val parts = listOfNotNull(addr?.subLocality, addr?.locality, addr?.adminArea).filter { it.isNotBlank() }
      if (parts.isNotEmpty()) parts.joinToString(", ") else String.format(Locale.US, "%.5f, %.5f", lat, lng)
    } catch (_: Throwable) {
      String.format(Locale.US, "%.5f, %.5f", lat, lng)
    }
  }
}
