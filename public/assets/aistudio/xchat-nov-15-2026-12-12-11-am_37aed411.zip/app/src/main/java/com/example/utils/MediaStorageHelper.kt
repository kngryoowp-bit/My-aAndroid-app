package com.example.utils

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.net.URL
import java.util.Locale
import java.util.UUID

data class PickedFileInfo(
  val uri: String,
  val fileName: String,
  val mimeType: String,
  val sizeBytes: Long
)

object MediaStorageHelper {
  fun isGifUri(context: Context, uri: Uri): Boolean {
    val mime = runCatching { context.contentResolver.getType(uri) }.getOrNull()
    if (mime?.equals("image/gif", ignoreCase = true) == true) return true
    val name = queryDisplayName(context, uri) ?: uri.lastPathSegment ?: ""
    return name.lowercase(Locale.ROOT).endsWith(".gif")
  }

  fun persistPickedMedia(context: Context, uri: Uri): String {
    val mime = runCatching { context.contentResolver.getType(uri) }.getOrNull().orEmpty()
    val origName = queryDisplayName(context, uri)
    val ext = resolveExtension(origName, mime, fallback = "bin")
    val dir = File(context.filesDir, "xchat_media").apply { mkdirs() }
    val outFile = File(dir, "media_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}.$ext")
    context.contentResolver.openInputStream(uri)?.use { input ->
      outFile.outputStream().use { output -> input.copyTo(output) }
    } ?: throw IllegalStateException("Cannot open selected media stream")
    return outFile.absolutePath
  }

  fun persistPickedFile(context: Context, uri: Uri): PickedFileInfo {
    val cr = context.contentResolver
    val mime = runCatching { cr.getType(uri) }.getOrNull() ?: "application/octet-stream"
    var displayName = queryDisplayName(context, uri) ?: "file_${System.currentTimeMillis()}"
    if (!displayName.contains('.')) {
      val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime)
      if (!ext.isNullOrBlank()) displayName = "$displayName.$ext"
    }
    val dir = File(context.filesDir, "xchat_files").apply { mkdirs() }
    val safeName = displayName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
    val outFile = File(dir, "${System.currentTimeMillis()}_${safeName}")
    cr.openInputStream(uri)?.use { input ->
      outFile.outputStream().use { output -> input.copyTo(output) }
    } ?: throw IllegalStateException("Cannot read picked file")
    val size = outFile.length().coerceAtLeast(queryFileSize(context, uri))
    return PickedFileInfo(
      uri = outFile.absolutePath,
      fileName = displayName,
      mimeType = mime,
      sizeBytes = size
    )
  }

  fun copyToDestinationUri(context: Context, sourceUriString: String, destUri: Uri): Result<Boolean> = runCatching {
    openInputStreamAny(context, sourceUriString).use { input ->
      context.contentResolver.openOutputStream(destUri)?.use { output ->
        input.copyTo(output)
      } ?: error("Cannot open destination URI")
    }
    true
  }

  fun saveToPublicDownloads(
    context: Context,
    uriString: String,
    fileName: String?,
    mimeType: String?
  ): Result<String> = runCatching {
    val resolvedName = (fileName?.takeIf { it.isNotBlank() }
      ?: Uri.parse(uriString).lastPathSegment?.substringAfterLast('/')
      ?: "xchat_file_${System.currentTimeMillis()}")
      .replace(Regex("[/\\\\]"), "_")
    val resolvedMime = mimeType?.takeIf { it.isNotBlank() } ?: guessMimeFromName(resolvedName)

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      val values = ContentValues().apply {
        put(MediaStore.Downloads.DISPLAY_NAME, resolvedName)
        put(MediaStore.Downloads.MIME_TYPE, resolvedMime)
        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/XChat")
        put(MediaStore.Downloads.IS_PENDING, 1)
      }
      val cr = context.contentResolver
      val itemUri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
        ?: error("Failed to create Downloads entry")
      try {
        openInputStreamAny(context, uriString).use { input ->
          cr.openOutputStream(itemUri)?.use { output ->
            input.copyTo(output)
          } ?: error("Cannot write to Downloads stream")
        }
        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        cr.update(itemUri, values, null, null)
      } catch (t: Throwable) {
        runCatching { cr.delete(itemUri, null, null) }
        throw t
      }
      "Downloads/XChat/$resolvedName"
    } else {
      @Suppress("DEPRECATION")
      val dlDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "XChat").apply { mkdirs() }
      val target = File(dlDir, resolvedName)
      openInputStreamAny(context, uriString).use { input ->
        target.outputStream().use { output -> input.copyTo(output) }
      }
      target.absolutePath
    }
  }

  fun openAttachmentExternally(
    context: Context,
    uriString: String,
    mimeType: String?,
    fileName: String?
  ): Boolean {
    return runCatching {
      val trimmed = uriString.trim()
      val resolvedMime = mimeType?.takeIf { it.isNotBlank() } ?: guessMimeFromName(fileName ?: trimmed)
      val intent = if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
        Intent(Intent.ACTION_VIEW, Uri.parse(trimmed))
      } else {
        val localFile = when {
          trimmed.startsWith("file://") -> File(Uri.parse(trimmed).path ?: return false)
          trimmed.startsWith("/") -> File(trimmed)
          else -> null
        }
        val contentUri = if (localFile != null && localFile.exists()) {
          FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", localFile)
        } else {
          Uri.parse(trimmed)
        }
        Intent(Intent.ACTION_VIEW).apply {
          setDataAndType(contentUri, resolvedMime)
          addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
      }
      intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
      true
    }.getOrDefault(false)
  }

  fun isImageAttachment(mimeType: String?, fileName: String?, uri: String?): Boolean {
    if (mimeType?.startsWith("image/", ignoreCase = true) == true) return true
    val target = (fileName ?: uri ?: "").lowercase(Locale.ROOT).substringBefore('?')
    return target.endsWith(".png") || target.endsWith(".jpg") || target.endsWith(".jpeg") ||
      target.endsWith(".webp") || target.endsWith(".gif") || target.endsWith(".bmp")
  }

  fun isVideoAttachment(mimeType: String?, fileName: String?, uri: String?): Boolean {
    if (mimeType?.startsWith("video/", ignoreCase = true) == true) return true
    val target = (fileName ?: uri ?: "").lowercase(Locale.ROOT).substringBefore('?')
    return target.endsWith(".mp4") || target.endsWith(".mkv") || target.endsWith(".webm") ||
      target.endsWith(".mov") || target.endsWith(".3gp")
  }

  fun formatFileSize(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    val kb = 1024.0
    val mb = kb * 1024.0
    val gb = mb * 1024.0
    return when {
      bytes >= gb -> String.format(Locale.US, "%.2f GB", bytes / gb)
      bytes >= mb -> String.format(Locale.US, "%.1f MB", bytes / mb)
      bytes >= kb -> String.format(Locale.US, "%.1f KB", bytes / kb)
      else -> "$bytes B"
    }
  }

  private fun openInputStreamAny(context: Context, sourceUriString: String): InputStream {
    val trimmed = sourceUriString.trim()
    val normalized = CloudMediaHelper.normalizeCloudUrl(trimmed)
    return when {
      trimmed.startsWith("/") -> FileInputStream(File(trimmed))
      trimmed.startsWith("file://") -> FileInputStream(File(Uri.parse(trimmed).path ?: ""))
      normalized.startsWith("http://") || normalized.startsWith("https://") -> URL(normalized).openStream()
      else -> context.contentResolver.openInputStream(Uri.parse(trimmed))
        ?: error("Cannot open input stream for $trimmed")
    }
  }

  private fun queryDisplayName(context: Context, uri: Uri): String? {
    return runCatching {
      context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(0) else null
      }
    }.getOrNull()
  }

  private fun queryFileSize(context: Context, uri: Uri): Long {
    return runCatching {
      context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getLong(0) else 0L
      }
    }.getOrNull() ?: 0L
  }

  private fun resolveExtension(fileName: String?, mime: String, fallback: String): String {
    val byName = fileName?.substringAfterLast('.', "")?.lowercase(Locale.ROOT)?.takeIf { it.isNotBlank() && it.length <= 6 }
    if (byName != null) return byName
    return MimeTypeMap.getSingleton().getExtensionFromMimeType(mime)?.takeIf { it.isNotBlank() } ?: fallback
  }

  private fun guessMimeFromName(name: String): String {
    val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
    return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
  }
}
