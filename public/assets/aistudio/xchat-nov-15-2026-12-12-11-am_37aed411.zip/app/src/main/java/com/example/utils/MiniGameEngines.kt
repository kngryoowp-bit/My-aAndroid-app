package com.example.utils

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.roundToInt

object MiniGameEngines {

  // ---------------- TIC-TAC-TOE ----------------
  data class TicTacToeState(
    val cells: List<String> = List(9) { "" },
    val nextSymbol: String = "X",
    val winnerSymbol: String? = null,
    val winningLine: List<Int> = emptyList()
  ) {
    fun toJson(): String = JSONObject().apply {
      put("cells", JSONArray(cells))
      put("nextSymbol", nextSymbol)
      if (winnerSymbol != null) put("winnerSymbol", winnerSymbol)
      put("winningLine", JSONArray(winningLine))
    }.toString()

    companion object {
      fun fromJson(json: String): TicTacToeState = runCatching {
        val o = JSONObject(json)
        val arr = o.optJSONArray("cells")
        val list = List(9) { i -> arr?.optString(i, "") ?: "" }
        val winArr = o.optJSONArray("winningLine")
        val winLine = if (winArr != null) List(winArr.length()) { i -> winArr.optInt(i) } else emptyList()
        TicTacToeState(
          cells = list,
          nextSymbol = o.optString("nextSymbol", "X"),
          winnerSymbol = if (o.has("winnerSymbol") && !o.isNull("winnerSymbol")) o.optString("winnerSymbol") else null,
          winningLine = winLine
        )
      }.getOrDefault(TicTacToeState())
    }
  }

  fun playTicTacToeMove(state: TicTacToeState, index: Int): TicTacToeState? {
    if (state.winnerSymbol != null || index !in 0..8 || state.cells[index].isNotEmpty()) return null
    val nextCells = state.cells.toMutableList().apply { set(index, state.nextSymbol) }
    val lines = listOf(
      listOf(0, 1, 2), listOf(3, 4, 5), listOf(6, 7, 8),
      listOf(0, 3, 6), listOf(1, 4, 7), listOf(2, 5, 8),
      listOf(0, 4, 8), listOf(2, 4, 6)
    )
    var winner: String? = null
    var winLine: List<Int> = emptyList()
    for (line in lines) {
      val a = nextCells[line[0]]
      if (a.isNotEmpty() && a == nextCells[line[1]] && a == nextCells[line[2]]) {
        winner = a
        winLine = line
        break
      }
    }
    if (winner == null && nextCells.none { it.isEmpty() }) winner = "DRAW"
    return TicTacToeState(
      cells = nextCells,
      nextSymbol = if (state.nextSymbol == "X") "O" else "X",
      winnerSymbol = winner,
      winningLine = winLine
    )
  }

  // ---------------- CONNECT FOUR (7 cols x 6 rows = 42) ----------------
  data class ConnectFourState(
    val board: List<Int> = List(42) { 0 },
    val nextPlayer: Int = 1,
    val winnerPlayer: Int? = null,
    val winningCells: List<Int> = emptyList()
  ) {
    fun toJson(): String = JSONObject().apply {
      put("board", JSONArray(board))
      put("nextPlayer", nextPlayer)
      if (winnerPlayer != null) put("winnerPlayer", winnerPlayer)
      put("winningCells", JSONArray(winningCells))
    }.toString()

    companion object {
      fun fromJson(json: String): ConnectFourState = runCatching {
        val o = JSONObject(json)
        val arr = o.optJSONArray("board")
        val board = List(42) { i -> arr?.optInt(i, 0) ?: 0 }
        val wArr = o.optJSONArray("winningCells")
        val wCells = if (wArr != null) List(wArr.length()) { i -> wArr.optInt(i) } else emptyList()
        ConnectFourState(
          board = board,
          nextPlayer = o.optInt("nextPlayer", 1),
          winnerPlayer = if (o.has("winnerPlayer") && !o.isNull("winnerPlayer")) o.optInt("winnerPlayer") else null,
          winningCells = wCells
        )
      }.getOrDefault(ConnectFourState())
    }
  }

  fun playConnectFourMove(state: ConnectFourState, col: Int): ConnectFourState? {
    if (state.winnerPlayer != null || col !in 0..6) return null
    var targetRow = -1
    for (r in 5 downTo 0) {
      if (state.board[r * 7 + col] == 0) {
        targetRow = r
        break
      }
    }
    if (targetRow < 0) return null
    val next = state.board.toMutableList().apply { set(targetRow * 7 + col, state.nextPlayer) }
    val p = state.nextPlayer
    val dirs = listOf(0 to 1, 1 to 0, 1 to 1, 1 to -1)
    var winner: Int? = null
    var winCells: List<Int> = emptyList()
    outer@ for (r in 0..5) {
      for (c in 0..6) {
        if (next[r * 7 + c] != p) continue
        for ((dr, dc) in dirs) {
          val seq = mutableListOf<Int>()
          for (k in 0..3) {
            val nr = r + dr * k
            val nc = c + dc * k
            if (nr in 0..5 && nc in 0..6 && next[nr * 7 + nc] == p) seq.add(nr * 7 + nc)
          }
          if (seq.size == 4) {
            winner = p
            winCells = seq
            break@outer
          }
        }
      }
    }
    if (winner == null && next.none { it == 0 }) winner = 0 // 0 represents DRAW in caller ("else -> DRAW")
    return ConnectFourState(
      board = next,
      nextPlayer = if (p == 1) 2 else 1,
      winnerPlayer = winner,
      winningCells = winCells
    )
  }

  // ---------------- REVERSI (8x8 = 64) ----------------
  data class ReversiState(
    val board: List<Int> = initialReversiBoard(),
    val nextPlayer: Int = 1,
    val winnerPlayer: Int? = null,
    val blackCount: Int = 2,
    val whiteCount: Int = 2
  ) {
    fun toJson(): String = JSONObject().apply {
      put("board", JSONArray(board))
      put("nextPlayer", nextPlayer)
      if (winnerPlayer != null) put("winnerPlayer", winnerPlayer)
      put("blackCount", blackCount)
      put("whiteCount", whiteCount)
    }.toString()

    companion object {
      fun initialReversiBoard(): List<Int> = MutableList(64) { 0 }.apply {
        this[3 * 8 + 3] = 2
        this[3 * 8 + 4] = 1
        this[4 * 8 + 3] = 1
        this[4 * 8 + 4] = 2
      }

      fun fromJson(json: String): ReversiState = runCatching {
        val o = JSONObject(json)
        val arr = o.optJSONArray("board")
        val b = if (arr != null && arr.length() == 64) List(64) { i -> arr.optInt(i, 0) } else initialReversiBoard()
        ReversiState(
          board = b,
          nextPlayer = o.optInt("nextPlayer", 1),
          winnerPlayer = if (o.has("winnerPlayer") && !o.isNull("winnerPlayer")) o.optInt("winnerPlayer") else null,
          blackCount = b.count { it == 1 },
          whiteCount = b.count { it == 2 }
        )
      }.getOrDefault(ReversiState())
    }
  }

  fun getReversiValidMoves(board: List<Int>, player: Int): List<Int> {
    if (board.size != 64) return emptyList()
    val valid = mutableListOf<Int>()
    for (idx in 0 until 64) {
      if (board[idx] == 0 && reversiFlips(board, idx, player).isNotEmpty()) valid.add(idx)
    }
    return valid
  }

  private fun reversiFlips(board: List<Int>, idx: Int, player: Int): List<Int> {
    val opp = if (player == 1) 2 else 1
    val r = idx / 8
    val c = idx % 8
    val flips = mutableListOf<Int>()
    for (dr in -1..1) {
      for (dc in -1..1) {
        if (dr == 0 && dc == 0) continue
        var nr = r + dr
        var nc = c + dc
        val line = mutableListOf<Int>()
        while (nr in 0..7 && nc in 0..7 && board[nr * 8 + nc] == opp) {
          line.add(nr * 8 + nc)
          nr += dr
          nc += dc
        }
        if (line.isNotEmpty() && nr in 0..7 && nc in 0..7 && board[nr * 8 + nc] == player) {
          flips.addAll(line)
        }
      }
    }
    return flips
  }

  fun playReversiMove(state: ReversiState, idx: Int): ReversiState? {
    if (state.winnerPlayer != null || idx !in 0..63 || state.board[idx] != 0) return null
    val flips = reversiFlips(state.board, idx, state.nextPlayer)
    if (flips.isEmpty()) return null
    val next = state.board.toMutableList()
    next[idx] = state.nextPlayer
    flips.forEach { next[it] = state.nextPlayer }

    val opp = if (state.nextPlayer == 1) 2 else 1
    val oppMoves = getReversiValidMoves(next, opp)
    val selfMoves = getReversiValidMoves(next, state.nextPlayer)
    val bCount = next.count { it == 1 }
    val wCount = next.count { it == 2 }
    var nextPlayer = opp
    var winner: Int? = null
    if (oppMoves.isEmpty()) {
      if (selfMoves.isNotEmpty()) {
        nextPlayer = state.nextPlayer
      } else {
        winner = when {
          bCount > wCount -> 1
          wCount > bCount -> 2
          else -> 0
        }
      }
    }
    return ReversiState(
      board = next,
      nextPlayer = nextPlayer,
      winnerPlayer = winner,
      blackCount = bCount,
      whiteCount = wCount
    )
  }

  // ---------------- CHESS (8x8 = 64) ----------------
  data class ChessState(
    val board: String = INITIAL_BOARD,
    val turn: String = "W",
    val status: String = "ONGOING",
    val lastFrom: Int = -1,
    val lastTo: Int = -1
  ) {
    fun toJson(): String = JSONObject().apply {
      put("board", board)
      put("turn", turn)
      put("status", status)
      put("lastFrom", lastFrom)
      put("lastTo", lastTo)
    }.toString()

    companion object {
      const val INITIAL_BOARD = "rnbqkbnrpppppppp................................PPPPPPPPRNBQKBNR"

      fun fromJson(json: String): ChessState = runCatching {
        val o = JSONObject(json)
        val b = o.optString("board", INITIAL_BOARD)
        ChessState(
          board = if (b.length == 64) b else INITIAL_BOARD,
          turn = o.optString("turn", "W"),
          status = o.optString("status", "ONGOING"),
          lastFrom = o.optInt("lastFrom", -1),
          lastTo = o.optInt("lastTo", -1)
        )
      }.getOrDefault(ChessState())
    }
  }

  fun pieceSymbolUnicode(piece: Char): String = when (piece) {
    'K' -> "♔"
    'Q' -> "♕"
    'R' -> "♖"
    'B' -> "♗"
    'N' -> "♘"
    'P' -> "♙"
    'k' -> "♚"
    'q' -> "♛"
    'r' -> "♜"
    'b' -> "♝"
    'n' -> "♞"
    'p' -> "♟"
    else -> ""
  }

  private fun isWhitePiece(c: Char): Boolean = c in 'A'..'Z'
  private fun isBlackPiece(c: Char): Boolean = c in 'a'..'z'
  private fun belongsToTurn(c: Char, turn: String): Boolean = if (turn == "W") isWhitePiece(c) else isBlackPiece(c)

  fun getChessLegalMovesFrom(state: ChessState, fromIdx: Int): List<Int> {
    if (fromIdx !in 0..63 || state.board.length != 64) return emptyList()
    val p = state.board[fromIdx]
    if (!belongsToTurn(p, state.turn)) return emptyList()
    val pseudo = pseudoMovesForPiece(state.board, fromIdx, state.turn)
    return pseudo.filter { to ->
      val nextBoard = applyBoardMove(state.board, fromIdx, to, 'Q')
      !isKingInCheck(nextBoard, state.turn)
    }
  }

  fun playChessMove(state: ChessState, fromIdx: Int, toIdx: Int, promotion: Char = 'Q'): ChessState? {
    if (state.status.startsWith("WHITE_WIN") || state.status.startsWith("BLACK_WIN") || state.status.startsWith("DRAW")) {
      return null
    }
    val legal = getChessLegalMovesFrom(state, fromIdx)
    if (!legal.contains(toIdx)) return null

    val promoChar = if (promotion.uppercaseChar() in listOf('Q', 'R', 'B', 'N')) promotion.uppercaseChar() else 'Q'
    val nextBoard = applyBoardMove(state.board, fromIdx, toIdx, promoChar)
    val nextTurn = if (state.turn == "W") "B" else "W"
    val nextInCheck = isKingInCheck(nextBoard, nextTurn)

    var anyLegal = false
    for (sq in 0..63) {
      if (belongsToTurn(nextBoard[sq], nextTurn)) {
        val candidateState = ChessState(nextBoard, nextTurn, "ONGOING", fromIdx, toIdx)
        if (getChessLegalMovesFrom(candidateState, sq).isNotEmpty()) {
          anyLegal = true
          break
        }
      }
    }

    val nextStatus = when {
      !anyLegal && nextInCheck -> if (nextTurn == "B") "WHITE_WIN" else "BLACK_WIN"
      !anyLegal -> "DRAW_STALEMATE"
      nextInCheck -> "CHECK"
      else -> "ONGOING"
    }

    return ChessState(
      board = nextBoard,
      turn = nextTurn,
      status = nextStatus,
      lastFrom = fromIdx,
      lastTo = toIdx
    )
  }

  private fun applyBoardMove(board: String, from: Int, to: Int, promo: Char): String {
    val arr = board.toCharArray()
    var moving = arr[from]
    val toRow = to / 8
    if (moving == 'P' && toRow == 0) moving = promo.uppercaseChar()
    else if (moving == 'p' && toRow == 7) moving = promo.lowercaseChar()
    arr[to] = moving
    arr[from] = '.'
    // Simple castling rook shift if King moves 2 squares horizontally
    if ((moving == 'K' || moving == 'k') && abs((to % 8) - (from % 8)) == 2) {
      val r = from / 8
      if (to % 8 == 6) {
        arr[r * 8 + 5] = arr[r * 8 + 7]
        arr[r * 8 + 7] = '.'
      } else if (to % 8 == 2) {
        arr[r * 8 + 3] = arr[r * 8 + 0]
        arr[r * 8 + 0] = '.'
      }
    }
    return String(arr)
  }

  private fun isKingInCheck(board: String, turn: String): Boolean {
    val kingChar = if (turn == "W") 'K' else 'k'
    val kingSq = board.indexOf(kingChar)
    if (kingSq < 0) return false
    val attackerTurn = if (turn == "W") "B" else "W"
    for (sq in 0..63) {
      if (belongsToTurn(board[sq], attackerTurn)) {
        if (pseudoMovesForPiece(board, sq, attackerTurn).contains(kingSq)) return true
      }
    }
    return false
  }

  private fun pseudoMovesForPiece(board: String, from: Int, turn: String): List<Int> {
    val p = board[from]
    val r = from / 8
    val c = from % 8
    val isW = turn == "W"
    val targets = mutableListOf<Int>()

    fun isOwn(ch: Char) = if (isW) isWhitePiece(ch) else isBlackPiece(ch)
    fun isOpp(ch: Char) = if (isW) isBlackPiece(ch) else isWhitePiece(ch)

    fun addRay(dr: Int, dc: Int) {
      var nr = r + dr
      var nc = c + dc
      while (nr in 0..7 && nc in 0..7) {
        val idx = nr * 8 + nc
        val target = board[idx]
        if (target == '.') {
          targets.add(idx)
        } else {
          if (isOpp(target)) targets.add(idx)
          break
        }
        nr += dr
        nc += dc
      }
    }

    when (p.uppercaseChar()) {
      'P' -> {
        val dir = if (isW) -1 else 1
        val startRow = if (isW) 6 else 1
        val r1 = r + dir
        if (r1 in 0..7) {
          if (board[r1 * 8 + c] == '.') {
            targets.add(r1 * 8 + c)
            val r2 = r + dir * 2
            if (r == startRow && r2 in 0..7 && board[r2 * 8 + c] == '.') {
              targets.add(r2 * 8 + c)
            }
          }
          for (dc in listOf(-1, 1)) {
            val nc = c + dc
            if (nc in 0..7 && isOpp(board[r1 * 8 + nc])) targets.add(r1 * 8 + nc)
          }
        }
      }
      'N' -> {
        val jumps = listOf(-2 to -1, -2 to 1, -1 to -2, -1 to 2, 1 to -2, 1 to 2, 2 to -1, 2 to 1)
        for ((dr, dc) in jumps) {
          val nr = r + dr
          val nc = c + dc
          if (nr in 0..7 && nc in 0..7 && !isOwn(board[nr * 8 + nc])) targets.add(nr * 8 + nc)
        }
      }
      'B' -> { addRay(-1, -1); addRay(-1, 1); addRay(1, -1); addRay(1, 1) }
      'R' -> { addRay(-1, 0); addRay(1, 0); addRay(0, -1); addRay(0, 1) }
      'Q' -> {
        addRay(-1, -1); addRay(-1, 1); addRay(1, -1); addRay(1, 1)
        addRay(-1, 0); addRay(1, 0); addRay(0, -1); addRay(0, 1)
      }
      'K' -> {
        for (dr in -1..1) {
          for (dc in -1..1) {
            if (dr == 0 && dc == 0) continue
            val nr = r + dr
            val nc = c + dc
            if (nr in 0..7 && nc in 0..7 && !isOwn(board[nr * 8 + nc])) targets.add(nr * 8 + nc)
          }
        }
      }
    }
    return targets
  }

  fun computeEloDelta(ratingA: Int, ratingB: Int, scoreA: Double, k: Int = 32): Int {
    val expectedA = 1.0 / (1.0 + 10.0.pow((ratingB - ratingA) / 400.0))
    return (k * (scoreA - expectedA)).roundToInt()
  }
}
