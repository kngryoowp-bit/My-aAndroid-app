package com.example.utils

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

enum class SoundEffectType(
  val labelId: String,
  val labelEn: String,
  val freqHz: Double,
  val freqEndHz: Double,
  val durationMs: Int
) {
  MESSAGE_SENT("Pesan Terkirim", "Message Sent", 660.0, 880.0, 90),
  MESSAGE_RECEIVED("Pesan Masuk", "Message Received", 523.25, 784.0, 130),
  CALL_RING("Nada Panggilan", "Call Ring", 740.0, 988.0, 260),
  NOTIFICATION("Notifikasi", "Notification", 587.33, 880.0, 150),
  FRIEND_REQUEST("Permintaan Teman", "Friend Request", 440.0, 659.25, 180),
  GAME_INVITE("Undangan Game", "Game Invite", 523.25, 1046.5, 190),
  PURCHASE("Transaksi Pasar", "Market Purchase", 659.25, 1318.5, 220),
  BUTTON("Klik Tombol", "Button Click", 480.0, 600.0, 45),
  POPUP("Pop-up / Modal", "Pop-up / Modal", 392.0, 587.33, 85);

  fun labelFor(langCode: String): String = when (langCode) {
    "id", "ms" -> labelId
    else -> labelEn
  }
}

data class SoundSettingsState(
  val masterEnabled: Boolean = true,
  val volume: Float = 0.7f,
  val mutedTypes: Set<SoundEffectType> = emptySet()
)

object SoundEffectsEngine {
  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
  private val _state = MutableStateFlow(SoundSettingsState())
  val state = _state.asStateFlow()

  private var appContext: Context? = null

  fun init(context: Context) {
    appContext = context.applicationContext
  }

  fun updateSettings(enabled: Boolean, volume: Float, mutedCsv: String) {
    val mutedSet = mutedCsv.split(',')
      .map { it.trim() }
      .filter { it.isNotEmpty() }
      .mapNotNull { name -> runCatching { SoundEffectType.valueOf(name) }.getOrNull() }
      .toSet()
    _state.value = SoundSettingsState(
      masterEnabled = enabled,
      volume = volume.coerceIn(0f, 1f),
      mutedTypes = mutedSet
    )
  }

  fun setMasterEnabled(enabled: Boolean) {
    _state.value = _state.value.copy(masterEnabled = enabled)
  }

  fun setVolume(volume: Float) {
    _state.value = _state.value.copy(volume = volume.coerceIn(0f, 1f))
  }

  fun toggleEffectMuted(type: SoundEffectType): Set<SoundEffectType> {
    val next = _state.value.mutedTypes.toMutableSet()
    if (!next.add(type)) next.remove(type)
    _state.value = _state.value.copy(mutedTypes = next)
    return next
  }

  fun play(type: SoundEffectType) {
    val cur = _state.value
    if (!cur.masterEnabled || cur.volume <= 0.01f || type in cur.mutedTypes) return
    playTone(type.freqHz, type.freqEndHz, type.durationMs, cur.volume * 0.45f)
  }

  fun playTone(freqStart: Double, freqEnd: Double, durationMs: Int, amplitude: Float = 0.35f) {
    scope.launch {
      runCatching {
        val sampleRate = 22050
        val count = ((durationMs / 1000.0) * sampleRate).toInt().coerceAtLeast(256)
        val samples = ShortArray(count)
        for (i in 0 until count) {
          val t = i.toDouble() / count
          val freq = freqStart + (freqEnd - freqStart) * t
          val env = (1.0 - t) * (1.0 - exp(-20.0 * t))
          val phase = 2.0 * PI * freq * (i.toDouble() / sampleRate)
          val v = (sin(phase) * env * amplitude * Short.MAX_VALUE).toInt()
            .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
          samples[i] = v.toShort()
        }
        val track = AudioTrack.Builder()
          .setAudioAttributes(
            AudioAttributes.Builder()
              .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
              .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
              .build()
          )
          .setAudioFormat(
            AudioFormat.Builder()
              .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
              .setSampleRate(sampleRate)
              .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
              .build()
          )
          .setTransferMode(AudioTrack.MODE_STATIC)
          .setBufferSizeInBytes(samples.size * 2)
          .build()
        track.write(samples, 0, samples.size)
        track.play()
        kotlinx.coroutines.delay(durationMs.toLong() + 40L)
        runCatching { track.stop() }
        runCatching { track.release() }
      }
    }
  }
}
