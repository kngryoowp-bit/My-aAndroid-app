package com.example.utils

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer

data class VideoInspectionResult(
  val durationMs: Long,
  val width: Int,
  val height: Int,
  val needsTrim: Boolean,
  val thumbnailPath: String?
)

object VideoTrimHelper {
  const val MAX_VIDEO_DURATION_MS = 7000L

  suspend fun inspectVideo(context: Context, uri: Uri): VideoInspectionResult = withContext(Dispatchers.IO) {
    val retriever = MediaMetadataRetriever()
    try {
      retriever.setDataSource(context, uri)
      val durMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
      val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
      val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
      val thumbPath = runCatching {
        val frame = retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        if (frame != null) {
          val thumbFile = File(context.cacheDir, "vthumb_${System.currentTimeMillis()}.jpg")
          FileOutputStream(thumbFile).use { fos ->
            frame.compress(Bitmap.CompressFormat.JPEG, 82, fos)
          }
          frame.recycle()
          thumbFile.absolutePath
        } else null
      }.getOrNull()
      VideoInspectionResult(
        durationMs = durMs,
        width = width,
        height = height,
        needsTrim = durMs > MAX_VIDEO_DURATION_MS,
        thumbnailPath = thumbPath
      )
    } finally {
      runCatching { retriever.release() }
    }
  }

  suspend fun trimVideoToMax7s(
    context: Context,
    uri: Uri,
    startMs: Long,
    endMs: Long
  ): Result<Pair<File, Long>> = withContext(Dispatchers.IO) {
    runCatching {
      val safeStartMs = startMs.coerceAtLeast(0L)
      val safeEndMs = endMs.coerceAtMost(safeStartMs + MAX_VIDEO_DURATION_MS).coerceAtLeast(safeStartMs + 500L)
      val outFile = File(context.cacheDir, "xchat_trim_${System.currentTimeMillis()}.mp4")

      val extractor = MediaExtractor()
      var muxer: MediaMuxer? = null
      try {
        extractor.setDataSource(context, uri, null)
        muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        val trackMap = mutableMapOf<Int, Int>()
        var maxBufferSize = 256 * 1024
        for (i in 0 until extractor.trackCount) {
          val format = extractor.getTrackFormat(i)
          val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
          if (mime.startsWith("video/") || mime.startsWith("audio/")) {
            extractor.selectTrack(i)
            val dstTrack = muxer.addTrack(format)
            trackMap[i] = dstTrack
            if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
              val trackMax = format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
              if (trackMax > maxBufferSize) maxBufferSize = trackMax
            }
          }
        }
        if (trackMap.isEmpty()) error("No audio/video tracks found")

        val retriever = MediaMetadataRetriever()
        runCatching {
          retriever.setDataSource(context, uri)
          val rot = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull()
          if (rot != null) muxer.setOrientationHint(rot)
        }
        runCatching { retriever.release() }

        muxer.start()
        extractor.seekTo(safeStartMs * 1000L, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

        val buffer = ByteBuffer.allocate(maxBufferSize)
        val bufferInfo = MediaCodec.BufferInfo()
        val endUs = safeEndMs * 1000L
        val startUs = safeStartMs * 1000L
        var firstSampleUs = -1L

        while (true) {
          val sampleSize = extractor.readSampleData(buffer, 0)
          if (sampleSize < 0) break
          val sampleTimeUs = extractor.sampleTime
          if (sampleTimeUs > endUs) break
          val trackIndex = extractor.sampleTrackIndex
          val dstIndex = trackMap[trackIndex]
          if (dstIndex != null && sampleTimeUs >= startUs - 500_000L) {
            if (firstSampleUs < 0L) firstSampleUs = sampleTimeUs
            bufferInfo.offset = 0
            bufferInfo.size = sampleSize
            bufferInfo.presentationTimeUs = (sampleTimeUs - firstSampleUs).coerceAtLeast(0L)
            @Suppress("DEPRECATION")
            bufferInfo.flags = extractor.sampleFlags
            muxer.writeSampleData(dstIndex, buffer, bufferInfo)
          }
          extractor.advance()
        }
        muxer.stop()
        val actualDur = (safeEndMs - safeStartMs).coerceIn(500L, MAX_VIDEO_DURATION_MS)
        outFile to actualDur
      } catch (t: Throwable) {
        runCatching { outFile.delete() }
        // Fallback: copy directly if inspection says <= 7s
        val inspected = runCatching {
          val r = MediaMetadataRetriever()
          r.setDataSource(context, uri)
          val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
          r.release()
          d
        }.getOrDefault(0L)
        if (inspected in 1L..MAX_VIDEO_DURATION_MS) {
          val fallbackOut = File(context.cacheDir, "xchat_vid_${System.currentTimeMillis()}.mp4")
          context.contentResolver.openInputStream(uri)?.use { inp ->
            fallbackOut.outputStream().use { out -> inp.copyTo(out) }
          } ?: throw t
          fallbackOut to inspected
        } else {
          throw t
        }
      } finally {
        runCatching { muxer?.release() }
        runCatching { extractor.release() }
      }
    }
  }
}
