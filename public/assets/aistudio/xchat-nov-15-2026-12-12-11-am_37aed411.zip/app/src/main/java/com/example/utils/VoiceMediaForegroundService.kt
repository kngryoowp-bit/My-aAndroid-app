package com.example.utils

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.ImageReader
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sqrt

object ScreenShareBus {
  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
  private var micJob: Job? = null

  private val _micLevel = MutableStateFlow(0f)
  val micLevel = _micLevel.asStateFlow()

  private val _latestFrame = MutableStateFlow<Bitmap?>(null)
  val latestFrame = _latestFrame.asStateFlow()

  private val _isScreenSharing = MutableStateFlow(false)
  val isScreenSharing = _isScreenSharing.asStateFlow()

  fun updateScreenSharing(active: Boolean, frame: Bitmap? = null) {
    _isScreenSharing.value = active
    if (!active) {
      _latestFrame.value = null
    } else if (frame != null) {
      _latestFrame.value = frame
    }
  }

  fun startMicLevelMonitor(context: Context, isMutedProvider: () -> Boolean) {
    micJob?.cancel()
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
      _micLevel.value = 0f
      return
    }
    micJob = scope.launch {
      val sampleRate = 16000
      val bufSize = AudioRecord.getMinBufferSize(
        sampleRate,
        AudioFormat.CHANNEL_IN_MONO,
        AudioFormat.ENCODING_PCM_16BIT
      ).coerceAtLeast(1024)
      val recorder = runCatching {
        AudioRecord(
          MediaRecorder.AudioSource.VOICE_COMMUNICATION,
          sampleRate,
          AudioFormat.CHANNEL_IN_MONO,
          AudioFormat.ENCODING_PCM_16BIT,
          bufSize
        )
      }.getOrNull() ?: return@launch

      if (recorder.state != AudioRecord.STATE_INITIALIZED) {
        runCatching { recorder.release() }
        return@launch
      }

      val buf = ShortArray(bufSize / 2)
      runCatching { recorder.startRecording() }
      try {
        while (isActive) {
          if (isMutedProvider()) {
            _micLevel.value = 0f
            delay(120L)
            continue
          }
          val read = recorder.read(buf, 0, buf.size)
          if (read > 0) {
            var sumSq = 0.0
            for (i in 0 until read) {
              val s = buf[i].toDouble() / Short.MAX_VALUE
              sumSq += s * s
            }
            val rms = sqrt(sumSq / read).toFloat()
            _micLevel.value = (rms * 3.8f).coerceIn(0f, 1f)
          }
          delay(60L)
        }
      } finally {
        runCatching { recorder.stop() }
        runCatching { recorder.release() }
        _micLevel.value = 0f
      }
    }
  }

  fun stopMicLevelMonitor() {
    micJob?.cancel()
    micJob = null
    _micLevel.value = 0f
  }

  fun playSoundboardCue(soundId: String) {
    when (soundId.lowercase()) {
      "airhorn", "horn" -> SoundEffectsEngine.playTone(440.0, 620.0, 280, 0.4f)
      "applause", "clap" -> SoundEffectsEngine.playTone(520.0, 780.0, 200, 0.35f)
      "rimshot", "drum" -> SoundEffectsEngine.playTone(220.0, 440.0, 160, 0.4f)
      "oof", "bruh" -> SoundEffectsEngine.playTone(300.0, 150.0, 220, 0.4f)
      else -> SoundEffectsEngine.playTone(587.33, 880.0, 180, 0.35f)
    }
  }
}

class VoiceMediaForegroundService : Service() {
  private var mediaProjection: MediaProjection? = null
  private var virtualDisplay: VirtualDisplay? = null
  private var imageReader: ImageReader? = null
  private var handlerThread: HandlerThread? = null

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    when (intent?.action) {
      ACTION_STOP_SHARE -> {
        stopProjection()
        stopSelf()
        return START_NOT_STICKY
      }
      ACTION_START_SHARE -> {
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        if (resultCode != Activity.RESULT_OK || data == null) {
          stopSelf()
          return START_NOT_STICKY
        }
        startFgNotification()
        startProjection(resultCode, data)
      }
    }
    return START_NOT_STICKY
  }

  private fun startFgNotification() {
    val channelId = "xchat_screen_share"
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      nm.createNotificationChannel(
        NotificationChannel(channelId, "XChat Screen Share", NotificationManager.IMPORTANCE_LOW)
      )
    }
    val notif: Notification = NotificationCompat.Builder(this, channelId)
      .setSmallIcon(android.R.drawable.presence_video_online)
      .setContentTitle("XChat Voice & Screen Share")
      .setContentText("Screen sharing is active")
      .setOngoing(true)
      .build()
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      startForeground(4102, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    } else {
      startForeground(4102, notif)
    }
  }

  private fun startProjection(resultCode: Int, data: Intent) {
    stopProjection()
    val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    val projection = mpm.getMediaProjection(resultCode, data) ?: return
    mediaProjection = projection
    val dm = resources.displayMetrics
    val width = (dm.widthPixels / 2).coerceAtLeast(360)
    val height = (dm.heightPixels / 2).coerceAtLeast(640)
    val density = dm.densityDpi

    val ht = HandlerThread("XChatScreenCapture").apply { start() }
    handlerThread = ht
    val handler = Handler(ht.looper)

    projection.registerCallback(object : MediaProjection.Callback() {
      override fun onStop() {
        ScreenShareBus.updateScreenSharing(false)
        stopSelf()
      }
    }, handler)

    val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
    imageReader = reader
    reader.setOnImageAvailableListener({ r ->
      val img = runCatching { r.acquireLatestImage() }.getOrNull() ?: return@setOnImageAvailableListener
      try {
        val plane = img.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * width
        val fullBmp = Bitmap.createBitmap(
          width + rowPadding / pixelStride,
          height,
          Bitmap.Config.ARGB_8888
        )
        fullBmp.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(fullBmp, 0, 0, width, height)
        if (cropped != fullBmp) fullBmp.recycle()
        ScreenShareBus.updateScreenSharing(true, cropped)
      } catch (_: Throwable) {
      } finally {
        img.close()
      }
    }, handler)

    virtualDisplay = projection.createVirtualDisplay(
      "XChatScreenShare",
      width,
      height,
      density,
      DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
      reader.surface,
      null,
      handler
    )
    ScreenShareBus.updateScreenSharing(true)
  }

  private fun stopProjection() {
    ScreenShareBus.updateScreenSharing(false)
    runCatching { virtualDisplay?.release() }
    virtualDisplay = null
    runCatching { imageReader?.close() }
    imageReader = null
    runCatching { mediaProjection?.stop() }
    mediaProjection = null
    runCatching { handlerThread?.quitSafely() }
    handlerThread = null
  }

  override fun onDestroy() {
    stopProjection()
    super.onDestroy()
  }

  companion object {
    private const val ACTION_START_SHARE = "com.example.action.START_SHARE"
    private const val ACTION_STOP_SHARE = "com.example.action.STOP_SHARE"
    private const val EXTRA_RESULT_CODE = "result_code"
    private const val EXTRA_RESULT_DATA = "result_data"

    fun startScreenShare(context: Context, resultCode: Int, data: Intent) {
      val intent = Intent(context, VoiceMediaForegroundService::class.java).apply {
        action = ACTION_START_SHARE
        putExtra(EXTRA_RESULT_CODE, resultCode)
        putExtra(EXTRA_RESULT_DATA, data)
      }
      ContextCompat.startForegroundService(context, intent)
    }

    fun stopScreenShare(context: Context) {
      ScreenShareBus.updateScreenSharing(false)
      val intent = Intent(context, VoiceMediaForegroundService::class.java).apply {
        action = ACTION_STOP_SHARE
      }
      runCatching { context.startService(intent) }
    }
  }
}
