package com.example.utils

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import androidx.core.content.ContextCompat
import com.google.firebase.Firebase
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.firestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.webrtc.AudioSource
import org.webrtc.AudioTrack as RtcAudioTrack
import org.webrtc.Camera2Enumerator
import org.webrtc.CameraVideoCapturer
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoSource
import org.webrtc.VideoTrack
import java.util.UUID
import kotlin.math.sqrt

enum class RtcConnectionStage {
  IDLE,
  RINGING,
  CONNECTING,
  CONNECTED,
  RECONNECTING,
  ENDED,
  FAILED
}

data class RtcCallUiState(
  val callId: String? = null,
  val callType: String = "DM_VOICE",
  val stage: RtcConnectionStage = RtcConnectionStage.IDLE,
  val isIncoming: Boolean = false,
  val peerId: String = "",
  val peerName: String = "",
  val peerAvatarUri: String? = null,
  val isMuted: Boolean = false,
  val isDeafened: Boolean = false,
  val isSpeakerOn: Boolean = true,
  val isCameraOn: Boolean = false,
  val remoteAudioDetected: Boolean = false,
  val connectedPeerCount: Int = 0,
  val callDurationSec: Long = 0L,
  val qualityLabel: String = "Opus 48kHz • P2P",
  val errorMessage: String? = null,
  val isMicLoopbackTesting: Boolean = false,
  val loopbackDbLevel: Float = 0f
)

object WebRtcCallManager {
  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
  private val db by lazy { Firebase.firestore }

  private val _callState = MutableStateFlow(RtcCallUiState())
  val callState = _callState.asStateFlow()

  private val _localVideoTrack = MutableStateFlow<VideoTrack?>(null)
  val localVideoTrack = _localVideoTrack.asStateFlow()

  private val _remoteVideoTracks = MutableStateFlow<Map<String, VideoTrack>>(emptyMap())
  val remoteVideoTracks = _remoteVideoTracks.asStateFlow()

  private var eglBase: EglBase? = null
  private var factory: PeerConnectionFactory? = null
  private var localAudioSource: AudioSource? = null
  private var localAudioTrack: RtcAudioTrack? = null
  private var localVideoSource: VideoSource? = null
  private var videoCapturer: CameraVideoCapturer? = null
  private var surfaceTextureHelper: SurfaceTextureHelper? = null

  private val peerConnections = mutableMapOf<String, PeerConnection>()
  private var incomingCallListener: ListenerRegistration? = null
  private var activeCallDocListener: ListenerRegistration? = null
  private var timerJob: Job? = null
  private var loopbackJob: Job? = null

  private val iceServers = listOf(
    PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
    PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
  )

  @Synchronized
  fun getEglContext(): EglBase.Context? {
    if (eglBase == null) {
      eglBase = runCatching { EglBase.create() }.getOrNull()
    }
    return eglBase?.eglBaseContext
  }

  @Synchronized
  private fun ensureFactory(context: Context): PeerConnectionFactory? {
    factory?.let { return it }
    val appCtx = context.applicationContext
    val eglCtx = getEglContext()
    return runCatching {
      PeerConnectionFactory.initialize(
        PeerConnectionFactory.InitializationOptions.builder(appCtx)
          .setEnableInternalTracer(false)
          .createInitializationOptions()
      )
      val encoderFactory = DefaultVideoEncoderFactory(eglCtx, true, true)
      val decoderFactory = DefaultVideoDecoderFactory(eglCtx)
      val created = PeerConnectionFactory.builder()
        .setVideoEncoderFactory(encoderFactory)
        .setVideoDecoderFactory(decoderFactory)
        .createPeerConnectionFactory()
      factory = created
      created
    }.getOrNull()
  }

  private fun ensureLocalAudioTrack(context: Context): RtcAudioTrack? {
    localAudioTrack?.let { return it }
    val f = ensureFactory(context) ?: return null
    val constraints = MediaConstraints().apply {
      mandatory.add(MediaConstraints.KeyValuePair("googEchoCancellation", "true"))
      mandatory.add(MediaConstraints.KeyValuePair("googNoiseSuppression", "true"))
      mandatory.add(MediaConstraints.KeyValuePair("googAutoGainControl", "true"))
    }
    val src = f.createAudioSource(constraints)
    val track = f.createAudioTrack("xchat_audio_${UUID.randomUUID()}", src)
    track.setEnabled(!_callState.value.isMuted && !_callState.value.isDeafened)
    localAudioSource = src
    localAudioTrack = track
    return track
  }

  fun observeIncomingCalls(context: Context, myUserId: String) {
    incomingCallListener?.remove()
    incomingCallListener = db.collection("calls")
      .whereArrayContains("participants", myUserId)
      .whereEqualTo("status", "RINGING")
      .addSnapshotListener { snap, err ->
        if (err != null || snap == null) return@addSnapshotListener
        for (doc in snap.documents) {
          val calleeId = doc.getString("calleeId") ?: continue
          if (calleeId != myUserId) continue
          if (_callState.value.stage != RtcConnectionStage.IDLE) continue
          val callId = doc.id
          val callType = doc.getString("callType") ?: "DM_VOICE"
          val callerId = doc.getString("callerId") ?: ""
          val callerName = doc.getString("callerName") ?: "XChat User"
          val callerAvatar = doc.getString("callerAvatarUri")
          _callState.value = RtcCallUiState(
            callId = callId,
            callType = callType,
            stage = RtcConnectionStage.RINGING,
            isIncoming = true,
            peerId = callerId,
            peerName = callerName,
            peerAvatarUri = callerAvatar,
            isCameraOn = callType == "DM_VIDEO"
          )
          SoundEffectsEngine.play(SoundEffectType.CALL_RING)
          watchCallDocument(context, callId, myUserId)
          break
        }
      }
  }

  fun startOutgoingDmCall(
    context: Context,
    callerId: String,
    callerName: String,
    callerAvatarUri: String?,
    calleeId: String,
    calleeName: String,
    isVideo: Boolean
  ) {
    val callId = "call_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}"
    val callType = if (isVideo) "DM_VIDEO" else "DM_VOICE"
    _callState.value = RtcCallUiState(
      callId = callId,
      callType = callType,
      stage = RtcConnectionStage.RINGING,
      isIncoming = false,
      peerId = calleeId,
      peerName = calleeName,
      isCameraOn = isVideo
    )
    setSpeakerphone(context, isVideo)

    val pc = createPeerConnection(context, calleeId, callId, callerId)
    ensureLocalAudioTrack(context)?.let { track ->
      pc?.addTrack(track, listOf("xchat_stream"))
    }
    if (isVideo) {
      enableLocalCamera(context, true)?.let { vTrack ->
        pc?.addTrack(vTrack, listOf("xchat_stream"))
      }
    }

    val mediaConstraints = MediaConstraints().apply {
      mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
      mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", if (isVideo) "true" else "false"))
    }

    val callMap = hashMapOf(
      "participants" to listOf(callerId, calleeId),
      "callType" to callType,
      "callerId" to callerId,
      "callerName" to callerName,
      "callerAvatarUri" to callerAvatarUri,
      "calleeId" to calleeId,
      "calleeName" to calleeName,
      "status" to "RINGING",
      "qualityLabel" to "Opus 48kHz • P2P"
    )

    if (pc == null) {
      db.collection("calls").document(callId).set(callMap)
      watchCallDocument(context, callId, callerId)
      return
    }

    pc.createOffer(object : SdpObserver {
      override fun onCreateSuccess(sdp: SessionDescription?) {
        if (sdp == null) return
        pc.setLocalDescription(SimpleSdpObserver(), sdp)
        callMap["offerSdp"] = sdp.description
        db.collection("calls").document(callId).set(callMap)
        watchCallDocument(context, callId, callerId)
      }
      override fun onSetSuccess() {}
      override fun onCreateFailure(err: String?) {
        callMap["offerSdp"] = ""
        db.collection("calls").document(callId).set(callMap)
        watchCallDocument(context, callId, callerId)
      }
      override fun onSetFailure(err: String?) {}
    }, mediaConstraints)
  }

  fun acceptIncomingDmCall(context: Context, myUserId: String) {
    val cur = _callState.value
    val callId = cur.callId ?: return
    _callState.value = cur.copy(stage = RtcConnectionStage.CONNECTING)
    setSpeakerphone(context, cur.callType == "DM_VIDEO")

    db.collection("calls").document(callId).get().addOnSuccessListener { snap ->
      val offerSdp = snap.getString("offerSdp").orEmpty()
      val callerId = snap.getString("callerId") ?: cur.peerId
      val pc = createPeerConnection(context, callerId, callId, myUserId)
      ensureLocalAudioTrack(context)?.let { track ->
        pc?.addTrack(track, listOf("xchat_stream"))
      }
      if (cur.callType == "DM_VIDEO") {
        enableLocalCamera(context, true)?.let { vTrack ->
          pc?.addTrack(vTrack, listOf("xchat_stream"))
        }
      }

      if (pc != null && offerSdp.isNotBlank()) {
        val remoteSdp = SessionDescription(SessionDescription.Type.OFFER, offerSdp)
        pc.setRemoteDescription(object : SimpleSdpObserver() {
          override fun onSetSuccess() {
            val constraints = MediaConstraints().apply {
              mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
              mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", if (cur.callType == "DM_VIDEO") "true" else "false"))
            }
            pc.createAnswer(object : SdpObserver {
              override fun onCreateSuccess(ans: SessionDescription?) {
                if (ans == null) return
                pc.setLocalDescription(SimpleSdpObserver(), ans)
                db.collection("calls").document(callId).update(
                  mapOf("status" to "ACTIVE", "answerSdp" to ans.description)
                )
              }
              override fun onSetSuccess() {}
              override fun onCreateFailure(err: String?) {
                db.collection("calls").document(callId).update("status", "ACTIVE")
              }
              override fun onSetFailure(err: String?) {}
            }, constraints)
          }
        }, remoteSdp)
      } else {
        db.collection("calls").document(callId).update("status", "ACTIVE")
        startCallTimer()
        _callState.value = _callState.value.copy(stage = RtcConnectionStage.CONNECTED, connectedPeerCount = 1)
      }
    }
  }

  fun declineOrEndCall(context: Context) {
    val cur = _callState.value
    val callId = cur.callId
    val newStatus = if (cur.isIncoming && cur.stage == RtcConnectionStage.RINGING) "DECLINED" else "ENDED"
    if (!callId.isNullOrBlank()) {
      runCatching { db.collection("calls").document(callId).update("status", newStatus) }
    }
    cleanupAllPeers()
  }

  fun joinServerVoiceMesh(
    context: Context,
    serverId: String,
    channelId: String,
    channelName: String,
    myId: String,
    participantIds: List<String>
  ) {
    setSpeakerphone(context, true)
    ensureLocalAudioTrack(context)
    val others = participantIds.filter { it != myId }
    _callState.value = _callState.value.copy(
      callId = channelId,
      callType = "SERVER_VOICE",
      stage = RtcConnectionStage.CONNECTED,
      peerId = serverId,
      peerName = channelName,
      connectedPeerCount = others.size,
      errorMessage = null
    )
    startCallTimer()
  }

  fun syncServerVoicePeers(
    context: Context,
    serverId: String,
    channelId: String,
    myId: String,
    participantIds: List<String>
  ) {
    if (_callState.value.callType != "SERVER_VOICE") return
    val others = participantIds.filter { it != myId }
    _callState.value = _callState.value.copy(connectedPeerCount = others.size)
  }

  fun setMuted(muted: Boolean) {
    _callState.value = _callState.value.copy(isMuted = muted)
    localAudioTrack?.setEnabled(!muted && !_callState.value.isDeafened)
  }

  fun setDeafened(deafened: Boolean) {
    _callState.value = _callState.value.copy(isDeafened = deafened)
    localAudioTrack?.setEnabled(!deafened && !_callState.value.isMuted)
  }

  fun setSpeakerphone(context: Context, enabled: Boolean) {
    _callState.value = _callState.value.copy(isSpeakerOn = enabled)
    runCatching {
      val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
      am.mode = AudioManager.MODE_IN_COMMUNICATION
      @Suppress("DEPRECATION")
      am.isSpeakerphoneOn = enabled
    }
  }

  fun setCameraEnabled(context: Context, enabled: Boolean) {
    _callState.value = _callState.value.copy(isCameraOn = enabled)
    if (enabled) {
      enableLocalCamera(context, true)
    } else {
      enableLocalCamera(context, false)
    }
  }

  private fun enableLocalCamera(context: Context, enabled: Boolean): VideoTrack? {
    if (!enabled) {
      runCatching { videoCapturer?.stopCapture() }
      runCatching { videoCapturer?.dispose() }
      videoCapturer = null
      _localVideoTrack.value = null
      return null
    }
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
      return null
    }
    _localVideoTrack.value?.let { return it }
    val f = ensureFactory(context) ?: return null
    val eglCtx = getEglContext() ?: return null
    val enumerator = Camera2Enumerator(context)
    val camName = enumerator.deviceNames.firstOrNull { enumerator.isFrontFacing(it) }
      ?: enumerator.deviceNames.firstOrNull()
      ?: return null
    val capturer = enumerator.createCapturer(camName, null) ?: return null
    val sth = SurfaceTextureHelper.create("XChatCaptureThread", eglCtx)
    val vSrc = f.createVideoSource(capturer.isScreencast)
    capturer.initialize(sth, context.applicationContext, vSrc.capturerObserver)
    runCatching { capturer.startCapture(640, 480, 24) }
    val vTrack = f.createVideoTrack("xchat_video_${UUID.randomUUID()}", vSrc)
    vTrack.setEnabled(true)
    videoCapturer = capturer
    surfaceTextureHelper = sth
    localVideoSource = vSrc
    _localVideoTrack.value = vTrack
    return vTrack
  }

  fun toggleMicLoopbackTest(context: Context) {
    if (_callState.value.isMicLoopbackTesting) {
      loopbackJob?.cancel()
      loopbackJob = null
      _callState.value = _callState.value.copy(isMicLoopbackTesting = false, loopbackDbLevel = 0f)
      return
    }
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
      _callState.value = _callState.value.copy(errorMessage = "Microphone permission required for mic test.")
      return
    }
    _callState.value = _callState.value.copy(isMicLoopbackTesting = true, errorMessage = null)
    loopbackJob = scope.launch {
      val sampleRate = 16000
      val bufSize = AudioRecord.getMinBufferSize(
        sampleRate,
        AudioFormat.CHANNEL_IN_MONO,
        AudioFormat.ENCODING_PCM_16BIT
      ).coerceAtLeast(1024)
      val rec = runCatching {
        AudioRecord(
          MediaRecorder.AudioSource.VOICE_COMMUNICATION,
          sampleRate,
          AudioFormat.CHANNEL_IN_MONO,
          AudioFormat.ENCODING_PCM_16BIT,
          bufSize
        )
      }.getOrNull() ?: return@launch

      val player = AudioTrack.Builder()
        .setAudioAttributes(
          AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        )
        .setAudioFormat(
          AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(sampleRate)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()
        )
        .setBufferSizeInBytes(bufSize)
        .setTransferMode(AudioTrack.MODE_STREAM)
        .build()

      val buf = ShortArray(bufSize / 2)
      runCatching {
        rec.startRecording()
        player.play()
        while (isActive) {
          val n = rec.read(buf, 0, buf.size)
          if (n > 0) {
            player.write(buf, 0, n)
            var sum = 0.0
            for (i in 0 until n) {
              val x = buf[i].toDouble() / Short.MAX_VALUE
              sum += x * x
            }
            val level = (sqrt(sum / n).toFloat() * 4.0f).coerceIn(0f, 1f)
            _callState.value = _callState.value.copy(loopbackDbLevel = level)
          }
        }
      }
      runCatching { rec.stop() }
      runCatching { rec.release() }
      runCatching { player.stop() }
      runCatching { player.release() }
      _callState.value = _callState.value.copy(isMicLoopbackTesting = false, loopbackDbLevel = 0f)
    }
  }

  fun playSpeakerDiagnosticsTone() {
    SoundEffectsEngine.playTone(440.0, 880.0, 350, 0.45f)
  }

  fun cleanupAllPeers() {
    timerJob?.cancel()
    timerJob = null
    loopbackJob?.cancel()
    loopbackJob = null
    activeCallDocListener?.remove()
    activeCallDocListener = null
    peerConnections.values.forEach { runCatching { it.close() }; runCatching { it.dispose() } }
    peerConnections.clear()
    runCatching { videoCapturer?.stopCapture() }
    runCatching { videoCapturer?.dispose() }
    videoCapturer = null
    runCatching { surfaceTextureHelper?.dispose() }
    surfaceTextureHelper = null
    runCatching { localVideoSource?.dispose() }
    localVideoSource = null
    runCatching { localAudioSource?.dispose() }
    localAudioSource = null
    localAudioTrack = null
    _localVideoTrack.value = null
    _remoteVideoTracks.value = emptyMap()
    _callState.value = RtcCallUiState()
  }

  private fun watchCallDocument(context: Context, callId: String, myId: String) {
    activeCallDocListener?.remove()
    activeCallDocListener = db.collection("calls").document(callId)
      .addSnapshotListener { snap, _ ->
        if (snap == null || !snap.exists()) return@addSnapshotListener
        val status = snap.getString("status") ?: return@addSnapshotListener
        when (status) {
          "ENDED", "DECLINED" -> cleanupAllPeers()
          "ACTIVE" -> {
            val ansSdp = snap.getString("answerSdp")
            val cur = _callState.value
            if (!cur.isIncoming && !ansSdp.isNullOrBlank()) {
              val pc = peerConnections[cur.peerId]
              if (pc != null && pc.remoteDescription == null) {
                pc.setRemoteDescription(
                  SimpleSdpObserver(),
                  SessionDescription(SessionDescription.Type.ANSWER, ansSdp)
                )
              }
            }
            if (cur.stage != RtcConnectionStage.CONNECTED) {
              _callState.value = cur.copy(stage = RtcConnectionStage.CONNECTED, connectedPeerCount = 1)
              startCallTimer()
            }
          }
        }
      }
  }

  private fun createPeerConnection(
    context: Context,
    peerId: String,
    callId: String,
    myId: String
  ): PeerConnection? {
    val f = ensureFactory(context) ?: return null
    val cfg = PeerConnection.RTCConfiguration(iceServers).apply {
      sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
    }
    val observer = object : PeerConnection.Observer {
      override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
      override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
        when (s) {
          PeerConnection.IceConnectionState.CONNECTED -> {
            _callState.value = _callState.value.copy(
              stage = RtcConnectionStage.CONNECTED,
              remoteAudioDetected = true,
              connectedPeerCount = peerConnections.size.coerceAtLeast(1)
            )
            startCallTimer()
          }
          PeerConnection.IceConnectionState.DISCONNECTED -> {
            _callState.value = _callState.value.copy(stage = RtcConnectionStage.RECONNECTING)
          }
          PeerConnection.IceConnectionState.FAILED -> {
            _callState.value = _callState.value.copy(stage = RtcConnectionStage.FAILED)
          }
          else -> {}
        }
      }
      override fun onIceConnectionReceivingChange(b: Boolean) {}
      override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {}
      override fun onIceCandidate(c: IceCandidate?) {
        if (c == null) return
        val candMap = hashMapOf(
          "from" to myId,
          "sdpMid" to c.sdpMid,
          "sdpMLineIndex" to c.sdpMLineIndex,
          "sdp" to c.sdp
        )
        runCatching { db.collection("calls").document(callId).collection("candidates").add(candMap) }
      }
      override fun onIceCandidatesRemoved(arr: Array<out IceCandidate>?) {}
      override fun onAddStream(stream: MediaStream?) {
        stream?.videoTracks?.firstOrNull()?.let { vt ->
          _remoteVideoTracks.value = _remoteVideoTracks.value + (peerId to vt)
        }
        if (stream?.audioTracks?.isNotEmpty() == true) {
          _callState.value = _callState.value.copy(remoteAudioDetected = true)
        }
      }
      override fun onRemoveStream(stream: MediaStream?) {
        _remoteVideoTracks.value = _remoteVideoTracks.value - peerId
      }
      override fun onDataChannel(dc: DataChannel?) {}
      override fun onRenegotiationNeeded() {}
      override fun onAddTrack(receiver: RtpReceiver?, streams: Array<out MediaStream>?) {
        val track = receiver?.track()
        if (track is VideoTrack) {
          _remoteVideoTracks.value = _remoteVideoTracks.value + (peerId to track)
        } else if (track != null) {
          _callState.value = _callState.value.copy(remoteAudioDetected = true)
        }
      }
    }
    val pc = f.createPeerConnection(cfg, observer)
    if (pc != null) {
      peerConnections[peerId] = pc
      db.collection("calls").document(callId).collection("candidates")
        .addSnapshotListener { snap, _ ->
          snap?.documentChanges?.forEach { change ->
            val d = change.document
            val from = d.getString("from") ?: return@forEach
            if (from != myId) {
              val sdp = d.getString("sdp") ?: return@forEach
              val mid = d.getString("sdpMid") ?: ""
              val idx = d.getLong("sdpMLineIndex")?.toInt() ?: 0
              pc.addIceCandidate(IceCandidate(mid, idx, sdp))
            }
          }
        }
    }
    return pc
  }

  private fun startCallTimer() {
    if (timerJob?.isActive == true) return
    timerJob = scope.launch {
      while (isActive) {
        delay(1000L)
        _callState.value = _callState.value.copy(callDurationSec = _callState.value.callDurationSec + 1L)
      }
    }
  }

  private open class SimpleSdpObserver : SdpObserver {
    override fun onCreateSuccess(p0: SessionDescription?) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(p0: String?) {}
    override fun onSetFailure(p0: String?) {}
  }
}
