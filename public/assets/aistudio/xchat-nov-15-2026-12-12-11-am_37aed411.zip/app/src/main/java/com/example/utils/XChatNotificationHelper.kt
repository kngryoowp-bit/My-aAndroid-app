package com.example.utils

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity

object XChatNotificationHelper {
  const val CHANNEL_MESSAGES = "xchat_messages"
  const val CHANNEL_CALLS = "xchat_calls"
  const val EXTRA_NAV_TYPE = "xchat_nav_type"
  const val EXTRA_NAV_TARGET_ID = "xchat_nav_target_id"

  fun ensureChannels(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      val msgChan = NotificationChannel(
        CHANNEL_MESSAGES,
        "XChat Messages",
        NotificationManager.IMPORTANCE_HIGH
      ).apply { description = "Channel & Direct Message alerts" }

      val callChan = NotificationChannel(
        CHANNEL_CALLS,
        "XChat Voice & Calls",
        NotificationManager.IMPORTANCE_HIGH
      ).apply { description = "Voice rooms and WebRTC calls" }

      nm.createNotificationChannel(msgChan)
      nm.createNotificationChannel(callChan)
    }
  }

  fun showIncomingMessageNotification(
    context: Context,
    title: String,
    body: String,
    isDm: Boolean,
    targetId: String
  ) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      val granted = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.POST_NOTIFICATIONS
      ) == PackageManager.PERMISSION_GRANTED
      if (!granted) return
    }
    ensureChannels(context)
    val intent = Intent(context, MainActivity::class.java).apply {
      flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
      putExtra(EXTRA_NAV_TYPE, if (isDm) "DM" else "CHANNEL")
      putExtra(EXTRA_NAV_TARGET_ID, targetId)
    }
    val pi = PendingIntent.getActivity(
      context,
      targetId.hashCode(),
      intent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val notif = NotificationCompat.Builder(context, CHANNEL_MESSAGES)
      .setSmallIcon(android.R.drawable.stat_notify_chat)
      .setContentTitle(title)
      .setContentText(body)
      .setPriority(NotificationCompat.PRIORITY_HIGH)
      .setAutoCancel(true)
      .setContentIntent(pi)
      .build()
    runCatching {
      NotificationManagerCompat.from(context).notify((targetId.hashCode() and 0x7FFFFFFF), notif)
    }
  }
}
