package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.DirectMessageEntity
import com.example.data.model.ForumPostEntity
import com.example.data.model.MessageEntity
import com.example.data.model.SavedProfileThemeEntity
import com.example.data.model.ServerEntity
import com.example.data.model.ServerRoleEntity
import com.example.data.model.VoiceParticipantModel
import com.example.data.remote.FirestoreCloudRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.UUID

class XChatFirestoreRepositoryRuleTest : FirestoreEmulatorTestBase() {

  @Test
  fun createOwnProfile_andObservePublicUsers_succeedsForAuthenticatedUser() = runBlocking {
    val aliceUid = signInTestUser(ALICE_EMAIL)
    val repo = FirestoreCloudRepository(firestore, auth)
    val suffix = UUID.randomUUID().toString().take(6)
    val username = "alice_$suffix"

    val result = withTimeout(DEFAULT_TIMEOUT_MS) {
      repo.createOrUpdateOwnProfile(
        username = username,
        displayName = "Alice Tester",
        bio = "Testing real-time sync",
        presenceStatus = "ONLINE",
        statusTag = "Testing"
      )
    }
    assertTrue("Expected profile creation to succeed: ${result.exceptionOrNull()}", result.isSuccess)

    val found = withTimeout(DEFAULT_TIMEOUT_MS) {
      repo.findUserByUsernameOnce(username)
    }
    assertNotNull(found)
    assertEquals(aliceUid, found?.id)

    val users = withTimeout(FLOW_TIMEOUT_MS) {
      repo.observePublicUsers().first { list -> list.any { it.id == aliceUid } }
    }
    assertTrue(users.any { it.username == username })
  }

  @Test
  fun readPrivateInfo_crossUser_failsWithPermissionDenied() = runBlocking {
    val aliceUid = signInTestUser(ALICE_EMAIL)
    val aliceRepo = FirestoreCloudRepository(firestore, auth)
    withTimeout(DEFAULT_TIMEOUT_MS) {
      aliceRepo.upsertPrivateInfo(
        userId = aliceUid,
        email = ALICE_EMAIL,
        languageCode = "id",
        allowProfileVisitors = true
      )
    }

    signInTestUser(BOB_EMAIL)
    val bobRepo = FirestoreCloudRepository(firestore, auth)
    val readResult = withTimeout(DEFAULT_TIMEOUT_MS) {
      bobRepo.readPrivateInfo(aliceUid)
    }
    assertTrue("Cross-user private read must fail", readResult.isFailure)
    val ex = readResult.exceptionOrNull()?.unwrapFirestoreException()
    assertNotNull("Expected FirebaseFirestoreException", ex)
    assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, ex?.code)
  }

  @Test
  fun sendDirectMessage_participantCanRead_outsiderGetsPermissionDenied() = runBlocking {
    val aliceUid = signInTestUser(ALICE_EMAIL)
    val bobUid = signInTestUser(BOB_EMAIL)
    signInTestUser(ALICE_EMAIL)

    val aliceRepo = FirestoreCloudRepository(firestore, auth)
    val dmId = "dm_${UUID.randomUUID()}"
    val conversationId = listOf(aliceUid, bobUid).sorted().joinToString("_")
    val dm = DirectMessageEntity(
      id = dmId,
      conversationId = conversationId,
      senderId = aliceUid,
      senderName = "Alice",
      receiverId = bobUid,
      content = "Secret DM for Bob"
    )

    val sendResult = withTimeout(DEFAULT_TIMEOUT_MS) { aliceRepo.sendDirectMessage(dm) }
    assertTrue("DM send should succeed", sendResult.isSuccess)

    signInTestUser(BOB_EMAIL)
    val bobRepo = FirestoreCloudRepository(firestore, auth)
    val bobRead = withTimeout(DEFAULT_TIMEOUT_MS) { bobRepo.readDirectMessage(dmId) }
    assertTrue("Receiver Bob should read DM", bobRead.isSuccess)
    assertEquals("Secret DM for Bob", bobRead.getOrNull()?.content)

    signInTestUser(CHARLIE_EMAIL)
    val charlieRepo = FirestoreCloudRepository(firestore, auth)
    val charlieRead = withTimeout(DEFAULT_TIMEOUT_MS) { charlieRepo.readDirectMessage(dmId) }
    assertTrue("Outsider Charlie must not read DM", charlieRead.isFailure)
    val ex = charlieRead.exceptionOrNull()?.unwrapFirestoreException()
    assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, ex?.code)
  }

  @Test
  fun upsertServerAndForumPost_withMultiGameAndRoleIcon_succeeds() = runBlocking {
    val aliceUid = signInTestUser(ALICE_EMAIL)
    val repo = FirestoreCloudRepository(firestore, auth)
    val serverId = "srv_${UUID.randomUUID()}"
    val channelId = "chn_${UUID.randomUUID()}"
    val postId = "post_${UUID.randomUUID()}"
    val roleId = "role_${UUID.randomUUID()}"

    withTimeout(DEFAULT_TIMEOUT_MS) {
      repo.upsertServer(
        ServerEntity(
          id = serverId,
          name = "Cyber Hub",
          description = "Multi game server",
          inviteCode = "CYBER_${UUID.randomUUID().toString().take(4)}",
          ownerId = aliceUid,
          boostLevel = 2,
          boostCount = 5,
          serverType = "Gaming",
          serverTag = "CYBR",
          serverTagIcon = "shield",
          serverGenre = "FPS / RPG",
          supportedGame = "minecraft,valorant,fortnite,marvel_rivals"
        ),
        isCreate = true
      )
      repo.upsertRole(
        ServerRoleEntity(
          id = roleId,
          serverId = serverId,
          name = "MVP",
          colorHex = 0xFF8B5CF6L,
          iconUri = "https://tmpfiles.org/dl/12345/icon.png",
          chromaKeyColorsCsv = "#00FF00,#FFFFFF"
        )
      )
      repo.createForumPost(
        ForumPostEntity(
          id = postId,
          channelId = channelId,
          authorId = aliceUid,
          authorName = "Alice",
          title = "Fortnite Season Guide",
          content = "Best drop spots",
          tagLabel = "Games",
          tagEmoji = "🎮"
        )
      )
    }

    val posts = withTimeout(FLOW_TIMEOUT_MS) {
      repo.observeForumPosts(channelId).first { list -> list.any { it.id == postId } }
    }
    assertTrue(posts.any { it.title == "Fortnite Season Guide" })
  }

  @Test
  fun savedThemes_voiceParticipants_andMessageReadReceipts_enforceRules() = runBlocking {
    val aliceUid = signInTestUser(ALICE_EMAIL)
    val aliceRepo = FirestoreCloudRepository(firestore, auth)
    val themeId = "theme_${UUID.randomUUID()}"
    val serverId = "srv_${UUID.randomUUID()}"
    val channelId = "chn_${UUID.randomUUID()}"
    val messageId = "msg_${UUID.randomUUID()}"

    withTimeout(DEFAULT_TIMEOUT_MS) {
      aliceRepo.upsertSavedTheme(
        SavedProfileThemeEntity(
          id = themeId,
          userId = aliceUid,
          name = "Sasuke",
          displayNameFont = "GOTHIC",
          profileBgColorsCsv = "0xFF1E1B4B,0xFF312E81,0xFF0F172A",
          isEquipped = true
        )
      )
      aliceRepo.upsertVoiceParticipant(
        VoiceParticipantModel(
          userId = aliceUid,
          channelId = channelId,
          serverId = serverId,
          displayName = "Alice",
          isCameraOn = true,
          isSpeaking = true
        )
      )
      aliceRepo.sendChannelMessage(
        MessageEntity(
          id = messageId,
          channelId = channelId,
          senderId = aliceUid,
          senderName = "Alice",
          content = "Read receipt test",
          readByCsv = aliceUid
        )
      )
    }

    val themes = withTimeout(FLOW_TIMEOUT_MS) {
      aliceRepo.observeSavedThemes(aliceUid).first { list -> list.any { it.id == themeId } }
    }
    assertTrue(themes.any { it.name == "Sasuke" && it.isEquipped })

    val participants = withTimeout(FLOW_TIMEOUT_MS) {
      aliceRepo.observeVoiceParticipants(serverId, channelId).first { list -> list.any { it.userId == aliceUid } }
    }
    assertTrue(participants.any { it.isCameraOn && it.isSpeaking })

    val bobUid = signInTestUser(BOB_EMAIL)
    val bobRepo = FirestoreCloudRepository(firestore, auth)
    withTimeout(DEFAULT_TIMEOUT_MS) {
      bobRepo.markChannelMessageReadBy(channelId, messageId, "$aliceUid,$bobUid")
    }
    val updatedMessages = withTimeout(FLOW_TIMEOUT_MS) {
      bobRepo.observeChannelMessages(channelId).first { list ->
        list.any { it.id == messageId && it.readByCsv.contains(bobUid) }
      }
    }
    assertTrue(updatedMessages.any { it.id == messageId && it.readByCsv.contains(bobUid) })

    // Cross-user read of Alice's saved_themes must fail with PERMISSION_DENIED
    try {
      withTimeout(FLOW_TIMEOUT_MS) {
        bobRepo.observeSavedThemes(aliceUid).first()
      }
      fail("Expected cross-user saved_themes read to fail")
    } catch (e: Exception) {
      val firestoreEx = e.unwrapFirestoreException()
      assertNotNull("Expected FirebaseFirestoreException, got $e", firestoreEx)
      assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx?.code)
    }
  }

  @Test
  fun observePublicUsers_unauthenticated_failsWithPermissionDenied() = runBlocking {
    auth.signOut()
    val repo = FirestoreCloudRepository(firestore, auth)
    try {
      withTimeout(FLOW_TIMEOUT_MS) {
        repo.observePublicUsers().first()
      }
      fail("Expected unauthenticated repo stream to fail")
    } catch (e: Exception) {
      assertTrue("Expected IllegalStateException fail-fast, got $e", e is IllegalStateException)
    }

    // Also verify Firestore rules directly reject unauthenticated list query with PERMISSION_DENIED
    try {
      withTimeout(FLOW_TIMEOUT_MS) {
        firestore.collection("users")
          .whereEqualTo("isPublicProfile", true)
          .snapshots()
          .first()
      }
      fail("Expected unauthenticated Firestore query to fail with PERMISSION_DENIED")
    } catch (e: Exception) {
      val firestoreEx = e.unwrapFirestoreException()
      assertNotNull("Expected nested FirebaseFirestoreException, got $e", firestoreEx)
      assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx?.code)
    }
  }

  @Test
  fun ensureUserProfile_createUpdateAndReRegister_succeedsAndPreservesSecurity() = runBlocking {
    val aliceUid = signInTestUser(ALICE_EMAIL)
    val fbUser = checkNotNull(auth.currentUser) { "Expected authenticated FirebaseUser" }
    val repo = FirestoreCloudRepository(firestore, auth)

    // 1. Initial login creates full 45-field user profile in Firestore without hitting expression limit
    val initial = withTimeout(DEFAULT_TIMEOUT_MS) {
      repo.ensureUserProfile(
        firebaseUser = fbUser,
        preferredUsername = null,
        preferredDisplayName = null
      )
    }
    assertEquals(aliceUid, initial.id)
    assertTrue(initial.username.isNotBlank())
    assertEquals(ALICE_EMAIL, initial.email)

    // 2. Subsequent login / re-register with preferredUsername & preferredDisplayName updates profile cleanly
    val updated = withTimeout(DEFAULT_TIMEOUT_MS) {
      repo.ensureUserProfile(
        firebaseUser = fbUser,
        preferredUsername = "alice_v2",
        preferredDisplayName = "Alice V2"
      )
    }
    assertEquals("alice_v2", updated.username)
    assertEquals("Alice V2", updated.displayName)

    // 3. Presence heartbeat update on existing full profile doc succeeds
    withTimeout(DEFAULT_TIMEOUT_MS) {
      repo.updatePresenceAndTyping(presenceStatus = "DND", statusTag = "Testing", updateTyping = false)
    }

    // 4. Verify private/info doc exists and is readable by Alice
    val privateInfo = withTimeout(DEFAULT_TIMEOUT_MS) {
      repo.readPrivateInfo(aliceUid)
    }
    assertTrue("Alice should read own private/info: ${privateInfo.exceptionOrNull()}", privateInfo.isSuccess)
    assertEquals(ALICE_EMAIL, privateInfo.getOrNull()?.get("email"))
  }

  private companion object {
    const val ALICE_EMAIL = "alice_rule@test.com"
    const val BOB_EMAIL = "bob_rule@test.com"
    const val CHARLIE_EMAIL = "charlie_rule@test.com"
    const val DEFAULT_TIMEOUT_MS = 5000L
    const val FLOW_TIMEOUT_MS = 4000L
  }
}
